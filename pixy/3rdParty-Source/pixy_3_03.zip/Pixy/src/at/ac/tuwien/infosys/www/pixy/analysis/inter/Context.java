package at.ac.tuwien.infosys.www.pixy.analysis.inter;


// could also be implemented as interface;
// don't forget to override equals() and hashCode() in the
// subclasses!
public abstract class Context {

}
