package at.ac.tuwien.infosys.www.pixy.sanit;

// thrown for unsupported regexes
public class UnsupportedRegexException 
extends RuntimeException {

}
