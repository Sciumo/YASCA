<?

$phpEx = "php";

?>
