<?

// heuristic resolution:
// warning in case of impossible includes;
// also: some array fun

require_once $lang_path . $available_languages[$GLOBALS['lang']][1] . '.inc.php';


?>
