<?php

function foo() {
    return 1;
}

?>
