<?php

define('C1', $evil);

?>
