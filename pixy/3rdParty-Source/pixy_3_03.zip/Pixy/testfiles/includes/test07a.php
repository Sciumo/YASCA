<?php

$x1 = intval($evil);

?>
