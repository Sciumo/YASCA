<?php

// was a bug; requires builtin function intval

$includeMe = 'test07a.php';
include $includeMe;
echo $x1;

?>
