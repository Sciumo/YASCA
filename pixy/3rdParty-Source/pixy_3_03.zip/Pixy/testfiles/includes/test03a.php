<?php

echo $x1;
echo $x2;

?>
