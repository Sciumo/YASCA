<?

// heuristic resolution combined with literal analysis

$phpEx = '.php';
include(something_very_complicated() . '/test15a' . $phpEx);


?>
