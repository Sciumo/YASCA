<?

// easy heuristic resolution

include(dirname(__FILE__) . '/test12a.php');

?>
