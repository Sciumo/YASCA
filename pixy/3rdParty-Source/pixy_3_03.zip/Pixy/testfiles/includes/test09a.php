<?php

$x1 = 'good';

$ime2 = 'test09b.php';
include $ime2;
include 'test09c.php';

?>
