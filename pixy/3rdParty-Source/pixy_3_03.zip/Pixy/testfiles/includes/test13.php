<?

// dirname() and __FILE__

$phpEx = '.php';
include(dirname(__FILE__) . '/test13a' . $phpEx);


?>
