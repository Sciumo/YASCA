<?php

// included file has literal and non-literal includes,
// must all be handled

$ime = 'test09a.php';
include $ime;
echo $x1;
echo $x2;
echo $x3;

?>
