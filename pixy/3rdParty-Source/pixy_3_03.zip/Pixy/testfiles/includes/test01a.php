<?php

$x1 = $evil;

?>
