<?php

$x2 = 'good';

?>
