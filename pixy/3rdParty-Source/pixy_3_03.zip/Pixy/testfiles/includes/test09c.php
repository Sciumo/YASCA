<?php

$x3 = 'good';

?>
