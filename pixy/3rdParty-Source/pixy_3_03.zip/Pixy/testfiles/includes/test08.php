<?php

// was a bug; must not result in an exception

include 'test08a.php';

?>
