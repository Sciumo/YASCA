<?php

if ($u) {
    $a =& $b;
} else {
    $c =& $b;
}
~_hotspot0;     // u{} a{ (a,b) (b,c) }


?>
