<?php

if ($u) {
    $a =& $c;
    $b =& $c;
} else {
    $a =& $d;
    $b =& $d;
}
~_hotspot0;     // u{(a,b)} a{(a,c) (b,c) (a,d) (b,d)}



?>
