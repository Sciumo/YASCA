<?php

/*

this test (for literals analysis) sometimes fails (at
hotspot1, a.a1 is computed to be 1 instead of T);
when it does, compare the output with the output given below
(which is the output when the correct results are computed);

INDETERMINISM (due to some hidden implementation bug):
alias analysis sometimes doesn't realize that a1 is
a may-alias of main.x2 at hotspot0; strange: if you remove
any of the assignments inside function b, the correct
result is computed

=> test23 of literal analysis sometimes fails as well (same structure as this one)

*/


// MAY WITH GLOBALS (4)

$x1 = 1;
$x2 = 1;
a();

function a() {                  // u{ } a{ }
                                // u{ (main.x1, a.x1_gs) (main.x2, a.x2_gs) } a{ }
    $a1 = 1;
    if ($GLOBALS['u']) {
        $a1 =& $GLOBALS['x1'];  // u{ (main.x1, a.x1_gs, a.a1) (main.x2, a.x2_gs) } a{ }
    }                           // u{ (main.x1, a.x1_gs) (main.x2, a.x2_gs) } a{ (main.x1, a.a1) (main.x1_gs, a.a1) }
    if ($GLOBALS['v']) {
        $a1 =& $GLOBALS['x2'];  // u{ (main.x1, a.x1_gs) (main.x2, a.x2_gs, a.a1) } a{ }
    }                           
    ~_hotspot0;                 // u{ (main.x1, a.x1_gs) (main.x2, a.x2_gs) } a{ (main.x1, a.a1) (main.x1_gs, a.a1) (main.x2, a.a1) (main.x2_gs, a.a1)}
    b();
    ~_hotspot1;                 // (nothing has changed for alias analysis)
}

function b() {                  // u{ } a{ }
                                // u{ (main.x1, b.x1_gs) (main.x2, b.x2_gs) } a{ }
    $GLOBALS['x1'] = 1;
    $GLOBALS['x2'] = 2;
}

?>
