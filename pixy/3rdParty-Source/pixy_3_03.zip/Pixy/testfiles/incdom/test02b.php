<?

// included by test02.php

echo 'hi';
~_hotspot0;     // 1 element (includeStart)

?>
