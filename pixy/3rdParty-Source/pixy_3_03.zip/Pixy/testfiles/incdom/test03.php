<?php

// dominators must really dominate...

if ($x) {
    include 'test03b.php';
}
~_hotspot0;         // empty

?>
