<?php

// is the longest matching prefix computed correctly?

include 'test05b.php';
if ($x) {
    include 'test05c.php';
}
~_hotspot0;         // 2 elements

?>
