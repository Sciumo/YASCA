<?php

// simple one-level inclusion

include 'test02b.php';
~_hotspot1;         // 2 elements (includeStart and includeEnd)



?>
