<?

echo 'in included file';
~_hotspot0;     // 1 entry

?>
