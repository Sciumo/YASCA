<?php

// initial incdom info: empty

echo 'hi';
~_hotspot0;     // empty (no inclusion dominators here)

?>
