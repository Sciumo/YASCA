<?

// included by test03.php

echo 'hi';

?>
