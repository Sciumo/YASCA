<?

// included by test05.php

echo 'hi';

?>
