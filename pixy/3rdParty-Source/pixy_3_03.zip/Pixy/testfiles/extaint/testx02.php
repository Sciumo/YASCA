<? //

// test for pass-through builtin functions
$a = fread();
$x1 = trim($a);
//fopen($y);
~_hotspot0;     // x1:{(fread,4)}

?>
