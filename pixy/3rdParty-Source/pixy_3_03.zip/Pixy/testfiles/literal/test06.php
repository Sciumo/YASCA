<?php

// unary assignment

$x1 = 1;
$x2 = - $x1;
~_hotspot0;     // x1:1, x2:-1.0

?>
