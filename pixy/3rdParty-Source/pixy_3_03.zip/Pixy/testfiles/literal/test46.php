<?php

// was a bug: didn't consider the effect
// of the call to the unknown function
    
$x1 = 'hei';
$x1 = alskdjf();
~_hotspot0;



?>
