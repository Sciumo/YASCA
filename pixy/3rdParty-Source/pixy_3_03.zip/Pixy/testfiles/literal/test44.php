<?php

// when allowing unknown functions, their
// return value should be TOP

$x1 = 1;
$x1 = youDontKnowMe();
~_hotspot0;

?>
