<?php

// binary assignment

$x1 = 1;
$x2 = 2;
$x3 = $x1 + $x2;
~_hotspot0;         // x1:1, x2:2, x3:3.0

?>
