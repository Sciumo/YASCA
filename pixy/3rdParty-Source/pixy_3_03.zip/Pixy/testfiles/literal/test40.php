<?php

// you should terminate...

while (true) {
    $x1 = $x1 + 1;
}
~_hotspot0;     // this program point is unreachable

?>
