<?php

// was a bug once

$x1[1] = 1;
a();
~_hotspot0;     // x1[1]:1

function a() {
}

?>
