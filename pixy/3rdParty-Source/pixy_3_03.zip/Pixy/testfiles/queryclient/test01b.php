<?

echo 'in ' . 'test01b';
echo $GLOBALS['x'];

?>
