there are no JUnit test cases for these, just for informal tests
