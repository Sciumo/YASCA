<?

// was a bug that resulted in an exception

echo $x->method() . $evil;

?>
