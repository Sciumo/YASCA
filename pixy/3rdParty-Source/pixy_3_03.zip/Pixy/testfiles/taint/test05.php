<?php

// unary assignment

$x1 = 1;
$x2 = - $x1;
~_hotspot0;     // x1:U/C, x2:U/C



?>
