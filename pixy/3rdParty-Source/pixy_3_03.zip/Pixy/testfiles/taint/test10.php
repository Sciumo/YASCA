<?php

// isset

$x1;
$x2 = isset($x1);

~_hotspot0;     // x1:T/D, x2:U/C


?>
