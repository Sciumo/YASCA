<?php

// lub

if ($u) {
    $x1 = 1;
}

~_hotspot0;     // x1:T/D

$x2 = array();
if ($u) {
    $x2[1] = $evil;
}

~_hotspot1;     // x2:U/D, x2[1]:T/D

?>
