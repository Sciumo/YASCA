<?php

// default mappings (we always assume that register_globals is active)

$x1;
$x2['1'];
~_hotspot0;     // main.x1:T/F, main.x2[1]:T/F


?>
