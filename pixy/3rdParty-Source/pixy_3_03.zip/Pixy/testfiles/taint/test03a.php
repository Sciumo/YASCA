<?php

// array()

$x1 = array();
$x1[1];
~_hotspot0;     // x1:U/C, x1[1]:U/C

?>
