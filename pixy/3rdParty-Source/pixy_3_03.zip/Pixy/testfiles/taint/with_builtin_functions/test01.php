<?php

// builtin functions file

~_hotspot0;     // x1:T/D
$x1 = htmlspecialchars($evil);
~_hotspot1;     // x1:U/C



?>


