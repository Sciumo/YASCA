<? //

// assignArray

$a = array();
echo $a;



?>
