<? //

// abbreviated binary assignment

$a = 7;
$b = $get;
$a += $b;
echo($a);




?>
