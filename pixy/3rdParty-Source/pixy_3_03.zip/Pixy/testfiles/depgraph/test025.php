<? //

// return values

$a = foo();
echo $a;
function foo() {
    $x = 'hi';
    return $x;
}



?>
