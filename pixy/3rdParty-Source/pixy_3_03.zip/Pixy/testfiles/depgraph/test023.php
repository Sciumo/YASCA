<? //

// actual params -> formal params

$a = $get;
foo($a);
function foo($x) {
    echo $x;
}

?>
