<? //

// concatenation (simplest)


$x = $a . $b;
echo($x);



?>
