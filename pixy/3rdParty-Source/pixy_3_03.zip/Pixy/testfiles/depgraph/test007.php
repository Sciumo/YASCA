<? //

// concatenation (mixed)

$a = $_GET['x'];
$x = $a . $b;
echo($x);



?>
