<? //

// was a bug

if ($x) {
    exit;
}

$x = 1;
echo $evil;



?>
