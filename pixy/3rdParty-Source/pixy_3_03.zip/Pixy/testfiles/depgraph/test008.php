<? //


// concatenation (multi-element)


$x = $a . $b . $c;
echo($x);





?>
