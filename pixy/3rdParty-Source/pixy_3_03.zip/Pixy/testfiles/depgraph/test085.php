<? //

// a called method is defined in an included file (was a bug)

include 'test085b.php';
$foo->bar($evil, 'ok');


?>
