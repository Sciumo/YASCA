<? //


// while loop leading to a loop in the dep graph



do {
    $a = $b;
    $b = $a;
    echo($a);
} while ($rand)



?>
