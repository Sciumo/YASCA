<? //

// this class definition is included by another file

class MyClass {

    function bar($p1, $p2) {
        echo $_GET['x'];
        echo $p1;
        echo $p2;
    }
    
}

?>
