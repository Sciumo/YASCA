<? //

// "global" (3)

foo();
function foo() {
    global $a;
    echo $a;
}



?>
