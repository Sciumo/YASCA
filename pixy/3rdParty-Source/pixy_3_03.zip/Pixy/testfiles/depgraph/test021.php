<? //

// unset

$a = 7;
unset($a);
echo $a;


?>
