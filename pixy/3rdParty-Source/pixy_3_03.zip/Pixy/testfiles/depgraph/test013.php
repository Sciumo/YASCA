<? //

// array-aware dep graph construction 


$a[1] = 7;
$b = $a;
echo($b[1]);


?>
