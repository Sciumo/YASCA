<? //


// control flow merges


$a = socket_read();
$b = fread();
if ($rand) {
    $x = $a;
} else if ($rand2) {
    $x = $b;
}
echo($x);



?>
