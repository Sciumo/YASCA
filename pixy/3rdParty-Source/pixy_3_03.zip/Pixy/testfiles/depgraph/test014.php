<? //


// unary assignment


$b = $get;
$a = -$b;
echo $a;


?>
