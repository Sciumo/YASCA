<?php

// transitive case

$a = $_GET['x'];
$b = $a;
echo $b;


?>
