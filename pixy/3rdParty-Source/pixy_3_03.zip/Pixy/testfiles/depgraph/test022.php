<? //

// very simple function example 


foo();
function foo() {
    $x = 7;
    echo $x;
}



?>
