<? //



    
$a;
$b = $a;
$c = some_builtin_function(); 
$d = trim($b);               
echo $c;
echo $d;



?>
