<? //

// constants definition


define("MYCONST", "hi");
echo MYCONST;


?>
