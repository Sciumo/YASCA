<? //

if ($x) {
    exit;
}





?>
