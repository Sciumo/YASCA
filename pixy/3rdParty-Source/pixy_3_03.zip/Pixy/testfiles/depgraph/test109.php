<? //

// was a bug

$inc = 'test109b.php';
include($inc);

echo $evil;




?>
