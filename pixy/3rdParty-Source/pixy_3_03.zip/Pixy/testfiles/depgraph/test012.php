<? //


// simple test for "array case 3"


$a[1] = 7;
echo($a[1]);



?>
