<? //

// default params

$a = $get;
foo($a);
function foo($x, $y = 7) {
    echo $y;
}


?>
