<? //


// simple while loop, without a loop in the resulting
// dep graph



$x = $get;
while ($rand) {
    $x = $get2;
}
echo $x;



?>
