<? //


// binary assignment


$a = 7;
$b = $get;
$c = $a + $b;
echo($c);



?>
