<? //


// nice usability example:
// see what happens if you remove the "else" branch
// (i.e., compare the two examples)


$x = 7;
if ($rand) {
    $x = $get1;
} else {
    $x = 99;
}
echo $x;

$y = 7;
if ($rand) {
    $y = $get1;
}
echo $y;




?>
