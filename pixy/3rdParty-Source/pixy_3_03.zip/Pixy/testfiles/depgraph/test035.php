<? //

// multiple sinks

$a = $_GET['x'];
$b = $_GET['y'];
echo($a); 
echo($b);




?>
