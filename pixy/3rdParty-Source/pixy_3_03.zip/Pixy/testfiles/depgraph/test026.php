<? //

// VERY NICE EXAMPLE:
// combination parameters / return values


$b = $get;
$a = foo($b);
echo $a;
function foo($x) {
    $x = $x . 'hi';
    return $x;
}



?>
