/* IMPLEMENTATION MODULE Exceptions */
#define M2_IMPORT_Exceptions

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/* 10*/ int Exceptions_try_block_nesting_level = 0;
/* 15*/ ARRAY * Exceptions_exceptions = NULL;

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

void Exceptions_0err_entry_get(int i, char **m, char **f, int *l);

/* 10*/ int
/* 10*/ Exceptions_IsExceptionClass(RECORD *Exceptions_c)
/* 10*/ {
/* 12*/ 	RECORD * Exceptions_t = NULL;
/* 12*/ 	Exceptions_t = Exceptions_c;
/* 13*/ 	while( Exceptions_t != NULL ){
/* 14*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_t, 8, Exceptions_0err_entry_get, 0), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Exception") == 0 ){
/* 15*/ 			return TRUE;
/* 17*/ 		}
/* 17*/ 		Exceptions_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Exceptions_t, 16, Exceptions_0err_entry_get, 1);
/* 19*/ 	}
/* 19*/ 	return FALSE;
/* 23*/ }


/* 25*/ void
/* 25*/ Exceptions_AddExceptionToList(RECORD *Exceptions_exception, ARRAY **Exceptions_exceptions)
/* 25*/ {
/* 27*/ 	int Exceptions_i = 0;
/* 27*/ 	{
/* 27*/ 		int m2runtime_for_limit_1;
/* 27*/ 		Exceptions_i = 0;
/* 27*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_exceptions) - 1);
/* 28*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/* 28*/ 			if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_exceptions, Exceptions_i, Exceptions_0err_entry_get, 2) == Exceptions_exception ){
/* 30*/ 				return ;
/* 32*/ 			}
/* 32*/ 		}
/* 32*/ 	}
/* 32*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(Exceptions_exceptions, 4, 1, Exceptions_0err_entry_get, 3) = Exceptions_exception;
/* 36*/ }


/* 38*/ void
/* 38*/ Exceptions_AddException(RECORD *Exceptions_exception)
/* 38*/ {
/* 38*/ 	if( (Exceptions_try_block_nesting_level == 0) ){
/* 39*/ 		if( Globals_curr_func != NULL ){
/* 40*/ 			Exceptions_AddExceptionToList(Exceptions_exception, (ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 64, 10, 32, Exceptions_0err_entry_get, 4));
/* 41*/ 		} else if( Globals_curr_method != NULL ){
/* 42*/ 			Exceptions_AddExceptionToList(Exceptions_exception, (ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 76, 9, 28, Exceptions_0err_entry_get, 5));
/* 45*/ 		}
/* 45*/ 	} else {
/* 45*/ 		Exceptions_AddExceptionToList(Exceptions_exception, &Exceptions_exceptions);
/* 48*/ 	}
/* 50*/ }


/* 52*/ void
/* 52*/ Exceptions_ThrowException(RECORD *Exceptions_exception)
/* 52*/ {
/* 52*/ 	Exceptions_AddException(Exceptions_exception);
/* 53*/ 	if( (Exceptions_try_block_nesting_level == 0) ){
/* 54*/ 		if( Globals_curr_func != NULL ){
/* 55*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 6), 1));
/* 56*/ 		} else if( Globals_curr_method != NULL ){
/* 57*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 7), 1));
/* 59*/ 		} else {
/* 59*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"uncought exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 8), 1));
/* 62*/ 		}
/* 62*/ 	} else {
/* 62*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"here generating exception ", (STRING *)m2runtime_dereference_rhs_RECORD(Exceptions_exception, 8, Exceptions_0err_entry_get, 9), 1));
/* 65*/ 	}
/* 67*/ }


/* 68*/ void
/* 68*/ Exceptions_ThrowExceptions(ARRAY *Exceptions_exceptions)
/* 68*/ {
/* 70*/ 	int Exceptions_i = 0;
/* 70*/ 	{
/* 70*/ 		int m2runtime_for_limit_1;
/* 70*/ 		Exceptions_i = 0;
/* 70*/ 		m2runtime_for_limit_1 = (m2runtime_count(Exceptions_exceptions) - 1);
/* 71*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/* 71*/ 			Exceptions_ThrowException((RECORD *)m2runtime_dereference_rhs_ARRAY(Exceptions_exceptions, Exceptions_i, Exceptions_0err_entry_get, 10));
/* 74*/ 		}
/* 74*/ 	}
/* 76*/ }


/* 78*/ void
/* 78*/ Exceptions_AddPdbExceptions(ARRAY *Exceptions_exceptions)
/* 78*/ {
/* 79*/ 	int Exceptions_i = 0;
/* 80*/ 	STRING * Exceptions_name = NULL;
/* 82*/ 	RECORD * Exceptions_exception = NULL;
/* 82*/ 	{
/* 82*/ 		int m2runtime_for_limit_1;
/* 82*/ 		Exceptions_i = 0;
/* 82*/ 		m2runtime_for_limit_1 = (m2runtime_count(Exceptions_exceptions) - 1);
/* 83*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/* 83*/ 			Exceptions_name = (STRING *)m2runtime_dereference_rhs_ARRAY(Exceptions_exceptions, Exceptions_i, Exceptions_0err_entry_get, 11);
/* 84*/ 			Exceptions_exception = Search_SearchClass(Exceptions_name, TRUE);
/* 85*/ 			if( Exceptions_exception == NULL ){
/* 86*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown exception `", Exceptions_name, m2runtime_CHR(39), 1));
/* 87*/ 			} else if( !Exceptions_IsExceptionClass(Exceptions_exception) ){
/* 88*/ 				Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Exceptions_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' is not an exception", 1));
/* 90*/ 			} else {
/* 90*/ 				Exceptions_AddException(Exceptions_exception);
/* 93*/ 			}
/* 94*/ 		}
/* 94*/ 	}
/* 96*/ }


/* 98*/ void
/* 98*/ Exceptions_ParseThrows(void)
/* 98*/ {
/*100*/ 	RECORD * Exceptions_exception = NULL;
/*100*/ 	Scanner_ReadSym();
/*101*/ 	Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected exception name");
/*103*/ 	do{
/*103*/ 		Exceptions_exception = Search_SearchClass(Scanner_s, TRUE);
/*104*/ 		if( Exceptions_exception == NULL ){
/*105*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown exception `", Scanner_s, m2runtime_CHR(39), 1));
/*106*/ 		} else if( !Exceptions_IsExceptionClass(Exceptions_exception) ){
/*107*/ 			Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' is not an exception", 1));
/*109*/ 		} else {
/*109*/ 			Exceptions_AddException(Exceptions_exception);
/*111*/ 		}
/*111*/ 		Scanner_ReadSym();
/*112*/ 		if( (Scanner_sym == 131) ){
/*113*/ 			Scanner_ReadSym();
/*116*/ 		} else {
/*117*/ 			goto m2runtime_loop_1;
/*118*/ 		}
/*119*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*121*/ }


/*124*/ int
/*124*/ Exceptions_RemoveExceptionFromSet(RECORD *Exceptions_caught_exception, ARRAY **Exceptions_thrown_exceptions)
/*124*/ {
/*125*/ 	int Exceptions_i = 0;
/*126*/ 	int Exceptions_found = 0;
/*128*/ 	ARRAY * Exceptions_shorter = NULL;
/*128*/ 	{
/*128*/ 		int m2runtime_for_limit_1;
/*128*/ 		Exceptions_i = 0;
/*128*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_thrown_exceptions) - 1);
/*129*/ 		for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/*129*/ 			if( (((RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 12) != NULL) && Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 13), Exceptions_caught_exception)) ){
/*131*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY(Exceptions_thrown_exceptions, 4, 1, Exceptions_i, Exceptions_0err_entry_get, 14) = NULL;
/*132*/ 				Exceptions_found = TRUE;
/*135*/ 			}
/*136*/ 		}
/*136*/ 	}
/*136*/ 	if( Exceptions_found ){
/*137*/ 		{
/*137*/ 			int m2runtime_for_limit_1;
/*137*/ 			Exceptions_i = 0;
/*137*/ 			m2runtime_for_limit_1 = (m2runtime_count(*Exceptions_thrown_exceptions) - 1);
/*138*/ 			for( ; Exceptions_i <= m2runtime_for_limit_1; Exceptions_i += 1 ){
/*138*/ 				if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 15) != NULL ){
/*139*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Exceptions_shorter, 4, 1, Exceptions_0err_entry_get, 16) = (RECORD *)m2runtime_dereference_rhs_ARRAY(*Exceptions_thrown_exceptions, Exceptions_i, Exceptions_0err_entry_get, 17);
/*142*/ 				}
/*142*/ 			}
/*142*/ 		}
/*142*/ 		*Exceptions_thrown_exceptions = Exceptions_shorter;
/*145*/ 	}
/*145*/ 	return Exceptions_found;
/*150*/ }


char * Exceptions_0func[] = {
    "IsExceptionClass",
    "AddExceptionToList",
    "AddException",
    "ThrowException",
    "ThrowExceptions",
    "AddPdbExceptions",
    "RemoveExceptionFromSet"
};

int Exceptions_0err_entry[] = {
    0 /* IsExceptionClass */, 14,
    0 /* IsExceptionClass */, 17,
    1 /* AddExceptionToList */, 28,
    1 /* AddExceptionToList */, 32,
    2 /* AddException */, 41,
    2 /* AddException */, 43,
    3 /* ThrowException */, 55,
    3 /* ThrowException */, 57,
    3 /* ThrowException */, 59,
    3 /* ThrowException */, 62,
    4 /* ThrowExceptions */, 71,
    5 /* AddPdbExceptions */, 84,
    6 /* RemoveExceptionFromSet */, 129,
    6 /* RemoveExceptionFromSet */, 130,
    6 /* RemoveExceptionFromSet */, 131,
    6 /* RemoveExceptionFromSet */, 138,
    6 /* RemoveExceptionFromSet */, 139,
    6 /* RemoveExceptionFromSet */, 140
};

void Exceptions_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Exceptions";
    *f = Exceptions_0func[ Exceptions_0err_entry[2*i] ];
    *l = Exceptions_0err_entry[2*i + 1];
}
