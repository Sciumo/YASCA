/* IMPLEMENTATION MODULE FileName */
#define M2_IMPORT_FileName

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void FileName_0err_entry_get(int i, char **m, char **f, int *l);

/* 32*/ STRING *
/* 32*/ FileName_Normalize(STRING *FileName_f)
/* 32*/ {
/* 33*/ 	ARRAY * FileName_b = NULL;
/* 33*/ 	ARRAY * FileName_a = NULL;
/* 34*/ 	int FileName_j = 0;
/* 34*/ 	int FileName_i = 0;
/* 35*/ 	STRING * FileName_w = NULL;
/* 37*/ 	int FileName_abs = 0;
/* 37*/ 	if( m2runtime_strcmp(FileName_f, EMPTY_STRING) <= 0 ){
/* 38*/ 		m2runtime_HALT(FileName_0err_entry_get, 0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"path is NIL or empty");
/* 40*/ 	}
/* 40*/ 	FileName_a = str_split(FileName_f, m2runtime_CHR(47));
/* 41*/ 	FileName_j = 0;
/* 42*/ 	{
/* 42*/ 		int m2runtime_for_limit_1;
/* 42*/ 		FileName_i = 0;
/* 42*/ 		m2runtime_for_limit_1 = (m2runtime_count(FileName_a) - 1);
/* 43*/ 		for( ; FileName_i <= m2runtime_for_limit_1; FileName_i += 1 ){
/* 43*/ 			FileName_w = (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_a, FileName_i, FileName_0err_entry_get, 1);
/* 44*/ 			if( m2runtime_strcmp(FileName_w, EMPTY_STRING) == 0 ){
/* 45*/ 				if( (FileName_i == 0) ){
/* 47*/ 					FileName_abs = TRUE;
/* 49*/ 				}
/* 49*/ 			} else if( m2runtime_strcmp(FileName_w, m2runtime_CHR(46)) == 0 ){
/* 51*/ 			} else if( m2runtime_strcmp(FileName_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..") == 0 ){
/* 52*/ 				if( (FileName_j == 0) ){
/* 53*/ 					if( FileName_abs ){
/* 56*/ 					} else {
/* 56*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, 0, FileName_0err_entry_get, 2) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..";
/* 57*/ 						FileName_j = 1;
/* 59*/ 					}
/* 59*/ 				} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, (FileName_j - 1), FileName_0err_entry_get, 3), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..") == 0 ){
/* 60*/ 					*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, FileName_j, FileName_0err_entry_get, 4) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..";
/* 61*/ 					FileName_j = (FileName_j + 1);
/* 64*/ 				} else {
/* 64*/ 					FileName_j = (FileName_j - 1);
/* 66*/ 				}
/* 67*/ 			} else {
/* 67*/ 				*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, FileName_j, FileName_0err_entry_get, 5) = FileName_w;
/* 68*/ 				FileName_j = (FileName_j + 1);
/* 71*/ 			}
/* 71*/ 		}
/* 71*/ 	}
/* 71*/ 	if( (FileName_j == 0) ){
/* 72*/ 		if( FileName_abs ){
/* 73*/ 			return m2runtime_CHR(47);
/* 75*/ 		} else {
/* 75*/ 			return m2runtime_CHR(46);
/* 78*/ 		}
/* 78*/ 	} else {
/* 78*/ 		if( FileName_abs ){
/* 79*/ 			FileName_f = m2runtime_concat_STRING(0, m2runtime_CHR(47), (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, 0, FileName_0err_entry_get, 6), 1);
/* 81*/ 		} else {
/* 81*/ 			FileName_f = (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, 0, FileName_0err_entry_get, 7);
/* 83*/ 		}
/* 83*/ 		{
/* 83*/ 			int m2runtime_for_limit_1;
/* 83*/ 			FileName_i = 1;
/* 83*/ 			m2runtime_for_limit_1 = (FileName_j - 1);
/* 84*/ 			for( ; FileName_i <= m2runtime_for_limit_1; FileName_i += 1 ){
/* 84*/ 				FileName_f = m2runtime_concat_STRING(0, FileName_f, m2runtime_CHR(47), (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, FileName_i, FileName_0err_entry_get, 8), 1);
/* 87*/ 			}
/* 87*/ 		}
/* 87*/ 	}
/* 87*/ 	return FileName_f;
/* 91*/ }


/* 92*/ STRING *
/* 92*/ FileName_Dirname(STRING *FileName_f)
/* 92*/ {
/* 94*/ 	int FileName_i = 0;
/* 94*/ 	{
/* 94*/ 		int m2runtime_for_limit_1;
/* 94*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/* 94*/ 		m2runtime_for_limit_1 = 0;
/* 95*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/* 95*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 9), m2runtime_CHR(47)) == 0 ){
/* 96*/ 				if( (FileName_i == 0) ){
/* 97*/ 					return m2runtime_CHR(47);
/* 99*/ 				} else {
/* 99*/ 					return m2runtime_substr(FileName_f, 0, FileName_i, 1, FileName_0err_entry_get, 10);
/*102*/ 				}
/*103*/ 			}
/*103*/ 		}
/*103*/ 	}
/*103*/ 	return m2runtime_CHR(46);
/*107*/ }


/*108*/ STRING *
/*108*/ FileName_Basename(STRING *FileName_f)
/*108*/ {
/*110*/ 	int FileName_i = 0;
/*110*/ 	if( m2runtime_strcmp(FileName_f, m2runtime_CHR(47)) == 0 ){
/*111*/ 		return m2runtime_CHR(47);
/*113*/ 	}
/*113*/ 	{
/*113*/ 		int m2runtime_for_limit_1;
/*113*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/*113*/ 		m2runtime_for_limit_1 = 0;
/*114*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/*114*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 11), m2runtime_CHR(47)) == 0 ){
/*115*/ 				return m2runtime_substr(FileName_f, (FileName_i + 1), m2runtime_length(FileName_f), 1, FileName_0err_entry_get, 12);
/*118*/ 			}
/*118*/ 		}
/*118*/ 	}
/*118*/ 	return FileName_f;
/*122*/ }


/*128*/ STRING *
/*128*/ FileName_Absolute(STRING *FileName_cwd, STRING *FileName_f)
/*128*/ {
/*128*/ 	if( m2runtime_strcmp(FileName_f, EMPTY_STRING) <= 0 ){
/*129*/ 		m2runtime_HALT(FileName_0err_entry_get, 13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"empty path");
/*132*/ 	}
/*132*/ 	if( m2runtime_strcmp(m2runtime_substr(FileName_f, 0, 0, 0, FileName_0err_entry_get, 14), m2runtime_CHR(47)) == 0 ){
/*133*/ 		return FileName_Normalize(FileName_f);
/*136*/ 	}
/*136*/ 	if( FileName_cwd == NULL ){
/*137*/ 		m2runtime_ERROR_CODE = 0;
/*137*/ 		FileName_cwd = io_GetCWD(1);
/*138*/ 		switch( m2runtime_ERROR_CODE ){

/*138*/ 		case 0:  break;
/*138*/ 		default:
/*138*/ 			m2runtime_HALT(FileName_0err_entry_get, 15, m2runtime_ERROR_MESSAGE);
/*139*/ 		}
/*140*/ 	}
/*140*/ 	return FileName_Normalize(m2runtime_concat_STRING(0, FileName_cwd, m2runtime_CHR(47), FileName_f, 1));
/*144*/ }


/*146*/ STRING *
/*146*/ FileName_Relative(STRING *FileName_a, STRING *FileName_b)
/*146*/ {
/*147*/ 	int FileName_j = 0;
/*147*/ 	int FileName_i = 0;
/*149*/ 	STRING * FileName_c = NULL;
/*151*/ 	FileName_j = -1;
/*152*/ 	FileName_i = 0;
/*154*/ 	do{
/*154*/ 		if( (FileName_i == m2runtime_length(FileName_a)) ){
/*155*/ 			if( (((FileName_i == m2runtime_length(FileName_b))) || (m2runtime_strcmp(m2runtime_substr(FileName_b, FileName_i, 0, 0, FileName_0err_entry_get, 16), m2runtime_CHR(47)) == 0)) ){
/*156*/ 				FileName_j = FileName_i;
/*159*/ 			}
/*159*/ 			goto m2runtime_loop_1;
/*159*/ 		} else if( (FileName_i == m2runtime_length(FileName_b)) ){
/*160*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 17), m2runtime_CHR(47)) == 0 ){
/*161*/ 				FileName_j = FileName_i;
/*164*/ 			}
/*164*/ 			goto m2runtime_loop_1;
/*164*/ 		} else if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 18), m2runtime_substr(FileName_b, FileName_i, 0, 0, FileName_0err_entry_get, 19)) == 0 ){
/*165*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 20), m2runtime_CHR(47)) == 0 ){
/*166*/ 				FileName_j = FileName_i;
/*168*/ 			}
/*168*/ 			m2_inc(&FileName_i, 1);
/*171*/ 		} else {
/*172*/ 			goto m2runtime_loop_1;
/*173*/ 		}
/*173*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*173*/ 	if( (FileName_j == -1) ){
/*174*/ 		return FileName_b;
/*176*/ 	}
/*176*/ 	if( (FileName_j == m2runtime_length(FileName_b)) ){
/*177*/ 		return FileName_Basename(FileName_b);
/*181*/ 	}
/*181*/ 	FileName_i = (FileName_j + 1);
/*182*/ 	FileName_c = EMPTY_STRING;
/*183*/ 	while( (FileName_i < m2runtime_length(FileName_a)) ){
/*184*/ 		if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 21), m2runtime_CHR(47)) == 0 ){
/*185*/ 			FileName_c = m2runtime_concat_STRING(0, FileName_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"../", 1);
/*187*/ 		}
/*187*/ 		m2_inc(&FileName_i, 1);
/*190*/ 	}
/*190*/ 	return m2runtime_concat_STRING(0, FileName_c, m2runtime_substr(FileName_b, (FileName_j + 1), m2runtime_length(FileName_b), 1, FileName_0err_entry_get, 22), 1);
/*194*/ }


/*195*/ STRING *
/*195*/ FileName_DropExtension(STRING *FileName_f)
/*195*/ {
/*197*/ 	int FileName_i = 0;
/*197*/ 	{
/*197*/ 		int m2runtime_for_limit_1;
/*197*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/*197*/ 		m2runtime_for_limit_1 = 0;
/*198*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/*198*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 23), m2runtime_CHR(46)) == 0 ){
/*199*/ 				return m2runtime_substr(FileName_f, 0, FileName_i, 1, FileName_0err_entry_get, 24);
/*200*/ 			} else if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 25), m2runtime_CHR(47)) == 0 ){
/*201*/ 				return FileName_f;
/*204*/ 			}
/*204*/ 		}
/*204*/ 	}
/*204*/ 	return FileName_f;
/*208*/ }


char * FileName_0func[] = {
    "Normalize",
    "Dirname",
    "Basename",
    "Absolute",
    "Relative",
    "DropExtension"
};

int FileName_0err_entry[] = {
    0 /* Normalize */, 38,
    0 /* Normalize */, 44,
    0 /* Normalize */, 56,
    0 /* Normalize */, 59,
    0 /* Normalize */, 60,
    0 /* Normalize */, 67,
    0 /* Normalize */, 80,
    0 /* Normalize */, 82,
    0 /* Normalize */, 85,
    1 /* Dirname */, 95,
    1 /* Dirname */, 99,
    2 /* Basename */, 114,
    2 /* Basename */, 115,
    3 /* Absolute */, 129,
    3 /* Absolute */, 132,
    3 /* Absolute */, 137,
    4 /* Relative */, 155,
    4 /* Relative */, 160,
    4 /* Relative */, 164,
    4 /* Relative */, 164,
    4 /* Relative */, 165,
    4 /* Relative */, 184,
    4 /* Relative */, 190,
    5 /* DropExtension */, 198,
    5 /* DropExtension */, 199,
    5 /* DropExtension */, 200
};

void FileName_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "FileName";
    *f = FileName_0func[ FileName_0err_entry[2*i] ];
    *l = FileName_0err_entry[2*i + 1];
}
