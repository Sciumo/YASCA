/* IMPLEMENTATION MODULE Proto */
#define M2_IMPORT_Proto

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_Exceptions
#    include "Exceptions.c"
#endif

#ifndef M2_IMPORT_Expressions
#    include "Expressions.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

void Proto_0err_entry_get(int i, char **m, char **f, int *l);

/* 15*/ void
/* 15*/ Proto_ParseArgsListDecl(RECORD *Proto_sign, STRING *Proto_function_or_method)
/* 15*/ {
/* 16*/ 	RECORD * Proto_a = NULL;
/* 17*/ 	RECORD * Proto_v = NULL;
/* 19*/ 	int Proto_opt_arg = 0;
/* 19*/ 	Scanner_Expect(153, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected '(' in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/* 20*/ 	Scanner_ReadSym();
/* 23*/ 	do{
/* 23*/ 		if( (Scanner_sym == 154) ){
/* 26*/ 			goto m2runtime_loop_1;
/* 27*/ 		}
/* 27*/ 		if( (Scanner_sym == 152) ){
/* 28*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 24, Proto_0err_entry_get, 0) = TRUE;
/* 29*/ 			Scanner_ReadSym();
/* 32*/ 			goto m2runtime_loop_1;
/* 36*/ 		}
/* 36*/ 		Proto_a = NULL;
/* 37*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 12, Proto_0err_entry_get, 1) = Expressions_ParseType(FALSE);
/* 38*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 2) == NULL ){
/* 39*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"missing type of the argument");
/* 40*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 12, Proto_0err_entry_get, 3) = Globals_mixed_type;
/* 41*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 4) == Globals_void_type ){
/* 42*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"argument of type `void' not allowed");
/* 48*/ 		}
/* 48*/ 		if( (Scanner_sym == 151) ){
/* 49*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 20, Proto_0err_entry_get, 5) = TRUE;
/* 50*/ 			Scanner_ReadSym();
/* 56*/ 		}
/* 56*/ 		Scanner_Expect(150, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected name of the formal argument in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/* 58*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_a, 24, 3, 8, Proto_0err_entry_get, 6) = Scanner_s;
/* 63*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/* 64*/ 		Proto_v = Search_SearchVar(Scanner_s, Globals_scope);
/* 65*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 48, Proto_0err_entry_get, 7) = 100;
/* 66*/ 		Scanner_ReadSym();
/* 71*/ 		if( (Scanner_sym == 132) ){
/* 72*/ 			if( (((Globals_php_ver == 4)) &&  *(int *)m2runtime_dereference_rhs_RECORD(Proto_a, 20, Proto_0err_entry_get, 8)) ){
/* 73*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\111,\0,\0,\0)"can't assign default value to formal argument passed by reference (PHP 5)");
/* 75*/ 			}
/* 75*/ 			Proto_opt_arg = TRUE;
/* 76*/ 			Scanner_ReadSym();
/* 77*/ 		} else if( Proto_opt_arg ){
/* 78*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing default value for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_a, 8, Proto_0err_entry_get, 9), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"'. Hint: mandatory arguments can't follow the default ones.", 1));
/* 81*/ 		}
/* 81*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 20, Proto_0err_entry_get, 10) = (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_a, 12, Proto_0err_entry_get, 11);
/* 82*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_v, 52, 7, 24, Proto_0err_entry_get, 12) = NULL;
/* 83*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 12, Proto_0err_entry_get, 13), 4, 1, Proto_0err_entry_get, 14) = Proto_a;
/* 84*/ 		if( !Proto_opt_arg ){
/* 85*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 20, Proto_0err_entry_get, 15), 1);
/* 88*/ 		}
/* 88*/ 		if( (Scanner_sym == 131) ){
/* 89*/ 			Scanner_ReadSym();
/* 90*/ 			if( (Scanner_sym == 152) ){
/* 91*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 24, Proto_0err_entry_get, 16) = TRUE;
/* 92*/ 				Scanner_ReadSym();
/* 95*/ 				goto m2runtime_loop_1;
/* 97*/ 			}
/* 98*/ 		} else {
/*100*/ 			goto m2runtime_loop_1;
/*101*/ 		}
/*101*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*101*/ 	Scanner_Expect(154, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected ')' or ',' in ", Proto_function_or_method, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*103*/ 	Scanner_ReadSym();
/*107*/ }


/*109*/ void
/*109*/ Proto_ForwFuncDecl(int Proto_private, RECORD *Proto_t)
/*109*/ {
/*110*/ 	RECORD * Proto_sign = NULL;
/*112*/ 	RECORD * Proto_parent_func = NULL;
/*112*/ 	RECORD * Proto_f = NULL;
/*113*/ 	if( Proto_t == NULL ){
/*114*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"missing or invalid return type in function prototype");
/*116*/ 	}
/*116*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 17) = Proto_t;
/*117*/ 	Scanner_ReadSym();
/*119*/ 	if( (Scanner_sym == 151) ){
/*120*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 16, Proto_0err_entry_get, 18) = TRUE;
/*121*/ 		if( (Globals_php_ver == 5) ){
/*122*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*124*/ 		}
/*124*/ 		Scanner_ReadSym();
/*131*/ 	}
/*131*/ 	Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected function name after `function'");
/*132*/ 	Proto_f = Search_SearchFunc(Scanner_s, FALSE);
/*133*/ 	if( Proto_f == NULL ){
/*134*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 8, Proto_0err_entry_get, 19) = Scanner_s;
/*135*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 12, Proto_0err_entry_get, 20) = str_toupper(Scanner_s);
/*136*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 48, Proto_0err_entry_get, 21) = TRUE;
/*137*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 52, Proto_0err_entry_get, 22) = Proto_private;
/*138*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 16, Proto_0err_entry_get, 23) = Scanner_here();
/*139*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 56, Proto_0err_entry_get, 24) = 0;
/*140*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 24, Proto_0err_entry_get, 25) = NULL;
/*141*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_f, 64, 10, 28, Proto_0err_entry_get, 26) = Proto_sign;
/*142*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_funcs, 4, 1, Proto_0err_entry_get, 27) = Proto_f;
/*144*/ 	} else {
/*144*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_f, 16, Proto_0err_entry_get, 28)), 1));
/*146*/ 	}
/*146*/ 	Proto_parent_func = Globals_curr_func;
/*147*/ 	Globals_curr_func = Proto_f;
/*148*/ 	m2_inc(&Globals_scope, 1);
/*149*/ 	Scanner_ReadSym();
/*154*/ 	Proto_ParseArgsListDecl(Proto_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function");
/*160*/ 	if( (Scanner_sym == 173) ){
/*161*/ 		Exceptions_ParseThrows();
/*164*/ 	}
/*164*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"expected `;' after function prototype");
/*165*/ 	Scanner_ReadSym();
/*167*/ 	Expressions_CleanCurrentScope();
/*168*/ 	m2_inc(&Globals_scope, -1);
/*169*/ 	Globals_curr_func = Proto_parent_func;
/*187*/ }


/*190*/ void
/*190*/ Proto_ParseMethodProto(int Proto_visibility, int Proto_abstract, int Proto_final, int Proto_static, RECORD *Proto_t)
/*190*/ {
/*191*/ 	RECORD * Proto_old_m = NULL;
/*191*/ 	RECORD * Proto_m = NULL;
/*192*/ 	int Proto_i = 0;
/*193*/ 	RECORD * Proto_sign = NULL;
/*194*/ 	RECORD * Proto_this = NULL;
/*195*/ 	int Proto_guess = 0;
/*231*/ 	int Proto_is_destructor = 0;
/*231*/ 	int Proto_is_constructor = 0;
/*234*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 76, Proto_0err_entry_get, 29) ){
/*235*/ 		Proto_abstract = TRUE;
/*236*/ 		if( (Proto_visibility != 2) ){
/*237*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"interface methods must be `public'");
/*238*/ 			Proto_visibility = 2;
/*240*/ 		}
/*240*/ 		if( Proto_final ){
/*241*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"interface methods cannot be `final'");
/*242*/ 			Proto_final = FALSE;
/*245*/ 		}
/*245*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 72, Proto_0err_entry_get, 30) ){
/*246*/ 		if( Proto_abstract ){
/*247*/ 			if( (Proto_visibility == 0) ){
/*248*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"abstract methods cannot be `private'");
/*249*/ 				Proto_visibility = 1;
/*251*/ 			}
/*251*/ 			if( Proto_static ){
/*252*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"abstract methods cannot be static");
/*253*/ 				Proto_static = FALSE;
/*255*/ 			}
/*255*/ 			if( Proto_final ){
/*256*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"abstract methods cannot be `final'");
/*257*/ 				Proto_final = FALSE;
/*260*/ 			}
/*260*/ 		} else {
/*260*/ 			if( (Proto_final && ((Proto_visibility == 0))) ){
/*261*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*262*/ 				Proto_final = FALSE;
/*265*/ 			}
/*266*/ 		}
/*267*/ 	} else {
/*267*/ 		if( Proto_abstract ){
/*268*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*269*/ 			Proto_abstract = FALSE;
/*271*/ 		}
/*271*/ 		if( (Proto_final && ((Proto_visibility == 0))) ){
/*272*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*273*/ 			Proto_final = FALSE;
/*277*/ 		}
/*278*/ 	}
/*278*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 44, Proto_0err_entry_get, 31) = TRUE;
/*279*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 48, Proto_0err_entry_get, 32) = Proto_abstract;
/*280*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 52, Proto_0err_entry_get, 33) = Proto_visibility;
/*281*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 56, Proto_0err_entry_get, 34) = Proto_static;
/*282*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 60, Proto_0err_entry_get, 35) = Proto_final;
/*284*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 36) = Proto_t;
/*285*/ 	if( Proto_t == NULL ){
/*286*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\130,\0,\0,\0)"missing return type in method prototype -- assuming `void' and trying to continue anyway");
/*287*/ 		Proto_guess = TRUE;
/*288*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 37) = Globals_void_type;
/*291*/ 	}
/*291*/ 	Scanner_ReadSym();
/*296*/ 	if( (Scanner_sym == 151) ){
/*297*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 16, Proto_0err_entry_get, 38) = TRUE;
/*298*/ 		if( (Globals_php_ver == 5) ){
/*299*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*301*/ 		}
/*301*/ 		Scanner_ReadSym();
/*307*/ 	}
/*307*/ 	Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method name");
/*308*/ 	Proto_old_m = Search_SearchClassMethod(Globals_curr_class, Scanner_s, FALSE);
/*309*/ 	if( Proto_old_m != NULL ){
/*310*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Proto_old_m, 20, Proto_0err_entry_get, 39) != NULL ){
/*311*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"()' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_old_m, 20, Proto_0err_entry_get, 40)), 1));
/*316*/ 		}
/*316*/ 		Proto_i = 0;
/*317*/ 		while( (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 36, Proto_0err_entry_get, 41), Proto_i, Proto_0err_entry_get, 42) != Proto_old_m ){
/*318*/ 			m2_inc(&Proto_i, 1);
/*320*/ 		}
/*320*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Proto_0err_entry_get, 43), 4, 1, Proto_i, Proto_0err_entry_get, 44) = Proto_m;
/*323*/ 	} else {
/*323*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Proto_0err_entry_get, 45), 4, 1, Proto_0err_entry_get, 46) = Proto_m;
/*325*/ 	}
/*325*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 8, Proto_0err_entry_get, 47) = Scanner_s;
/*326*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 12, Proto_0err_entry_get, 48) = str_toupper(Scanner_s);
/*328*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 20, Proto_0err_entry_get, 49) = Scanner_here();
/*329*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 16, Proto_0err_entry_get, 50) = Proto_sign;
/*334*/ 	if( (Globals_php_ver == 4) ){
/*336*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 51), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0 ){
/*337*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 52), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"': this name is reserved for PHP 5 constructors", 1));
/*340*/ 		}
/*340*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 53), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Proto_0err_entry_get, 54)) == 0 ){
/*341*/ 			Proto_is_constructor = TRUE;
/*342*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 55) == NULL ){
/*343*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Proto_0err_entry_get, 56) = Proto_m;
/*345*/ 			} else {
/*345*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 57), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 58), 8, Proto_0err_entry_get, 59), m2runtime_CHR(39), 1));
/*350*/ 			}
/*351*/ 		}
/*353*/ 	} else {
/*353*/ 		if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 60), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Proto_0err_entry_get, 61)) == 0) || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 62), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0)) ){
/*355*/ 			Proto_is_constructor = TRUE;
/*356*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 63), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") != 0 ){
/*357*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"the constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 64), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' has the same name of the class. PHP 5 states", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" it should be called `__construct()'", 1));
/*361*/ 			}
/*361*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 65) == NULL ){
/*362*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Proto_0err_entry_get, 66) = Proto_m;
/*364*/ 			} else {
/*364*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 67), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Proto_0err_entry_get, 68), 8, Proto_0err_entry_get, 69), m2runtime_CHR(39), 1));
/*369*/ 			}
/*371*/ 		}
/*375*/ 	}
/*375*/ 	Proto_is_destructor = (((Globals_php_ver == 5)) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 12, Proto_0err_entry_get, 70), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT") == 0));
/*376*/ 	if( Proto_is_destructor ){
/*377*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 44, Proto_0err_entry_get, 71) = Proto_m;
/*380*/ 	}
/*380*/ 	if( (!Accounting_report_unused || Proto_is_constructor || Proto_is_destructor || Proto_abstract) ){
/*381*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 64, Proto_0err_entry_get, 72) = 100;
/*384*/ 	}
/*384*/ 	Globals_curr_method = Proto_m;
/*385*/ 	m2_inc(&Globals_scope, 1);
/*386*/ 	Scanner_ReadSym();
/*392*/ 	Accounting_AccountVarLHS(m2runtime_CHR(42), FALSE);
/*393*/ 	Proto_this = Search_SearchVar(m2runtime_CHR(42), Globals_scope);
/*394*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 8, Proto_0err_entry_get, 73) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this";
/*395*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 20, Proto_0err_entry_get, 74) = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 24, Proto_0err_entry_get, 75);
/*400*/ 	Proto_ParseArgsListDecl(Proto_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"method");
/*402*/ 	if( !Proto_is_constructor ){
/*413*/ 	} else {
/*413*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Proto_m, 56, Proto_0err_entry_get, 76) ){
/*414*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 77), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"': a constructor cannot be `static'", 1));
/*416*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_m, 76, 9, 56, Proto_0err_entry_get, 78) = FALSE;
/*418*/ 		}
/*418*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_sign, 8, Proto_0err_entry_get, 79) != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_sign, 8, Proto_0err_entry_get, 80) != Globals_void_type)) ){
/*419*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_m, 8, Proto_0err_entry_get, 81), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"': a constructor cannot", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)" return a value. It must be declared `void'.", 1));
/*422*/ 		}
/*422*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_sign, 28, 2, 8, Proto_0err_entry_get, 82) = Globals_void_type;
/*429*/ 	}
/*429*/ 	if( (Scanner_sym == 173) ){
/*430*/ 		Exceptions_ParseThrows();
/*433*/ 	}
/*433*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected `;' at the end of the method prototype");
/*434*/ 	Scanner_ReadSym();
/*436*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Proto_this, 52, 7, 48, Proto_0err_entry_get, 83) = 100;
/*441*/ 	Expressions_CleanCurrentScope();
/*442*/ 	m2_inc(&Globals_scope, -1);
/*443*/ 	Globals_curr_method = NULL;
/*447*/ }


/*449*/ void
/*449*/ Proto_ParseClassConstProto(void)
/*449*/ {
/*450*/ 	RECORD * Proto_cl = NULL;
/*452*/ 	RECORD * Proto_c = NULL;
/*452*/ 	Scanner_ReadSym();
/*455*/ 	do{
/*455*/ 		Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected constant name");
/*460*/ 		Search_ResolveClassConst(Globals_curr_class, Scanner_s, &Proto_cl, &Proto_c);
/*461*/ 		if( Proto_c != NULL ){
/*462*/ 			if( Proto_cl == Globals_curr_class ){
/*463*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"class constant `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_c, 16, Proto_0err_entry_get, 84)), 1));
/*465*/ 			} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Proto_cl, 72, Proto_0err_entry_get, 85) ||  *(int *)m2runtime_dereference_rhs_RECORD(Proto_cl, 76, Proto_0err_entry_get, 86)) ){
/*466*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"cannot re-define the constant `", Classes_pc(Globals_curr_class, Proto_cl), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"' inherited from interface or abstract class", 1));
/*471*/ 			}
/*472*/ 		}
/*472*/ 		Proto_c = NULL;
/*473*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 8, Proto_0err_entry_get, 87) = Scanner_s;
/*474*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 40, Proto_0err_entry_get, 88) = TRUE;
/*475*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 28, Proto_0err_entry_get, 89) = 2;
/*476*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 16, Proto_0err_entry_get, 90) = Scanner_here();
/*477*/ 		if( !Accounting_report_unused ){
/*478*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 32, Proto_0err_entry_get, 91) = 100;
/*480*/ 		}
/*480*/ 		Scanner_ReadSym();
/*481*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 44, 5, 12, Proto_0err_entry_get, 92) = NULL;
/*482*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 28, Proto_0err_entry_get, 93), 4, 1, Proto_0err_entry_get, 94) = Proto_c;
/*484*/ 		if( (Scanner_sym == 131) ){
/*485*/ 			Scanner_ReadSym();
/*488*/ 		} else {
/*489*/ 			goto m2runtime_loop_1;
/*490*/ 		}
/*491*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*491*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*492*/ 	Scanner_ReadSym();
/*497*/ }


/*503*/ void
/*503*/ Proto_ParseAttributes(int *Proto_visibility, int *Proto_abstract, int *Proto_final, int *Proto_static)
/*503*/ {
/*503*/ 	*Proto_visibility = 2;
/*504*/ 	*Proto_abstract = FALSE;
/*505*/ 	*Proto_final = FALSE;
/*506*/ 	*Proto_static = FALSE;
/*509*/ 	do{
/*509*/ 		if( (Scanner_sym == 167) ){
/*510*/ 			*Proto_visibility = 0;
/*511*/ 			Scanner_ReadSym();
/*513*/ 		} else if( (Scanner_sym == 166) ){
/*514*/ 			*Proto_visibility = 1;
/*515*/ 			Scanner_ReadSym();
/*517*/ 		} else if( (Scanner_sym == 165) ){
/*518*/ 			*Proto_visibility = 2;
/*519*/ 			Scanner_ReadSym();
/*521*/ 		} else if( (Scanner_sym == 168) ){
/*522*/ 			*Proto_abstract = TRUE;
/*523*/ 			Scanner_ReadSym();
/*525*/ 		} else if( (Scanner_sym == 170) ){
/*526*/ 			*Proto_final = TRUE;
/*527*/ 			Scanner_ReadSym();
/*529*/ 		} else if( (Scanner_sym == 169) ){
/*530*/ 			*Proto_static = TRUE;
/*531*/ 			Scanner_ReadSym();
/*535*/ 		} else {
/*536*/ 			goto m2runtime_loop_1;
/*537*/ 		}
/*538*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*540*/ }


/*542*/ void
/*542*/ Proto_ForwInterfaceDecl(int Proto_private)
/*542*/ {
/*543*/ 	RECORD * Proto_c = NULL;
/*544*/ 	int Proto_visibility = 0;
/*545*/ 	int Proto_static = 0;
/*545*/ 	int Proto_final = 0;
/*545*/ 	int Proto_abstract = 0;
/*547*/ 	RECORD * Proto_t = NULL;
/*547*/ 	Scanner_ReadSym();
/*548*/ 	Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected interface name");
/*549*/ 	Proto_c = Search_SearchClass(Scanner_s, TRUE);
/*550*/ 	if( Proto_c != NULL ){
/*552*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_c, 48, Proto_0err_entry_get, 95)), 1));
/*557*/ 	} else {
/*557*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 8, Proto_0err_entry_get, 96) = Scanner_s;
/*558*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 12, Proto_0err_entry_get, 97) = str_toupper(Scanner_s);
/*559*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 60, Proto_0err_entry_get, 98) = TRUE;
/*560*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 76, Proto_0err_entry_get, 99) = TRUE;
/*561*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 24, Proto_0err_entry_get, 100) = (
/*561*/ 			push((char*) alloc_RECORD(24, 2)),
/*561*/ 			*(int*) (tos()+16) = 9,
/*561*/ 			*(int*) (tos()+20) = 1,
/*561*/ 			push((char*) NULL),
/*561*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*561*/ 			push((char*) Proto_c),
/*562*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*562*/ 			(RECORD*) pop()
/*562*/ 		);
/*562*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 64, Proto_0err_entry_get, 101) = Proto_private;
/*563*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Proto_0err_entry_get, 102) = Proto_c;
/*565*/ 	}
/*565*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 48, Proto_0err_entry_get, 103) = Scanner_here();
/*566*/ 	Scanner_ReadSym();
/*568*/ 	if( (Scanner_sym == 136) ){
/*570*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)"`extends' keyword still unimplemented in interface prototype, sorry");
/*573*/ 	}
/*573*/ 	Scanner_Expect(157, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"expected '{' in interface prototype");
/*574*/ 	Scanner_ReadSym();
/*576*/ 	Globals_curr_class = Proto_c;
/*577*/ 	while( (Scanner_sym != 158) ){
/*578*/ 		if( (Scanner_sym == 138) ){
/*579*/ 			Proto_ParseClassConstProto();
/*581*/ 		} else {
/*581*/ 			Proto_ParseAttributes(&Proto_visibility, &Proto_abstract, &Proto_final, &Proto_static);
/*582*/ 			Proto_t = Expressions_ParseType(FALSE);
/*583*/ 			Proto_ParseMethodProto(Proto_visibility, Proto_abstract, Proto_final, Proto_static, Proto_t);
/*586*/ 		}
/*586*/ 	}
/*586*/ 	Globals_curr_class = NULL;
/*588*/ 	Scanner_Expect(158, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"expected `}' in interface prototype");
/*589*/ 	Scanner_ReadSym();
/*593*/ }


/*595*/ void
/*595*/ Proto_ForwClassDecl(int Proto_private, int Proto_abstract, int Proto_final)
/*595*/ {
/*596*/ 	RECORD * Proto_parent = NULL;
/*596*/ 	RECORD * Proto_c = NULL;
/*597*/ 	int Proto_visibility = 0;
/*598*/ 	int Proto_static = 0;
/*600*/ 	RECORD * Proto_t = NULL;
/*600*/ 	Scanner_ReadSym();
/*601*/ 	Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*602*/ 	Proto_c = Search_SearchClass(Scanner_s, TRUE);
/*603*/ 	if( Proto_c != NULL ){
/*605*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Proto_c, 48, Proto_0err_entry_get, 104)), 1));
/*610*/ 	} else {
/*610*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 8, Proto_0err_entry_get, 105) = Scanner_s;
/*611*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 12, Proto_0err_entry_get, 106) = str_toupper(Scanner_s);
/*612*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 60, Proto_0err_entry_get, 107) = TRUE;
/*613*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 72, Proto_0err_entry_get, 108) = Proto_abstract;
/*614*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 68, Proto_0err_entry_get, 109) = Proto_final;
/*615*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 24, Proto_0err_entry_get, 110) = (
/*615*/ 			push((char*) alloc_RECORD(24, 2)),
/*615*/ 			*(int*) (tos()+16) = 9,
/*615*/ 			*(int*) (tos()+20) = 1,
/*615*/ 			push((char*) NULL),
/*615*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*615*/ 			push((char*) Proto_c),
/*616*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*616*/ 			(RECORD*) pop()
/*616*/ 		);
/*616*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 64, Proto_0err_entry_get, 111) = Proto_private;
/*617*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Proto_0err_entry_get, 112) = Proto_c;
/*619*/ 	}
/*619*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 48, Proto_0err_entry_get, 113) = Scanner_here();
/*620*/ 	Scanner_ReadSym();
/*622*/ 	if( (Scanner_sym == 136) ){
/*623*/ 		Scanner_ReadSym();
/*624*/ 		Scanner_Expect(149, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected parent class name after `extend'");
/*625*/ 		Proto_parent = Search_SearchClass(Scanner_s, TRUE);
/*626*/ 		if( Proto_parent == NULL ){
/*627*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"undeclared parent class `", Scanner_s, m2runtime_CHR(39), 1));
/*628*/ 		} else if( Classes_IsSubclassOf(Proto_parent, Proto_c) ){
/*629*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"class ", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_c, 8, Proto_0err_entry_get, 114), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" cannot extend child class ", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_parent, 8, Proto_0err_entry_get, 115), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)": forbidden circular reference", 1));
/*631*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Proto_parent, 68, Proto_0err_entry_get, 116) ){
/*632*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"can't extend final class `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_parent, 8, Proto_0err_entry_get, 117), m2runtime_CHR(39), 1));
/*633*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Proto_parent, 76, Proto_0err_entry_get, 118) ){
/*634*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"can't extend interface class `", (STRING *)m2runtime_dereference_rhs_RECORD(Proto_parent, 8, Proto_0err_entry_get, 119), m2runtime_CHR(39), 1));
/*636*/ 		} else {
/*636*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Proto_c, 92, 13, 16, Proto_0err_entry_get, 120) = Proto_parent;
/*638*/ 		}
/*638*/ 		Scanner_ReadSym();
/*641*/ 	}
/*641*/ 	if( (Scanner_sym == 137) ){
/*643*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\102,\0,\0,\0)"`implements' keyword still unimplemented in class prototype, sorry");
/*646*/ 	}
/*646*/ 	Scanner_Expect(157, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected `{' in class prototype");
/*647*/ 	Scanner_ReadSym();
/*649*/ 	Globals_curr_class = Proto_c;
/*650*/ 	while( (Scanner_sym != 158) ){
/*651*/ 		if( (Scanner_sym == 138) ){
/*652*/ 			Proto_ParseClassConstProto();
/*654*/ 		} else {
/*654*/ 			Proto_ParseAttributes(&Proto_visibility, &Proto_abstract, &Proto_final, &Proto_static);
/*655*/ 			Proto_t = Expressions_ParseType(FALSE);
/*656*/ 			Proto_ParseMethodProto(Proto_visibility, Proto_abstract, Proto_final, Proto_static, Proto_t);
/*659*/ 		}
/*659*/ 	}
/*659*/ 	Globals_curr_class = NULL;
/*661*/ 	Scanner_Expect(158, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected `}' in class prototype");
/*662*/ 	Scanner_ReadSym();
/*666*/ }


/*668*/ void
/*668*/ Proto_ParseForwardDecl(void)
/*668*/ {
/*669*/ 	int Proto_visibility = 0;
/*670*/ 	int Proto_static = 0;
/*670*/ 	int Proto_final = 0;
/*670*/ 	int Proto_abstract = 0;
/*672*/ 	RECORD * Proto_t = NULL;
/*672*/ 	if( (Globals_scope > 0) ){
/*673*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"forward declarations allowed only in global scope");
/*676*/ 	}
/*676*/ 	Scanner_ReadSym();
/*678*/ 	Proto_ParseAttributes(&Proto_visibility, &Proto_abstract, &Proto_final, &Proto_static);
/*679*/ 	Proto_t = Expressions_ParseType(FALSE);
/*681*/ 	if( ((Globals_curr_class == NULL) && ((Globals_scope == 0))) ){
/*684*/ 		if( (Scanner_sym == 134) ){
/*686*/ 			if( (((Proto_visibility == 1)) || Proto_static || Proto_final || Proto_abstract) ){
/*687*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"invalid attributes for function prototype");
/*689*/ 			}
/*689*/ 			Proto_ForwFuncDecl((Proto_visibility == 0), Proto_t);
/*691*/ 		} else if( (Scanner_sym == 139) ){
/*692*/ 			if( (((Proto_visibility == 1)) || Proto_static || Proto_final || Proto_abstract) ){
/*693*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid attributes for interface prototype");
/*695*/ 			}
/*695*/ 			if( Proto_t != NULL ){
/*696*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"invalid return type in interface prototype");
/*698*/ 			}
/*698*/ 			Proto_ForwInterfaceDecl((Proto_visibility == 0));
/*700*/ 		} else if( (Scanner_sym == 135) ){
/*701*/ 			if( (((Proto_visibility == 1)) || Proto_static) ){
/*702*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"invalid attributes for class prototype");
/*704*/ 			}
/*704*/ 			if( Proto_t != NULL ){
/*705*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"invalid return type in class prototype");
/*707*/ 			}
/*707*/ 			Proto_ForwClassDecl((Proto_visibility == 0), Proto_abstract, Proto_final);
/*710*/ 		} else {
/*710*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected function, interface or class prototype");
/*713*/ 		}
/*713*/ 	} else if( ((Globals_curr_class != NULL) && ((Globals_scope == 0))) ){
/*716*/ 		if( (Scanner_sym != 134) ){
/*717*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"expected function prototype");
/*720*/ 		}
/*720*/ 		Proto_ParseMethodProto(Proto_visibility, Proto_abstract, Proto_final, Proto_static, Proto_t);
/*723*/ 	} else {
/*723*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"forward declaration not allowed here");
/*728*/ 	}
/*730*/ }


char * Proto_0func[] = {
    "ParseArgsListDecl",
    "ForwFuncDecl",
    "ParseMethodProto",
    "ParseClassConstProto",
    "ForwInterfaceDecl",
    "ForwClassDecl"
};

int Proto_0err_entry[] = {
    0 /* ParseArgsListDecl */, 28,
    0 /* ParseArgsListDecl */, 37,
    0 /* ParseArgsListDecl */, 38,
    0 /* ParseArgsListDecl */, 40,
    0 /* ParseArgsListDecl */, 41,
    0 /* ParseArgsListDecl */, 49,
    0 /* ParseArgsListDecl */, 58,
    0 /* ParseArgsListDecl */, 65,
    0 /* ParseArgsListDecl */, 72,
    0 /* ParseArgsListDecl */, 78,
    0 /* ParseArgsListDecl */, 81,
    0 /* ParseArgsListDecl */, 81,
    0 /* ParseArgsListDecl */, 82,
    0 /* ParseArgsListDecl */, 83,
    0 /* ParseArgsListDecl */, 83,
    0 /* ParseArgsListDecl */, 85,
    0 /* ParseArgsListDecl */, 91,
    1 /* ForwFuncDecl */, 116,
    1 /* ForwFuncDecl */, 120,
    1 /* ForwFuncDecl */, 134,
    1 /* ForwFuncDecl */, 135,
    1 /* ForwFuncDecl */, 136,
    1 /* ForwFuncDecl */, 137,
    1 /* ForwFuncDecl */, 138,
    1 /* ForwFuncDecl */, 139,
    1 /* ForwFuncDecl */, 140,
    1 /* ForwFuncDecl */, 141,
    1 /* ForwFuncDecl */, 142,
    1 /* ForwFuncDecl */, 144,
    2 /* ParseMethodProto */, 234,
    2 /* ParseMethodProto */, 245,
    2 /* ParseMethodProto */, 278,
    2 /* ParseMethodProto */, 279,
    2 /* ParseMethodProto */, 280,
    2 /* ParseMethodProto */, 281,
    2 /* ParseMethodProto */, 282,
    2 /* ParseMethodProto */, 284,
    2 /* ParseMethodProto */, 288,
    2 /* ParseMethodProto */, 297,
    2 /* ParseMethodProto */, 310,
    2 /* ParseMethodProto */, 312,
    2 /* ParseMethodProto */, 317,
    2 /* ParseMethodProto */, 317,
    2 /* ParseMethodProto */, 320,
    2 /* ParseMethodProto */, 320,
    2 /* ParseMethodProto */, 323,
    2 /* ParseMethodProto */, 323,
    2 /* ParseMethodProto */, 325,
    2 /* ParseMethodProto */, 326,
    2 /* ParseMethodProto */, 328,
    2 /* ParseMethodProto */, 329,
    2 /* ParseMethodProto */, 336,
    2 /* ParseMethodProto */, 337,
    2 /* ParseMethodProto */, 340,
    2 /* ParseMethodProto */, 340,
    2 /* ParseMethodProto */, 342,
    2 /* ParseMethodProto */, 343,
    2 /* ParseMethodProto */, 345,
    2 /* ParseMethodProto */, 347,
    2 /* ParseMethodProto */, 347,
    2 /* ParseMethodProto */, 353,
    2 /* ParseMethodProto */, 353,
    2 /* ParseMethodProto */, 354,
    2 /* ParseMethodProto */, 356,
    2 /* ParseMethodProto */, 357,
    2 /* ParseMethodProto */, 361,
    2 /* ParseMethodProto */, 362,
    2 /* ParseMethodProto */, 364,
    2 /* ParseMethodProto */, 366,
    2 /* ParseMethodProto */, 366,
    2 /* ParseMethodProto */, 375,
    2 /* ParseMethodProto */, 377,
    2 /* ParseMethodProto */, 381,
    2 /* ParseMethodProto */, 394,
    2 /* ParseMethodProto */, 395,
    2 /* ParseMethodProto */, 395,
    2 /* ParseMethodProto */, 413,
    2 /* ParseMethodProto */, 414,
    2 /* ParseMethodProto */, 416,
    2 /* ParseMethodProto */, 418,
    2 /* ParseMethodProto */, 418,
    2 /* ParseMethodProto */, 419,
    2 /* ParseMethodProto */, 422,
    2 /* ParseMethodProto */, 436,
    3 /* ParseClassConstProto */, 464,
    3 /* ParseClassConstProto */, 465,
    3 /* ParseClassConstProto */, 465,
    3 /* ParseClassConstProto */, 473,
    3 /* ParseClassConstProto */, 474,
    3 /* ParseClassConstProto */, 475,
    3 /* ParseClassConstProto */, 476,
    3 /* ParseClassConstProto */, 478,
    3 /* ParseClassConstProto */, 481,
    3 /* ParseClassConstProto */, 482,
    3 /* ParseClassConstProto */, 482,
    4 /* ForwInterfaceDecl */, 553,
    4 /* ForwInterfaceDecl */, 557,
    4 /* ForwInterfaceDecl */, 558,
    4 /* ForwInterfaceDecl */, 559,
    4 /* ForwInterfaceDecl */, 560,
    4 /* ForwInterfaceDecl */, 561,
    4 /* ForwInterfaceDecl */, 562,
    4 /* ForwInterfaceDecl */, 563,
    4 /* ForwInterfaceDecl */, 565,
    5 /* ForwClassDecl */, 606,
    5 /* ForwClassDecl */, 610,
    5 /* ForwClassDecl */, 611,
    5 /* ForwClassDecl */, 612,
    5 /* ForwClassDecl */, 613,
    5 /* ForwClassDecl */, 614,
    5 /* ForwClassDecl */, 615,
    5 /* ForwClassDecl */, 616,
    5 /* ForwClassDecl */, 617,
    5 /* ForwClassDecl */, 619,
    5 /* ForwClassDecl */, 629,
    5 /* ForwClassDecl */, 630,
    5 /* ForwClassDecl */, 631,
    5 /* ForwClassDecl */, 632,
    5 /* ForwClassDecl */, 633,
    5 /* ForwClassDecl */, 634,
    5 /* ForwClassDecl */, 636
};

void Proto_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Proto";
    *f = Proto_0func[ Proto_0err_entry[2*i] ];
    *l = Proto_0err_entry[2*i + 1];
}
