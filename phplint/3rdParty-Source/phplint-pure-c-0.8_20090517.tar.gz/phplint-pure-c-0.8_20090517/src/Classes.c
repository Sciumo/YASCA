/* IMPLEMENTATION MODULE Classes */
#define M2_IMPORT_Classes

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

void Classes_0err_entry_get(int i, char **m, char **f, int *l);

/* 11*/ int
/* 11*/ Classes_IsSubclassOf(RECORD *Classes_child, RECORD *Classes_parent)
/* 11*/ {
/* 12*/ 	int Classes_i = 0;
/* 14*/ 	ARRAY * Classes_c = NULL;
/* 14*/ 	if( ((Classes_child == NULL) || (Classes_parent == NULL)) ){
/* 15*/ 		return FALSE;
/* 17*/ 	}
/* 17*/ 	if( Classes_child == Classes_parent ){
/* 18*/ 		return TRUE;
/* 20*/ 	}
/* 20*/ 	if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 16, Classes_0err_entry_get, 0), Classes_parent) ){
/* 21*/ 		return TRUE;
/* 23*/ 	}
/* 23*/ 	Classes_c = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 1);
/* 24*/ 	{
/* 24*/ 		int m2runtime_for_limit_1;
/* 24*/ 		Classes_i = 0;
/* 24*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_c) - 1);
/* 25*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 25*/ 			if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_c, Classes_i, Classes_0err_entry_get, 2), Classes_parent) ){
/* 26*/ 				return TRUE;
/* 29*/ 			}
/* 29*/ 		}
/* 29*/ 	}
/* 29*/ 	return FALSE;
/* 33*/ }


/* 34*/ int
/* 34*/ Classes_IsSubclassOfSet(RECORD *Classes_c, ARRAY *Classes_set)
/* 34*/ {
/* 36*/ 	int Classes_i = 0;
/* 36*/ 	{
/* 36*/ 		int m2runtime_for_limit_1;
/* 36*/ 		Classes_i = 0;
/* 36*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_set) - 1);
/* 37*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 37*/ 			if( Classes_IsSubclassOf(Classes_c, (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 3)) ){
/* 38*/ 				return TRUE;
/* 41*/ 			}
/* 41*/ 		}
/* 41*/ 	}
/* 41*/ 	return FALSE;
/* 45*/ }


/* 48*/ ARRAY *
/* 48*/ Classes_OrphanClasses(ARRAY *Classes_parents, ARRAY *Classes_children)
/* 48*/ {
/* 49*/ 	int Classes_i = 0;
/* 51*/ 	ARRAY * Classes_orphans = NULL;
/* 51*/ 	{
/* 51*/ 		int m2runtime_for_limit_1;
/* 51*/ 		Classes_i = 0;
/* 51*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_children) - 1);
/* 52*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 52*/ 			if( !Classes_IsSubclassOfSet((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_children, Classes_i, Classes_0err_entry_get, 4), Classes_parents) ){
/* 53*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_orphans, 4, 1, Classes_0err_entry_get, 5) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_children, Classes_i, Classes_0err_entry_get, 6);
/* 56*/ 			}
/* 56*/ 		}
/* 56*/ 	}
/* 56*/ 	return Classes_orphans;
/* 60*/ }


/* 62*/ STRING *
/* 62*/ Classes_ClassesList(ARRAY *Classes_set)
/* 62*/ {
/* 63*/ 	STRING * Classes_s = NULL;
/* 65*/ 	int Classes_i = 0;
/* 65*/ 	{
/* 65*/ 		int m2runtime_for_limit_1;
/* 65*/ 		Classes_i = 0;
/* 65*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_set) - 1);
/* 66*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/* 66*/ 			if( (Classes_i > 0) ){
/* 67*/ 				Classes_s = m2runtime_concat_STRING(0, Classes_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", 1);
/* 69*/ 			}
/* 69*/ 			Classes_s = m2runtime_concat_STRING(0, Classes_s, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 7), 8, Classes_0err_entry_get, 8), 1);
/* 71*/ 		}
/* 71*/ 	}
/* 71*/ 	return Classes_s;
/* 75*/ }


/* 77*/ ARRAY *
/* 77*/ Classes_CloneSet(ARRAY *Classes_set)
/* 77*/ {
/* 78*/ 	ARRAY * Classes_copy = NULL;
/* 80*/ 	int Classes_i = 0;
/* 80*/ 	{
/* 80*/ 		int m2runtime_for_limit_1;
/* 80*/ 		Classes_i = (m2runtime_count(Classes_set) - 1);
/* 80*/ 		m2runtime_for_limit_1 = 0;
/* 81*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/* 81*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_copy, 4, 1, Classes_i, Classes_0err_entry_get, 9) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_set, Classes_i, Classes_0err_entry_get, 10);
/* 83*/ 		}
/* 83*/ 	}
/* 83*/ 	return Classes_copy;
/* 87*/ }


/* 89*/ ARRAY *
/* 89*/ Classes_Sort(ARRAY *Classes_set)
/* 89*/ {

/* 91*/ 	int
/* 91*/ 	Classes_cmp(RECORD *Classes_a, RECORD *Classes_b)
/* 91*/ 	{
/* 91*/ 		if( Classes_IsSubclassOf(Classes_a, Classes_b) ){
/* 92*/ 			return -1;
/* 93*/ 		} else if( Classes_IsSubclassOf(Classes_b, Classes_a) ){
/* 94*/ 			return 1;
/* 96*/ 		} else {
/* 96*/ 			return m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_a, 8, Classes_0err_entry_get, 11), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_b, 8, Classes_0err_entry_get, 12));
/* 99*/ 		}
/* 99*/ 		m2runtime_missing_return(Classes_0err_entry_get, 13);
/* 99*/ 		return 0;
/*101*/ 	}

/*102*/ 	int Classes_j = 0;
/*102*/ 	int Classes_i = 0;
/*103*/ 	RECORD * Classes_t = NULL;
/*105*/ 	ARRAY * Classes_new = NULL;
/*105*/ 	Classes_new = Classes_CloneSet(Classes_set);
/*106*/ 	{
/*106*/ 		int m2runtime_for_limit_1;
/*106*/ 		Classes_i = 0;
/*106*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_new) - 2);
/*107*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*107*/ 			{
/*107*/ 				int m2runtime_for_limit_2;
/*107*/ 				Classes_j = (Classes_i + 1);
/*107*/ 				m2runtime_for_limit_2 = (m2runtime_count(Classes_new) - 1);
/*108*/ 				for( ; Classes_j <= m2runtime_for_limit_2; Classes_j += 1 ){
/*108*/ 					if( (Classes_cmp((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_j, Classes_0err_entry_get, 14), (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_i, Classes_0err_entry_get, 15)) < 0) ){
/*109*/ 						Classes_t = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_i, Classes_0err_entry_get, 16);
/*110*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_new, 4, 1, Classes_i, Classes_0err_entry_get, 17) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_new, Classes_j, Classes_0err_entry_get, 18);
/*111*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Classes_new, 4, 1, Classes_j, Classes_0err_entry_get, 19) = Classes_t;
/*114*/ 					}
/*115*/ 				}
/*115*/ 			}
/*115*/ 		}
/*115*/ 	}
/*115*/ 	return Classes_new;
/*119*/ }


/*125*/ STRING *
/*125*/ Classes_pc(RECORD *Classes_c1, RECORD *Classes_c2)
/*125*/ {
/*126*/ 	STRING * Classes_s = NULL;
/*128*/ 	int Classes_i = 0;
/*128*/ 	if( ((Classes_c1 == NULL) || (Classes_c2 == NULL)) ){
/*129*/ 		return NULL;
/*131*/ 	}
/*131*/ 	if( Classes_c1 == Classes_c2 ){
/*132*/ 		return (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 20);
/*136*/ 	}
/*136*/ 	Classes_s = Classes_pc((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c1, 16, Classes_0err_entry_get, 21), Classes_c2);
/*137*/ 	if( Classes_s != NULL ){
/*138*/ 		return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 22), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Classes_s, 1);
/*142*/ 	}
/*142*/ 	{
/*142*/ 		int m2runtime_for_limit_1;
/*142*/ 		Classes_i = 0;
/*142*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c1, 20, Classes_0err_entry_get, 23)) - 1);
/*143*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*143*/ 			Classes_s = Classes_pc((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c1, 20, Classes_0err_entry_get, 24), Classes_i, Classes_0err_entry_get, 25), Classes_c2);
/*144*/ 			if( Classes_s != NULL ){
/*145*/ 				return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_c1, 8, Classes_0err_entry_get, 26), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Classes_s, 1);
/*148*/ 			}
/*149*/ 		}
/*149*/ 	}
/*149*/ 	return NULL;
/*153*/ }


/*167*/ RECORD *
/*167*/ Classes_SearchMethod(RECORD *Classes_c, STRING *Classes_name, STRING *Classes_name_upper, int Classes_warn)
/*167*/ {
/*168*/ 	ARRAY * Classes_methods = NULL;
/*169*/ 	int Classes_i = 0;
/*170*/ 	RECORD * Classes_m = NULL;
/*172*/ 	STRING * Classes_action = NULL;
/*172*/ 	if( Classes_c == NULL ){
/*173*/ 		return NULL;
/*175*/ 	}
/*175*/ 	Classes_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 36, Classes_0err_entry_get, 27);
/*176*/ 	{
/*176*/ 		int m2runtime_for_limit_1;
/*176*/ 		Classes_i = 0;
/*176*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_methods) - 1);
/*177*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*177*/ 			Classes_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_methods, Classes_i, Classes_0err_entry_get, 28);
/*178*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 12, Classes_0err_entry_get, 29), Classes_name_upper) == 0 ){
/*179*/ 				if( (Classes_warn && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 30), Classes_name) != 0)) ){
/*180*/ 					if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_m, 48, Classes_0err_entry_get, 31) ){
/*181*/ 						Classes_action = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"implemented";
/*183*/ 					} else {
/*183*/ 						Classes_action = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"overridden";
/*185*/ 					}
/*185*/ 					Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"the name of the method `", Classes_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"()' differs from the name of the ", Classes_action, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_c, Classes_m), 1));
/*189*/ 				}
/*189*/ 				return Classes_m;
/*192*/ 			}
/*192*/ 		}
/*192*/ 	}
/*192*/ 	return NULL;
/*203*/ }


/*210*/ ARRAY *
/*210*/ Classes_MergeIConstArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*210*/ {
/*211*/ 	ARRAY * Classes_c = NULL;
/*213*/ 	int Classes_j = 0;
/*213*/ 	int Classes_i = 0;
/*213*/ 	if( Classes_a == NULL ){
/*214*/ 		return Classes_b;
/*216*/ 	}
/*216*/ 	if( Classes_b == NULL ){
/*217*/ 		return Classes_a;
/*221*/ 	}
/*221*/ 	{
/*221*/ 		int m2runtime_for_limit_1;
/*221*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*221*/ 		m2runtime_for_limit_1 = 0;
/*222*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*222*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 32) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 33);
/*226*/ 		}
/*226*/ 	}
/*226*/ 	{
/*226*/ 		int m2runtime_for_limit_1;
/*226*/ 		Classes_i = 0;
/*226*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*227*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*228*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*230*/ 			do{
/*230*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 34), 8, Classes_0err_entry_get, 35) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 36), 8, Classes_0err_entry_get, 37))) ){
/*232*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 38) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 39);
/*235*/ 					goto m2runtime_loop_1;
/*235*/ 				} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 40), 12, Classes_0err_entry_get, 41), 8, Classes_0err_entry_get, 42), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 43), 12, Classes_0err_entry_get, 44), 8, Classes_0err_entry_get, 45)) == 0 ){
/*237*/ 					if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 46), 8, Classes_0err_entry_get, 47), 76, Classes_0err_entry_get, 48) ||  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 49), 8, Classes_0err_entry_get, 50), 76, Classes_0err_entry_get, 51)) ){
/*241*/ 						if( Classes_errorOnCollision ){
/*242*/ 							Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"colliding inherited constants ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 52), 8, Classes_0err_entry_get, 53), 8, Classes_0err_entry_get, 54), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 55), 12, Classes_0err_entry_get, 56), 8, Classes_0err_entry_get, 57), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 58), 12, Classes_0err_entry_get, 59), 16, Classes_0err_entry_get, 60)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 61), 8, Classes_0err_entry_get, 62), 8, Classes_0err_entry_get, 63), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 64), 12, Classes_0err_entry_get, 65), 8, Classes_0err_entry_get, 66), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 67), 12, Classes_0err_entry_get, 68), 16, Classes_0err_entry_get, 69)), 1));
/*255*/ 						}
/*256*/ 					}
/*258*/ 					goto m2runtime_loop_1;
/*258*/ 				}
/*258*/ 				m2_inc(&Classes_j, -1);
/*261*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*262*/ 		}
/*262*/ 	}
/*262*/ 	return Classes_c;
/*266*/ }


/*269*/ ARRAY *
/*269*/ Classes_CollectConsts(RECORD *Classes_cl, int Classes_errorOnCollision)
/*269*/ {
/*270*/ 	ARRAY * Classes_b = NULL;
/*270*/ 	ARRAY * Classes_a = NULL;
/*271*/ 	RECORD * Classes_c = NULL;
/*273*/ 	int Classes_i = 0;
/*273*/ 	if( Classes_cl == NULL ){
/*274*/ 		return NULL;
/*280*/ 	}
/*280*/ 	Classes_a = Classes_CollectConsts((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_cl, 16, Classes_0err_entry_get, 70), FALSE);
/*285*/ 	{
/*285*/ 		int m2runtime_for_limit_1;
/*285*/ 		Classes_i = 0;
/*285*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 71)) - 1);
/*286*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*286*/ 			Classes_b = Classes_CollectConsts((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 72), Classes_i, Classes_0err_entry_get, 73), FALSE);
/*287*/ 			Classes_a = Classes_MergeIConstArrays(Classes_a, Classes_b, Classes_errorOnCollision);
/*293*/ 		}
/*293*/ 	}
/*293*/ 	Classes_b = NULL;
/*294*/ 	{
/*294*/ 		int m2runtime_for_limit_1;
/*294*/ 		Classes_i = 0;
/*294*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 28, Classes_0err_entry_get, 74)) - 1);
/*295*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*295*/ 			Classes_c = NULL;
/*296*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_c, 16, 2, 8, Classes_0err_entry_get, 75) = Classes_cl;
/*297*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_c, 16, 2, 12, Classes_0err_entry_get, 76) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 28, Classes_0err_entry_get, 77), Classes_i, Classes_0err_entry_get, 78);
/*298*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 79) = Classes_c;
/*300*/ 		}
/*300*/ 	}
/*300*/ 	Classes_a = Classes_MergeIConstArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*302*/ 	return Classes_a;
/*313*/ }


/*319*/ ARRAY *
/*319*/ Classes_MergeIPropArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*319*/ {
/*320*/ 	ARRAY * Classes_c = NULL;
/*321*/ 	int Classes_j = 0;
/*321*/ 	int Classes_i = 0;
/*323*/ 	STRING * Classes_hint = NULL;
/*323*/ 	if( Classes_a == NULL ){
/*324*/ 		return Classes_b;
/*326*/ 	}
/*326*/ 	if( Classes_b == NULL ){
/*327*/ 		return Classes_a;
/*331*/ 	}
/*331*/ 	{
/*331*/ 		int m2runtime_for_limit_1;
/*331*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*331*/ 		m2runtime_for_limit_1 = 0;
/*332*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*332*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 80) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 81);
/*336*/ 		}
/*336*/ 	}
/*336*/ 	{
/*336*/ 		int m2runtime_for_limit_1;
/*336*/ 		Classes_i = 0;
/*336*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*337*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*338*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*340*/ 			do{
/*340*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 82), 8, Classes_0err_entry_get, 83) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 84), 8, Classes_0err_entry_get, 85))) ){
/*342*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 86) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 87);
/*345*/ 					goto m2runtime_loop_1;
/*345*/ 				} else if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 88), 12, Classes_0err_entry_get, 89), 8, Classes_0err_entry_get, 90), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 91), 12, Classes_0err_entry_get, 92), 8, Classes_0err_entry_get, 93)) == 0) && ((((Globals_php_ver == 4)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 94), 12, Classes_0err_entry_get, 95), 32, Classes_0err_entry_get, 96) != 0)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 97), 12, Classes_0err_entry_get, 98), 32, Classes_0err_entry_get, 99) != 0))))) ){
/*352*/ 					if( Classes_errorOnCollision ){
/*353*/ 						if( (Globals_php_ver == 4) ){
/*354*/ 							Classes_hint = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\161,\0,\0,\0)". Private properties cannot be re-defined nor public|protected properties can be overriden (PHPLint restriction).";
/*356*/ 						} else {
/*356*/ 							Classes_hint = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)". Public|protected properties cannot be overriden (PHPLint restriction).";
/*358*/ 						}
/*358*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"colliding inherited properties ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 100), 8, Classes_0err_entry_get, 101), 8, Classes_0err_entry_get, 102), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 103), 12, Classes_0err_entry_get, 104), 8, Classes_0err_entry_get, 105), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 106), 12, Classes_0err_entry_get, 107), 20, Classes_0err_entry_get, 108)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 109), 8, Classes_0err_entry_get, 110), 8, Classes_0err_entry_get, 111), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 112), 12, Classes_0err_entry_get, 113), 8, Classes_0err_entry_get, 114), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 115), 12, Classes_0err_entry_get, 116), 20, Classes_0err_entry_get, 117)), Classes_hint, 1));
/*368*/ 					}
/*370*/ 					goto m2runtime_loop_1;
/*370*/ 				}
/*370*/ 				m2_inc(&Classes_j, -1);
/*373*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*374*/ 		}
/*374*/ 	}
/*374*/ 	return Classes_c;
/*378*/ }


/*381*/ ARRAY *
/*381*/ Classes_CollectProps(RECORD *Classes_cl, int Classes_errorOnCollision)
/*381*/ {
/*382*/ 	ARRAY * Classes_b = NULL;
/*382*/ 	ARRAY * Classes_a = NULL;
/*383*/ 	RECORD * Classes_p = NULL;
/*385*/ 	int Classes_i = 0;
/*385*/ 	if( Classes_cl == NULL ){
/*386*/ 		return NULL;
/*392*/ 	}
/*392*/ 	Classes_a = Classes_CollectProps((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_cl, 16, Classes_0err_entry_get, 118), FALSE);
/*409*/ 	Classes_b = NULL;
/*410*/ 	{
/*410*/ 		int m2runtime_for_limit_1;
/*410*/ 		Classes_i = 0;
/*410*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 32, Classes_0err_entry_get, 119)) - 1);
/*411*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*411*/ 			Classes_p = NULL;
/*412*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_p, 16, 2, 8, Classes_0err_entry_get, 120) = Classes_cl;
/*413*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_p, 16, 2, 12, Classes_0err_entry_get, 121) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 32, Classes_0err_entry_get, 122), Classes_i, Classes_0err_entry_get, 123);
/*414*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 124) = Classes_p;
/*416*/ 		}
/*416*/ 	}
/*416*/ 	Classes_a = Classes_MergeIPropArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*418*/ 	return Classes_a;
/*430*/ }


/*436*/ ARRAY *
/*436*/ Classes_MergeIMethodArrays(ARRAY *Classes_a, ARRAY *Classes_b, int Classes_errorOnCollision)
/*436*/ {
/*437*/ 	ARRAY * Classes_c = NULL;
/*438*/ 	int Classes_j = 0;
/*438*/ 	int Classes_i = 0;
/*440*/ 	RECORD * Classes_bm = NULL;
/*440*/ 	RECORD * Classes_am = NULL;
/*440*/ 	if( Classes_a == NULL ){
/*441*/ 		return Classes_b;
/*443*/ 	}
/*443*/ 	if( Classes_b == NULL ){
/*444*/ 		return Classes_a;
/*448*/ 	}
/*448*/ 	{
/*448*/ 		int m2runtime_for_limit_1;
/*448*/ 		Classes_i = (m2runtime_count(Classes_a) - 1);
/*448*/ 		m2runtime_for_limit_1 = 0;
/*449*/ 		for( ; Classes_i >= m2runtime_for_limit_1; Classes_i -= 1 ){
/*449*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 125) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_i, Classes_0err_entry_get, 126);
/*453*/ 		}
/*453*/ 	}
/*453*/ 	{
/*453*/ 		int m2runtime_for_limit_1;
/*453*/ 		Classes_i = 0;
/*453*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_b) - 1);
/*454*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*455*/ 			Classes_j = (m2runtime_count(Classes_a) - 1);
/*457*/ 			do{
/*457*/ 				if( (((Classes_j < 0)) || ((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 127), 8, Classes_0err_entry_get, 128) == (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 129), 8, Classes_0err_entry_get, 130))) ){
/*459*/ 					*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_c, 4, 1, Classes_0err_entry_get, 131) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 132);
/*462*/ 					goto m2runtime_loop_1;
/*463*/ 				}
/*463*/ 				Classes_am = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_a, Classes_j, Classes_0err_entry_get, 133);
/*464*/ 				Classes_bm = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_b, Classes_i, Classes_0err_entry_get, 134);
/*466*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 135), 12, Classes_0err_entry_get, 136), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 137), 12, Classes_0err_entry_get, 138)) == 0) && ((((Globals_php_ver == 4)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 139), 52, Classes_0err_entry_get, 140) != 0)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 141), 52, Classes_0err_entry_get, 142) != 0))))) ){
/*473*/ 					if( Classes_errorOnCollision ){
/*474*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"colliding inherited methods ", Scanner_mn((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 8, Classes_0err_entry_get, 143), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 144)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_am, 12, Classes_0err_entry_get, 145), 20, Classes_0err_entry_get, 146)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" and ", Scanner_mn((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 8, Classes_0err_entry_get, 147), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 148)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_bm, 12, Classes_0err_entry_get, 149), 20, Classes_0err_entry_get, 150)), 1));
/*483*/ 					}
/*485*/ 					goto m2runtime_loop_1;
/*485*/ 				}
/*485*/ 				m2_inc(&Classes_j, -1);
/*488*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*489*/ 		}
/*489*/ 	}
/*489*/ 	return Classes_c;
/*493*/ }


/*496*/ ARRAY *
/*496*/ Classes_CollectMethods(RECORD *Classes_cl, int Classes_errorOnCollision)
/*496*/ {
/*497*/ 	ARRAY * Classes_b = NULL;
/*497*/ 	ARRAY * Classes_a = NULL;
/*498*/ 	RECORD * Classes_m = NULL;
/*500*/ 	int Classes_i = 0;
/*500*/ 	if( Classes_cl == NULL ){
/*501*/ 		return NULL;
/*512*/ 	}
/*512*/ 	{
/*512*/ 		int m2runtime_for_limit_1;
/*512*/ 		Classes_i = 0;
/*512*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 151)) - 1);
/*513*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*513*/ 			Classes_b = Classes_CollectMethods((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 20, Classes_0err_entry_get, 152), Classes_i, Classes_0err_entry_get, 153), FALSE);
/*514*/ 			Classes_a = Classes_MergeIMethodArrays(Classes_a, Classes_b, Classes_errorOnCollision);
/*520*/ 		}
/*520*/ 	}
/*520*/ 	Classes_b = NULL;
/*521*/ 	{
/*521*/ 		int m2runtime_for_limit_1;
/*521*/ 		Classes_i = 0;
/*521*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 36, Classes_0err_entry_get, 154)) - 1);
/*522*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*522*/ 			Classes_m = NULL;
/*523*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_m, 16, 2, 8, Classes_0err_entry_get, 155) = Classes_cl;
/*524*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Classes_m, 16, 2, 12, Classes_0err_entry_get, 156) = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_cl, 36, Classes_0err_entry_get, 157), Classes_i, Classes_0err_entry_get, 158);
/*525*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Classes_b, 4, 1, Classes_0err_entry_get, 159) = Classes_m;
/*527*/ 		}
/*527*/ 	}
/*527*/ 	Classes_a = Classes_MergeIMethodArrays(Classes_b, Classes_a, Classes_errorOnCollision);
/*529*/ 	return Classes_a;
/*534*/ }


/*536*/ void
/*536*/ Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(RECORD *Classes_cl)
/*536*/ {
/*537*/ 	ARRAY * Classes_ic = NULL;
/*538*/ 	ARRAY * Classes_ip = NULL;
/*540*/ 	ARRAY * Classes_im = NULL;
/*545*/ 	Classes_ic = Classes_CollectConsts(Classes_cl, TRUE);
/*558*/ 	Classes_ip = Classes_CollectProps(Classes_cl, TRUE);
/*563*/ 	Classes_im = Classes_CollectMethods(Classes_cl, TRUE);
/*568*/ }


/*570*/ void
/*570*/ Classes_CheckImplementedMethods(RECORD *Classes_child)
/*570*/ {
/*571*/ 	RECORD * Classes_parent = NULL;
/*572*/ 	ARRAY * Classes_parent_methods = NULL;
/*573*/ 	int Classes_j = 0;
/*573*/ 	int Classes_i = 0;
/*575*/ 	RECORD * Classes_c_m = NULL;
/*575*/ 	RECORD * Classes_p_m = NULL;
/*578*/ 	Classes_parent = (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 16, Classes_0err_entry_get, 160);
/*579*/ 	if( ((Classes_parent != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_parent, 72, Classes_0err_entry_get, 161)) ){
/*580*/ 		Classes_parent_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_parent, 36, Classes_0err_entry_get, 162);
/*581*/ 		{
/*581*/ 			int m2runtime_for_limit_1;
/*581*/ 			Classes_i = 0;
/*581*/ 			m2runtime_for_limit_1 = (m2runtime_count(Classes_parent_methods) - 1);
/*582*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*582*/ 				Classes_p_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_parent_methods, Classes_i, Classes_0err_entry_get, 163);
/*583*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 48, Classes_0err_entry_get, 164) ){
/*584*/ 					Classes_c_m = Classes_SearchMethod(Classes_child, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 8, Classes_0err_entry_get, 165), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 12, Classes_0err_entry_get, 166), TRUE);
/*585*/ 					if( Classes_c_m == NULL ){
/*586*/ 						Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 48, Classes_0err_entry_get, 167), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"in class `", (STRING *)m2runtime_dereference_rhs_RECORD(Classes_child, 8, Classes_0err_entry_get, 168), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"': missing implementation of the abstract method ", Scanner_mn(Classes_parent, Classes_p_m), 1));
/*591*/ 					}
/*592*/ 				}
/*593*/ 			}
/*593*/ 		}
/*596*/ 	}
/*596*/ 	{
/*596*/ 		int m2runtime_for_limit_1;
/*596*/ 		Classes_i = 0;
/*596*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 169)) - 1);
/*597*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*597*/ 			Classes_parent = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_child, 20, Classes_0err_entry_get, 170), Classes_i, Classes_0err_entry_get, 171);
/*598*/ 			Classes_parent_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_parent, 36, Classes_0err_entry_get, 172);
/*599*/ 			{
/*599*/ 				int m2runtime_for_limit_2;
/*599*/ 				Classes_j = 0;
/*599*/ 				m2runtime_for_limit_2 = (m2runtime_count(Classes_parent_methods) - 1);
/*600*/ 				for( ; Classes_j <= m2runtime_for_limit_2; Classes_j += 1 ){
/*600*/ 					Classes_p_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_parent_methods, Classes_j, Classes_0err_entry_get, 173);
/*601*/ 					Classes_c_m = Classes_SearchMethod(Classes_child, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 8, Classes_0err_entry_get, 174), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_p_m, 12, Classes_0err_entry_get, 175), TRUE);
/*602*/ 					if( Classes_c_m == NULL ){
/*603*/ 						Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_child, 48, Classes_0err_entry_get, 176), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"in class `", (STRING *)m2runtime_dereference_rhs_RECORD(Classes_child, 8, Classes_0err_entry_get, 177), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"': missing implementation of the abstract method ", Scanner_mn(Classes_parent, Classes_p_m), 1));
/*608*/ 					}
/*609*/ 				}
/*609*/ 			}
/*610*/ 		}
/*610*/ 	}
/*612*/ }


/*635*/ int
/*635*/ Classes_IsOverridingType(RECORD *Classes_a, RECORD *Classes_b)
/*635*/ {
/*635*/ 	if( Types_SameType(Classes_a, Classes_b) ){
/*636*/ 		return TRUE;
/*639*/ 	}
/*639*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 178)){

/*641*/ 	case 7:
/*643*/ 	return ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 179) == 5)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 180) == 6)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 181) == 7)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 182) == 8)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 183) == 9)));
/*649*/ 	break;

/*649*/ 	case 9:
/*650*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 184) == NULL ){
/*652*/ 		return ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 185) == 5)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 186) == 6)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 187) == 7)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 188) == 8)) || (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 189) == 9)));
/*659*/ 	} else {
/*659*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 190) == 9) ){
/*660*/ 			return Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 191), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 192));
/*662*/ 		} else {
/*662*/ 			return FALSE;
/*666*/ 		}
/*668*/ 	}
/*668*/ 	break;

/*668*/ 	default:
/*668*/ 	return FALSE;
/*672*/ 	}
/*672*/ 	m2runtime_missing_return(Classes_0err_entry_get, 193);
/*672*/ 	return 0;
/*674*/ }


/*681*/ void
/*681*/ Classes_CheckOverridesImplements(RECORD *Classes_ac, RECORD *Classes_a, RECORD *Classes_bc, RECORD *Classes_b)
/*681*/ {

/*688*/ 	STRING *
/*688*/ 	Classes_CheckSign(RECORD *Classes_a, RECORD *Classes_b)
/*688*/ 	{
/*689*/ 		int Classes_b_n = 0;
/*689*/ 		int Classes_b_m = 0;
/*689*/ 		int Classes_a_n = 0;
/*689*/ 		int Classes_a_m = 0;
/*689*/ 		int Classes_i = 0;
/*691*/ 		RECORD * Classes_b_arg = NULL;
/*691*/ 		RECORD * Classes_a_arg = NULL;
/*695*/ 		if( !Classes_IsOverridingType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 8, Classes_0err_entry_get, 194), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 8, Classes_0err_entry_get, 195)) ){
/*696*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"incompatible return types";
/*702*/ 		}
/*702*/ 		Classes_a_m =  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 196);
/*702*/ 		Classes_a_n = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 197)) - Classes_a_m);
/*703*/ 		Classes_b_m =  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 198);
/*703*/ 		Classes_b_n = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 199)) - Classes_b_m);
/*705*/ 		if( (Classes_a_m != Classes_b_m) ){
/*706*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"different number of mandatory arguments";
/*709*/ 		}
/*709*/ 		if( (Classes_b_n < Classes_a_n) ){
/*710*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"too few default arguments";
/*713*/ 		}
/*713*/ 		{
/*713*/ 			int m2runtime_for_limit_1;
/*713*/ 			Classes_i = 0;
/*713*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 200)) - 1);
/*714*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*715*/ 				Classes_a_arg = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 12, Classes_0err_entry_get, 201), Classes_i, Classes_0err_entry_get, 202);
/*716*/ 				Classes_b_arg = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 12, Classes_0err_entry_get, 203), Classes_i, Classes_0err_entry_get, 204);
/*721*/ 				if( ((! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 205) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 20, Classes_0err_entry_get, 206)) || ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 207) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 20, Classes_0err_entry_get, 208))) ){
/*723*/ 					return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid & in argument no. ", m2runtime_itos(((Classes_i + 1))), 1);
/*731*/ 				}
/*731*/ 				if( (( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 209) && !Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 12, Classes_0err_entry_get, 210), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 12, Classes_0err_entry_get, 211))) || (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 20, Classes_0err_entry_get, 212) && !Classes_IsOverridingType((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b_arg, 12, Classes_0err_entry_get, 213), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a_arg, 12, Classes_0err_entry_get, 214)))) ){
/*733*/ 					return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"incompatible type in overriding argument no. ", m2runtime_itos(((Classes_i + 1))), 1);
/*736*/ 				}
/*740*/ 			}
/*740*/ 		}
/*740*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 24, Classes_0err_entry_get, 215) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 24, Classes_0err_entry_get, 216)) ){
/*741*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"required variable number of arguments /*.args.*/";
/*744*/ 		}
/*744*/ 		return NULL;
/*748*/ 	}

/*749*/ 	STRING * Classes_t = NULL;
/*751*/ 	STRING * Classes_err = NULL;
/*756*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 48, Classes_0err_entry_get, 217) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 48, Classes_0err_entry_get, 218)) ){
/*757*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 219), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"abstract method ", Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)" redeclares inherited abstract method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)" (PHP restriction)", 1));
/*762*/ 	}
/*762*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 48, Classes_0err_entry_get, 220) ){
/*763*/ 		Classes_t = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"implemented";
/*765*/ 	} else {
/*765*/ 		Classes_t = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"overridden";
/*769*/ 	}
/*769*/ 	if( (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 48, Classes_0err_entry_get, 221) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 48, Classes_0err_entry_get, 222)) ){
/*770*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 223), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)": cannot make abstract the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" non-abstract method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 224)), 1));
/*776*/ 	}
/*776*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 56, Classes_0err_entry_get, 225) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 56, Classes_0err_entry_get, 226)) ){
/*777*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 227), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)": cannot make static the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" non-static method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 228)), 1));
/*780*/ 	} else if( (! *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 56, Classes_0err_entry_get, 229) &&  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 56, Classes_0err_entry_get, 230)) ){
/*781*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 231), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)": cannot make non-static the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)" static method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 232)), 1));
/*787*/ 	}
/*787*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 60, Classes_0err_entry_get, 233) ){
/*788*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 234), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)": cannot override final method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 235)), 1));
/*793*/ 	}
/*793*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Classes_b, 52, Classes_0err_entry_get, 236) <  *(int *)m2runtime_dereference_rhs_RECORD(Classes_a, 52, Classes_0err_entry_get, 237)) ){
/*794*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 238), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)": cannot lower the visibility of the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 239)), 1));
/*799*/ 	}
/*799*/ 	Classes_err = Classes_CheckSign((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 240), (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 241));
/*800*/ 	if( Classes_err != NULL ){
/*801*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 242), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)": the signature `", Types_FunctionSignatureToString((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 16, Classes_0err_entry_get, 243)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' does not match the ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 244)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_FunctionSignatureToString((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 16, Classes_0err_entry_get, 245)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", Classes_err, 1));
/*809*/ 	}
/*809*/ 	Classes_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_a, 28, Classes_0err_entry_get, 246), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_b, 28, Classes_0err_entry_get, 247))));
/*810*/ 	if( Classes_err != NULL ){
/*811*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_b, 20, Classes_0err_entry_get, 248), m2runtime_concat_STRING(0, Scanner_mn(Classes_bc, Classes_b), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)": more exceptions thrown than declared in ", Classes_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)" method ", Scanner_mn(Classes_ac, Classes_a), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_a, 20, Classes_0err_entry_get, 249)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Classes_err, 1));
/*816*/ 	}
/*818*/ }


/*826*/ void
/*826*/ Classes_ResolveClassMethod(RECORD *Classes_class, STRING *Classes_id, RECORD **Classes_res_class, RECORD **Classes_res_method)
/*826*/ {
/*827*/ 	int Classes_i = 0;
/*829*/ 	RECORD * Classes_m = NULL;
/*829*/ 	if( Classes_class == NULL ){
/*830*/ 		*Classes_res_class = NULL;
/*831*/ 		*Classes_res_method = NULL;
/*833*/ 		return ;
/*836*/ 	}
/*836*/ 	Classes_m = Search_SearchClassMethod(Classes_class, Classes_id, TRUE);
/*837*/ 	if( Classes_m != NULL ){
/*839*/ 		*Classes_res_class = Classes_class;
/*840*/ 		*Classes_res_method = Classes_m;
/*842*/ 		return ;
/*845*/ 	}
/*845*/ 	Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_class, 16, Classes_0err_entry_get, 250), Classes_id, Classes_res_class, Classes_res_method);
/*846*/ 	if( *Classes_res_method != NULL ){
/*848*/ 		return ;
/*851*/ 	}
/*851*/ 	{
/*851*/ 		int m2runtime_for_limit_1;
/*851*/ 		Classes_i = 0;
/*851*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_class, 20, Classes_0err_entry_get, 251)) - 1);
/*852*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*852*/ 			Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_class, 20, Classes_0err_entry_get, 252), Classes_i, Classes_0err_entry_get, 253), Classes_id, Classes_res_class, Classes_res_method);
/*853*/ 			if( *Classes_res_method != NULL ){
/*855*/ 				return ;
/*857*/ 			}
/*859*/ 		}
/*859*/ 	}
/*859*/ 	*Classes_res_class = NULL;
/*860*/ 	*Classes_res_method = NULL;
/*864*/ }


/*871*/ void
/*871*/ Classes_InheritExceptions(ARRAY **Classes_new, ARRAY *Classes_old)
/*871*/ {

/*873*/ 	int
/*873*/ 	Classes_Contains(RECORD *Classes_c)
/*873*/ 	{
/*875*/ 		int Classes_i = 0;
/*875*/ 		{
/*875*/ 			int m2runtime_for_limit_1;
/*875*/ 			Classes_i = 0;
/*875*/ 			m2runtime_for_limit_1 = (m2runtime_count(*Classes_new) - 1);
/*876*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*876*/ 				if( (RECORD *)m2runtime_dereference_rhs_ARRAY(*Classes_new, Classes_i, Classes_0err_entry_get, 254) == Classes_c ){
/*877*/ 					return TRUE;
/*880*/ 				}
/*880*/ 			}
/*880*/ 		}
/*880*/ 		return FALSE;
/*884*/ 	}

/*886*/ 	int Classes_i = 0;
/*886*/ 	{
/*886*/ 		int m2runtime_for_limit_1;
/*886*/ 		Classes_i = 0;
/*886*/ 		m2runtime_for_limit_1 = (m2runtime_count(Classes_old) - 1);
/*887*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*887*/ 			if( !Classes_Contains((RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_old, Classes_i, Classes_0err_entry_get, 255)) ){
/*888*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(Classes_new, 4, 1, Classes_0err_entry_get, 256) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Classes_old, Classes_i, Classes_0err_entry_get, 257);
/*891*/ 			}
/*892*/ 		}
/*892*/ 	}
/*894*/ }


/*900*/ void
/*900*/ Classes_CheckOverriddenMethod(RECORD *Classes_c, RECORD *Classes_m)
/*900*/ {
/*901*/ 	RECORD * Classes_o_c = NULL;
/*902*/ 	RECORD * Classes_o_m = NULL;
/*905*/ 	int Classes_i = 0;

/*910*/ 	void
/*910*/ 	Classes_CheckImplementation(RECORD *Classes_c, RECORD *Classes_m, RECORD *Classes_if)
/*910*/ 	{
/*911*/ 		RECORD * Classes_i_m = NULL;
/*913*/ 		int Classes_i = 0;
/*913*/ 		if( Classes_if == NULL ){
/*915*/ 			return ;
/*916*/ 		}
/*916*/ 		Classes_i_m = Classes_SearchMethod(Classes_if, (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 258), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 12, Classes_0err_entry_get, 259), TRUE);
/*917*/ 		if( Classes_i_m != NULL ){
/*918*/ 			Classes_CheckOverridesImplements(Classes_if, Classes_i_m, Classes_c, Classes_m);
/*919*/ 			Classes_InheritExceptions((ARRAY **)m2runtime_dereference_lhs_RECORD(&Classes_m, 76, 9, 28, Classes_0err_entry_get, 260), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_i_m, 28, Classes_0err_entry_get, 261));
/*921*/ 		}
/*921*/ 		{
/*921*/ 			int m2runtime_for_limit_1;
/*921*/ 			Classes_i = 0;
/*921*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_if, 20, Classes_0err_entry_get, 262)) - 1);
/*922*/ 			for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*922*/ 				Classes_CheckImplementation(Classes_c, Classes_m, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_if, 20, Classes_0err_entry_get, 263), Classes_i, Classes_0err_entry_get, 264));
/*925*/ 			}
/*925*/ 		}
/*927*/ 	}

/*931*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c, 16, Classes_0err_entry_get, 265) != NULL ){
/*932*/ 		Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Classes_c, 16, Classes_0err_entry_get, 266), (STRING *)m2runtime_dereference_rhs_RECORD(Classes_m, 8, Classes_0err_entry_get, 267), &Classes_o_c, &Classes_o_m);
/*933*/ 		if( Classes_o_m == NULL ){
/*935*/ 		} else if( ((Classes_o_m == (RECORD *)m2runtime_dereference_rhs_RECORD(Classes_o_c, 40, Classes_0err_entry_get, 268)) && ! *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 48, Classes_0err_entry_get, 269)) ){
/*937*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 60, Classes_0err_entry_get, 270) ){
/*938*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Classes_c, Classes_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" cannot override the final method ", Scanner_mn(Classes_o_c, Classes_o_m), 1));
/*940*/ 		} else if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 52, Classes_0err_entry_get, 271) == 0)) && ((Globals_php_ver == 4))) ){
/*941*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the method ", Scanner_mn(Classes_c, Classes_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" cannot redefine the private method ", Scanner_mn(Classes_o_c, Classes_o_m), 1));
/*944*/ 		} else {
/*944*/ 			Classes_CheckOverridesImplements(Classes_o_c, Classes_o_m, Classes_c, Classes_m);
/*945*/ 			Classes_InheritExceptions((ARRAY **)m2runtime_dereference_lhs_RECORD(&Classes_m, 76, 9, 28, Classes_0err_entry_get, 272), (ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_o_m, 28, Classes_0err_entry_get, 273));
/*948*/ 		}
/*949*/ 	}
/*949*/ 	{
/*949*/ 		int m2runtime_for_limit_1;
/*949*/ 		Classes_i = 0;
/*949*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 20, Classes_0err_entry_get, 274)) - 1);
/*950*/ 		for( ; Classes_i <= m2runtime_for_limit_1; Classes_i += 1 ){
/*950*/ 			Classes_CheckImplementation(Classes_c, Classes_m, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Classes_c, 20, Classes_0err_entry_get, 275), Classes_i, Classes_0err_entry_get, 276));
/*953*/ 		}
/*953*/ 	}
/*956*/ }


char * Classes_0func[] = {
    "IsSubclassOf",
    "IsSubclassOfSet",
    "OrphanClasses",
    "ClassesList",
    "CloneSet",
    "cmp",
    "Sort",
    "pc",
    "SearchMethod",
    "MergeIConstArrays",
    "CollectConsts",
    "MergeIPropArrays",
    "CollectProps",
    "MergeIMethodArrays",
    "CollectMethods",
    "CheckImplementedMethods",
    "IsOverridingType",
    "CheckSign",
    "CheckOverridesImplements",
    "ResolveClassMethod",
    "Contains",
    "InheritExceptions",
    "CheckImplementation",
    "CheckOverriddenMethod"
};

int Classes_0err_entry[] = {
    0 /* IsSubclassOf */, 20,
    0 /* IsSubclassOf */, 23,
    0 /* IsSubclassOf */, 25,
    1 /* IsSubclassOfSet */, 37,
    2 /* OrphanClasses */, 52,
    2 /* OrphanClasses */, 53,
    2 /* OrphanClasses */, 54,
    3 /* ClassesList */, 69,
    3 /* ClassesList */, 69,
    4 /* CloneSet */, 81,
    4 /* CloneSet */, 82,
    5 /* cmp */, 96,
    5 /* cmp */, 96,
    5 /* cmp */, 98,
    6 /* Sort */, 108,
    6 /* Sort */, 108,
    6 /* Sort */, 110,
    6 /* Sort */, 110,
    6 /* Sort */, 111,
    6 /* Sort */, 111,
    7 /* pc */, 132,
    7 /* pc */, 136,
    7 /* pc */, 138,
    7 /* pc */, 142,
    7 /* pc */, 143,
    7 /* pc */, 143,
    7 /* pc */, 145,
    8 /* SearchMethod */, 175,
    8 /* SearchMethod */, 178,
    8 /* SearchMethod */, 178,
    8 /* SearchMethod */, 179,
    8 /* SearchMethod */, 180,
    9 /* MergeIConstArrays */, 222,
    9 /* MergeIConstArrays */, 223,
    9 /* MergeIConstArrays */, 230,
    9 /* MergeIConstArrays */, 230,
    9 /* MergeIConstArrays */, 230,
    9 /* MergeIConstArrays */, 230,
    9 /* MergeIConstArrays */, 232,
    9 /* MergeIConstArrays */, 233,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 235,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 237,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 243,
    9 /* MergeIConstArrays */, 244,
    9 /* MergeIConstArrays */, 244,
    9 /* MergeIConstArrays */, 244,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 246,
    9 /* MergeIConstArrays */, 247,
    9 /* MergeIConstArrays */, 247,
    9 /* MergeIConstArrays */, 247,
    10 /* CollectConsts */, 280,
    10 /* CollectConsts */, 285,
    10 /* CollectConsts */, 286,
    10 /* CollectConsts */, 286,
    10 /* CollectConsts */, 294,
    10 /* CollectConsts */, 296,
    10 /* CollectConsts */, 297,
    10 /* CollectConsts */, 297,
    10 /* CollectConsts */, 298,
    10 /* CollectConsts */, 298,
    11 /* MergeIPropArrays */, 332,
    11 /* MergeIPropArrays */, 333,
    11 /* MergeIPropArrays */, 340,
    11 /* MergeIPropArrays */, 340,
    11 /* MergeIPropArrays */, 340,
    11 /* MergeIPropArrays */, 340,
    11 /* MergeIPropArrays */, 342,
    11 /* MergeIPropArrays */, 343,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 345,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 348,
    11 /* MergeIPropArrays */, 349,
    11 /* MergeIPropArrays */, 349,
    11 /* MergeIPropArrays */, 349,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 359,
    11 /* MergeIPropArrays */, 360,
    11 /* MergeIPropArrays */, 360,
    11 /* MergeIPropArrays */, 360,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 362,
    11 /* MergeIPropArrays */, 363,
    11 /* MergeIPropArrays */, 363,
    11 /* MergeIPropArrays */, 363,
    12 /* CollectProps */, 392,
    12 /* CollectProps */, 410,
    12 /* CollectProps */, 412,
    12 /* CollectProps */, 413,
    12 /* CollectProps */, 413,
    12 /* CollectProps */, 414,
    12 /* CollectProps */, 414,
    13 /* MergeIMethodArrays */, 449,
    13 /* MergeIMethodArrays */, 450,
    13 /* MergeIMethodArrays */, 457,
    13 /* MergeIMethodArrays */, 457,
    13 /* MergeIMethodArrays */, 457,
    13 /* MergeIMethodArrays */, 457,
    13 /* MergeIMethodArrays */, 459,
    13 /* MergeIMethodArrays */, 460,
    13 /* MergeIMethodArrays */, 464,
    13 /* MergeIMethodArrays */, 466,
    13 /* MergeIMethodArrays */, 466,
    13 /* MergeIMethodArrays */, 466,
    13 /* MergeIMethodArrays */, 466,
    13 /* MergeIMethodArrays */, 466,
    13 /* MergeIMethodArrays */, 469,
    13 /* MergeIMethodArrays */, 469,
    13 /* MergeIMethodArrays */, 470,
    13 /* MergeIMethodArrays */, 470,
    13 /* MergeIMethodArrays */, 475,
    13 /* MergeIMethodArrays */, 475,
    13 /* MergeIMethodArrays */, 476,
    13 /* MergeIMethodArrays */, 476,
    13 /* MergeIMethodArrays */, 478,
    13 /* MergeIMethodArrays */, 478,
    13 /* MergeIMethodArrays */, 479,
    13 /* MergeIMethodArrays */, 479,
    14 /* CollectMethods */, 512,
    14 /* CollectMethods */, 513,
    14 /* CollectMethods */, 513,
    14 /* CollectMethods */, 521,
    14 /* CollectMethods */, 523,
    14 /* CollectMethods */, 524,
    14 /* CollectMethods */, 524,
    14 /* CollectMethods */, 525,
    14 /* CollectMethods */, 525,
    15 /* CheckImplementedMethods */, 578,
    15 /* CheckImplementedMethods */, 579,
    15 /* CheckImplementedMethods */, 580,
    15 /* CheckImplementedMethods */, 583,
    15 /* CheckImplementedMethods */, 583,
    15 /* CheckImplementedMethods */, 584,
    15 /* CheckImplementedMethods */, 584,
    15 /* CheckImplementedMethods */, 586,
    15 /* CheckImplementedMethods */, 586,
    15 /* CheckImplementedMethods */, 596,
    15 /* CheckImplementedMethods */, 597,
    15 /* CheckImplementedMethods */, 598,
    15 /* CheckImplementedMethods */, 598,
    15 /* CheckImplementedMethods */, 601,
    15 /* CheckImplementedMethods */, 601,
    15 /* CheckImplementedMethods */, 601,
    15 /* CheckImplementedMethods */, 603,
    15 /* CheckImplementedMethods */, 603,
    16 /* IsOverridingType */, 639,
    16 /* IsOverridingType */, 643,
    16 /* IsOverridingType */, 644,
    16 /* IsOverridingType */, 645,
    16 /* IsOverridingType */, 646,
    16 /* IsOverridingType */, 647,
    16 /* IsOverridingType */, 650,
    16 /* IsOverridingType */, 652,
    16 /* IsOverridingType */, 653,
    16 /* IsOverridingType */, 654,
    16 /* IsOverridingType */, 655,
    16 /* IsOverridingType */, 656,
    16 /* IsOverridingType */, 659,
    16 /* IsOverridingType */, 660,
    16 /* IsOverridingType */, 660,
    16 /* IsOverridingType */, 671,
    17 /* CheckSign */, 695,
    17 /* CheckSign */, 695,
    17 /* CheckSign */, 702,
    17 /* CheckSign */, 702,
    17 /* CheckSign */, 703,
    17 /* CheckSign */, 703,
    17 /* CheckSign */, 713,
    17 /* CheckSign */, 715,
    17 /* CheckSign */, 716,
    17 /* CheckSign */, 716,
    17 /* CheckSign */, 721,
    17 /* CheckSign */, 721,
    17 /* CheckSign */, 721,
    17 /* CheckSign */, 722,
    17 /* CheckSign */, 722,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 731,
    17 /* CheckSign */, 732,
    17 /* CheckSign */, 732,
    17 /* CheckSign */, 732,
    17 /* CheckSign */, 740,
    17 /* CheckSign */, 740,
    18 /* CheckOverridesImplements */, 756,
    18 /* CheckOverridesImplements */, 756,
    18 /* CheckOverridesImplements */, 757,
    18 /* CheckOverridesImplements */, 762,
    18 /* CheckOverridesImplements */, 769,
    18 /* CheckOverridesImplements */, 769,
    18 /* CheckOverridesImplements */, 770,
    18 /* CheckOverridesImplements */, 772,
    18 /* CheckOverridesImplements */, 776,
    18 /* CheckOverridesImplements */, 776,
    18 /* CheckOverridesImplements */, 777,
    18 /* CheckOverridesImplements */, 779,
    18 /* CheckOverridesImplements */, 780,
    18 /* CheckOverridesImplements */, 780,
    18 /* CheckOverridesImplements */, 781,
    18 /* CheckOverridesImplements */, 783,
    18 /* CheckOverridesImplements */, 787,
    18 /* CheckOverridesImplements */, 788,
    18 /* CheckOverridesImplements */, 789,
    18 /* CheckOverridesImplements */, 793,
    18 /* CheckOverridesImplements */, 793,
    18 /* CheckOverridesImplements */, 794,
    18 /* CheckOverridesImplements */, 795,
    18 /* CheckOverridesImplements */, 799,
    18 /* CheckOverridesImplements */, 799,
    18 /* CheckOverridesImplements */, 801,
    18 /* CheckOverridesImplements */, 802,
    18 /* CheckOverridesImplements */, 803,
    18 /* CheckOverridesImplements */, 804,
    18 /* CheckOverridesImplements */, 809,
    18 /* CheckOverridesImplements */, 809,
    18 /* CheckOverridesImplements */, 811,
    18 /* CheckOverridesImplements */, 813,
    19 /* ResolveClassMethod */, 845,
    19 /* ResolveClassMethod */, 851,
    19 /* ResolveClassMethod */, 852,
    19 /* ResolveClassMethod */, 852,
    20 /* Contains */, 876,
    21 /* InheritExceptions */, 887,
    21 /* InheritExceptions */, 888,
    21 /* InheritExceptions */, 889,
    22 /* CheckImplementation */, 916,
    22 /* CheckImplementation */, 916,
    22 /* CheckImplementation */, 919,
    22 /* CheckImplementation */, 919,
    22 /* CheckImplementation */, 921,
    22 /* CheckImplementation */, 922,
    22 /* CheckImplementation */, 922,
    23 /* CheckOverriddenMethod */, 931,
    23 /* CheckOverriddenMethod */, 932,
    23 /* CheckOverriddenMethod */, 932,
    23 /* CheckOverriddenMethod */, 935,
    23 /* CheckOverriddenMethod */, 935,
    23 /* CheckOverriddenMethod */, 937,
    23 /* CheckOverriddenMethod */, 940,
    23 /* CheckOverriddenMethod */, 945,
    23 /* CheckOverriddenMethod */, 945,
    23 /* CheckOverriddenMethod */, 949,
    23 /* CheckOverriddenMethod */, 950,
    23 /* CheckOverriddenMethod */, 950
};

void Classes_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Classes";
    *f = Classes_0func[ Classes_0err_entry[2*i] ];
    *l = Classes_0err_entry[2*i + 1];
}
