/* IMPLEMENTATION MODULE Statements */
#define M2_IMPORT_Statements

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_ParseDocBlock
#    include "ParseDocBlock.c"
#endif
/* 11*/ int Statements_recursive_parsing = 0;
/* 16*/ ARRAY * Statements_include_path = NULL;
/* 19*/ ARRAY * Statements_modules_abs_path = NULL;
/* 22*/ ARRAY * Statements_packages_abs_path = NULL;
/* 26*/ RECORD * Statements_curr_package = NULL;

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Documentator
#    include "Documentator.c"
#endif

#ifndef M2_IMPORT_Exceptions
#    include "Exceptions.c"
#endif

#ifndef M2_IMPORT_Expressions
#    include "Expressions.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Proto
#    include "Proto.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void Statements_0err_entry_get(int i, char **m, char **f, int *l);
/* 97*/ int Statements_loop_level = 0;
/*101*/ RECORD * Statements_pdb = NULL;

/*103*/ void
/*103*/ Statements_ParseEcho(void)
/*103*/ {
/*104*/ 	RECORD * Statements_r = NULL;
/*106*/ 	RECORD * Statements_t = NULL;
/*106*/ 	Scanner_ReadSym();
/*108*/ 	do{
/*108*/ 		Statements_r = Expressions_ParseExpr();
/*109*/ 		if( Statements_r == NULL ){
/*112*/ 		} else {
/*112*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 0);
/*113*/ 			if( ((Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type)) ){
/*116*/ 			} else if( Statements_t == Globals_boolean_type ){
/*117*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\151,\0,\0,\0)"found boolean value: remember that FALSE gets rendered as empty string \042\042 while TRUE gets rendered as \0421\042");
/*118*/ 			} else if( (((Globals_php_ver == 5)) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_t, 16, Statements_0err_entry_get, 1) == 9)) && (Search_SearchClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 2), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__toString", FALSE) != NULL)) ){
/*122*/ 			} else {
/*122*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"found argument of the type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)". The arguments of the `echo' statement must be of", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)" type int, float, string.", 1));
/*127*/ 			}
/*127*/ 		}
/*127*/ 		if( (Scanner_sym != 16) ){
/*130*/ 			goto m2runtime_loop_1;
/*130*/ 		}
/*130*/ 		Scanner_ReadSym();
/*133*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*135*/ }


/*137*/ void
/*137*/ Statements_ParseReturn(void)
/*137*/ {
/*138*/ 	RECORD * Statements_r = NULL;
/*139*/ 	RECORD * Statements_found = NULL;
/*139*/ 	RECORD * Statements_expected = NULL;
/*140*/ 	STRING * Statements_n = NULL;
/*141*/ 	RECORD * Statements_sign = NULL;
/*143*/ 	int Statements_no_expr = 0;
/*143*/ 	Scanner_ReadSym();
/*144*/ 	if( Globals_curr_func != NULL ){
/*145*/ 		Statements_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 28, Statements_0err_entry_get, 3);
/*146*/ 		Statements_expected = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 4);
/*147*/ 		Statements_n = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 8, Statements_0err_entry_get, 5), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"()'", 1);
/*148*/ 	} else if( Globals_curr_method != NULL ){
/*149*/ 		Statements_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 16, Statements_0err_entry_get, 6);
/*150*/ 		Statements_expected = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 7);
/*151*/ 		Statements_n = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Globals_curr_method), 1);
/*153*/ 	} else {
/*153*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"`return' in global scope");
/*155*/ 		if( (Scanner_sym != 17) ){
/*156*/ 			Statements_r = Expressions_ParseExpr();
/*159*/ 		}
/*160*/ 	}
/*160*/ 	if( (Scanner_sym == 17) ){
/*161*/ 		Statements_found = NULL;
/*162*/ 		Statements_no_expr = TRUE;
/*164*/ 	} else {
/*164*/ 		Statements_r = Expressions_ParseExpr();
/*165*/ 		if( Statements_r == NULL ){
/*166*/ 			Statements_found = NULL;
/*167*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 8) == Globals_void_type ){
/*168*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"the expression do not returns a value");
/*169*/ 			Statements_found = NULL;
/*171*/ 		} else {
/*171*/ 			Statements_found = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 9);
/*173*/ 		}
/*173*/ 		Statements_no_expr = FALSE;
/*176*/ 	}
/*176*/ 	if( Statements_expected == NULL ){
/*177*/ 		if( Statements_no_expr ){
/*178*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"from this `return;' we guess the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" is of type void", 1));
/*180*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 10) = Globals_void_type;
/*181*/ 		} else if( Statements_found == NULL ){
/*182*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"cannot determinate the type of the returned ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"expression. Presuming `mixed' and trying to continue anyway.", 1));
/*184*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 11) = Globals_mixed_type;
/*186*/ 		} else {
/*186*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"from this `return' we guess the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)" returns a value of type ", Types_TypeToString(Statements_found), 1));
/*188*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 12) = Statements_found;
/*191*/ 		}
/*191*/ 	} else {
/*191*/ 		if( Statements_no_expr ){
/*192*/ 			if( Statements_expected != Globals_void_type ){
/*193*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"missing returned value for ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)" declared of type ", Types_TypeToString(Statements_expected), 1));
/*196*/ 			}
/*196*/ 		} else if( Statements_found == NULL ){
/*197*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"cannot determinate the type of the returned ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"expression. The type of the value returned by the ", Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)" should be ", Types_TypeToString(Statements_expected), 1));
/*201*/ 		} else {
/*201*/ 			switch(Expressions_LhsMatchRhs(Statements_expected, Statements_found)){

/*202*/ 			case 0:
/*203*/ 			break;

/*203*/ 			case 1:
/*204*/ 			Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)": expected return type ", Types_TypeToString(Statements_expected), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)", found expression of type ", Types_TypeToString(Statements_found), 1));
/*208*/ 			break;

/*208*/ 			case 2:
/*209*/ 			Scanner_Error(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)": expected return type ", Types_TypeToString(Statements_expected), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)", found expression of type ", Types_TypeToString(Statements_found), 1));
/*214*/ 			break;

/*214*/ 			default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 13);
/*215*/ 			}
/*216*/ 		}
/*217*/ 	}
/*219*/ }


/*221*/ void
/*221*/ Statements_ParseTriggerError(void)
/*221*/ {
/*226*/ 	RECORD * Statements_r = NULL;
/*228*/ 	int Statements_err = 0;
/*228*/ 	Scanner_ReadSym();
/*229*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*230*/ 	Scanner_ReadSym();
/*235*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*236*/ 	if( (Scanner_sym == 13) ){
/*237*/ 		Scanner_ReadSym();
/*239*/ 		return ;
/*244*/ 	}
/*244*/ 	Scanner_Expect(16, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected `,' or `)'");
/*245*/ 	Scanner_ReadSym();
/*246*/ 	Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*247*/ 	Statements_err = 0;
/*248*/ 	if( Statements_r == NULL ){
/*250*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 14) == NULL ){
/*253*/ 	} else {
/*253*/ 		Statements_err = m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 15));
/*266*/ 	}
/*266*/ 	if( (Statements_err == 1024) ){
/*267*/ 		Statements_err = 0;
/*270*/ 	}
/*270*/ 	if( Globals_curr_func != NULL ){
/*271*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_func, 64, 10, 60, Statements_0err_entry_get, 16) = ( *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_func, 60, Statements_0err_entry_get, 17) | Statements_err);
/*272*/ 	} else if( Globals_curr_method != NULL ){
/*273*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Globals_curr_method, 76, 9, 72, Statements_0err_entry_get, 18) = ( *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 72, Statements_0err_entry_get, 19) | Statements_err);
/*280*/ 	}
/*280*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*281*/ 	Scanner_ReadSym();
/*286*/ }


/*304*/ void
/*304*/ Statements_DocBlockCheckAllowedLineTags(int Statements_allow, STRING *Statements_documenting_what)
/*304*/ {

/*306*/ 	void
/*306*/ 	Statements_err(STRING *Statements_tag)
/*306*/ 	{
/*306*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"invalid DocBlock line tag `", Statements_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"': not allowed for ", Statements_documenting_what, 1));
/*311*/ 	}

/*311*/ 	if( Statements_pdb == NULL ){
/*313*/ 		return ;
/*315*/ 	}
/*315*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 20) != NULL) && (((Statements_allow & 2) == 0))) ){
/*316*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@var");
/*318*/ 	}
/*318*/ 	if( (((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 28, Statements_0err_entry_get, 21) != NULL) && (((Statements_allow & 4) == 0))) ){
/*319*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@param");
/*321*/ 	}
/*321*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 22) != NULL) && (((Statements_allow & 8) == 0))) ){
/*322*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@return");
/*324*/ 	}
/*324*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 23) && (((Statements_allow & 16) == 0))) ){
/*325*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract");
/*327*/ 	}
/*327*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 64, Statements_0err_entry_get, 24) && (((Statements_allow & 32) == 0))) ){
/*328*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static");
/*330*/ 	}
/*330*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 60, Statements_0err_entry_get, 25) && (((Statements_allow & 64) == 0))) ){
/*331*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final");
/*333*/ 	}
/*333*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 26) && (((Statements_allow & 128) == 0))) ){
/*334*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"@access private");
/*336*/ 	}
/*336*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 27) && (((Statements_allow & 256) == 0))) ){
/*337*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"@access protected");
/*339*/ 	}
/*339*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 28) && (((Statements_allow & 512) == 0))) ){
/*340*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"@access public");
/*342*/ 	}
/*342*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 29) && (((Statements_allow & 1) == 0))) ){
/*343*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package");
/*345*/ 	}
/*345*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 30) != NULL) && (((Statements_allow & 1024) == 0))) ){
/*346*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*348*/ 	}
/*348*/ 	if( (((m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 31)) > 0)) && (((Statements_allow & 2048) == 0))) ){
/*349*/ 		Statements_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@throws");
/*352*/ 	}
/*354*/ }


/*356*/ void
/*356*/ Statements_FatalUnsupportedOldStyleSyntax(void)
/*356*/ {
/*356*/ 	Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"unsupported old-style syntax. Please use {...} instead.");
/*361*/ }

	static int Statements_ForwardParseStatement(void);
	static RECORD * Statements_ParsePackage(STRING *s, int module);

/*366*/ int
/*366*/ Statements_ParseStatement(void)
/*366*/ {
	return Statements_ForwardParseStatement();
/*368*/ 	m2runtime_missing_return(Statements_0err_entry_get, 32);
/*368*/ 	return 0;
/*370*/ }


/*378*/ int
/*378*/ Statements_ParseBlock(void)
/*378*/ {
/*378*/ 	if( (Scanner_sym == 18) ){
/*379*/ 		Statements_FatalUnsupportedOldStyleSyntax();
/*381*/ 	} else {
/*381*/ 		return Statements_ParseStatement();
/*384*/ 	}
/*384*/ 	m2runtime_missing_return(Statements_0err_entry_get, 33);
/*384*/ 	return 0;
/*386*/ }


/*393*/ int
/*393*/ Statements_ParseArgsListDecl(RECORD *Statements_sign, STRING *Statements_function_or_module)
/*393*/ {
/*394*/ 	RECORD * Statements_a = NULL;
/*395*/ 	RECORD * Statements_r = NULL;
/*396*/ 	RECORD * Statements_v = NULL;
/*397*/ 	int Statements_guess = 0;
/*398*/ 	int Statements_opt_arg = 0;
/*400*/ 	RECORD * Statements_p = NULL;
/*400*/ 	Scanner_Expect(12, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected '(' in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*401*/ 	Scanner_ReadSym();
/*404*/ 	do{
/*404*/ 		if( (Scanner_sym == 13) ){
/*407*/ 			goto m2runtime_loop_1;
/*408*/ 		}
/*408*/ 		if( (Scanner_sym == 152) ){
/*409*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 24, Statements_0err_entry_get, 34) = TRUE;
/*410*/ 			Scanner_ReadSym();
/*413*/ 			goto m2runtime_loop_1;
/*417*/ 		}
/*417*/ 		Statements_a = NULL;
/*418*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 35) = Expressions_ParseType(TRUE);
/*419*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 36) == Globals_void_type ){
/*420*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"argument of type `void' not allowed");
/*426*/ 		}
/*426*/ 		if( (Scanner_sym == 73) ){
/*427*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 20, Statements_0err_entry_get, 37) = TRUE;
/*428*/ 			Scanner_ReadSym();
/*434*/ 		}
/*434*/ 		Scanner_Expect(20, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected name of the formal argument in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*436*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 8, Statements_0err_entry_get, 38) = Scanner_s;
/*442*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 39) == NULL) && (Statements_pdb != NULL)) ){
/*443*/ 			Statements_p = ParseDocBlock_SearchParam(Statements_pdb, Scanner_s);
/*444*/ 			if( Statements_p == NULL ){
/*445*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"missing `@param TYPE $", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"' in DocBlock above", 1));
/*447*/ 			} else {
/*447*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 40) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 41);
/*448*/ 				if( (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 42) && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 43)) || (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 44) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 45))) ){
/*451*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\106,\0,\0,\0)"conflicting passing method between DocBlock @param and actual PHP code");
/*454*/ 				}
/*455*/ 			}
/*459*/ 		}
/*459*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*460*/ 		Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*461*/ 		if( ((Globals_curr_method != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 48, Statements_0err_entry_get, 46)) ){
/*462*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 48, Statements_0err_entry_get, 47) = 100;
/*464*/ 		}
/*464*/ 		Scanner_ReadSym();
/*469*/ 		if( (Scanner_sym == 31) ){
/*470*/ 			if( (((Globals_php_ver == 4)) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 48)) ){
/*471*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\111,\0,\0,\0)"can't assign default value to formal argument passed by reference (PHP 5)");
/*473*/ 			}
/*473*/ 			Statements_opt_arg = TRUE;
/*474*/ 			Scanner_ReadSym();
/*475*/ 			Statements_r = Expressions_ParseStaticExpr();
/*476*/ 			if( Statements_r == NULL ){
/*478*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 49) == NULL ){
/*479*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 50) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 51);
/*480*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 16, Statements_0err_entry_get, 52) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 53);
/*482*/ 			} else {
/*482*/ 				switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 54), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 55))){

/*483*/ 				case 1:
/*484*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"type mismatch: formal argument of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 56)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)", default expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 57)), 1));
/*487*/ 				break;

/*487*/ 				case 2:
/*488*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"type mismatch: formal argument of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 58)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)", default expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 59)), 1));
/*492*/ 				break;
/*493*/ 				}
/*493*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 16, Statements_0err_entry_get, 60) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 61);
/*495*/ 			}
/*495*/ 		} else if( Statements_opt_arg ){
/*496*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing default value for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 62), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"'. Hint: mandatory arguments can't follow the default ones.", 1));
/*499*/ 		}
/*499*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 63) == NULL ){
/*500*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_a, 24, 3, 12, Statements_0err_entry_get, 64) = Globals_mixed_type;
/*501*/ 			Statements_guess = TRUE;
/*502*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"undefined type for argument `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 65), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\154,\0,\0,\0)"', presuming `mixed' and trying to continue anyway. Hint: either use an explicit type (example: `/*.int.*/ $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 66), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"')", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)" or assign a default value (example: `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 67), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"=123').", 1));
/*507*/ 		}
/*507*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 68) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 69);
/*508*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 24, Statements_0err_entry_get, 70) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_a, 16, Statements_0err_entry_get, 71);
/*509*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 12, Statements_0err_entry_get, 72), 4, 1, Statements_0err_entry_get, 73) = Statements_a;
/*510*/ 		if( !Statements_opt_arg ){
/*511*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 20, Statements_0err_entry_get, 74), 1);
/*514*/ 		}
/*514*/ 		if( (Scanner_sym == 16) ){
/*515*/ 			Scanner_ReadSym();
/*517*/ 		} else if( (Scanner_sym == 131) ){
/*518*/ 			Scanner_ReadSym();
/*519*/ 			Scanner_Expect(152, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"expected `args'");
/*520*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 24, Statements_0err_entry_get, 75) = TRUE;
/*521*/ 			Scanner_ReadSym();
/*525*/ 			goto m2runtime_loop_1;
/*526*/ 		} else {
/*528*/ 			goto m2runtime_loop_1;
/*529*/ 		}
/*529*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*529*/ 	Scanner_Expect(13, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected ')' or ',' in ", Statements_function_or_module, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" declaration", 1));
/*531*/ 	Scanner_ReadSym();
/*532*/ 	return Statements_guess;
/*536*/ }


/*541*/ int
/*541*/ Statements_eqbool(int Statements_a, int Statements_b)
/*541*/ {
/*541*/ 	return ((Statements_a && Statements_b) || (!Statements_a && !Statements_b));
/*545*/ }


/*546*/ int
/*546*/ Statements_SameSign(RECORD *Statements_a, RECORD *Statements_b)
/*546*/ {
/*548*/ 	int Statements_i = 0;
/*548*/ 	if( (!Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_a, 8, Statements_0err_entry_get, 76), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_b, 8, Statements_0err_entry_get, 77)) || !Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 16, Statements_0err_entry_get, 78),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_b, 16, Statements_0err_entry_get, 79))) ){
/*551*/ 		return FALSE;
/*553*/ 	}
/*553*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_a, 20, Statements_0err_entry_get, 80) !=  *(int *)m2runtime_dereference_rhs_RECORD(Statements_b, 20, Statements_0err_entry_get, 81)) ){
/*554*/ 		return FALSE;
/*556*/ 	}
/*556*/ 	if( (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 82)) != m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 83))) ){
/*557*/ 		return FALSE;
/*559*/ 	}
/*559*/ 	{
/*559*/ 		int m2runtime_for_limit_1;
/*559*/ 		Statements_i = 0;
/*559*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 84)) - 1);
/*560*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*560*/ 			if( (!Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 85), Statements_i, Statements_0err_entry_get, 86), 12, Statements_0err_entry_get, 87), (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 88), Statements_i, Statements_0err_entry_get, 89), 12, Statements_0err_entry_get, 90)) || !Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_a, 12, Statements_0err_entry_get, 91), Statements_i, Statements_0err_entry_get, 92), 20, Statements_0err_entry_get, 93),  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_b, 12, Statements_0err_entry_get, 94), Statements_i, Statements_0err_entry_get, 95), 20, Statements_0err_entry_get, 96))) ){
/*563*/ 				return FALSE;
/*566*/ 			}
/*566*/ 		}
/*566*/ 	}
/*566*/ 	return TRUE;
/*570*/ }


/*576*/ void
/*576*/ Statements_ParseFuncDecl(int Statements_private, RECORD *Statements_t)
/*576*/ {

/*577*/ 	void
/*577*/ 	Statements_AccountFuncDecl(STRING *Statements_name, int Statements_private)
/*577*/ 	{
/*577*/ 		RECORD * Statements_f = NULL;
/*579*/ 		STRING * Statements_name_upper = NULL;
/*579*/ 		if( (Globals_scope > 0) ){
/*580*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"' nested inside another function.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)" The scope of this function is global but it will exist only if", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)" the parent function will be called. If the parent function is", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)" called once more, this will give a fatal error.", 1));
/*586*/ 		}
/*586*/ 		Statements_name_upper = str_toupper(Statements_name);
/*587*/ 		if( (((m2runtime_length(Statements_name) >= 2)) && (m2runtime_strcmp(m2runtime_substr(Statements_name, 0, 2, 1, Statements_0err_entry_get, 97), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") == 0)) ){
/*588*/ 			if( m2runtime_strcmp(Statements_name_upper, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__AUTOLOAD") == 0 ){
/*589*/ 				if( (Globals_php_ver == 4) ){
/*590*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"function name `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"' is reserved for special use in PHP 5", 1));
/*593*/ 				}
/*593*/ 			} else {
/*593*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"': names beginning with two underscores are reserved for future extensions of the language, do not use", 1));
/*596*/ 			}
/*597*/ 		}
/*597*/ 		Statements_f = Search_SearchFunc(Statements_name, TRUE);
/*598*/ 		if( Statements_f == NULL ){
/*599*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 8, Statements_0err_entry_get, 98) = Statements_name;
/*600*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 12, Statements_0err_entry_get, 99) = Statements_name_upper;
/*601*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 52, Statements_0err_entry_get, 100) = Statements_private;
/*602*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 16, Statements_0err_entry_get, 101) = Scanner_here();
/*603*/ 			if( !Accounting_report_unused ){
/*604*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 56, Statements_0err_entry_get, 102) = 100;
/*606*/ 			}
/*606*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 24, Statements_0err_entry_get, 103) = NULL;
/*607*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 28, Statements_0err_entry_get, 104) = NULL;
/*608*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_funcs, 4, 1, Statements_0err_entry_get, 105) = Statements_f;
/*609*/ 		} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 106) == NULL ){
/*610*/ 			if( (Statements_private && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 107), 8, Statements_0err_entry_get, 108)) != 0)) ){
/*611*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"private function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"' declared after being used in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 24, Statements_0err_entry_get, 109)), 1));
/*615*/ 			} else {
/*615*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"' declared after being used in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 24, Statements_0err_entry_get, 110)), 1));
/*621*/ 			}
/*621*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 8, Statements_0err_entry_get, 111) = Statements_name;
/*622*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 16, Statements_0err_entry_get, 112) = Scanner_here();
/*624*/ 		} else {
/*624*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 113)), 1));
/*628*/ 		}
/*631*/ 	}

/*632*/ 	RECORD * Statements_f = NULL;
/*633*/ 	RECORD * Statements_parent_func = NULL;
/*634*/ 	RECORD * Statements_old_sign = NULL;
/*634*/ 	RECORD * Statements_sign = NULL;
/*635*/ 	int Statements_guess = 0;
/*636*/ 	RECORD * Statements_proto_in = NULL;
/*637*/ 	ARRAY * Statements_proto_exceptions = NULL;
/*638*/ 	STRING * Statements_err = NULL;
/*640*/ 	int Statements_res = 0;
/*641*/ 	Statements_DocBlockCheckAllowedLineTags((((4 | 8) | 128) | 2048), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function");
/*644*/ 	if( (!Statements_private && (Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 114)) ){
/*645*/ 		Statements_private = TRUE;
/*648*/ 	}
/*648*/ 	if( ((Statements_t == NULL) && (Statements_pdb != NULL)) ){
/*649*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 115) == NULL ){
/*650*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"missing `@return TYPE' declaration in DocBlock above");
/*652*/ 		} else {
/*652*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 116);
/*655*/ 		}
/*655*/ 	}
/*655*/ 	if( Statements_t == NULL ){
/*656*/ 		Statements_guess = TRUE;
/*658*/ 	}
/*658*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 117) = Statements_t;
/*660*/ 	Scanner_ReadSym();
/*662*/ 	if( (Scanner_sym == 73) ){
/*663*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 16, Statements_0err_entry_get, 118) = TRUE;
/*664*/ 		if( (Globals_php_ver == 5) ){
/*665*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*667*/ 		}
/*667*/ 		Scanner_ReadSym();
/*674*/ 	}
/*674*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"expected function name after `function'");
/*675*/ 	Statements_f = Search_SearchFunc(Scanner_s, FALSE);
/*676*/ 	if( Statements_f == NULL ){
/*677*/ 		Statements_AccountFuncDecl(Scanner_s, Statements_private);
/*678*/ 		Statements_f = Search_SearchFunc(Scanner_s, FALSE);
/*679*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 48, Statements_0err_entry_get, 119) ){
/*680*/ 		Statements_old_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 28, Statements_0err_entry_get, 120);
/*681*/ 		Statements_proto_in = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 121);
/*682*/ 		Statements_proto_exceptions = Classes_CloneSet((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 122));
/*683*/ 		if( (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 52, Statements_0err_entry_get, 123) && !Statements_private) || (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 52, Statements_0err_entry_get, 124) && Statements_private)) ){
/*685*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"mismatch on the `private' attribute, check prototype in ", Scanner_reference(Statements_proto_in), 1));
/*687*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 52, Statements_0err_entry_get, 125) = Statements_private;
/*689*/ 		}
/*690*/ 	} else {
/*690*/ 		Statements_old_sign = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 28, Statements_0err_entry_get, 126);
/*691*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 52, Statements_0err_entry_get, 127) = Statements_private;
/*693*/ 	}
/*693*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 28, Statements_0err_entry_get, 128) = Statements_sign;
/*694*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 16, Statements_0err_entry_get, 129) = Scanner_here();
/*695*/ 	Statements_parent_func = Globals_curr_func;
/*696*/ 	Globals_curr_func = Statements_f;
/*697*/ 	m2_inc(&Globals_scope, 1);
/*698*/ 	Scanner_ReadSym();
/*703*/ 	if( Statements_ParseArgsListDecl(Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function") ){
/*704*/ 		Statements_guess = TRUE;
/*710*/ 	}
/*710*/ 	if( (Scanner_sym == 173) ){
/*711*/ 		Exceptions_ParseThrows();
/*718*/ 	}
/*718*/ 	if( ((Statements_pdb != NULL) && ((m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 130)) > 0))) ){
/*719*/ 		Exceptions_AddPdbExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 131));
/*726*/ 	}
/*726*/ 	if( Statements_pdb != NULL ){
/*727*/ 		*(ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 36, Statements_0err_entry_get, 132) = (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 36, Statements_0err_entry_get, 133);
/*733*/ 	}
/*733*/ 	if( (Scanner_sym == 174) ){
/*734*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 40, Statements_0err_entry_get, 134) = Scanner_s;
/*735*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 44, Statements_0err_entry_get, 135) = Documentator_ExtractDeprecated(Scanner_s);
/*736*/ 		Scanner_ReadSym();
/*737*/ 	} else if( Statements_pdb != NULL ){
/*738*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 40, Statements_0err_entry_get, 136) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 137);
/*739*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 44, Statements_0err_entry_get, 138) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 139));
/*740*/ 		Statements_pdb = NULL;
/*746*/ 	}
/*746*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected '{' in function body declaration");
/*747*/ 	Statements_res = Statements_ParseBlock();
/*748*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 140) == NULL ){
/*750*/ 		Statements_guess = TRUE;
/*751*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 141) = Globals_void_type;
/*752*/ 	} else if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 142) != Globals_void_type) && (((Statements_res & 1) != 0)) && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 20, Statements_0err_entry_get, 143)) ){
/*758*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 144), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\105,\0,\0,\0)"missing `return' in at least one execution path in non-void function ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 145), 1));
/*761*/ 	}
/*761*/ 	Expressions_CleanCurrentScope();
/*762*/ 	m2_inc(&Globals_scope, -1);
/*763*/ 	Globals_curr_func = Statements_parent_func;
/*765*/ 	if( Statements_guess ){
/*766*/ 		Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 146), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"guessed signature of the function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 147), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"()' as ", Types_FunctionSignatureToString(Statements_sign), 1));
/*770*/ 	}
/*770*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 48, Statements_0err_entry_get, 148) ){
/*771*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 56, Statements_0err_entry_get, 149) == 0) ){
/*772*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 150), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference(Statements_proto_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)" but never used before implementation", 1));
/*775*/ 		}
/*775*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_f, 64, 10, 48, Statements_0err_entry_get, 151) = FALSE;
/*776*/ 		if( !Statements_SameSign(Statements_old_sign, Statements_sign) ){
/*777*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 152), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 153), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"()': the actual signature ", Types_FunctionSignatureToString(Statements_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)" does not match the prototype ", Types_FunctionSignatureToString(Statements_old_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)" as declared in ", Scanner_reference(Statements_proto_in), 1));
/*783*/ 		}
/*783*/ 		Statements_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses(Statements_proto_exceptions, (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 154))));
/*784*/ 		if( m2runtime_strcmp(Statements_err, NULL) > 0 ){
/*785*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 155), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 156), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\112,\0,\0,\0)"()' throws more exceptions than those listed in the prototype declared in ", Scanner_reference(Statements_proto_in), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Statements_err, 1));
/*789*/ 		}
/*789*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 157) != NULL ){
/*790*/ 		if( !Statements_SameSign(Statements_old_sign, Statements_sign) ){
/*791*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 158), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 159), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()': declared signature ", Types_FunctionSignatureToString(Statements_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)" differs from signature ", Types_FunctionSignatureToString(Statements_old_sign), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)" as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 160)), 1));
/*797*/ 		}
/*797*/ 		if( (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 161) != NULL ){
/*798*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 162), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 163), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"()' as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 20, Statements_0err_entry_get, 164)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)" throws unexpected exceptions: ", Classes_ClassesList((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_f, 32, Statements_0err_entry_get, 165)), 1));
/*804*/ 		}
/*806*/ 	}
/*808*/ }


/*809*/ void
/*809*/ Statements_ParseBreak(void)
/*809*/ {
/*811*/ 	RECORD * Statements_r = NULL;
/*811*/ 	if( (Statements_loop_level == 0) ){
/*812*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"`break' MUST be inside a loop or a switch");
/*814*/ 	}
/*814*/ 	Scanner_ReadSym();
/*815*/ 	if( (Scanner_sym != 17) ){
/*816*/ 		Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*817*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"`break EXPR'", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)": unadvised programming practice; can't check", 1));
/*821*/ 	}
/*823*/ }


/*824*/ void
/*824*/ Statements_ParseContinue(void)
/*824*/ {
/*826*/ 	RECORD * Statements_r = NULL;
/*826*/ 	if( (Statements_loop_level == 0) ){
/*827*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"`continue' MUST be inside a loop or a switch");
/*829*/ 	}
/*829*/ 	Scanner_ReadSym();
/*830*/ 	if( (Scanner_sym != 17) ){
/*831*/ 		Statements_r = Expressions_ParseExprOfType(Globals_int_type);
/*832*/ 		Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"'continue EXPR'", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)": unadvised programming practice", 1));
/*836*/ 	}
/*838*/ }


/*843*/ int
/*843*/ Statements_ParseCompound(void)
/*843*/ {
/*845*/ 	int Statements_p = 0;
/*845*/ 	int Statements_res = 0;
/*845*/ 	Scanner_ReadSym();
/*846*/ 	Statements_res = 1;
/*847*/ 	while( (Scanner_sym != 11) ){
/*848*/ 		if( ((Statements_res & 1) == 0) ){
/*849*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unreachable statement");
/*851*/ 		}
/*851*/ 		Statements_p = Statements_ParseStatement();
/*852*/ 		Statements_res = (((Statements_res & ~1)) | Statements_p);
/*854*/ 	}
/*854*/ 	Scanner_ReadSym();
/*855*/ 	return Statements_res;
/*859*/ }


/*861*/ int
/*861*/ Statements_ParseWhile(void)
/*861*/ {
/*862*/ 	RECORD * Statements_r = NULL;
/*864*/ 	int Statements_res = 0;
/*864*/ 	Scanner_ReadSym();
/*865*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*866*/ 	Scanner_ReadSym();
/*867*/ 	Statements_r = Expressions_ParseExpr();
/*868*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"expected closing ')' of the 'while' statement");
/*869*/ 	Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"`while(EXPR)'", Statements_r);
/*870*/ 	Scanner_ReadSym();
/*871*/ 	m2_inc(&Statements_loop_level, 1);
/*872*/ 	Statements_res = Statements_ParseBlock();
/*873*/ 	m2_inc(&Statements_loop_level, -1);
/*874*/ 	return ((Statements_res & 8) | 1);
/*878*/ }


/*880*/ int
/*880*/ Statements_ParseDo(void)
/*880*/ {
/*881*/ 	RECORD * Statements_r = NULL;
/*883*/ 	int Statements_p = 0;
/*883*/ 	int Statements_res = 0;
/*883*/ 	Scanner_ReadSym();
/*884*/ 	m2_inc(&Statements_loop_level, 1);
/*885*/ 	Statements_p = Statements_ParseBlock();
/*886*/ 	m2_inc(&Statements_loop_level, -1);
/*887*/ 	Scanner_Expect(24, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected 'while' in do...while() statement");
/*888*/ 	Scanner_ReadSym();
/*889*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*890*/ 	Scanner_ReadSym();
/*891*/ 	Statements_r = Expressions_ParseExpr();
/*892*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"expected closing ')' of while(...)");
/*893*/ 	Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"`do ... while(EXPR)'", Statements_r);
/*894*/ 	Scanner_ReadSym();
/*895*/ 	Statements_res = (Statements_p & 8);
/*896*/ 	if( ((Statements_p & ((1 | 2))) != 0) ){
/*897*/ 		Statements_res = (Statements_res | 1);
/*899*/ 	}
/*899*/ 	return Statements_res;
/*903*/ }


/*908*/ int
/*908*/ Statements_ParseFor(void)
/*908*/ {
/*909*/ 	RECORD * Statements_r = NULL;
/*911*/ 	int Statements_p = 0;
/*911*/ 	int Statements_res = 0;
/*911*/ 	Scanner_ReadSym();
/*912*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected '('");
/*913*/ 	Scanner_ReadSym();
/*916*/ 	if( (Scanner_sym != 17) ){
/*917*/ 		Statements_r = Expressions_ParseExprList();
/*919*/ 	}
/*919*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*920*/ 	Scanner_ReadSym();
/*923*/ 	if( (Scanner_sym != 17) ){
/*924*/ 		Statements_res = 1;
/*925*/ 		Statements_r = Expressions_ParseExprList();
/*926*/ 		Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"`for(...; EXPR; ...)'", Statements_r);
/*928*/ 	}
/*928*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*929*/ 	Scanner_ReadSym();
/*932*/ 	if( (Scanner_sym != 13) ){
/*933*/ 		Statements_r = Expressions_ParseExprList();
/*935*/ 	}
/*935*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"expected closing `)' of the `for' statement");
/*936*/ 	Scanner_ReadSym();
/*938*/ 	m2_inc(&Statements_loop_level, 1);
/*939*/ 	Statements_p = Statements_ParseBlock();
/*940*/ 	m2_inc(&Statements_loop_level, -1);
/*943*/ 	if( ((Statements_p & 2) != 0) ){
/*944*/ 		Statements_res = (Statements_res | 1);
/*947*/ 	}
/*947*/ 	Statements_res = (Statements_res | ((Statements_p & 8)));
/*948*/ 	return Statements_res;
/*952*/ }


/*959*/ int
/*959*/ Statements_ParseForeach(void)
/*959*/ {
/*960*/ 	RECORD * Statements_r = NULL;
/*961*/ 	RECORD * Statements_elem_type = NULL;
/*961*/ 	RECORD * Statements_index_type = NULL;
/*962*/ 	RECORD * Statements_v = NULL;
/*962*/ 	RECORD * Statements_k = NULL;
/*963*/ 	int Statements_by_addr = 0;
/*965*/ 	int Statements_p = 0;
/*965*/ 	int Statements_res = 0;
/*965*/ 	Scanner_ReadSym();
/*966*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"required `(' after `foreach'");
/*967*/ 	Scanner_ReadSym();
/*970*/ 	Statements_r = Expressions_ParseExpr();
/*971*/ 	Statements_index_type = Globals_mixed_type;
/*972*/ 	Statements_elem_type = Globals_mixed_type;
/*973*/ 	if( Statements_r == NULL ){
/*975*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 166), 16, Statements_0err_entry_get, 167) == 6) ){
/*976*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 168), 20, Statements_0err_entry_get, 169)){

/*977*/ 		case 1:
/*977*/ 		Statements_index_type = Globals_mixed_type;
/*978*/ 		break;

/*978*/ 		case 3:
/*978*/ 		Statements_index_type = Globals_int_type;
/*979*/ 		break;

/*979*/ 		case 5:
/*979*/ 		Statements_index_type = Globals_string_type;
/*980*/ 		break;

/*980*/ 		case 7:
/*980*/ 		Statements_index_type = Globals_mixed_type;
/*982*/ 		break;

/*982*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 170);
/*982*/ 		}
/*982*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 171), 8, Statements_0err_entry_get, 172) != NULL ){
/*983*/ 			Statements_elem_type = (RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 173), 8, Statements_0err_entry_get, 174);
/*985*/ 		}
/*985*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 175), 16, Statements_0err_entry_get, 176) == 9) ){
/*988*/ 	} else {
/*988*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"`foreach(EXPR' requires an array or an object, found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 177)), 1));
/*993*/ 	}
/*993*/ 	Scanner_Expect(23, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\75,\0,\0,\0)"expected `as'. Hint: check `foreach( ARRAY_EXPRESSION as ...'");
/*994*/ 	Scanner_ReadSym();
/*997*/ 	if( (Scanner_sym == 73) ){
/*998*/ 		if( (Globals_php_ver == 4) ){
/*999*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"can't use `&' in `foreach' (PHP 5)");
/*1001*/ 		}
/*1001*/ 		Statements_by_addr = TRUE;
/*1002*/ 		Scanner_ReadSym();
/*1006*/ 	}
/*1006*/ 	Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"`foreach': expected variable name");
/*1007*/ 	Accounting_AccountVarLHS(Scanner_s, FALSE);
/*1008*/ 	Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*1009*/ 	Scanner_ReadSym();
/*1012*/ 	if( (Scanner_sym == 32) ){
/*1013*/ 		if( Statements_by_addr ){
/*1014*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"the key cannot be passed by reference");
/*1015*/ 			Statements_by_addr = FALSE;
/*1017*/ 		}
/*1017*/ 		Statements_k = Statements_v;
/*1018*/ 		Scanner_ReadSym();
/*1019*/ 		if( (Scanner_sym == 73) ){
/*1020*/ 			Statements_by_addr = TRUE;
/*1021*/ 			Scanner_ReadSym();
/*1023*/ 		}
/*1023*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"`foreach': expected variable name after `=>'");
/*1024*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*1025*/ 		Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*1026*/ 		Scanner_ReadSym();
/*1029*/ 	}
/*1029*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected closing `)' of the `foreach' statement");
/*1030*/ 	Scanner_ReadSym();
/*1035*/ 	if( Statements_k == NULL ){
/*1037*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 178) == NULL ){
/*1039*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_k, 52, 7, 20, Statements_0err_entry_get, 179) = Statements_index_type;
/*1042*/ 	} else {
/*1042*/ 		switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 180), Statements_index_type)){

/*1043*/ 		case 0:
/*1044*/ 		break;

/*1044*/ 		case 1:
/*1045*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_k, 8, Statements_0err_entry_get, 181), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 182)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)" does not match the index of ", Types_TypeToString(Statements_index_type), 1));
/*1048*/ 		break;

/*1048*/ 		case 2:
/*1049*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_k, 8, Statements_0err_entry_get, 183), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_k, 20, Statements_0err_entry_get, 184)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)" does not match the index of ", Types_TypeToString(Statements_index_type), 1));
/*1053*/ 		break;

/*1053*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 185);
/*1054*/ 		}
/*1065*/ 	}
/*1065*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 186) == NULL ){
/*1066*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 187) = Statements_elem_type;
/*1068*/ 	} else {
/*1068*/ 		switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 188), Statements_elem_type)){

/*1069*/ 		case 0:
/*1070*/ 		break;

/*1070*/ 		case 1:
/*1071*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_v, 8, Statements_0err_entry_get, 189), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 190)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)" does not match the elements of the array ", Types_TypeToString(Statements_elem_type), 1));
/*1075*/ 		break;

/*1075*/ 		case 2:
/*1076*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"foreach(): the type of the variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_v, 8, Statements_0err_entry_get, 191), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_v, 20, Statements_0err_entry_get, 192)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)" does not match the elements of the array ", Types_TypeToString(Statements_elem_type), 1));
/*1081*/ 		break;

/*1081*/ 		default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 193);
/*1082*/ 		}
/*1083*/ 	}
/*1083*/ 	m2_inc(&Statements_loop_level, 1);
/*1084*/ 	Statements_p = Statements_ParseBlock();
/*1085*/ 	m2_inc(&Statements_loop_level, -1);
/*1087*/ 	Statements_res = (1 | (Statements_p & 8));
/*1088*/ 	return Statements_res;
/*1092*/ }


/*1094*/ int
/*1094*/ Statements_ParseSwitch(void)
/*1094*/ {

/*1096*/ 	void
/*1096*/ 	Statements_CheckAndDiscardUnreachableStatements(void)
/*1096*/ 	{
/*1098*/ 		int Statements_res = 0;
/*1098*/ 		if( (((Scanner_sym == 110)) || ((Scanner_sym == 112)) || ((Scanner_sym == 164)) || ((Scanner_sym == 11))) ){
/*1105*/ 			return ;
/*1107*/ 		}
/*1107*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unreachable statement");
/*1110*/ 		do {
/*1110*/ 			Statements_res = Statements_ParseStatement();
/*1111*/ 		} while( !( (((Scanner_sym == 110)) || ((Scanner_sym == 112)) || ((Scanner_sym == 164)) || ((Scanner_sym == 11))) ));
/*1118*/ 	}

/*1119*/ 	RECORD * Statements_r = NULL;
/*1120*/ 	RECORD * Statements_t = NULL;
/*1121*/ 	int Statements_found_statements = 0;
/*1121*/ 	int Statements_found_default = 0;
/*1122*/ 	int Statements_res = 0;
/*1123*/ 	int Statements_b = 0;
/*1125*/ 	int Statements_p = 0;
/*1125*/ 	Scanner_ReadSym();
/*1126*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*1127*/ 	Scanner_ReadSym();
/*1128*/ 	Statements_r = Expressions_ParseExpr();
/*1129*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*1130*/ 	if( Statements_r == NULL ){
/*1134*/ 	} else {
/*1134*/ 		Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 194);
/*1135*/ 		if( ((Statements_t != Globals_int_type) && (Statements_t != Globals_string_type)) ){
/*1136*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"switch(EXPR): invalid expression of type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)". Expected int or string.", 1));
/*1138*/ 			Statements_t = NULL;
/*1141*/ 		}
/*1141*/ 	}
/*1141*/ 	Scanner_ReadSym();
/*1142*/ 	if( (Scanner_sym == 18) ){
/*1143*/ 		Statements_FatalUnsupportedOldStyleSyntax();
/*1145*/ 	}
/*1145*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `{'");
/*1146*/ 	Scanner_ReadSym();
/*1147*/ 	m2_inc(&Statements_loop_level, 1);
/*1149*/ 	do{
/*1149*/ 		if( (((Scanner_sym == 110)) || ((Scanner_sym == 112))) ){
/*1151*/ 			if( (Scanner_sym == 110) ){
/*1152*/ 				Scanner_ReadSym();
/*1153*/ 				Statements_r = Expressions_ParseStaticExpr();
/*1154*/ 				if( Statements_t != NULL ){
/*1155*/ 					if( Statements_r == NULL ){
/*1158*/ 					} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 195) != Statements_t ){
/*1159*/ 						Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"invalid type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 196)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)" for the `case' branch. Expected ", Types_TypeToString(Statements_t), 1));
/*1164*/ 					}
/*1164*/ 				}
/*1164*/ 				Scanner_Expect(18, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"expected `:' after `case' expression");
/*1165*/ 				Scanner_ReadSym();
/*1168*/ 			} else {
/*1168*/ 				if( Statements_found_default ){
/*1169*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"multiple default branches");
/*1171*/ 				}
/*1171*/ 				Statements_found_default = TRUE;
/*1172*/ 				Scanner_ReadSym();
/*1173*/ 				Scanner_Expect(18, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected `:' after `default'");
/*1174*/ 				Scanner_ReadSym();
/*1185*/ 			}
/*1185*/ 			Statements_found_statements = FALSE;
/*1187*/ 			Statements_b = 1;
/*1188*/ 			while( ((((Statements_b & 1) != 0)) && ((Scanner_sym != 110)) && ((Scanner_sym != 112)) && ((Scanner_sym != 163)) && ((Scanner_sym != 164)) && ((Scanner_sym != 11))) ){
/*1195*/ 				Statements_found_statements = TRUE;
/*1196*/ 				Statements_p = Statements_ParseStatement();
/*1197*/ 				Statements_b = (((Statements_b & ~1)) | Statements_p);
/*1200*/ 			}
/*1200*/ 			if( ((Statements_b & 1) == 0) ){
/*1201*/ 				Statements_CheckAndDiscardUnreachableStatements();
/*1203*/ 			} else if( (((Scanner_sym == 110)) || ((Scanner_sym == 112))) ){
/*1204*/ 				if( Statements_found_statements ){
/*1205*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"improperly terminated non-empty `switch' branch", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" -- missing `break;'?", 1));
/*1209*/ 				}
/*1209*/ 			} else if( (Scanner_sym == 163) ){
/*1210*/ 				Scanner_ReadSym();
/*1211*/ 				Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*1212*/ 				Scanner_ReadSym();
/*1213*/ 				Statements_CheckAndDiscardUnreachableStatements();
/*1220*/ 			}
/*1220*/ 			Statements_res = (Statements_res | (Statements_b & ((8 | 4))));
/*1222*/ 			if( ((Statements_b & 2) != 0) ){
/*1223*/ 				Statements_res = (Statements_res | 1);
/*1226*/ 			}
/*1226*/ 		} else if( (Scanner_sym == 164) ){
/*1227*/ 			if( Statements_found_default ){
/*1228*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"multiple default branches");
/*1230*/ 			}
/*1230*/ 			Statements_found_default = TRUE;
/*1231*/ 			Scanner_ReadSym();
/*1232*/ 			Scanner_Expect(130, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"expected `:' in meta-code");
/*1233*/ 			Scanner_ReadSym();
/*1234*/ 			Statements_res = (Statements_res | 1);
/*1236*/ 		} else if( (Scanner_sym == 11) ){
/*1237*/ 			if( !Statements_found_default ){
/*1238*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"missing `default:' branch in `switch'");
/*1239*/ 				Statements_res = (Statements_res | 1);
/*1241*/ 			}
/*1241*/ 			Scanner_ReadSym();
/*1245*/ 			goto m2runtime_loop_1;
/*1245*/ 		} else {
/*1245*/ 			Scanner_UnexpectedSymbol();
/*1249*/ 		}
/*1249*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1249*/ 	m2_inc(&Statements_loop_level, -1);
/*1251*/ 	return Statements_res;
/*1255*/ }


/*1257*/ void
/*1257*/ Statements_ParseClassConstDecl(int Statements_visibility)
/*1257*/ {
/*1258*/ 	RECORD * Statements_cl = NULL;
/*1259*/ 	RECORD * Statements_c = NULL;
/*1261*/ 	RECORD * Statements_r = NULL;
/*1261*/ 	Scanner_ReadSym();
/*1264*/ 	do{
/*1264*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected constant name");
/*1269*/ 		Search_ResolveClassConst(Globals_curr_class, Scanner_s, &Statements_cl, &Statements_c);
/*1270*/ 		if( Statements_c != NULL ){
/*1271*/ 			if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_c, 40, Statements_0err_entry_get, 197) ){
/*1272*/ 				if( Statements_cl == Globals_curr_class ){
/*1273*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"class constant `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 198)), 1));
/*1275*/ 				} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_cl, 72, Statements_0err_entry_get, 199) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_cl, 76, Statements_0err_entry_get, 200)) ){
/*1276*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"cannot re-define the constant `", Classes_pc(Globals_curr_class, Statements_cl), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"' inherited from interface or abstract class", 1));
/*1280*/ 				}
/*1280*/ 				Statements_c = NULL;
/*1281*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 8, Statements_0err_entry_get, 201) = Scanner_s;
/*1282*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 28, Statements_0err_entry_get, 202), 4, 1, Statements_0err_entry_get, 203) = Statements_c;
/*1285*/ 			}
/*1285*/ 		} else {
/*1285*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 8, Statements_0err_entry_get, 204) = Scanner_s;
/*1286*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 28, Statements_0err_entry_get, 205), 4, 1, Statements_0err_entry_get, 206) = Statements_c;
/*1289*/ 		}
/*1289*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 40, Statements_0err_entry_get, 207) = FALSE;
/*1290*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 28, Statements_0err_entry_get, 208) = Statements_visibility;
/*1291*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 16, Statements_0err_entry_get, 209) = Scanner_here();
/*1292*/ 		if( !Accounting_report_unused ){
/*1293*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 32, Statements_0err_entry_get, 210) = 100;
/*1295*/ 		}
/*1295*/ 		Scanner_ReadSym();
/*1296*/ 		Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected `=' after constant name");
/*1297*/ 		Scanner_ReadSym();
/*1298*/ 		Statements_r = Expressions_ParseStaticExpr();
/*1299*/ 		if( Statements_r == NULL ){
/*1302*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 211), 16, Statements_0err_entry_get, 212) == 6) ){
/*1303*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"arrays are not allowed in class constants");
/*1305*/ 		}
/*1305*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 12, Statements_0err_entry_get, 213) = Statements_r;
/*1307*/ 		if( (Scanner_sym == 16) ){
/*1308*/ 			Scanner_ReadSym();
/*1311*/ 		} else {
/*1312*/ 			goto m2runtime_loop_1;
/*1313*/ 		}
/*1314*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1314*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*1315*/ 	Scanner_ReadSym();
/*1317*/ 	if( (Scanner_sym == 174) ){
/*1318*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 20, Statements_0err_entry_get, 214) = Scanner_s;
/*1319*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 24, Statements_0err_entry_get, 215) = Documentator_ExtractDeprecated(Scanner_s);
/*1320*/ 		Scanner_ReadSym();
/*1321*/ 	} else if( Statements_pdb != NULL ){
/*1322*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 20, Statements_0err_entry_get, 216) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 217);
/*1323*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 44, 5, 24, Statements_0err_entry_get, 218) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 219));
/*1324*/ 		Statements_pdb = NULL;
/*1328*/ 	}
/*1330*/ }


/*1332*/ void
/*1332*/ Statements_ParseClassPropertyDecl(int Statements_visibility, int Statements_static, RECORD *Statements_t)
/*1332*/ {
/*1333*/ 	RECORD * Statements_P = NULL;
/*1334*/ 	RECORD * Statements_p = NULL;
/*1336*/ 	RECORD * Statements_r = NULL;
/*1339*/ 	do{
/*1339*/ 		if( (Scanner_sym != 20) ){
/*1340*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected property name $NAME");
/*1344*/ 		}
/*1344*/ 		Search_SearchClassProperty(Globals_curr_class, Scanner_s, &Statements_P, &Statements_p);
/*1345*/ 		if( Statements_p != NULL ){
/*1346*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 20, Statements_0err_entry_get, 220)), 1));
/*1351*/ 		}
/*1351*/ 		Statements_p = NULL;
/*1352*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 8, Statements_0err_entry_get, 221) = Scanner_s;
/*1354*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 32, Statements_0err_entry_get, 222) = Statements_visibility;
/*1357*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 36, Statements_0err_entry_get, 223) = Statements_static;
/*1359*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 12, Statements_0err_entry_get, 224) = Statements_t;
/*1361*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 20, Statements_0err_entry_get, 225) = Scanner_here();
/*1362*/ 		if( !Accounting_report_unused ){
/*1363*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 40, Statements_0err_entry_get, 226) = 100;
/*1365*/ 		}
/*1365*/ 		Scanner_ReadSym();
/*1368*/ 		if( (Scanner_sym == 31) ){
/*1369*/ 			Scanner_ReadSym();
/*1370*/ 			Statements_r = Expressions_ParseStaticExpr();
/*1371*/ 			if( Statements_r == NULL ){
/*1373*/ 			} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 227) == NULL ){
/*1374*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 12, Statements_0err_entry_get, 228) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 229);
/*1375*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 16, Statements_0err_entry_get, 230) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 231);
/*1377*/ 			} else {
/*1377*/ 				switch(Expressions_LhsMatchRhs((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 232), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 233))){

/*1378*/ 				case 0:
/*1379*/ 				break;

/*1379*/ 				case 1:
/*1380*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 234), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"' of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 235)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)", expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 236)), 1));
/*1383*/ 				break;

/*1383*/ 				case 2:
/*1384*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 237), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"' of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_p, 12, Statements_0err_entry_get, 238)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)", expression of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 239)), 1));
/*1388*/ 				break;

/*1388*/ 				default: m2runtime_missing_case_in_switch(Statements_0err_entry_get, 240);
/*1388*/ 				}
/*1388*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 16, Statements_0err_entry_get, 241) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 242);
/*1390*/ 			}
/*1390*/ 		} else if( Statements_t == NULL ){
/*1391*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"undefined type for property `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 243), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"'. Undefined properties take the initial value NULL.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)" Hint: either specify a type (example: /*.int.*/ $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 244), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)") or an initial value (example: $", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_p, 8, Statements_0err_entry_get, 245), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"=123).", 1));
/*1397*/ 		}
/*1397*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 32, Statements_0err_entry_get, 246), 4, 1, Statements_0err_entry_get, 247) = Statements_p;
/*1400*/ 		if( (Scanner_sym == 16) ){
/*1401*/ 			Scanner_ReadSym();
/*1404*/ 		} else {
/*1405*/ 			goto m2runtime_loop_1;
/*1407*/ 		}
/*1408*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1408*/ 	Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected ';'");
/*1409*/ 	Scanner_ReadSym();
/*1411*/ 	if( (Scanner_sym == 174) ){
/*1412*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 24, Statements_0err_entry_get, 248) = Scanner_s;
/*1413*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 28, Statements_0err_entry_get, 249) = Documentator_ExtractDeprecated(Scanner_s);
/*1414*/ 		Scanner_ReadSym();
/*1415*/ 	} else if( Statements_pdb != NULL ){
/*1416*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 24, Statements_0err_entry_get, 250) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 251);
/*1417*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_p, 48, 6, 28, Statements_0err_entry_get, 252) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 253));
/*1418*/ 		Statements_pdb = NULL;
/*1422*/ 	}
/*1425*/ }

/*1431*/ ARRAY * Statements_specialMethods = NULL;

/*1432*/ void
/*1432*/ Statements_CheckSpecialMethodSignature(RECORD *Statements_m)
/*1432*/ {
/*1432*/ 	int Statements_i = 0;
/*1434*/ 	STRING * Statements_sign = NULL;
/*1434*/ 	if( (((m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 254)) <= 2)) || (m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 255), 0, 2, 1, Statements_0err_entry_get, 256), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") != 0)) ){
/*1436*/ 		return ;
/*1438*/ 	}
/*1438*/ 	if( Statements_specialMethods == NULL ){
/*1439*/ 		Statements_specialMethods = (
/*1442*/ 			push((char*) alloc_ARRAY(4, 1)),
/*1442*/ 			push((char*) (
/*1442*/ 				push((char*) alloc_RECORD(28, 3)),
/*1442*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__destruct"),
/*1442*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1442*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT"),
/*1442*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1442*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1442*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1442*/ 				*(int*) (tos()+20) = FALSE,
/*1442*/ 				*(int*) (tos()+24) = FALSE,
/*1443*/ 				(RECORD*) pop()
/*1443*/ 			)),
/*1443*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*1445*/ 			push((char*) (
/*1445*/ 				push((char*) alloc_RECORD(28, 3)),
/*1445*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__clone"),
/*1445*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1445*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__CLONE"),
/*1445*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1445*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1445*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1445*/ 				*(int*) (tos()+20) = FALSE,
/*1445*/ 				*(int*) (tos()+24) = FALSE,
/*1446*/ 				(RECORD*) pop()
/*1446*/ 			)),
/*1446*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*1447*/ 			push((char*) (
/*1447*/ 				push((char*) alloc_RECORD(28, 3)),
/*1447*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"__set_static"),
/*1447*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1447*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"__SET_STATIC"),
/*1447*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1447*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"public static void(array[string]mixed)"),
/*1447*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1447*/ 				*(int*) (tos()+20) = FALSE,
/*1447*/ 				*(int*) (tos()+24) = FALSE,
/*1448*/ 				(RECORD*) pop()
/*1448*/ 			)),
/*1448*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*1450*/ 			push((char*) (
/*1450*/ 				push((char*) alloc_RECORD(28, 3)),
/*1450*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__sleep"),
/*1450*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1450*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__SLEEP"),
/*1450*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1450*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"public array[int]string()"),
/*1450*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1450*/ 				*(int*) (tos()+20) = TRUE,
/*1450*/ 				*(int*) (tos()+24) = FALSE,
/*1451*/ 				(RECORD*) pop()
/*1451*/ 			)),
/*1451*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*1451*/ 			push((char*) (
/*1451*/ 				push((char*) alloc_RECORD(28, 3)),
/*1451*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"__wakeup"),
/*1451*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1451*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"__WAKEUP"),
/*1451*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1451*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"public void()"),
/*1451*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1451*/ 				*(int*) (tos()+20) = TRUE,
/*1451*/ 				*(int*) (tos()+24) = FALSE,
/*1452*/ 				(RECORD*) pop()
/*1452*/ 			)),
/*1452*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*1453*/ 			push((char*) (
/*1453*/ 				push((char*) alloc_RECORD(28, 3)),
/*1453*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__toString"),
/*1453*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1453*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__TOSTRING"),
/*1453*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1453*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"public string()"),
/*1453*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1453*/ 				*(int*) (tos()+20) = FALSE,
/*1453*/ 				*(int*) (tos()+24) = FALSE,
/*1454*/ 				(RECORD*) pop()
/*1454*/ 			)),
/*1454*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*1456*/ 			push((char*) (
/*1456*/ 				push((char*) alloc_RECORD(28, 3)),
/*1456*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__set"),
/*1456*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1456*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__SET"),
/*1456*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1456*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"public void(string, mixed)"),
/*1456*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1456*/ 				*(int*) (tos()+20) = FALSE,
/*1456*/ 				*(int*) (tos()+24) = TRUE,
/*1457*/ 				(RECORD*) pop()
/*1457*/ 			)),
/*1457*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*1457*/ 			push((char*) (
/*1457*/ 				push((char*) alloc_RECORD(28, 3)),
/*1457*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__get"),
/*1457*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1457*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"__GET"),
/*1457*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1457*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"public mixed(string)"),
/*1457*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1457*/ 				*(int*) (tos()+20) = FALSE,
/*1457*/ 				*(int*) (tos()+24) = TRUE,
/*1458*/ 				(RECORD*) pop()
/*1458*/ 			)),
/*1458*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*1458*/ 			push((char*) (
/*1458*/ 				push((char*) alloc_RECORD(28, 3)),
/*1458*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__isset"),
/*1458*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1458*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__ISSET"),
/*1458*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1458*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"public boolean(string)"),
/*1458*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1458*/ 				*(int*) (tos()+20) = FALSE,
/*1458*/ 				*(int*) (tos()+24) = TRUE,
/*1459*/ 				(RECORD*) pop()
/*1459*/ 			)),
/*1459*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*1459*/ 			push((char*) (
/*1459*/ 				push((char*) alloc_RECORD(28, 3)),
/*1459*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__unset"),
/*1459*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1459*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"__UNSET"),
/*1459*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1459*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"public void(string)"),
/*1459*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1459*/ 				*(int*) (tos()+20) = FALSE,
/*1459*/ 				*(int*) (tos()+24) = TRUE,
/*1460*/ 				(RECORD*) pop()
/*1460*/ 			)),
/*1460*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*1460*/ 			push((char*) (
/*1460*/ 				push((char*) alloc_RECORD(28, 3)),
/*1460*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"__call"),
/*1460*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1460*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"__CALL"),
/*1460*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1460*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"public mixed(string, array[]mixed)"),
/*1460*/ 				*(STRING**) (tosn(1)+16) = (STRING*) tos(), pop(),
/*1460*/ 				*(int*) (tos()+20) = FALSE,
/*1460*/ 				*(int*) (tos()+24) = TRUE,
/*1463*/ 				(RECORD*) pop()
/*1463*/ 			)),
/*1463*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*1464*/ 			(ARRAY*) pop()
/*1464*/ 		);
/*1466*/ 	}
/*1466*/ 	Statements_i = (m2runtime_count(Statements_specialMethods) - 1);
/*1468*/ 	do{
/*1468*/ 		if( (Statements_i < 0) ){
/*1471*/ 			goto m2runtime_loop_1;
/*1471*/ 		}
/*1471*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 257), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 258), 12, Statements_0err_entry_get, 259)) == 0 ){
/*1472*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 260), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 261), 8, Statements_0err_entry_get, 262)) != 0 ){
/*1473*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"the special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 263), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"' should be written as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 264), 8, Statements_0err_entry_get, 265), m2runtime_CHR(39), 1));
/*1477*/ 			}
/*1478*/ 			goto m2runtime_loop_1;
/*1478*/ 		}
/*1478*/ 		m2_inc(&Statements_i, -1);
/*1481*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1481*/ 	if( (Statements_i < 0) ){
/*1482*/ 		if( (((m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 266)) >= 2)) && (m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 267), 0, 2, 1, Statements_0err_entry_get, 268), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"__") == 0)) ){
/*1483*/ 			Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 269), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"unknown special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 270), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\121,\0,\0,\0)"'. Methods whose name begin with `__' are reserved for future use by the language", 1));
/*1487*/ 		}
/*1487*/ 		return ;
/*1491*/ 	}
/*1491*/ 	if( (((Globals_php_ver == 4)) && ! *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 271), 20, Statements_0err_entry_get, 272)) ){
/*1492*/ 		Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 273), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"the name `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 274), 8, Statements_0err_entry_get, 275), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\107,\0,\0,\0)"' is reserved for a special method in PHP5, use another name under PHP4", 1));
/*1494*/ 		return ;
/*1494*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 276), 24, Statements_0err_entry_get, 277) ){
/*1495*/ 		Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 278), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"special method `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 279), 8, Statements_0err_entry_get, 280), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"' not supported by PHPLint", 1));
/*1500*/ 	}
/*1500*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 60, Statements_0err_entry_get, 281) ){
/*1502*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 60, Statements_0err_entry_get, 282) = FALSE;
/*1503*/ 		Statements_sign = Types_MethodSignatureToString(Statements_m);
/*1504*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 60, Statements_0err_entry_get, 283) = TRUE;
/*1506*/ 	} else {
/*1506*/ 		Statements_sign = Types_MethodSignatureToString(Statements_m);
/*1509*/ 	}
/*1509*/ 	if( m2runtime_strcmp(Statements_sign, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 284), 16, Statements_0err_entry_get, 285)) != 0 ){
/*1510*/ 		Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 286), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"special method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 287), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"': invalid signature `", Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"', expected `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Statements_specialMethods, Statements_i, Statements_0err_entry_get, 288), 16, Statements_0err_entry_get, 289), m2runtime_CHR(39), 1));
/*1515*/ 	}
/*1517*/ }


/*1519*/ int
/*1519*/ Statements_SameMethodSignature(RECORD *Statements_m1, RECORD *Statements_m2)
/*1519*/ {
/*1519*/ 	return (Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 60, Statements_0err_entry_get, 290),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 60, Statements_0err_entry_get, 291)) && Statements_eqbool( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 56, Statements_0err_entry_get, 292),  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 56, Statements_0err_entry_get, 293)) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_m1, 52, Statements_0err_entry_get, 294) ==  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m2, 52, Statements_0err_entry_get, 295))) && Statements_SameSign((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m1, 16, Statements_0err_entry_get, 296), (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m2, 16, Statements_0err_entry_get, 297)));
/*1526*/ }


/*1529*/ void
/*1529*/ Statements_ParseClassMethodDecl(int Statements_abstract, int Statements_visibility, int Statements_static, int Statements_final, RECORD *Statements_t)
/*1529*/ {
/*1530*/ 	RECORD * Statements_old_m = NULL;
/*1530*/ 	RECORD * Statements_m = NULL;
/*1531*/ 	int Statements_i = 0;
/*1532*/ 	RECORD * Statements_sign = NULL;
/*1533*/ 	RECORD * Statements_this = NULL;
/*1534*/ 	int Statements_guess = 0;
/*1535*/ 	int Statements_is_destructor = 0;
/*1535*/ 	int Statements_is_constructor = 0;
/*1536*/ 	STRING * Statements_err = NULL;
/*1538*/ 	int Statements_res = 0;

/*1544*/ 	RECORD *
/*1544*/ 	Statements_ParentConstructor(RECORD *Statements_c)
/*1544*/ 	{
/*1544*/ 		Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 298);
/*1545*/ 		while( ((Statements_c != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 40, Statements_0err_entry_get, 299) == NULL)) ){
/*1546*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 300);
/*1548*/ 		}
/*1548*/ 		return Statements_c;
/*1551*/ 	}


/*1557*/ 	RECORD *
/*1557*/ 	Statements_ParentDestructor(RECORD *Statements_c)
/*1557*/ 	{
/*1557*/ 		Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 301);
/*1558*/ 		while( ((Statements_c != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 44, Statements_0err_entry_get, 302) == NULL)) ){
/*1559*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 16, Statements_0err_entry_get, 303);
/*1561*/ 		}
/*1561*/ 		return Statements_c;
/*1565*/ 	}

/*1568*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 76, Statements_0err_entry_get, 304) ){
/*1569*/ 		Statements_abstract = TRUE;
/*1570*/ 		if( (Statements_visibility != 2) ){
/*1571*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"interface methods must be `public'");
/*1572*/ 			Statements_visibility = 2;
/*1574*/ 		}
/*1574*/ 		if( Statements_final ){
/*1575*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"interface methods cannot be `final'");
/*1576*/ 			Statements_final = FALSE;
/*1579*/ 		}
/*1579*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 72, Statements_0err_entry_get, 305) ){
/*1580*/ 		if( Statements_abstract ){
/*1581*/ 			if( (Statements_visibility == 0) ){
/*1582*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"abstract methods cannot be `private'");
/*1583*/ 				Statements_visibility = 1;
/*1585*/ 			}
/*1585*/ 			if( Statements_static ){
/*1586*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"abstract methods cannot be static");
/*1587*/ 				Statements_static = FALSE;
/*1589*/ 			}
/*1589*/ 			if( Statements_final ){
/*1590*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"abstract methods cannot be `final'");
/*1591*/ 				Statements_final = FALSE;
/*1594*/ 			}
/*1594*/ 		} else {
/*1594*/ 			if( (Statements_final && ((Statements_visibility == 0))) ){
/*1595*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*1596*/ 				Statements_final = FALSE;
/*1599*/ 			}
/*1600*/ 		}
/*1601*/ 	} else {
/*1601*/ 		if( Statements_abstract ){
/*1602*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*1603*/ 			Statements_abstract = FALSE;
/*1605*/ 		}
/*1605*/ 		if( (Statements_final && ((Statements_visibility == 0))) ){
/*1606*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"a private method is implicitly `final'");
/*1607*/ 			Statements_final = FALSE;
/*1611*/ 		}
/*1612*/ 	}
/*1612*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 48, Statements_0err_entry_get, 306) = Statements_abstract;
/*1613*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 52, Statements_0err_entry_get, 307) = Statements_visibility;
/*1614*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 56, Statements_0err_entry_get, 308) = Statements_static;
/*1615*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 60, Statements_0err_entry_get, 309) = Statements_final;
/*1617*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 310) = Statements_t;
/*1618*/ 	if( Statements_t == NULL ){
/*1619*/ 		Statements_guess = TRUE;
/*1622*/ 	}
/*1622*/ 	Scanner_ReadSym();
/*1627*/ 	if( (Scanner_sym == 73) ){
/*1628*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 16, Statements_0err_entry_get, 311) = TRUE;
/*1629*/ 		if( (Globals_php_ver == 5) ){
/*1630*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"obsolete syntax `function &func()', don't use in PHP 5");
/*1632*/ 		}
/*1632*/ 		Scanner_ReadSym();
/*1638*/ 	}
/*1638*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method name");
/*1639*/ 	Statements_old_m = Search_SearchClassMethod(Globals_curr_class, Scanner_s, FALSE);
/*1640*/ 	if( Statements_old_m != NULL ){
/*1648*/ 		if( (! *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 44, Statements_0err_entry_get, 312) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 313) != NULL)) ){
/*1649*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"()' already defined in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 314)), 1));
/*1654*/ 		}
/*1654*/ 		Statements_i = 0;
/*1655*/ 		while( (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 36, Statements_0err_entry_get, 315), Statements_i, Statements_0err_entry_get, 316) != Statements_old_m ){
/*1656*/ 			m2_inc(&Statements_i, 1);
/*1658*/ 		}
/*1658*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Statements_0err_entry_get, 317), 4, 1, Statements_i, Statements_0err_entry_get, 318) = Statements_m;
/*1661*/ 	} else {
/*1661*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 36, Statements_0err_entry_get, 319), 4, 1, Statements_0err_entry_get, 320) = Statements_m;
/*1663*/ 	}
/*1663*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 8, Statements_0err_entry_get, 321) = Scanner_s;
/*1664*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 12, Statements_0err_entry_get, 322) = str_toupper(Scanner_s);
/*1666*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 20, Statements_0err_entry_get, 323) = Scanner_here();
/*1667*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 16, Statements_0err_entry_get, 324) = Statements_sign;
/*1672*/ 	if( (Globals_php_ver == 4) ){
/*1674*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 325), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0 ){
/*1675*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 326), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"': this name is reserved for PHP 5 constructors", 1));
/*1678*/ 		}
/*1678*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 327), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Statements_0err_entry_get, 328)) == 0 ){
/*1679*/ 			Statements_is_constructor = TRUE;
/*1680*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 329) == NULL) || ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 330), 44, Statements_0err_entry_get, 331))) ){
/*1681*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Statements_0err_entry_get, 332) = Statements_m;
/*1683*/ 			} else {
/*1683*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 333), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 334), 8, Statements_0err_entry_get, 335), m2runtime_CHR(39), 1));
/*1688*/ 			}
/*1689*/ 		}
/*1691*/ 	} else {
/*1691*/ 		if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 336), (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 12, Statements_0err_entry_get, 337)) == 0) || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 338), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") == 0)) ){
/*1693*/ 			Statements_is_constructor = TRUE;
/*1694*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 339), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"__CONSTRUCT") != 0 ){
/*1695*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"the constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 340), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' has the same name of the class. PHP 5 states", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" it should be called `__construct()'", 1));
/*1699*/ 			}
/*1699*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 341) == NULL) || ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 342), 44, Statements_0err_entry_get, 343))) ){
/*1700*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 40, Statements_0err_entry_get, 344) = Statements_m;
/*1702*/ 			} else {
/*1702*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 345), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"': constructor already declared as `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 40, Statements_0err_entry_get, 346), 8, Statements_0err_entry_get, 347), m2runtime_CHR(39), 1));
/*1707*/ 			}
/*1709*/ 		}
/*1713*/ 	}
/*1713*/ 	Statements_is_destructor = (((Globals_php_ver == 5)) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 12, Statements_0err_entry_get, 348), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__DESTRUCT") == 0));
/*1714*/ 	if( Statements_is_destructor ){
/*1715*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Globals_curr_class, 92, 13, 44, Statements_0err_entry_get, 349) = Statements_m;
/*1718*/ 	}
/*1718*/ 	if( (!Accounting_report_unused || Statements_is_constructor || Statements_is_destructor || Statements_abstract) ){
/*1719*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 64, Statements_0err_entry_get, 350) = 100;
/*1722*/ 	}
/*1722*/ 	Globals_curr_method = Statements_m;
/*1723*/ 	m2_inc(&Globals_scope, 1);
/*1724*/ 	Scanner_ReadSym();
/*1730*/ 	if( ((Statements_pdb != NULL) && ((m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 351)) > 0))) ){
/*1731*/ 		Exceptions_AddPdbExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 32, Statements_0err_entry_get, 352));
/*1738*/ 	}
/*1738*/ 	if( Statements_pdb != NULL ){
/*1739*/ 		*(ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 32, Statements_0err_entry_get, 353) = (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 36, Statements_0err_entry_get, 354);
/*1746*/ 	}
/*1746*/ 	Accounting_AccountVarLHS(m2runtime_CHR(42), FALSE);
/*1747*/ 	Statements_this = Search_SearchVar(m2runtime_CHR(42), Globals_scope);
/*1748*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 8, Statements_0err_entry_get, 355) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this";
/*1749*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 20, Statements_0err_entry_get, 356) = (RECORD *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 24, Statements_0err_entry_get, 357);
/*1754*/ 	if( Statements_ParseArgsListDecl(Statements_sign, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"method") ){
/*1755*/ 		Statements_guess = TRUE;
/*1758*/ 	}
/*1758*/ 	if( !Statements_is_constructor ){
/*1765*/ 		if( !Statements_guess ){
/*1766*/ 			Statements_CheckSpecialMethodSignature(Statements_m);
/*1770*/ 		}
/*1776*/ 	} else {
/*1776*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 56, Statements_0err_entry_get, 358) ){
/*1777*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 359), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"': a constructor cannot be `static'", 1));
/*1779*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 56, Statements_0err_entry_get, 360) = FALSE;
/*1781*/ 		}
/*1781*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 361) != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 362) != Globals_void_type)) ){
/*1782*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"constructor `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 363), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"': a constructor cannot", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)" return a value. It must be declared `void'.", 1));
/*1785*/ 		}
/*1785*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 364) = Globals_void_type;
/*1791*/ 	}
/*1791*/ 	if( (Scanner_sym == 173) ){
/*1792*/ 		Exceptions_ParseThrows();
/*1795*/ 	}
/*1795*/ 	if( (Scanner_sym == 174) ){
/*1796*/ 		if( (((Globals_php_ver == 5)) && Statements_abstract) ){
/*1797*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"the DOC description for abstract methods must follows ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"the `;'", 1));
/*1800*/ 		}
/*1800*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 36, Statements_0err_entry_get, 365) = Scanner_s;
/*1801*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 40, Statements_0err_entry_get, 366) = Documentator_ExtractDeprecated(Scanner_s);
/*1802*/ 		Scanner_ReadSym();
/*1803*/ 	} else if( Statements_pdb != NULL ){
/*1804*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 36, Statements_0err_entry_get, 367) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 368);
/*1805*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 40, Statements_0err_entry_get, 369) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 370));
/*1806*/ 		Statements_pdb = NULL;
/*1812*/ 	}
/*1812*/ 	if( (Scanner_sym == 17) ){
/*1814*/ 		if( (Globals_php_ver == 4) ){
/*1815*/ 			if( Statements_abstract ){
/*1816*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected empty body `{}' for abstract method");
/*1818*/ 			} else {
/*1818*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"expected method body");
/*1821*/ 			}
/*1821*/ 		} else {
/*1821*/ 			if( !Statements_abstract ){
/*1822*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"missing method body in non abstract method");
/*1825*/ 			}
/*1826*/ 		}
/*1826*/ 		Scanner_ReadSym();
/*1828*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 371) = 100;
/*1830*/ 		if( (Scanner_sym == 174) ){
/*1831*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 36, Statements_0err_entry_get, 372) = Scanner_s;
/*1832*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 40, Statements_0err_entry_get, 373) = Documentator_ExtractDeprecated(Scanner_s);
/*1833*/ 			Scanner_ReadSym();
/*1834*/ 		} else if( Statements_pdb != NULL ){
/*1835*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_m, 76, 9, 36, Statements_0err_entry_get, 374) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 375);
/*1836*/ 			Statements_pdb = NULL;
/*1839*/ 		}
/*1839*/ 	} else if( (Scanner_sym == 10) ){
/*1841*/ 		if( (Globals_php_ver == 4) ){
/*1842*/ 			if( Statements_abstract ){
/*1843*/ 				Scanner_ReadSym();
/*1844*/ 				Scanner_Expect(11, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"expected `}'. The body of an abstract method must be empty.");
/*1845*/ 				Scanner_ReadSym();
/*1846*/ 				if( !Statements_static ){
/*1847*/ 					*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 376) = 100;
/*1850*/ 				}
/*1850*/ 			} else {
/*1850*/ 				Statements_res = Statements_ParseBlock();
/*1854*/ 			}
/*1854*/ 		} else {
/*1854*/ 			if( Statements_abstract ){
/*1855*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"expected `;'. Abstract method cannot contain a body.");
/*1857*/ 			}
/*1857*/ 			Statements_res = Statements_ParseBlock();
/*1864*/ 		}
/*1864*/ 		if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 377) != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 378) != Globals_void_type) && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 48, Statements_0err_entry_get, 379) && (((Statements_res & 1) != 0)) && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 20, Statements_0err_entry_get, 380)) ){
/*1871*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 381), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)"missing `return' in at least one execution path in non-void method ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 382), 1));
/*1877*/ 		}
/*1877*/ 		if( (Statements_is_constructor && (Statements_ParentConstructor(Globals_curr_class) != NULL) && ! *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 80, Statements_0err_entry_get, 383)) ){
/*1881*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 384), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\102,\0,\0,\0)"missing call to the parent constructor in overridding constructor ", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Statements_0err_entry_get, 385), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 386), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1887*/ 		}
/*1887*/ 		if( (Statements_is_destructor && (Statements_ParentDestructor(Globals_curr_class) != NULL) && ! *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 84, Statements_0err_entry_get, 387)) ){
/*1891*/ 			Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 388), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\100,\0,\0,\0)"missing call to the parent destructor in overridding destructor ", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_class, 8, Statements_0err_entry_get, 389), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 390), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1895*/ 		}
/*1895*/ 	} else {
/*1895*/ 		Scanner_UnexpectedSymbol();
/*1899*/ 	}
/*1899*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_sign, 8, Statements_0err_entry_get, 391) == NULL ){
/*1901*/ 		Statements_guess = TRUE;
/*1902*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_sign, 28, 2, 8, Statements_0err_entry_get, 392) = Globals_void_type;
/*1909*/ 	}
/*1909*/ 	if( (Statements_guess && !Statements_is_constructor) ){
/*1910*/ 		Statements_CheckSpecialMethodSignature(Statements_m);
/*1937*/ 	}
/*1937*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_this, 52, 7, 48, Statements_0err_entry_get, 393) = 100;
/*1939*/ 	if( Statements_guess ){
/*1940*/ 		Scanner_Notice2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 394), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"guessed signature of the method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" as ", Types_MethodSignatureToString(Statements_m), 1));
/*1944*/ 	}
/*1944*/ 	Classes_CheckOverriddenMethod(Globals_curr_class, Statements_m);
/*1946*/ 	Expressions_CleanCurrentScope();
/*1947*/ 	m2_inc(&Globals_scope, -1);
/*1948*/ 	Globals_curr_method = NULL;
/*1950*/ 	if( Statements_old_m != NULL ){
/*1951*/ 		if( !Statements_SameMethodSignature(Statements_m, Statements_old_m) ){
/*1952*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 44, Statements_0err_entry_get, 395) ){
/*1953*/ 				Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 396), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_MethodSignatureToString(Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"' does not match forward signature `", Types_MethodSignatureToString(Statements_old_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' as declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 397)), 1));
/*1960*/ 			} else {
/*1960*/ 				Scanner_Error2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 398), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"method ", Scanner_mn(Globals_curr_class, Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)" with signature `", Types_MethodSignatureToString(Statements_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"' does not match the signature `", Types_MethodSignatureToString(Statements_old_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"' as guessed in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 24, Statements_0err_entry_get, 399)), 1));
/*1968*/ 			}
/*1970*/ 		}
/*1970*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 44, Statements_0err_entry_get, 400) ){
/*1971*/ 			Statements_err = Classes_ClassesList(Classes_Sort(Classes_OrphanClasses((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 28, Statements_0err_entry_get, 401), (ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_m, 28, Statements_0err_entry_get, 402))));
/*1972*/ 			if( m2runtime_strcmp(Statements_err, NULL) > 0 ){
/*1973*/ 				Scanner_Warning2((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 403), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 404), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\112,\0,\0,\0)"()' throws more exceptions than those listed in the prototype declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_old_m, 20, Statements_0err_entry_get, 405)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Statements_err, 1));
/*1978*/ 			}
/*1979*/ 		}
/*1980*/ 	}
/*1982*/ }


/*1985*/ void
/*1985*/ Statements_ParseClass(int Statements_private_class)
/*1985*/ {
/*1986*/ 	RECORD * Statements_if = NULL;
/*1986*/ 	RECORD * Statements_parent = NULL;
/*1986*/ 	RECORD * Statements_class2 = NULL;
/*1986*/ 	RECORD * Statements_class = NULL;
/*1989*/ 	RECORD * Statements_t = NULL;
/*1989*/ 	int Statements_x_visibility_set = 0;
/*1990*/ 	int Statements_x_visibility = 0;
/*1991*/ 	int Statements_x_abstract = 0;
/*1992*/ 	int Statements_x_final = 0;
/*1993*/ 	int Statements_x_static = 0;
/*1994*/ 	int Statements_abstract = 0;
/*1994*/ 	int Statements_visibility_set = 0;
/*1995*/ 	int Statements_visibility = 0;
/*1996*/ 	int Statements_static = 0;
/*1998*/ 	int Statements_final = 0;
/*1999*/ 	int Statements_i = 0;
/*2002*/ 	RECORD * Statements_m = NULL;
/*2002*/ 	if( (Globals_php_ver == 4) ){
/*2003*/ 		Statements_DocBlockCheckAllowedLineTags(((64 | 16) | 128), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*2006*/ 	} else {
/*2006*/ 		Statements_DocBlockCheckAllowedLineTags(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*2010*/ 	}
/*2010*/ 	if( (Globals_scope > 0) ){
/*2011*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\171,\0,\0,\0)"class declaration inside a function. The namespace of the classes is still global so the function cannot be called twice.");
/*2014*/ 	}
/*2014*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 48, Statements_0err_entry_get, 406) = Scanner_here();
/*2016*/ 	if( !Accounting_report_unused ){
/*2017*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 88, Statements_0err_entry_get, 407) = 100;
/*2023*/ 	}
/*2023*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 64, Statements_0err_entry_get, 408) = (Statements_private_class || ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 409)));
/*2024*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 410) = ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 411));
/*2025*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 412) = ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 60, Statements_0err_entry_get, 413));
/*2031*/ 	do{
/*2031*/ 		if( (Scanner_sym == 168) ){
/*2032*/ 			if( (Globals_php_ver == 5) ){
/*2033*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"invalid qualifier `/*.abstract.*/', use `abstract' instead");
/*2035*/ 			}
/*2035*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 414) ){
/*2036*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"`abstract' attribute already set");
/*2038*/ 			}
/*2038*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 415) = TRUE;
/*2039*/ 			Scanner_ReadSym();
/*2041*/ 		} else if( (Scanner_sym == 170) ){
/*2042*/ 			if( (Globals_php_ver == 5) ){
/*2043*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"invalid qualifier `/*.final.*/', use `final' instead");
/*2045*/ 			}
/*2045*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 416) ){
/*2046*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"`final' attribute already set");
/*2048*/ 			}
/*2048*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 417) = TRUE;
/*2049*/ 			Scanner_ReadSym();
/*2051*/ 		} else if( (Scanner_sym == 91) ){
/*2052*/ 			if( (Globals_php_ver == 4) ){
/*2053*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"invalid qualifier `abstract', use `/*.abstract.*/' instead");
/*2055*/ 			}
/*2055*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 418) ){
/*2056*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"`abstract' attribute already set");
/*2058*/ 			}
/*2058*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 72, Statements_0err_entry_get, 419) = TRUE;
/*2059*/ 			Scanner_ReadSym();
/*2061*/ 		} else if( (Scanner_sym == 102) ){
/*2062*/ 			if( (Globals_php_ver == 4) ){
/*2063*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"invalid qualifier `final', use `/*.final.*/' instead");
/*2065*/ 			}
/*2065*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 420) ){
/*2066*/ 				Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"`final' attribute already set");
/*2068*/ 			}
/*2068*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 68, Statements_0err_entry_get, 421) = TRUE;
/*2069*/ 			Scanner_ReadSym();
/*2073*/ 		} else {
/*2075*/ 			goto m2runtime_loop_1;
/*2076*/ 		}
/*2077*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*2077*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 422) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 423)) ){
/*2078*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"a class cannot be both final and abstract");
/*2081*/ 	}
/*2081*/ 	Scanner_Expect(93, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected `class'");
/*2082*/ 	Scanner_ReadSym();
/*2087*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*2088*/ 	Statements_class2 = Search_SearchClass(Scanner_s, FALSE);
/*2089*/ 	if( Statements_class2 == NULL ){
/*2090*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 8, Statements_0err_entry_get, 424) = Scanner_s;
/*2091*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 12, Statements_0err_entry_get, 425) = str_toupper(Scanner_s);
/*2092*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 24, Statements_0err_entry_get, 426) = (
/*2092*/ 			push((char*) alloc_RECORD(24, 2)),
/*2092*/ 			*(int*) (tos()+16) = 9,
/*2092*/ 			*(int*) (tos()+20) = 1,
/*2092*/ 			push((char*) NULL),
/*2092*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2092*/ 			push((char*) Statements_class),
/*2093*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2093*/ 			(RECORD*) pop()
/*2093*/ 		);
/*2093*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Statements_0err_entry_get, 427) = Statements_class;
/*2095*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class2, 60, Statements_0err_entry_get, 428) ){
/*2096*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 64, Statements_0err_entry_get, 429) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 64, Statements_0err_entry_get, 430);
/*2097*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 72, Statements_0err_entry_get, 431) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 432);
/*2098*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 68, Statements_0err_entry_get, 433) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 68, Statements_0err_entry_get, 434);
/*2099*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 48, Statements_0err_entry_get, 435) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class, 48, Statements_0err_entry_get, 436);
/*2100*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 88, Statements_0err_entry_get, 437) =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 88, Statements_0err_entry_get, 438);
/*2101*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class2, 92, 13, 60, Statements_0err_entry_get, 439) = FALSE;
/*2102*/ 		Statements_class = Statements_class2;
/*2105*/ 	} else {
/*2105*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class2, 48, Statements_0err_entry_get, 440)), 1));
/*2109*/ 	}
/*2109*/ 	Globals_curr_class = Statements_class;
/*2110*/ 	Scanner_ReadSym();
/*2115*/ 	if( (Scanner_sym == 94) ){
/*2116*/ 		Scanner_ReadSym();
/*2117*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected parent class name after `extend'");
/*2118*/ 		Statements_parent = Search_SearchClass(Scanner_s, TRUE);
/*2119*/ 		if( Statements_parent == NULL ){
/*2120*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"undeclared parent class `", Scanner_s, m2runtime_CHR(39), 1));
/*2121*/ 		} else if( Classes_IsSubclassOf(Statements_parent, Statements_class) ){
/*2122*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"class ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 8, Statements_0err_entry_get, 441), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" cannot extend child class ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 442), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)": forbidden circular reference", 1));
/*2124*/ 		} else if( Classes_IsSubclassOf(Statements_class, Statements_parent) ){
/*2125*/ 			Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"class ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 8, Statements_0err_entry_get, 443), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" redundantly extends class ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 444), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" -- ignoring", 1));
/*2127*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_parent, 68, Statements_0err_entry_get, 445) ){
/*2128*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"can't extend final class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 446), m2runtime_CHR(39), 1));
/*2129*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_parent, 76, Statements_0err_entry_get, 447) ){
/*2130*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"can't extend interface class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 448), m2runtime_CHR(39), 1));
/*2132*/ 		} else {
/*2132*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 16, Statements_0err_entry_get, 449) = Statements_parent;
/*2133*/ 			Accounting_AccountClass(Statements_parent);
/*2134*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 56, Statements_0err_entry_get, 450), EMPTY_STRING) > 0 ){
/*2135*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"extending deprecated class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 8, Statements_0err_entry_get, 451), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_parent, 56, Statements_0err_entry_get, 452), 1));
/*2139*/ 			}
/*2139*/ 		}
/*2139*/ 		Scanner_ReadSym();
/*2145*/ 	}
/*2145*/ 	if( (Scanner_sym == 95) ){
/*2146*/ 		Scanner_ReadSym();
/*2148*/ 		do{
/*2148*/ 			Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected interface name");
/*2149*/ 			Statements_if = Search_SearchClass(Scanner_s, TRUE);
/*2150*/ 			if( Statements_if == NULL ){
/*2151*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"undeclared interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2152*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_if, 76, Statements_0err_entry_get, 453) ){
/*2153*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"' isn't an interface", 1));
/*2154*/ 			} else if( Classes_IsSubclassOf(Statements_class, Statements_if) ){
/*2155*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"class ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 8, Statements_0err_entry_get, 454), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)" redundantly extends interface ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 455), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" -- ignoring", 1));
/*2159*/ 			} else {
/*2159*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 20, Statements_0err_entry_get, 456), 4, 1, Statements_0err_entry_get, 457) = Statements_if;
/*2162*/ 				Accounting_AccountClass(Statements_if);
/*2163*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 458), EMPTY_STRING) > 0 ){
/*2164*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"implementing deprecated interface `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 459), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 460), 1));
/*2168*/ 				}
/*2168*/ 			}
/*2168*/ 			Scanner_ReadSym();
/*2169*/ 			if( (Scanner_sym == 16) ){
/*2170*/ 				Scanner_ReadSym();
/*2173*/ 			} else {
/*2174*/ 				goto m2runtime_loop_2;
/*2175*/ 			}
/*2176*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*2177*/ 	}
/*2177*/ 	Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(Statements_class);
/*2179*/ 	if( (Scanner_sym == 174) ){
/*2180*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 461) = Scanner_s;
/*2181*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 462) = Documentator_ExtractDeprecated(Scanner_s);
/*2182*/ 		Scanner_ReadSym();
/*2183*/ 	} else if( Statements_pdb != NULL ){
/*2184*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 463) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 464);
/*2185*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 465) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 466));
/*2186*/ 		Statements_pdb = NULL;
/*2189*/ 	}
/*2189*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"expected '{' in class declaration");
/*2190*/ 	Scanner_ReadSym();
/*2194*/ 	do{
/*2194*/ 		if( (Scanner_sym == 11) ){
/*2195*/ 			Scanner_ReadSym();
/*2198*/ 			goto m2runtime_loop_3;
/*2200*/ 		}
/*2200*/ 		Statements_x_visibility_set = FALSE;
/*2201*/ 		Statements_x_visibility = 2;
/*2202*/ 		Statements_x_abstract = FALSE;
/*2203*/ 		Statements_x_final = FALSE;
/*2204*/ 		Statements_x_static = FALSE;
/*2207*/ 		Statements_abstract = FALSE;
/*2208*/ 		Statements_visibility_set = FALSE;
/*2209*/ 		Statements_visibility = 2;
/*2210*/ 		Statements_static = FALSE;
/*2211*/ 		Statements_final = FALSE;
/*2216*/ 		while( (Scanner_sym == 175) ){
/*2217*/ 			Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*2218*/ 			if( Statements_pdb != NULL ){
/*2219*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 467) ){
/*2220*/ 					Statements_x_visibility = 0;
/*2221*/ 					Statements_x_visibility_set = TRUE;
/*2222*/ 				} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 468) ){
/*2223*/ 					Statements_x_visibility = 1;
/*2224*/ 					Statements_x_visibility_set = TRUE;
/*2225*/ 				} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 469) ){
/*2226*/ 					Statements_x_visibility = 2;
/*2227*/ 					Statements_x_visibility_set = TRUE;
/*2229*/ 				}
/*2229*/ 				Statements_x_abstract =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 44, Statements_0err_entry_get, 470);
/*2230*/ 				Statements_x_final =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 60, Statements_0err_entry_get, 471);
/*2231*/ 				Statements_x_static =  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 64, Statements_0err_entry_get, 472);
/*2233*/ 			}
/*2233*/ 			Scanner_ReadSym();
/*2238*/ 		}
/*2238*/ 		do{
/*2238*/ 			switch(Scanner_sym){

/*2240*/ 			case 165:
/*2241*/ 			if( Statements_x_visibility_set ){
/*2242*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2244*/ 			}
/*2244*/ 			Statements_x_visibility_set = TRUE;
/*2245*/ 			Statements_x_visibility = 2;
/*2247*/ 			break;

/*2247*/ 			case 166:
/*2248*/ 			if( Statements_x_visibility_set ){
/*2249*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2251*/ 			}
/*2251*/ 			Statements_x_visibility_set = TRUE;
/*2252*/ 			Statements_x_visibility = 1;
/*2254*/ 			break;

/*2254*/ 			case 167:
/*2255*/ 			if( Statements_x_visibility_set ){
/*2256*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2258*/ 			}
/*2258*/ 			Statements_x_visibility_set = TRUE;
/*2259*/ 			Statements_x_visibility = 0;
/*2261*/ 			break;

/*2261*/ 			case 168:
/*2262*/ 			if( Statements_x_abstract ){
/*2263*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"abstract attribute already set");
/*2265*/ 			}
/*2265*/ 			Statements_x_abstract = TRUE;
/*2267*/ 			break;

/*2267*/ 			case 170:
/*2268*/ 			if( Statements_x_final ){
/*2269*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"final attribute already set");
/*2271*/ 			}
/*2271*/ 			Statements_x_final = TRUE;
/*2273*/ 			break;

/*2273*/ 			case 169:
/*2274*/ 			if( Statements_x_static ){
/*2275*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"static attribute already set");
/*2277*/ 			}
/*2277*/ 			Statements_x_static = TRUE;
/*2279*/ 			break;

/*2279*/ 			case 91:
/*2280*/ 			if( Statements_abstract ){
/*2281*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"abstract attribute already set");
/*2283*/ 			}
/*2283*/ 			Statements_abstract = TRUE;
/*2285*/ 			break;

/*2285*/ 			case 98:
/*2286*/ 			if( Statements_visibility_set ){
/*2287*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2289*/ 			}
/*2289*/ 			Statements_visibility = 2;
/*2290*/ 			Statements_visibility_set = TRUE;
/*2292*/ 			break;

/*2292*/ 			case 100:
/*2293*/ 			if( Statements_visibility_set ){
/*2294*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2296*/ 			}
/*2296*/ 			Statements_visibility = 1;
/*2297*/ 			Statements_visibility_set = TRUE;
/*2299*/ 			break;

/*2299*/ 			case 99:
/*2300*/ 			if( Statements_visibility_set ){
/*2301*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"visibility attribute already set");
/*2303*/ 			}
/*2303*/ 			Statements_visibility = 0;
/*2304*/ 			Statements_visibility_set = TRUE;
/*2306*/ 			break;

/*2306*/ 			case 101:
/*2307*/ 			if( Statements_static ){
/*2308*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"static attribute already set");
/*2310*/ 			}
/*2310*/ 			Statements_static = TRUE;
/*2312*/ 			break;

/*2312*/ 			case 102:
/*2313*/ 			if( Statements_final ){
/*2314*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"final attribute already set");
/*2316*/ 			}
/*2316*/ 			Statements_final = TRUE;
/*2319*/ 			break;

/*2320*/ 			default:
/*2322*/ 			goto m2runtime_loop_4;
/*2323*/ 			}
/*2323*/ 			Scanner_ReadSym();
/*2329*/ 		}while(TRUE);
m2runtime_loop_4: ;
/*2329*/ 		Statements_t = Expressions_ParseType(FALSE);
/*2330*/ 		if( Statements_t == NULL ){
/*2331*/ 			if( Statements_pdb != NULL ){
/*2332*/ 				if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 473) != NULL ){
/*2333*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 474);
/*2334*/ 				} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 475) != NULL ){
/*2335*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 476);
/*2338*/ 				}
/*2339*/ 			}
/*2339*/ 		} else {
/*2339*/ 			if( ((Statements_pdb != NULL) && ((((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 477) != NULL) || ((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 478) != NULL)))) ){
/*2341*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"type declaration both in DocBlock and PHPLint meta-code");
/*2344*/ 			}
/*2345*/ 		}
/*2345*/ 		if( (Scanner_sym == 133) ){
/*2346*/ 			if( Statements_pdb != NULL ){
/*2347*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"unexpected DocBlock for forward declaration");
/*2349*/ 			}
/*2349*/ 			if( Statements_t != NULL ){
/*2350*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"unexpected type for forward declaration");
/*2352*/ 			}
/*2352*/ 			if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2354*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"unexpected attribute for forward declaration");
/*2356*/ 			}
/*2356*/ 			Proto_ParseForwardDecl();
/*2359*/ 		} else if( (Scanner_sym == 96) ){
/*2360*/ 			if( (Globals_php_ver == 4) ){
/*2361*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"invalid `const' declaration (PHP5)");
/*2363*/ 			}
/*2363*/ 			if( Statements_t != NULL ){
/*2364*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"can't provide a type to a class constants");
/*2366*/ 			}
/*2366*/ 			if( (Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2368*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\125,\0,\0,\0)"invalid attribute. Only /*.public|protected|private.*/ is allowed for class constant.");
/*2370*/ 			}
/*2370*/ 			Statements_ParseClassConstDecl(Statements_x_visibility);
/*2373*/ 		} else if( (Scanner_sym == 97) ){
/*2374*/ 			if( (Globals_php_ver == 4) ){
/*2375*/ 				if( (Statements_x_abstract || Statements_x_final || Statements_x_static || Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2377*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\122,\0,\0,\0)"invalid attribute. Only /*.public|protected|private.*/ are allowed for a property.");
/*2380*/ 				}
/*2380*/ 			} else {
/*2380*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"invalid qualifier `var' (PHP 4), use `public'");
/*2382*/ 			}
/*2382*/ 			Scanner_ReadSym();
/*2383*/ 			if( Statements_t == NULL ){
/*2384*/ 				Statements_t = Expressions_ParseType(FALSE);
/*2386*/ 			}
/*2386*/ 			Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"expected property name $xxx");
/*2387*/ 			if( Statements_x_visibility_set ){
/*2388*/ 				Statements_visibility = Statements_x_visibility;
/*2390*/ 			}
/*2390*/ 			Statements_ParseClassPropertyDecl(Statements_visibility, (Statements_x_static || Statements_static), Statements_t);
/*2393*/ 		} else if( (Scanner_sym == 20) ){
/*2394*/ 			if( (Globals_php_ver == 4) ){
/*2395*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"missing `var' before property name");
/*2397*/ 			} else {
/*2397*/ 				if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_final || Statements_x_static) ){
/*2398*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\152,\0,\0,\0)"cannot use meta-code or DocBlock to set visibility|abstract|final attributes, use proper language keywords");
/*2399*/ 				} else if( (Statements_abstract || Statements_final) ){
/*2400*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"properties cannot be abstract nor final");
/*2401*/ 				} else if( (!Statements_visibility_set && !Statements_static) ){
/*2402*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"property requires visibility attribute or static attribute");
/*2405*/ 				}
/*2405*/ 			}
/*2405*/ 			Statements_ParseClassPropertyDecl(Statements_visibility, Statements_static, Statements_t);
/*2408*/ 		} else if( (Scanner_sym == 8) ){
/*2409*/ 			if( (Globals_php_ver == 4) ){
/*2410*/ 				if( (Statements_abstract || Statements_visibility_set || Statements_static || Statements_final) ){
/*2411*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"invalid attribute. Only /*.abstract public|protected|private final static.*/ are allowed for a method.");
/*2413*/ 				}
/*2413*/ 				if( (Statements_x_abstract && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 479)) ){
/*2414*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*2415*/ 					Statements_x_abstract = FALSE;
/*2417*/ 				}
/*2417*/ 				Statements_ParseClassMethodDecl(Statements_x_abstract, Statements_x_visibility, Statements_x_static, Statements_x_final, Statements_t);
/*2419*/ 			} else {
/*2419*/ 				if( (Statements_x_visibility_set || Statements_x_abstract || Statements_x_static || Statements_x_final) ){
/*2420*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\146,\0,\0,\0)"invalid meta-code or DocBlock visibility|abstract|static|final attribute, use proper language keywords");
/*2422*/ 				}
/*2422*/ 				if( (Statements_abstract && ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 480)) ){
/*2423*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"abstract method in non-abstract class");
/*2424*/ 					Statements_abstract = FALSE;
/*2426*/ 				}
/*2426*/ 				Statements_ParseClassMethodDecl(Statements_abstract, Statements_visibility, Statements_static, Statements_final, Statements_t);
/*2430*/ 			}
/*2430*/ 		} else {
/*2430*/ 			Scanner_UnexpectedSymbol();
/*2434*/ 		}
/*2435*/ 	}while(TRUE);
m2runtime_loop_3: ;
/*2435*/ 	if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_class, 72, Statements_0err_entry_get, 481) ){
/*2436*/ 		Classes_CheckImplementedMethods(Statements_class);
/*2439*/ 	}
/*2439*/ 	{
/*2439*/ 		int m2runtime_for_limit_1;
/*2439*/ 		Statements_i = 0;
/*2439*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 36, Statements_0err_entry_get, 482)) - 1);
/*2440*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2440*/ 			Statements_m = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Statements_class, 36, Statements_0err_entry_get, 483), Statements_i, Statements_0err_entry_get, 484);
/*2441*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_m, 44, Statements_0err_entry_get, 485) ){
/*2442*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"missing method `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_m, 8, Statements_0err_entry_get, 486), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_m, 20, Statements_0err_entry_get, 487)), 1));
/*2446*/ 			}
/*2447*/ 		}
/*2447*/ 	}
/*2447*/ 	Globals_curr_class = NULL;
/*2451*/ }


/*2454*/ void
/*2454*/ Statements_ParseInterface(int Statements_private_class)
/*2454*/ {
/*2455*/ 	RECORD * Statements_if = NULL;
/*2455*/ 	RECORD * Statements_class2 = NULL;
/*2455*/ 	RECORD * Statements_class = NULL;
/*2456*/ 	int Statements_static = 0;
/*2458*/ 	RECORD * Statements_t = NULL;
/*2458*/ 	if( (Globals_scope > 0) ){
/*2459*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\171,\0,\0,\0)"class declaration inside a function. The namespace of the classes is still global so the function cannot be called twice.");
/*2461*/ 	}
/*2461*/ 	if( (Globals_php_ver == 4) ){
/*2462*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"invalid keyword `interface' (PHP 5)");
/*2465*/ 	}
/*2465*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 64, Statements_0err_entry_get, 488) = Statements_private_class;
/*2466*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 48, Statements_0err_entry_get, 489) = Scanner_here();
/*2467*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 76, Statements_0err_entry_get, 490) = TRUE;
/*2468*/ 	if( !Accounting_report_unused ){
/*2469*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 88, Statements_0err_entry_get, 491) = 100;
/*2475*/ 	}
/*2475*/ 	Scanner_ReadSym();
/*2476*/ 	Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected class name");
/*2477*/ 	Statements_class2 = Search_SearchClass(Scanner_s, FALSE);
/*2478*/ 	if( Statements_class2 != NULL ){
/*2479*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_class2, 60, Statements_0err_entry_get, 492) ){
/*2480*/ 			Statements_class = Statements_class2;
/*2481*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 60, Statements_0err_entry_get, 493) = FALSE;
/*2483*/ 		} else {
/*2483*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_class2, 48, Statements_0err_entry_get, 494)), 1));
/*2487*/ 		}
/*2490*/ 	} else {
/*2490*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 8, Statements_0err_entry_get, 495) = Scanner_s;
/*2491*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 12, Statements_0err_entry_get, 496) = str_toupper(Scanner_s);
/*2492*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 24, Statements_0err_entry_get, 497) = (
/*2492*/ 			push((char*) alloc_RECORD(24, 2)),
/*2492*/ 			*(int*) (tos()+16) = 9,
/*2492*/ 			*(int*) (tos()+20) = 1,
/*2492*/ 			push((char*) NULL),
/*2492*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*2492*/ 			push((char*) Statements_class),
/*2493*/ 			*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*2493*/ 			(RECORD*) pop()
/*2493*/ 		);
/*2493*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_classes, 4, 1, Statements_0err_entry_get, 498) = Statements_class;
/*2496*/ 	}
/*2496*/ 	Globals_curr_class = Statements_class;
/*2497*/ 	Scanner_ReadSym();
/*2502*/ 	if( (Scanner_sym == 94) ){
/*2503*/ 		Scanner_ReadSym();
/*2505*/ 		do{
/*2505*/ 			Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"expected interface class name");
/*2506*/ 			Statements_if = Search_SearchClass(Scanner_s, TRUE);
/*2507*/ 			if( Statements_if == NULL ){
/*2508*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"undeclared interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2509*/ 			} else if( Classes_IsSubclassOf(Statements_if, Statements_class) ){
/*2510*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"interface ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 8, Statements_0err_entry_get, 499), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)" cannot extend interface ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 500), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)": forbidden circular reference", 1));
/*2512*/ 			} else if( ! *(int *)m2runtime_dereference_rhs_RECORD(Statements_if, 76, Statements_0err_entry_get, 501) ){
/*2513*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"interface cannot extend non-interface class `", Scanner_s, m2runtime_CHR(39), 1));
/*2514*/ 			} else if( Classes_IsSubclassOf(Statements_class, Statements_if) ){
/*2515*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"interface ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_class, 8, Statements_0err_entry_get, 502), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)" redundantly extends interface ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 503), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)" -- ignoring", 1));
/*2519*/ 			} else {
/*2519*/ 				*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 20, Statements_0err_entry_get, 504), 4, 1, Statements_0err_entry_get, 505) = Statements_if;
/*2520*/ 				Accounting_AccountClass(Statements_if);
/*2521*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 506), EMPTY_STRING) > 0 ){
/*2522*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"extending deprecated class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 8, Statements_0err_entry_get, 507), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_if, 56, Statements_0err_entry_get, 508), 1));
/*2526*/ 				}
/*2526*/ 			}
/*2526*/ 			Scanner_ReadSym();
/*2527*/ 			if( (Scanner_sym == 16) ){
/*2528*/ 				Scanner_ReadSym();
/*2531*/ 			} else {
/*2532*/ 				goto m2runtime_loop_1;
/*2533*/ 			}
/*2534*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*2534*/ 	}
/*2534*/ 	Classes_CheckCollisionsBetweenExtendedAndImplementedClasses(Statements_class);
/*2536*/ 	if( (Scanner_sym == 174) ){
/*2537*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 509) = Scanner_s;
/*2538*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 510) = Documentator_ExtractDeprecated(Scanner_s);
/*2539*/ 		Scanner_ReadSym();
/*2540*/ 	} else if( Statements_pdb != NULL ){
/*2541*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 52, Statements_0err_entry_get, 511) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 512);
/*2542*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_class, 92, 13, 56, Statements_0err_entry_get, 513) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 514));
/*2543*/ 		Statements_pdb = NULL;
/*2546*/ 	}
/*2546*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"expected '{' in class declaration");
/*2547*/ 	Scanner_ReadSym();
/*2550*/ 	do{
/*2550*/ 		if( (Scanner_sym == 11) ){
/*2551*/ 			Scanner_ReadSym();
/*2554*/ 			goto m2runtime_loop_2;
/*2555*/ 		}
/*2555*/ 		Statements_static = FALSE;
/*2557*/ 		Statements_pdb = NULL;
/*2558*/ 		if( (Scanner_sym == 175) ){
/*2559*/ 			Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*2560*/ 			if( Statements_pdb != NULL ){
/*2561*/ 				if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 515) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 52, Statements_0err_entry_get, 516) ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 56, Statements_0err_entry_get, 517)) ){
/*2562*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"in DocBlock: visibility attributes not allowed in interface");
/*2564*/ 				}
/*2564*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 60, Statements_0err_entry_get, 518) ){
/*2565*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"in DocBlock: final attribute not allowed in interface");
/*2567*/ 				}
/*2567*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 64, Statements_0err_entry_get, 519) ){
/*2568*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\127,\0,\0,\0)"in DocBlock: static attribute not allowed, use proper language keyword `static' instead");
/*2571*/ 				}
/*2571*/ 			}
/*2571*/ 			Scanner_ReadSym();
/*2574*/ 		}
/*2574*/ 		if( (Scanner_sym == 96) ){
/*2575*/ 			Statements_ParseClassConstDecl(2);
/*2582*/ 		} else {
/*2582*/ 			Statements_static = FALSE;
/*2584*/ 			do{
/*2584*/ 				if( (Scanner_sym == 98) ){
/*2585*/ 					Scanner_ReadSym();
/*2586*/ 				} else if( (((Scanner_sym == 100)) || ((Scanner_sym == 99))) ){
/*2587*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\130,\0,\0,\0)"invalid visibility attribute for interface method. Abstract methods are always `public'.");
/*2588*/ 					Scanner_ReadSym();
/*2589*/ 				} else if( (Scanner_sym == 102) ){
/*2590*/ 					Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"invalid `final' attribute for abstract method");
/*2591*/ 					Scanner_ReadSym();
/*2592*/ 				} else if( (Scanner_sym == 101) ){
/*2593*/ 					Statements_static = TRUE;
/*2594*/ 					Scanner_ReadSym();
/*2597*/ 				} else {
/*2598*/ 					goto m2runtime_loop_3;
/*2599*/ 				}
/*2603*/ 			}while(TRUE);
m2runtime_loop_3: ;
/*2603*/ 			if( Statements_pdb != NULL ){
/*2604*/ 				Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 24, Statements_0err_entry_get, 520);
/*2606*/ 			} else {
/*2606*/ 				Statements_t = Expressions_ParseType(FALSE);
/*2609*/ 			}
/*2609*/ 			if( (Scanner_sym == 20) ){
/*2610*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"properties cannot be defined in interfaces");
/*2613*/ 			}
/*2613*/ 			Scanner_Expect(8, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"expected `function' declaration in interface class");
/*2614*/ 			Statements_ParseClassMethodDecl(TRUE, 2, Statements_static, FALSE, Statements_t);
/*2618*/ 		}
/*2619*/ 	}while(TRUE);
m2runtime_loop_2: ;
/*2619*/ 	Globals_curr_class = NULL;
/*2623*/ }


/*2625*/ void
/*2625*/ Statements_ParseStatic(void)
/*2625*/ {
/*2626*/ 	RECORD * Statements_r = NULL;
/*2627*/ 	STRING * Statements_id = NULL;
/*2628*/ 	RECORD * Statements_v = NULL;
/*2630*/ 	RECORD * Statements_t = NULL;
/*2630*/ 	if( (Globals_scope == 0) ){
/*2631*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"static declaration at global scope has no effect");
/*2633*/ 	}
/*2633*/ 	Scanner_ReadSym();
/*2634*/ 	Statements_t = Expressions_ParseType(FALSE);
/*2637*/ 	do{
/*2637*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected variable name in static declaration");
/*2638*/ 		Statements_id = Scanner_s;
/*2641*/ 		Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2642*/ 		if( ((Statements_v != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Statements_v, 40, Statements_0err_entry_get, 521) == Globals_scope))) ){
/*2643*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"`static $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"': variable already exists", 1));
/*2645*/ 		}
/*2645*/ 		Statements_v = NULL;
/*2647*/ 		Accounting_AccountVarLHS(Statements_id, FALSE);
/*2648*/ 		Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2650*/ 		if( Statements_t != NULL ){
/*2651*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 522) = Statements_t;
/*2654*/ 		}
/*2654*/ 		Scanner_ReadSym();
/*2655*/ 		if( (Scanner_sym == 31) ){
/*2656*/ 			Scanner_ReadSym();
/*2657*/ 			Statements_r = Expressions_ParseStaticExpr();
/*2658*/ 			if( Statements_r == NULL ){
/*2662*/ 			}
/*2662*/ 			if( Statements_r != NULL ){
/*2663*/ 				if( Statements_t == NULL ){
/*2664*/ 					Statements_v = Search_SearchVar(Statements_id, Globals_scope);
/*2665*/ 					*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 523) = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 524);
/*2667*/ 				} else {
/*2667*/ 					switch(Expressions_LhsMatchRhs(Statements_t, (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 525))){

/*2668*/ 					case 1:
/*2669*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"the type of the expression ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 526)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" does not match the ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"type of the variable `", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString(Statements_t), 1));
/*2673*/ 					break;

/*2673*/ 					case 2:
/*2674*/ 					Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"the type of the expression ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 527)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)" does not match the ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"type of the variable `", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"' ", Types_TypeToString(Statements_t), 1));
/*2679*/ 					break;
/*2681*/ 					}
/*2682*/ 				}
/*2682*/ 			}
/*2682*/ 		} else if( Statements_t == NULL ){
/*2683*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"undefined type for static variable `$", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"'. Undefined static variables take the initial value NULL.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)" Hint: either specify a type (example: /*.int.*/ $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)") or an initial value (example: $", Statements_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"=123).", 1));
/*2688*/ 		}
/*2688*/ 		if( (Scanner_sym == 16) ){
/*2689*/ 			Scanner_ReadSym();
/*2690*/ 		} else if( (Scanner_sym == 17) ){
/*2693*/ 			goto m2runtime_loop_1;
/*2693*/ 		} else {
/*2693*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"expected `=' or `,' or `;' in static declaration, found ", Scanner_SymToName(Scanner_sym), 1));
/*2696*/ 		}
/*2697*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*2699*/ }


/*2701*/ int
/*2701*/ Statements_ParseIf(void)
/*2701*/ {
/*2702*/ 	RECORD * Statements_r = NULL;
/*2703*/ 	STRING * Statements_s = NULL;
/*2705*/ 	int Statements_p = 0;
/*2705*/ 	int Statements_res = 0;
/*2705*/ 	Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"`if(EXPR)'";
/*2707*/ 	do {
/*2707*/ 		Scanner_ReadSym();
/*2708*/ 		Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"expected '(' after `if' or `elseif'");
/*2709*/ 		Scanner_ReadSym();
/*2710*/ 		Statements_r = Expressions_ParseExpr();
/*2711*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"expected closing ')' after 'if' condition");
/*2712*/ 		Expressions_CheckBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"`if(EXPR)'", Statements_r);
/*2713*/ 		Scanner_ReadSym();
/*2714*/ 		Statements_p = Statements_ParseBlock();
/*2715*/ 		Statements_res = (Statements_res | Statements_p);
/*2716*/ 		Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"`elseif(EXPR)'";
/*2717*/ 	} while( !( (Scanner_sym != 27) ));
/*2718*/ 	if( (Scanner_sym == 26) ){
/*2719*/ 		Scanner_ReadSym();
/*2720*/ 		Statements_p = Statements_ParseBlock();
/*2721*/ 		Statements_res = (Statements_res | Statements_p);
/*2723*/ 	} else {
/*2723*/ 		Statements_res = (Statements_res | 1);
/*2725*/ 	}
/*2725*/ 	return Statements_res;
/*2729*/ }


/*2731*/ void
/*2731*/ Statements_ParseDefine(int Statements_private)
/*2731*/ {
/*2732*/ 	STRING * Statements_name = NULL;
/*2733*/ 	RECORD * Statements_r = NULL;
/*2734*/ 	RECORD * Statements_t = NULL;
/*2735*/ 	RECORD * Statements_c = NULL;
/*2737*/ 	STRING * Statements_descr = NULL;
/*2738*/ 	Statements_DocBlockCheckAllowedLineTags(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"define()");
/*2740*/ 	if( (Globals_scope > 0) ){
/*2741*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\125,\0,\0,\0)"define() inside a function: the scope of the constants defined here however is global");
/*2743*/ 	}
/*2743*/ 	Scanner_ReadSym();
/*2744*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"missing '(' after 'define'");
/*2747*/ 	Scanner_ReadSym();
/*2748*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*2749*/ 	if( Statements_r == NULL ){
/*2751*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 528) == NULL ){
/*2752*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\126,\0,\0,\0)"unable to parse the name of the constant as a value statically determined, will ignore");
/*2754*/ 	} else {
/*2754*/ 		Statements_name = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 529);
/*2755*/ 		if( !m2_match(Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"^[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*$") ){
/*2756*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"invalid characters in constant name `", Statements_name, m2runtime_CHR(39), 1));
/*2757*/ 		} else if( (Scanner_SearchPhpKeyword(Statements_name) != 1) ){
/*2758*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"constant name `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' is a keyword", 1));
/*2761*/ 		}
/*2762*/ 	}
/*2762*/ 	Scanner_Expect(16, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"expexted `,' in define()");
/*2763*/ 	Scanner_ReadSym();
/*2766*/ 	Statements_r = Expressions_ParseExpr();
/*2767*/ 	if( Statements_r == NULL ){
/*2770*/ 	} else {
/*2770*/ 		Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 530);
/*2771*/ 		if( !(((Statements_t == Globals_null_type) || (Statements_t == Globals_boolean_type) || (Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type))) ){
/*2772*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid constant value of type ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)". It must be boolean, int, float or string", 1));
/*2774*/ 		} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 531) == NULL ){
/*2775*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)"can't parse the value of the constant as a statically determinable value");
/*2778*/ 		}
/*2779*/ 	}
/*2779*/ 	if( Statements_name != NULL ){
/*2780*/ 		Statements_c = Accounting_AccountConstLHS(Statements_name, Statements_private, Statements_r);
/*2783*/ 	}
/*2783*/ 	if( (Scanner_sym == 16) ){
/*2784*/ 		Scanner_ReadSym();
/*2785*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\113,\0,\0,\0)"will ignore third argument of define(): constants are always case-sensitive");
/*2786*/ 		Statements_r = Expressions_ParseExprOfType(Globals_boolean_type);
/*2789*/ 	}
/*2789*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"expected closing ')' in 'define'");
/*2790*/ 	Scanner_ReadSym();
/*2801*/ 	if( (Scanner_sym == 17) ){
/*2802*/ 		Scanner_ReadSym();
/*2803*/ 		if( (Scanner_sym == 174) ){
/*2804*/ 			Statements_descr = Scanner_s;
/*2805*/ 			Scanner_ReadSym();
/*2808*/ 		}
/*2808*/ 	} else if( (((Scanner_sym == 6)) || ((Scanner_sym == 0))) ){
/*2815*/ 	} else {
/*2820*/ 	}
/*2820*/ 	if( Statements_descr != NULL ){
/*2821*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 24, Statements_0err_entry_get, 532) = Statements_descr;
/*2822*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 28, Statements_0err_entry_get, 533) = Documentator_ExtractDeprecated(Statements_descr);
/*2823*/ 	} else if( Statements_pdb != NULL ){
/*2824*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 24, Statements_0err_entry_get, 534) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 535);
/*2825*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 28, Statements_0err_entry_get, 536) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 537));
/*2826*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_c, 40, 6, 32, Statements_0err_entry_get, 538) = ((Statements_private ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 539)));
/*2827*/ 		Statements_pdb = NULL;
/*2831*/ 	}
/*2833*/ }


/*2835*/ int
/*2835*/ Statements_ParseDeclare(void)
/*2835*/ {

/*2836*/ 	void
/*2836*/ 	Statements_ParseDirective(void)
/*2836*/ 	{
/*2838*/ 		RECORD * Statements_r = NULL;
/*2838*/ 		if( (Scanner_sym != 29) ){
/*2839*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected identifier");
/*2841*/ 		}
/*2841*/ 		if( m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"ticks") != 0 ){
/*2842*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unknown directive \042", Scanner_s, m2runtime_CHR(34), 1));
/*2844*/ 		}
/*2844*/ 		Scanner_ReadSym();
/*2846*/ 		Scanner_Expect(31, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `='");
/*2847*/ 		Scanner_ReadSym();
/*2849*/ 		Statements_r = Expressions_ParseStaticExpr();
/*2853*/ 	}

/*2853*/ 	Scanner_ReadSym();
/*2854*/ 	Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `('");
/*2855*/ 	Scanner_ReadSym();
/*2857*/ 	do{
/*2857*/ 		Statements_ParseDirective();
/*2858*/ 		if( (Scanner_sym == 16) ){
/*2859*/ 			Scanner_ReadSym();
/*2862*/ 		} else {
/*2863*/ 			goto m2runtime_loop_1;
/*2864*/ 		}
/*2864*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*2864*/ 	Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"expected `,' or `)'");
/*2865*/ 	Scanner_ReadSym();
/*2866*/ 	return Statements_ParseBlock();
/*2870*/ }


/*2871*/ int
/*2871*/ Statements_readable(STRING *Statements_f)
/*2871*/ {
/*2873*/ 	void * Statements_fd = NULL;
/*2873*/ 	m2runtime_ERROR_CODE = 0;
/*2873*/ 	io_Open(1, (void *)&Statements_fd, Statements_f, m2runtime_CHR(114));
/*2874*/ 	switch( m2runtime_ERROR_CODE ){

/*2874*/ 	case 0:
/*2875*/ 		m2runtime_ERROR_CODE = 0;
/*2875*/ 		io_Close(1, (void *)&Statements_fd);
/*2876*/ 		switch( m2runtime_ERROR_CODE ){

/*2876*/ 		case 0:  break;
/*2876*/ 		default:
/*2876*/ 			m2runtime_HALT(Statements_0err_entry_get, 540, m2runtime_ERROR_MESSAGE);
/*2876*/ 		}
/*2876*/ 		return TRUE;
/*2878*/ 		break;

/*2878*/ 	default:
/*2878*/ 		return FALSE;
/*2881*/ 	}
/*2881*/ 	m2runtime_missing_return(Statements_0err_entry_get, 541);
/*2881*/ 	return 0;
/*2883*/ }


/*2888*/ void
/*2888*/ Statements_AddPackageToIncludePath(STRING *Statements_p)
/*2888*/ {
/*2890*/ 	int Statements_i = 0;
/*2890*/ 	{
/*2890*/ 		int m2runtime_for_limit_1;
/*2890*/ 		Statements_i = 0;
/*2890*/ 		m2runtime_for_limit_1 = (m2runtime_count(Statements_include_path) - 1);
/*2891*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2891*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(Statements_include_path, Statements_i, Statements_0err_entry_get, 542), Statements_p) == 0 ){
/*2893*/ 				return ;
/*2895*/ 			}
/*2895*/ 		}
/*2895*/ 	}
/*2895*/ 	*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Statements_include_path, 4, 1, Statements_0err_entry_get, 543) = Statements_p;
/*2899*/ }


/*2905*/ STRING *
/*2905*/ Statements_SearchFileOnPaths(STRING *Statements_name, int Statements_module)
/*2905*/ {
/*2906*/ 	STRING * Statements_n = NULL;
/*2907*/ 	ARRAY * Statements_a = NULL;
/*2909*/ 	int Statements_i = 0;
/*2910*/ 	Statements_n = FileName_Absolute(NULL, Statements_name);
/*2911*/ 	if( Statements_readable(Statements_n) ){
/*2912*/ 		return Statements_n;
/*2915*/ 	}
/*2915*/ 	if( ((m2runtime_strcmp(Statements_name, EMPTY_STRING) > 0) && (m2runtime_strcmp(m2runtime_substr(Statements_name, 0, 0, 0, Statements_0err_entry_get, 544), m2runtime_CHR(47)) != 0)) ){
/*2916*/ 		if( Statements_module ){
/*2917*/ 			Statements_a = Statements_modules_abs_path;
/*2919*/ 		} else {
/*2919*/ 			Statements_a = Statements_packages_abs_path;
/*2921*/ 		}
/*2921*/ 		{
/*2921*/ 			int m2runtime_for_limit_1;
/*2921*/ 			Statements_i = 0;
/*2921*/ 			m2runtime_for_limit_1 = (m2runtime_count(Statements_a) - 1);
/*2922*/ 			for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*2922*/ 				Statements_n = FileName_Absolute(NULL, m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_ARRAY(Statements_a, Statements_i, Statements_0err_entry_get, 545), m2runtime_CHR(47), Statements_name, 1));
/*2923*/ 				if( Statements_readable(Statements_n) ){
/*2924*/ 					if( !Statements_module ){
/*2925*/ 						Statements_AddPackageToIncludePath(FileName_Basename(Statements_name));
/*2927*/ 					}
/*2927*/ 					return Statements_n;
/*2930*/ 				}
/*2931*/ 			}
/*2931*/ 		}
/*2932*/ 	}
/*2932*/ 	if( Statements_module ){
/*2933*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"module `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"' not found", 1));
/*2935*/ 	} else {
/*2935*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"package `", Statements_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"' not found", 1));
/*2938*/ 	}
/*2938*/ 	return NULL;
/*2943*/ }


/*2949*/ void
/*2949*/ Statements_RequirePackage(STRING *Statements_pathfile, int Statements_module)
/*2949*/ {
/*2950*/ 	STRING * Statements_abs_pathfile = NULL;
/*2951*/ 	void * Statements_sc = NULL;
/*2952*/ 	int Statements_s_print_notices = 0;
/*2952*/ 	int Statements_s_print_source = 0;
/*2952*/ 	int Statements_s_report_unused = 0;
/*2953*/ 	RECORD * Statements_s_curr_package = NULL;
/*2955*/ 	STRING * Statements_s = NULL;
/*2955*/ 	Statements_abs_pathfile = Statements_SearchFileOnPaths(Statements_pathfile, Statements_module);
/*2956*/ 	if( Statements_abs_pathfile == NULL ){
/*2958*/ 		return ;
/*2961*/ 	}
/*2961*/ 	Statements_sc = Scanner_Suspend();
/*2962*/ 	Statements_s_report_unused = Accounting_report_unused;
/*2963*/ 	Accounting_report_unused = FALSE;
/*2964*/ 	Statements_s_print_source = Scanner_print_source;
/*2965*/ 	Scanner_print_source = FALSE;
/*2966*/ 	Statements_s_print_notices = Scanner_print_notices;
/*2967*/ 	Scanner_print_notices = FALSE;
/*2968*/ 	Statements_s_curr_package = Statements_curr_package;
/*2969*/ 	Statements_pdb = NULL;
	Statements_curr_package = Statements_ParsePackage(Statements_abs_pathfile, Statements_module);
/*2974*/ 	Accounting_report_unused = Statements_s_report_unused;
/*2975*/ 	Scanner_print_source = Statements_s_print_source;
/*2976*/ 	Scanner_print_notices = Statements_s_print_notices;
/*2977*/ 	Scanner_Resume(Statements_sc);
/*2979*/ 	if( ((Statements_curr_package != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 16, Statements_0err_entry_get, 546), EMPTY_STRING) > 0)) ){
/*2980*/ 		if( Statements_module ){
/*2981*/ 			Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"module";
/*2983*/ 		} else {
/*2983*/ 			Statements_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package";
/*2985*/ 		}
/*2985*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"using deprecated ", Statements_s, m2runtime_CHR(32), Statements_abs_pathfile, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_curr_package, 16, Statements_0err_entry_get, 547), 1));
/*2989*/ 	}
/*2989*/ 	Statements_curr_package = Statements_s_curr_package;
/*2993*/ }


/*2995*/ void
/*2995*/ Statements_ParseRequireModule(void)
/*2995*/ {
/*2995*/ 	if( (Globals_scope > 0) ){
/*2996*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\51,\0,\0,\0)"found `require_module' in scope level > 0");
/*2998*/ 	}
/*2998*/ 	Scanner_ReadSym();
/*2999*/ 	Scanner_Expect(128, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"expected single quoted string after `require_module'");
/*3000*/ 	if( !m2_match(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"^[a-zA-Z0-9_]+$") ){
/*3001*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"require_module '", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"': invalid module name", 1));
/*3003*/ 	} else {
/*3003*/ 		Statements_RequirePackage(Scanner_s, TRUE);
/*3005*/ 	}
/*3005*/ 	Scanner_ReadSym();
/*3006*/ 	Scanner_Expect(129, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"missing `;'");
/*3007*/ 	Scanner_ReadSym();
/*3011*/ }


/*3013*/ void
/*3013*/ Statements_ParseRequireOnce(void)
/*3013*/ {
/*3014*/ 	RECORD * Statements_r = NULL;
/*3016*/ 	STRING * Statements_f = NULL;
/*3016*/ 	if( (Globals_scope > 0) ){
/*3017*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"found `require_once' in scope level > 0");
/*3019*/ 	}
/*3019*/ 	Scanner_ReadSym();
/*3021*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*3022*/ 	if( Statements_r == NULL ){
/*3024*/ 		return ;
/*3024*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 548) == NULL ){
/*3025*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"require_once: can't check file name, value undetermined");
/*3027*/ 		return ;
/*3027*/ 	} else if( (m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 549)) == 0) ){
/*3028*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"require_once: empty file name");
/*3030*/ 		return ;
/*3031*/ 	}
/*3031*/ 	Statements_f = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 550);
/*3033*/ 	if( !Statements_recursive_parsing ){
/*3034*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"require_once '", Statements_f, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"': recursive inclusion disabled", 1));
/*3036*/ 		return ;
/*3038*/ 	}
/*3038*/ 	Statements_RequirePackage(Statements_f, FALSE);
/*3042*/ }


/*3043*/ void
/*3043*/ Statements_ParseInclude(STRING *Statements_n)
/*3043*/ {
/*3045*/ 	RECORD * Statements_r = NULL;
/*3045*/ 	Scanner_ReadSym();
/*3046*/ 	Statements_r = Expressions_ParseExprOfType(Globals_string_type);
/*3047*/ 	if( Statements_r == NULL ){
/*3049*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 551) == NULL ){
/*3050*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)": can't check file name, value undetermined", 1));
/*3051*/ 	} else if( (m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 552)) == 0) ){
/*3052*/ 		Scanner_Error(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)": empty file name", 1));
/*3053*/ 	} else if( m2runtime_strcmp(m2runtime_substr((STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 553), 0, 0, 0, Statements_0err_entry_get, 554), m2runtime_CHR(47)) != 0 ){
/*3054*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" \042", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 555), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"\042 uses relative pathfile, check `include_path' in php.ini", 1));
/*3057*/ 	} else {
/*3057*/ 		Scanner_Notice(m2runtime_concat_STRING(0, Statements_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" \042", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_r, 12, Statements_0err_entry_get, 556), m2runtime_CHR(34), 1));
/*3060*/ 	}
/*3062*/ }


/*3064*/ void
/*3064*/ Statements_ParseThrow(void)
/*3064*/ {
/*3065*/ 	RECORD * Statements_r = NULL;
/*3067*/ 	RECORD * Statements_t = NULL;
/*3067*/ 	Scanner_ReadSym();
/*3068*/ 	Statements_r = Expressions_ParseExpr();
/*3069*/ 	if( Statements_r == NULL ){
/*3072*/ 		return ;
/*3073*/ 	}
/*3073*/ 	Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 557);
/*3074*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_t, 16, Statements_0err_entry_get, 558) == 9) ){
/*3075*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 559) == NULL ){
/*3076*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"the object isn't an extension of the Exception class");
/*3077*/ 		} else if( Exceptions_IsExceptionClass((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 560)) ){
/*3078*/ 			Exceptions_AddException((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 561));
/*3080*/ 		} else {
/*3080*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_t, 12, Statements_0err_entry_get, 562), 8, Statements_0err_entry_get, 563), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"' isn't an extension of the `Exception' class", 1));
/*3084*/ 		}
/*3084*/ 	} else {
/*3084*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected an object, found ", Types_TypeToString(Statements_t), 1));
/*3087*/ 	}
/*3089*/ }


/*3091*/ int
/*3091*/ Statements_ParseTry(void)
/*3091*/ {
/*3092*/ 	RECORD * Statements_try_location = NULL;
/*3093*/ 	RECORD * Statements_class = NULL;
/*3094*/ 	RECORD * Statements_v = NULL;
/*3095*/ 	ARRAY * Statements_exceptions = NULL;
/*3095*/ 	ARRAY * Statements_saved_exceptions = NULL;
/*3098*/ 	int Statements_p = 0;
/*3098*/ 	int Statements_res = 0;
/*3098*/ 	Statements_try_location = Scanner_here();
/*3099*/ 	Scanner_ReadSym();
/*3100*/ 	Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected `{' after try");
/*3103*/ 	m2_inc(&Exceptions_try_block_nesting_level, 1);
/*3104*/ 	Statements_saved_exceptions = Exceptions_exceptions;
/*3105*/ 	Exceptions_exceptions = NULL;
/*3108*/ 	Statements_res = Statements_ParseBlock();
/*3111*/ 	m2_inc(&Exceptions_try_block_nesting_level, -1);
/*3112*/ 	Statements_exceptions = Exceptions_exceptions;
/*3113*/ 	Exceptions_exceptions = Statements_saved_exceptions;
/*3114*/ 	if( Statements_exceptions == NULL ){
/*3115*/ 		Scanner_Notice2(Statements_try_location, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"no exception at all thrown inside this try{} block");
/*3120*/ 	}
/*3120*/ 	Scanner_Expect(119, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"expected `catch'");
/*3122*/ 	do {
/*3122*/ 		Scanner_ReadSym();
/*3124*/ 		Scanner_Expect(12, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"expected `(' after `catch'");
/*3125*/ 		Scanner_ReadSym();
/*3127*/ 		Scanner_Expect(29, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"expected exception class name");
/*3128*/ 		Statements_class = Search_SearchClass(Scanner_s, TRUE);
/*3129*/ 		if( Statements_class == NULL ){
/*3130*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"undefined class `", Scanner_s, m2runtime_CHR(39), 1));
/*3131*/ 		} else if( Exceptions_IsExceptionClass(Statements_class) ){
/*3132*/ 			if( !Exceptions_RemoveExceptionFromSet(Statements_class, &Statements_exceptions) ){
/*3133*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"exception `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"' not thrown or already caught", 1));
/*3136*/ 			}
/*3136*/ 		} else {
/*3136*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the class `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"' isn't an extension of the `Exception' class", 1));
/*3138*/ 		}
/*3138*/ 		Scanner_ReadSym();
/*3140*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"expected variable name");
/*3141*/ 		Accounting_AccountVarLHS(Scanner_s, FALSE);
/*3142*/ 		if( Statements_class != NULL ){
/*3143*/ 			Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*3144*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 564) = (
/*3144*/ 				push((char*) alloc_RECORD(24, 2)),
/*3144*/ 				*(int*) (tos()+16) = 9,
/*3144*/ 				*(int*) (tos()+20) = 1,
/*3144*/ 				push((char*) NULL),
/*3144*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3144*/ 				push((char*) Statements_class),
/*3145*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3146*/ 				(RECORD*) pop()
/*3146*/ 			);
/*3146*/ 		}
/*3146*/ 		Scanner_ReadSym();
/*3148*/ 		Scanner_Expect(13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `)'");
/*3149*/ 		Scanner_ReadSym();
/*3151*/ 		Scanner_Expect(10, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `{'");
/*3152*/ 		Statements_p = Statements_ParseBlock();
/*3154*/ 		Statements_res = (Statements_res | Statements_p);
/*3155*/ 	} while( !( (Scanner_sym != 119) ));
/*3158*/ 	Exceptions_ThrowExceptions(Statements_exceptions);
/*3160*/ 	return Statements_res;
/*3164*/ }


/*3166*/ void
/*3166*/ Statements_ParseEchoBlock(void)
/*3166*/ {
/*3166*/ 	RECORD * Statements_r = NULL;
/*3168*/ 	RECORD * Statements_t = NULL;
/*3168*/ 	Scanner_ReadSym();
/*3170*/ 	do{
/*3170*/ 		Statements_r = Expressions_ParseExpr();
/*3171*/ 		if( Statements_r == NULL ){
/*3174*/ 		} else {
/*3174*/ 			Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_r, 8, Statements_0err_entry_get, 565);
/*3175*/ 			if( !(((Statements_t == Globals_int_type) || (Statements_t == Globals_float_type) || (Statements_t == Globals_string_type))) ){
/*3177*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"found ", Types_TypeToString(Statements_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)". The arguments of the `<?= ... ?>' block must be of", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" type int, float or string.", 1));
/*3182*/ 			}
/*3182*/ 		}
/*3182*/ 		if( (Scanner_sym == 16) ){
/*3183*/ 			Scanner_ReadSym();
/*3184*/ 		} else if( (Scanner_sym == 6) ){
/*3185*/ 			Scanner_ReadSym();
/*3187*/ 			return ;
/*3187*/ 		} else if( (Scanner_sym == 0) ){
/*3189*/ 			return ;
/*3189*/ 		} else if( (Scanner_sym == 17) ){
/*3190*/ 			Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"unuseful `;' symbol");
/*3191*/ 			Scanner_ReadSym();
/*3192*/ 			Scanner_Expect(6, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"missing closing tag");
/*3193*/ 			Scanner_ReadSym();
/*3195*/ 			return ;
/*3196*/ 		} else {
/*3196*/ 			Scanner_UnexpectedSymbol();
/*3199*/ 		}
/*3200*/ 	}while(TRUE);
/*3202*/ }


/*3205*/ void
/*3205*/ Statements_ParseTextBlock(void)
/*3205*/ {
/*3205*/ 	Scanner_ReadSym();
/*3207*/ 	do{
/*3207*/ 		if( (Scanner_sym == 3) ){
/*3208*/ 			Scanner_ReadSym();
/*3209*/ 		} else if( (Scanner_sym == 5) ){
/*3210*/ 			Statements_ParseEchoBlock();
/*3211*/ 		} else if( (Scanner_sym == 4) ){
/*3212*/ 			Scanner_ReadSym();
/*3214*/ 			return ;
/*3215*/ 		} else {
/*3215*/ 			Scanner_UnexpectedSymbol();
/*3218*/ 		}
/*3219*/ 	}while(TRUE);
/*3221*/ }


/*3226*/ int
/*3226*/ Statements_ParseCodeBlock(void)
/*3226*/ {
/*3228*/ 	int Statements_res = 0;
/*3228*/ 	Scanner_ReadSym();
/*3229*/ 	Statements_res = 1;
/*3231*/ 	do{
/*3231*/ 		if( (Scanner_sym == 6) ){
/*3232*/ 			Scanner_ReadSym();
/*3233*/ 			return Statements_res;
/*3234*/ 		} else if( (Scanner_sym == 0) ){
/*3235*/ 			return Statements_res;
/*3237*/ 		} else {
/*3237*/ 			if( ((Statements_res & 1) == 0) ){
/*3238*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unreachable statement");
/*3240*/ 			}
/*3240*/ 			Statements_res = (((Statements_res & ~1)) | Statements_ParseStatement());
/*3243*/ 		}
/*3244*/ 	}while(TRUE);
/*3244*/ 	m2runtime_missing_return(Statements_0err_entry_get, 566);
/*3244*/ 	return 0;
/*3246*/ }


/*3249*/ void
/*3249*/ Statements_ParserInit(void)
/*3249*/ {
/*3250*/ 	static int Statements_parser_init = 0;
/*3251*/ 	static RECORD * Statements_here = NULL;
/*3253*/ 	static RECORD * Statements_ass = NULL;
/*3253*/ 	static RECORD * Statements_asm = NULL;

/*3254*/ 	void
/*3254*/ 	Statements_add(STRING *Statements_s, RECORD *Statements_t)
/*3254*/ 	{
/*3256*/ 		RECORD * Statements_v = NULL;
/*3256*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 8, Statements_0err_entry_get, 567) = Statements_s;
/*3257*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 12, Statements_0err_entry_get, 568) = Statements_here;
/*3258*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 40, Statements_0err_entry_get, 569) = -1;
/*3259*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 44, Statements_0err_entry_get, 570) = TRUE;
/*3260*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 16, Statements_0err_entry_get, 571) = Statements_here;
/*3261*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 48, Statements_0err_entry_get, 572) = 100;
/*3262*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 573) = Statements_t;
/*3263*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Globals_vars_n, Statements_0err_entry_get, 574) = Statements_v;
/*3264*/ 		m2_inc(&Globals_vars_n, 1);
/*3268*/ 	}

/*3268*/ 	if( Statements_parser_init ){
/*3270*/ 		return ;
/*3271*/ 	}
/*3271*/ 	Statements_parser_init = TRUE;
/*3273*/ 	Scanner_InitScanner();
/*3280*/ 	Globals_null_type = (
/*3280*/ 		push((char*) alloc_RECORD(24, 2)),
/*3280*/ 		*(int*) (tos()+16) = 0,
/*3280*/ 		*(int*) (tos()+20) = 1,
/*3280*/ 		push((char*) NULL),
/*3280*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3280*/ 		push((char*) NULL),
/*3281*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3281*/ 		(RECORD*) pop()
/*3281*/ 	);
/*3281*/ 	Globals_void_type = (
/*3281*/ 		push((char*) alloc_RECORD(24, 2)),
/*3281*/ 		*(int*) (tos()+16) = 1,
/*3281*/ 		*(int*) (tos()+20) = 1,
/*3281*/ 		push((char*) NULL),
/*3281*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3281*/ 		push((char*) NULL),
/*3282*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3282*/ 		(RECORD*) pop()
/*3282*/ 	);
/*3282*/ 	Globals_boolean_type = (
/*3282*/ 		push((char*) alloc_RECORD(24, 2)),
/*3282*/ 		*(int*) (tos()+16) = 2,
/*3282*/ 		*(int*) (tos()+20) = 1,
/*3282*/ 		push((char*) NULL),
/*3282*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3282*/ 		push((char*) NULL),
/*3283*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3283*/ 		(RECORD*) pop()
/*3283*/ 	);
/*3283*/ 	Globals_int_type = (
/*3283*/ 		push((char*) alloc_RECORD(24, 2)),
/*3283*/ 		*(int*) (tos()+16) = 3,
/*3283*/ 		*(int*) (tos()+20) = 1,
/*3283*/ 		push((char*) NULL),
/*3283*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3283*/ 		push((char*) NULL),
/*3284*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3284*/ 		(RECORD*) pop()
/*3284*/ 	);
/*3284*/ 	Globals_float_type = (
/*3284*/ 		push((char*) alloc_RECORD(24, 2)),
/*3284*/ 		*(int*) (tos()+16) = 4,
/*3284*/ 		*(int*) (tos()+20) = 1,
/*3284*/ 		push((char*) NULL),
/*3284*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3284*/ 		push((char*) NULL),
/*3285*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3285*/ 		(RECORD*) pop()
/*3285*/ 	);
/*3285*/ 	Globals_string_type = (
/*3285*/ 		push((char*) alloc_RECORD(24, 2)),
/*3285*/ 		*(int*) (tos()+16) = 5,
/*3285*/ 		*(int*) (tos()+20) = 1,
/*3285*/ 		push((char*) NULL),
/*3285*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3285*/ 		push((char*) NULL),
/*3286*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3286*/ 		(RECORD*) pop()
/*3286*/ 	);
/*3286*/ 	Globals_mixed_type = (
/*3286*/ 		push((char*) alloc_RECORD(24, 2)),
/*3286*/ 		*(int*) (tos()+16) = 7,
/*3286*/ 		*(int*) (tos()+20) = 1,
/*3286*/ 		push((char*) NULL),
/*3286*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3286*/ 		push((char*) NULL),
/*3287*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3287*/ 		(RECORD*) pop()
/*3287*/ 	);
/*3287*/ 	Globals_resource_type = (
/*3287*/ 		push((char*) alloc_RECORD(24, 2)),
/*3287*/ 		*(int*) (tos()+16) = 8,
/*3287*/ 		*(int*) (tos()+20) = 1,
/*3287*/ 		push((char*) NULL),
/*3287*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3287*/ 		push((char*) NULL),
/*3288*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3292*/ 		(RECORD*) pop()
/*3292*/ 	);
/*3292*/ 	Statements_here = (
/*3292*/ 		push((char*) alloc_RECORD(16, 1)),
/*3292*/ 		push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"standard"),
/*3292*/ 		*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*3292*/ 		*(int*) (tos()+12) = 0,
/*3293*/ 		(RECORD*) pop()
/*3293*/ 	);
/*3293*/ 	Statements_asm = (
/*3293*/ 		push((char*) alloc_RECORD(24, 2)),
/*3293*/ 		*(int*) (tos()+16) = 6,
/*3293*/ 		*(int*) (tos()+20) = 5,
/*3293*/ 		push((char*) Globals_mixed_type),
/*3293*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3293*/ 		push((char*) NULL),
/*3294*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3294*/ 		(RECORD*) pop()
/*3294*/ 	);
/*3294*/ 	Statements_ass = (
/*3294*/ 		push((char*) alloc_RECORD(24, 2)),
/*3294*/ 		*(int*) (tos()+16) = 6,
/*3294*/ 		*(int*) (tos()+20) = 5,
/*3294*/ 		push((char*) Globals_string_type),
/*3294*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3294*/ 		push((char*) NULL),
/*3295*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3295*/ 		(RECORD*) pop()
/*3295*/ 	);
/*3295*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"GLOBALS", Statements_asm);
/*3296*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"_SERVER", Statements_ass);
/*3297*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"_GET", Statements_asm);
/*3298*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"_POST", Statements_asm);
/*3299*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"_COOKIE", Statements_asm);
/*3300*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"_REQUEST", Statements_asm);
/*3301*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"_FILES", (
/*3301*/ 		push((char*) alloc_RECORD(24, 2)),
/*3301*/ 		*(int*) (tos()+16) = 6,
/*3301*/ 		*(int*) (tos()+20) = 5,
/*3301*/ 		push((char*) Statements_asm),
/*3301*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*3301*/ 		push((char*) NULL),
/*3301*/ 		*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*3302*/ 		(RECORD*) pop()
/*3302*/ 	));
/*3302*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"_ENV", Statements_ass);
/*3303*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"_SESSION", Statements_asm);
/*3305*/ 	Statements_add((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"php_errormsg", Globals_string_type);
/*3312*/ }


/*3314*/ RECORD *
/*3314*/ Statements_ParsePackage(STRING *Statements_abs_pathfile, int Statements_module)
/*3314*/ {
/*3315*/ 	STRING * Statements_saved_cwd = NULL;
/*3316*/ 	int Statements_code_found = 0;
/*3317*/ 	int Statements_i = 0;
/*3318*/ 	RECORD * Statements_f = NULL;
/*3319*/ 	RECORD * Statements_c = NULL;
/*3321*/ 	int Statements_res = 0;
/*3321*/ 	{
/*3321*/ 		int m2runtime_for_limit_1;
/*3321*/ 		Statements_i = 0;
/*3321*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_required_packages) - 1);
/*3322*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*3322*/ 			if( m2runtime_strcmp(Statements_abs_pathfile, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_required_packages, Statements_i, Statements_0err_entry_get, 575), 8, Statements_0err_entry_get, 576)) == 0 ){
/*3323*/ 				return (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_required_packages, Statements_i, Statements_0err_entry_get, 577);
/*3326*/ 			}
/*3327*/ 		}
/*3327*/ 	}
/*3327*/ 	if( !Statements_readable(Statements_abs_pathfile) ){
/*3328*/ 		Scanner_Error2(NULL, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"can't read `", Scanner_fmt_fn(Statements_abs_pathfile), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", m2runtime_ERROR_MESSAGE, 1));
/*3330*/ 		return NULL;
/*3333*/ 	}
/*3333*/ 	m2runtime_ERROR_CODE = 0;
/*3333*/ 	Statements_saved_cwd = io_GetCWD(1);
/*3334*/ 	switch( m2runtime_ERROR_CODE ){

/*3334*/ 	case 0:  break;
/*3334*/ 	default:
/*3334*/ 		m2runtime_HALT(Statements_0err_entry_get, 578, m2runtime_ERROR_MESSAGE);
/*3334*/ 	}
/*3334*/ 	m2runtime_ERROR_CODE = 0;
/*3334*/ 	io_ChDir(1, FileName_Dirname(Statements_abs_pathfile));
/*3336*/ 	switch( m2runtime_ERROR_CODE ){

/*3336*/ 	case 0:  break;
/*3336*/ 	default:
/*3336*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"can't move to the dir. of ", Statements_abs_pathfile, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", m2runtime_ERROR_MESSAGE, 1));
/*3338*/ 		return NULL;
/*3340*/ 	}
/*3340*/ 	if( !Scanner_Open(Statements_abs_pathfile) ){
/*3341*/ 		m2runtime_ERROR_CODE = 0;
/*3341*/ 		io_ChDir(1, Statements_saved_cwd);
/*3342*/ 		switch( m2runtime_ERROR_CODE ){

/*3342*/ 		case 0:  break;
/*3342*/ 		default:
/*3342*/ 			m2runtime_HALT(Statements_0err_entry_get, 579, m2runtime_ERROR_MESSAGE);
/*3342*/ 		}
/*3342*/ 		return NULL;
/*3345*/ 	}
/*3345*/ 	Statements_ParserInit();
/*3347*/ 	Statements_curr_package = NULL;
/*3348*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 8, Statements_0err_entry_get, 580) = Statements_abs_pathfile;
/*3349*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 20, Statements_0err_entry_get, 581) = Statements_module;
/*3350*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 24, Statements_0err_entry_get, 582) = 0;
/*3351*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 583) = NULL;
/*3352*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 584) = NULL;
/*3354*/ 	*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_required_packages, 4, 1, Statements_0err_entry_get, 585) = Statements_curr_package;
/*3356*/ 	while( (Scanner_sym != 0) ){
/*3357*/ 		if( (Scanner_sym == 4) ){
/*3358*/ 			Statements_code_found = TRUE;
/*3359*/ 			Statements_res = Statements_ParseCodeBlock();
/*3360*/ 			if( ((Statements_res & 8) != 0) ){
/*3363*/ 			}
/*3363*/ 		} else if( (Scanner_sym == 5) ){
/*3364*/ 			Statements_code_found = TRUE;
/*3365*/ 			Statements_ParseEchoBlock();
/*3366*/ 		} else if( (Scanner_sym == 3) ){
/*3367*/ 			Scanner_ReadSym();
/*3369*/ 		} else {
/*3369*/ 			Scanner_UnexpectedSymbol();
/*3372*/ 		}
/*3372*/ 	}
/*3372*/ 	if( !Statements_code_found ){
/*3373*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"no PHP code found at all");
/*3380*/ 	}
/*3380*/ 	{
/*3380*/ 		int m2runtime_for_limit_1;
/*3380*/ 		Statements_i = 0;
/*3380*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_funcs) - 1);
/*3381*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*3381*/ 			Statements_f = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_funcs, Statements_i, Statements_0err_entry_get, 586);
/*3382*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_f, 48, Statements_0err_entry_get, 587) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 588), 8, Statements_0err_entry_get, 589), Statements_abs_pathfile) == 0)) ){
/*3383*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"missing function `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_f, 8, Statements_0err_entry_get, 590), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"()' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_f, 16, Statements_0err_entry_get, 591)), 1));
/*3387*/ 			}
/*3392*/ 		}
/*3392*/ 	}
/*3392*/ 	{
/*3392*/ 		int m2runtime_for_limit_1;
/*3392*/ 		Statements_i = 0;
/*3392*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_classes) - 1);
/*3393*/ 		for( ; Statements_i <= m2runtime_for_limit_1; Statements_i += 1 ){
/*3393*/ 			Statements_c = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_classes, Statements_i, Statements_0err_entry_get, 592);
/*3394*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Statements_c, 60, Statements_0err_entry_get, 593) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 48, Statements_0err_entry_get, 594), 8, Statements_0err_entry_get, 595), Statements_abs_pathfile) == 0)) ){
/*3395*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"missing class `", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_c, 8, Statements_0err_entry_get, 596), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' declared forward in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_c, 48, Statements_0err_entry_get, 597)), 1));
/*3399*/ 			}
/*3400*/ 		}
/*3400*/ 	}
/*3400*/ 	Scanner_Close();
/*3401*/ 	m2runtime_ERROR_CODE = 0;
/*3401*/ 	io_ChDir(1, Statements_saved_cwd);
/*3402*/ 	switch( m2runtime_ERROR_CODE ){

/*3402*/ 	case 0:  break;
/*3402*/ 	default:
/*3402*/ 		m2runtime_HALT(Statements_0err_entry_get, 598, m2runtime_ERROR_MESSAGE);
/*3403*/ 	}
/*3403*/ 	if( (Statements_loop_level != 0) ){
/*3404*/ 		m2_error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"phplint: INTERNAL ERROR: loop_level=", m2runtime_itos(Statements_loop_level), m2runtime_CHR(10), 1));
/*3405*/ 		m2runtime_exit(1);
/*3408*/ 	}
/*3408*/ 	return Statements_curr_package;
/*3412*/ }

/*3415*/ int Statements_skip_else_php_ver = 0;

/*3423*/ int
/*3423*/ Statements_ForwardParseStatement(void)
/*3423*/ {

/*3440*/ 	void
/*3440*/ 	Statements_ParseSimpleStatementBeginningWithVar(int Statements_private, RECORD *Statements_t)
/*3440*/ 	{
/*3441*/ 		RECORD * Statements_v = NULL;
/*3442*/ 		RECORD * Statements_r = NULL;
/*3444*/ 		STRING * Statements_vn = NULL;
/*3445*/ 		if( (((Statements_private || (Statements_t != NULL) || (Statements_pdb != NULL))) && (m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"GLOBALS") == 0)) ){
/*3449*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\260,\0,\0,\0)"difining private attribute or type for $GLOBALS[] variables not supported (PHPLint limitation). Global variables can be declared in global scope in usual way `$varName = EXPR'.");
/*3452*/ 		}
/*3452*/ 		if( Statements_pdb != NULL ){
/*3453*/ 			Statements_DocBlockCheckAllowedLineTags((1024 | 128), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"variable");
/*3454*/ 			Statements_private = (Statements_private ||  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 48, Statements_0err_entry_get, 599));
/*3456*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 600) != NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 20, Statements_0err_entry_get, 601), 16, Statements_0err_entry_get, 602) != 6))) ){
/*3458*/ 				Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 12, Statements_0err_entry_get, 603);
/*3461*/ 			}
/*3461*/ 			if( (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 604) != NULL ){
/*3462*/ 				if( m2runtime_strcmp(Scanner_s, (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 605)) != 0 ){
/*3463*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"the name of the assigned variable `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"' does not match `$", (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 16, Statements_0err_entry_get, 606), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"' as indicated in @global", 1));
/*3467*/ 				}
/*3467*/ 				if( Statements_t == NULL ){
/*3468*/ 					Statements_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 12, Statements_0err_entry_get, 607);
/*3470*/ 				}
/*3470*/ 				if( (Globals_scope > 0) ){
/*3471*/ 					Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"@global line in inner scope level, must be at global scope");
/*3474*/ 				}
/*3476*/ 			}
/*3481*/ 		}
/*3481*/ 		if( (Statements_private || (Statements_t != NULL)) ){
/*3482*/ 			Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*3483*/ 			if( Statements_v == NULL ){
/*3484*/ 				Accounting_AccountVarLHS(Scanner_s, Statements_private);
/*3485*/ 				Statements_v = Search_SearchVar(Scanner_s, Globals_scope);
/*3486*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 20, Statements_0err_entry_get, 608) = Statements_t;
/*3487*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 36, Statements_0err_entry_get, 609) = Statements_private;
/*3490*/ 			}
/*3491*/ 		}
/*3491*/ 		Statements_vn = Scanner_s;
/*3492*/ 		Statements_r = Expressions_ParseExpr();
/*3493*/ 		Scanner_Expect(17, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"expected `;'");
/*3494*/ 		Scanner_ReadSym();
/*3499*/ 		if( (((Scanner_sym == 174)) || (Statements_pdb != NULL)) ){
/*3500*/ 			if( Statements_v == NULL ){
/*3501*/ 				Statements_v = Search_SearchVar(Statements_vn, Globals_scope);
/*3503*/ 			}
/*3503*/ 			if( Statements_v == NULL ){
/*3504*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"can't apply documentation to unknown variable `$", Statements_vn, m2runtime_CHR(39), 1));
/*3507*/ 			} else if( (Scanner_sym == 174) ){
/*3508*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 28, Statements_0err_entry_get, 610) = Scanner_s;
/*3509*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 32, Statements_0err_entry_get, 611) = Documentator_ExtractDeprecated(Scanner_s);
/*3510*/ 				Scanner_ReadSym();
/*3512*/ 			} else if( Statements_pdb != NULL ){
/*3513*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 28, Statements_0err_entry_get, 612) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 613);
/*3514*/ 				*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_v, 52, 7, 32, Statements_0err_entry_get, 614) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 615));
/*3516*/ 			}
/*3516*/ 			Statements_pdb = NULL;
/*3520*/ 		}
/*3522*/ 	}


/*3529*/ 	void
/*3529*/ 	Statements_ParseStatementTerminator(void)
/*3529*/ 	{
/*3529*/ 		if( (Scanner_sym == 17) ){
/*3530*/ 			Scanner_ReadSym();
/*3531*/ 		} else if( (((Scanner_sym == 6)) || ((Scanner_sym == 0))) ){
/*3534*/ 		} else {
/*3534*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"missing statement terminator `;' or `?>'");
/*3537*/ 		}
/*3540*/ 	}

/*3541*/ 	int Statements_private = 0;
/*3542*/ 	RECORD * Statements_r = NULL;
/*3543*/ 	RECORD * Statements_t = NULL;
/*3546*/ 	int Statements_res = 0;
/*3547*/ 	switch(Scanner_sym){

/*3549*/ 	case 10:
/*3550*/ 	return Statements_ParseCompound();
/*3552*/ 	break;

/*3552*/ 	case 127:
/*3553*/ 	Statements_ParseRequireModule();
/*3554*/ 	return 1;
/*3556*/ 	break;

/*3556*/ 	case 126:
/*3557*/ 	Statements_ParseRequireOnce();
/*3558*/ 	Statements_ParseStatementTerminator();
/*3559*/ 	return 1;
/*3561*/ 	break;

/*3561*/ 	case 125:
/*3562*/ 	if( (Globals_scope > 0) ){
/*3563*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"`require' inside a function. Suggest `require_once' instead");
/*3565*/ 	}
/*3565*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"require");
/*3566*/ 	Statements_ParseStatementTerminator();
/*3567*/ 	return 1;
/*3569*/ 	break;

/*3569*/ 	case 123:
/*3570*/ 	if( (Globals_scope > 0) ){
/*3571*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"include() inside a function. Suggest include_once() instead");
/*3573*/ 	}
/*3573*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"include");
/*3574*/ 	Statements_ParseStatementTerminator();
/*3575*/ 	return 1;
/*3577*/ 	break;

/*3577*/ 	case 124:
/*3578*/ 	Statements_ParseInclude((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"include_once");
/*3579*/ 	Statements_ParseStatementTerminator();
/*3580*/ 	return 1;
/*3582*/ 	break;

/*3582*/ 	case 174:
/*3583*/ 	if( (Globals_scope > 0) ){
/*3584*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid scope for documentation");
/*3586*/ 	}
/*3586*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 616) = Scanner_s;
/*3587*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 617) = Documentator_ExtractDeprecated(Scanner_s);
/*3588*/ 	Scanner_ReadSym();
/*3589*/ 	return 1;
/*3591*/ 	break;

/*3591*/ 	case 175:
/*3592*/ 	if( (Globals_scope > 0) ){
/*3593*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid scope for documentation");
/*3595*/ 	}
/*3595*/ 	Statements_pdb = ParseDocBlock_ParseDocBlock(Scanner_s);
/*3599*/ 	if( ((Statements_pdb != NULL) &&  *(int *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 40, Statements_0err_entry_get, 618)) ){
/*3601*/ 		Statements_DocBlockCheckAllowedLineTags(1, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package");
/*3602*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 12, Statements_0err_entry_get, 619) = (STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 620);
/*3603*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Statements_curr_package, 28, 3, 16, Statements_0err_entry_get, 621) = Documentator_ExtractDeprecated((STRING *)m2runtime_dereference_rhs_RECORD(Statements_pdb, 8, Statements_0err_entry_get, 622));
/*3604*/ 		Statements_pdb = NULL;
/*3608*/ 	} else {
/*3608*/ 	}
/*3608*/ 	Scanner_ReadSym();
/*3609*/ 	return 1;
/*3611*/ 	break;

/*3611*/ 	case 133:
/*3612*/ 	if( Statements_pdb != NULL ){
/*3613*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"unexpected DocBlock for forward declaration");
/*3615*/ 	}
/*3615*/ 	Proto_ParseForwardDecl();
/*3616*/ 	return 1;
/*3618*/ 	break;

/*3618*/ 	case 159:
/*3619*/ 	if( (Globals_php_ver == 4) ){
/*3620*/ 		Statements_skip_else_php_ver = TRUE;
/*3621*/ 		Scanner_ReadSym();
/*3623*/ 	} else {
/*3623*/ 		Statements_skip_else_php_ver = FALSE;
/*3625*/ 		do{
/*3625*/ 			Scanner_ReadSym();
/*3626*/ 			switch(Scanner_sym){

/*3628*/ 			case 161:
/*3629*/ 			Scanner_ReadSym();
/*3632*/ 			goto m2runtime_loop_1;
/*3632*/ 			break;

/*3632*/ 			case 162:
/*3633*/ 			Scanner_ReadSym();
/*3636*/ 			goto m2runtime_loop_1;
/*3636*/ 			break;

/*3636*/ 			case 0:
/*3637*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"premature end of the file. Expected closing of `if_php_ver_4'.");
/*3640*/ 			break;
/*3643*/ 			}
/*3644*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*3644*/ 	}
/*3644*/ 	return 1;
/*3646*/ 	break;

/*3646*/ 	case 160:
/*3647*/ 	if( (Globals_php_ver == 5) ){
/*3648*/ 		Statements_skip_else_php_ver = TRUE;
/*3649*/ 		Scanner_ReadSym();
/*3651*/ 	} else {
/*3651*/ 		Statements_skip_else_php_ver = FALSE;
/*3653*/ 		do{
/*3653*/ 			Scanner_ReadSym();
/*3654*/ 			switch(Scanner_sym){

/*3656*/ 			case 161:
/*3657*/ 			Scanner_ReadSym();
/*3660*/ 			goto m2runtime_loop_2;
/*3660*/ 			break;

/*3660*/ 			case 162:
/*3661*/ 			Scanner_ReadSym();
/*3664*/ 			goto m2runtime_loop_2;
/*3664*/ 			break;

/*3664*/ 			case 0:
/*3665*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"premature end of the file. Expected closing of `if_php_ver_5'.");
/*3668*/ 			break;
/*3671*/ 			}
/*3672*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*3672*/ 	}
/*3672*/ 	return 1;
/*3674*/ 	break;

/*3674*/ 	case 161:
/*3675*/ 	if( Statements_skip_else_php_ver ){
/*3676*/ 		Statements_skip_else_php_ver = FALSE;
/*3677*/ 		do {
/*3677*/ 			Scanner_ReadSym();
/*3678*/ 		} while( !( (((Scanner_sym == 162)) || ((Scanner_sym == 0))) ));
/*3679*/ 		if( (Scanner_sym == 162) ){
/*3680*/ 			Scanner_ReadSym();
/*3682*/ 		} else {
/*3682*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"missing closing `end_if_php_ver'");
/*3685*/ 		}
/*3685*/ 	} else {
/*3685*/ 		Scanner_ReadSym();
/*3687*/ 	}
/*3687*/ 	return 1;
/*3689*/ 	break;

/*3689*/ 	case 162:
/*3690*/ 	Scanner_ReadSym();
/*3691*/ 	return 1;
/*3693*/ 	break;

/*3693*/ 	case 7:
/*3694*/ 	Statements_ParseDefine(FALSE);
/*3695*/ 	return 1;
/*3697*/ 	break;

/*3697*/ 	case 9:
/*3698*/ 	return Statements_ParseDeclare();
/*3700*/ 	break;

/*3700*/ 	case 101:
/*3701*/ 	Statements_ParseStatic();
/*3702*/ 	Statements_ParseStatementTerminator();
/*3703*/ 	return 1;
/*3705*/ 	break;

/*3705*/ 	case 62:
/*3706*/ 	if( (Globals_scope == 0) ){
/*3707*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"`global' declaration at global scope has no effect.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)" Accounting variables as mixed type, and continuing anyway.", 1));
/*3710*/ 	}
/*3710*/ 	Scanner_ReadSym();
/*3712*/ 	do{
/*3712*/ 		Scanner_Expect(20, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"expected variable name in global declaration");
/*3713*/ 		if( (Globals_scope == 0) ){
/*3714*/ 			Accounting_AccountVarLHS(Scanner_s, FALSE);
/*3716*/ 		} else {
/*3716*/ 			Accounting_AccountGlobalVar(Scanner_s);
/*3718*/ 		}
/*3718*/ 		Scanner_ReadSym();
/*3719*/ 		if( (Scanner_sym == 16) ){
/*3720*/ 			Scanner_ReadSym();
/*3723*/ 		} else {
/*3724*/ 			goto m2runtime_loop_3;
/*3725*/ 		}
/*3725*/ 	}while(TRUE);
m2runtime_loop_3: ;
/*3725*/ 	Statements_ParseStatementTerminator();
/*3726*/ 	return 1;
/*3728*/ 	break;

/*3728*/ 	case 114:
/*3729*/ 	Statements_ParseEcho();
/*3730*/ 	Statements_ParseStatementTerminator();
/*3731*/ 	return 1;
/*3733*/ 	break;

/*3733*/ 	case 116:
/*3734*/ 	Statements_ParseTriggerError();
/*3735*/ 	Statements_ParseStatementTerminator();
/*3736*/ 	return 1;
/*3738*/ 	break;

/*3738*/ 	case 29:
/*3738*/ 	case 59:
/*3738*/ 	case 108:
/*3738*/ 	case 115:
/*3738*/ 	case 103:
/*3739*/ 	case 104:
/*3739*/ 	case 12:
/*3739*/ 	case 52:
/*3739*/ 	case 53:
/*3739*/ 	case 105:
/*3739*/ 	case 122:
/*3740*/ 	Statements_r = Expressions_ParseExpr();
/*3741*/ 	Statements_ParseStatementTerminator();
/*3742*/ 	return 1;
/*3744*/ 	break;

/*3744*/ 	case 113:
/*3745*/ 	Expressions_ParseExit();
/*3746*/ 	Statements_ParseStatementTerminator();
/*3747*/ 	return 8;
/*3749*/ 	break;

/*3749*/ 	case 20:
/*3750*/ 	Statements_ParseSimpleStatementBeginningWithVar(FALSE, NULL);
/*3751*/ 	return 1;
/*3753*/ 	break;

/*3753*/ 	case 25:
/*3754*/ 	return Statements_ParseIf();
/*3756*/ 	break;

/*3756*/ 	case 21:
/*3757*/ 	return Statements_ParseFor();
/*3759*/ 	break;

/*3759*/ 	case 22:
/*3760*/ 	return Statements_ParseForeach();
/*3762*/ 	break;

/*3762*/ 	case 109:
/*3763*/ 	return Statements_ParseSwitch();
/*3765*/ 	break;

/*3765*/ 	case 111:
/*3766*/ 	Statements_ParseBreak();
/*3767*/ 	Statements_ParseStatementTerminator();
/*3768*/ 	return 2;
/*3770*/ 	break;

/*3770*/ 	case 93:
/*3770*/ 	case 168:
/*3770*/ 	case 170:
/*3770*/ 	case 91:
/*3770*/ 	case 102:
/*3771*/ 	Statements_ParseClass(FALSE);
/*3772*/ 	return 1;
/*3774*/ 	break;

/*3774*/ 	case 92:
/*3775*/ 	Statements_ParseInterface(FALSE);
/*3776*/ 	return 1;
/*3778*/ 	break;

/*3778*/ 	case 24:
/*3779*/ 	return Statements_ParseWhile();
/*3781*/ 	break;

/*3781*/ 	case 117:
/*3782*/ 	Statements_res = Statements_ParseDo();
/*3783*/ 	Statements_ParseStatementTerminator();
/*3784*/ 	return Statements_res;
/*3786*/ 	break;

/*3786*/ 	case 121:
/*3787*/ 	Statements_ParseContinue();
/*3788*/ 	Statements_ParseStatementTerminator();
/*3789*/ 	return 4;
/*3791*/ 	break;

/*3791*/ 	case 28:
/*3792*/ 	Statements_ParseReturn();
/*3793*/ 	Statements_ParseStatementTerminator();
/*3794*/ 	return 8;
/*3796*/ 	break;

/*3796*/ 	case 17:
/*3798*/ 	Statements_ParseStatementTerminator();
/*3799*/ 	return 1;
/*3801*/ 	break;

/*3801*/ 	case 8:
/*3802*/ 	Statements_ParseFuncDecl(FALSE, NULL);
/*3803*/ 	return 1;
/*3805*/ 	break;

/*3805*/ 	case 140:
/*3805*/ 	case 141:
/*3805*/ 	case 142:
/*3805*/ 	case 143:
/*3806*/ 	case 144:
/*3806*/ 	case 145:
/*3806*/ 	case 146:
/*3807*/ 	case 147:
/*3807*/ 	case 148:
/*3807*/ 	case 149:
/*3808*/ 	case 167:
/*3809*/ 	if( (Scanner_sym == 167) ){
/*3810*/ 		Statements_private = TRUE;
/*3811*/ 		Scanner_ReadSym();
/*3813*/ 	}
/*3813*/ 	if( (Scanner_sym == 7) ){
/*3814*/ 		Statements_ParseDefine(Statements_private);
/*3815*/ 		return 1;
/*3816*/ 	} else if( (((Scanner_sym == 93)) || ((Scanner_sym == 91)) || ((Scanner_sym == 102))) ){
/*3818*/ 		Statements_ParseClass(Statements_private);
/*3819*/ 		return 1;
/*3820*/ 	} else if( (Scanner_sym == 92) ){
/*3821*/ 		Statements_ParseInterface(TRUE);
/*3822*/ 		return 1;
/*3824*/ 	}
/*3824*/ 	Statements_t = Expressions_ParseType(FALSE);
/*3825*/ 	if( (Scanner_sym == 20) ){
/*3826*/ 		Statements_ParseSimpleStatementBeginningWithVar(Statements_private, Statements_t);
/*3827*/ 		return 1;
/*3828*/ 	} else if( (Scanner_sym == 8) ){
/*3829*/ 		Statements_ParseFuncDecl(Statements_private, Statements_t);
/*3830*/ 		return 1;
/*3832*/ 	} else {
/*3832*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\52,\0,\0,\0)"expected variable or `function' after type");
/*3835*/ 	}
/*3835*/ 	break;

/*3835*/ 	case 120:
/*3836*/ 	Statements_ParseThrow();
/*3837*/ 	Statements_ParseStatementTerminator();
/*3838*/ 	return 8;
/*3840*/ 	break;

/*3840*/ 	case 118:
/*3841*/ 	return Statements_ParseTry();
/*3843*/ 	break;

/*3843*/ 	case 6:
/*3844*/ 	Statements_ParseTextBlock();
/*3845*/ 	return 1;
/*3848*/ 	break;

/*3848*/ 	default:
/*3848*/ 	Scanner_UnexpectedSymbol();
/*3851*/ 	}
/*3851*/ 	if( (FALSE && ((Statements_ForwardParseStatement() == 0))) ){
/*3855*/ 	}
/*3855*/ 	m2runtime_missing_return(Statements_0err_entry_get, 623);
/*3855*/ 	return 0;
/*3858*/ }


char * Statements_0func[] = {
    "ParseEcho",
    "ParseReturn",
    "ParseTriggerError",
    "DocBlockCheckAllowedLineTags",
    "ParseStatement",
    "ParseBlock",
    "ParseArgsListDecl",
    "SameSign",
    "AccountFuncDecl",
    "ParseFuncDecl",
    "ParseForeach",
    "ParseSwitch",
    "ParseClassConstDecl",
    "ParseClassPropertyDecl",
    "CheckSpecialMethodSignature",
    "SameMethodSignature",
    "ParentConstructor",
    "ParentDestructor",
    "ParseClassMethodDecl",
    "ParseClass",
    "ParseInterface",
    "ParseStatic",
    "ParseDefine",
    "readable",
    "AddPackageToIncludePath",
    "SearchFileOnPaths",
    "RequirePackage",
    "ParseRequireOnce",
    "ParseInclude",
    "ParseThrow",
    "ParseTry",
    "ParseEchoBlock",
    "ParseCodeBlock",
    "add",
    "ParsePackage",
    "ParseSimpleStatementBeginningWithVar",
    "ForwardParseStatement"
};

int Statements_0err_entry[] = {
    0 /* ParseEcho */, 112,
    0 /* ParseEcho */, 118,
    0 /* ParseEcho */, 119,
    1 /* ParseReturn */, 145,
    1 /* ParseReturn */, 146,
    1 /* ParseReturn */, 147,
    1 /* ParseReturn */, 149,
    1 /* ParseReturn */, 150,
    1 /* ParseReturn */, 167,
    1 /* ParseReturn */, 171,
    1 /* ParseReturn */, 180,
    1 /* ParseReturn */, 184,
    1 /* ParseReturn */, 188,
    1 /* ParseReturn */, 213,
    2 /* ParseTriggerError */, 250,
    2 /* ParseTriggerError */, 253,
    2 /* ParseTriggerError */, 271,
    2 /* ParseTriggerError */, 271,
    2 /* ParseTriggerError */, 273,
    2 /* ParseTriggerError */, 273,
    3 /* DocBlockCheckAllowedLineTags */, 315,
    3 /* DocBlockCheckAllowedLineTags */, 318,
    3 /* DocBlockCheckAllowedLineTags */, 321,
    3 /* DocBlockCheckAllowedLineTags */, 324,
    3 /* DocBlockCheckAllowedLineTags */, 327,
    3 /* DocBlockCheckAllowedLineTags */, 330,
    3 /* DocBlockCheckAllowedLineTags */, 333,
    3 /* DocBlockCheckAllowedLineTags */, 336,
    3 /* DocBlockCheckAllowedLineTags */, 339,
    3 /* DocBlockCheckAllowedLineTags */, 342,
    3 /* DocBlockCheckAllowedLineTags */, 345,
    3 /* DocBlockCheckAllowedLineTags */, 348,
    4 /* ParseStatement */, 367,
    5 /* ParseBlock */, 383,
    6 /* ParseArgsListDecl */, 409,
    6 /* ParseArgsListDecl */, 418,
    6 /* ParseArgsListDecl */, 419,
    6 /* ParseArgsListDecl */, 427,
    6 /* ParseArgsListDecl */, 436,
    6 /* ParseArgsListDecl */, 442,
    6 /* ParseArgsListDecl */, 447,
    6 /* ParseArgsListDecl */, 447,
    6 /* ParseArgsListDecl */, 448,
    6 /* ParseArgsListDecl */, 448,
    6 /* ParseArgsListDecl */, 449,
    6 /* ParseArgsListDecl */, 449,
    6 /* ParseArgsListDecl */, 461,
    6 /* ParseArgsListDecl */, 462,
    6 /* ParseArgsListDecl */, 470,
    6 /* ParseArgsListDecl */, 478,
    6 /* ParseArgsListDecl */, 479,
    6 /* ParseArgsListDecl */, 479,
    6 /* ParseArgsListDecl */, 480,
    6 /* ParseArgsListDecl */, 480,
    6 /* ParseArgsListDecl */, 482,
    6 /* ParseArgsListDecl */, 482,
    6 /* ParseArgsListDecl */, 485,
    6 /* ParseArgsListDecl */, 486,
    6 /* ParseArgsListDecl */, 489,
    6 /* ParseArgsListDecl */, 490,
    6 /* ParseArgsListDecl */, 493,
    6 /* ParseArgsListDecl */, 493,
    6 /* ParseArgsListDecl */, 496,
    6 /* ParseArgsListDecl */, 499,
    6 /* ParseArgsListDecl */, 500,
    6 /* ParseArgsListDecl */, 502,
    6 /* ParseArgsListDecl */, 504,
    6 /* ParseArgsListDecl */, 505,
    6 /* ParseArgsListDecl */, 507,
    6 /* ParseArgsListDecl */, 507,
    6 /* ParseArgsListDecl */, 508,
    6 /* ParseArgsListDecl */, 508,
    6 /* ParseArgsListDecl */, 509,
    6 /* ParseArgsListDecl */, 509,
    6 /* ParseArgsListDecl */, 511,
    6 /* ParseArgsListDecl */, 520,
    7 /* SameSign */, 548,
    7 /* SameSign */, 548,
    7 /* SameSign */, 549,
    7 /* SameSign */, 549,
    7 /* SameSign */, 553,
    7 /* SameSign */, 553,
    7 /* SameSign */, 556,
    7 /* SameSign */, 556,
    7 /* SameSign */, 559,
    7 /* SameSign */, 560,
    7 /* SameSign */, 560,
    7 /* SameSign */, 560,
    7 /* SameSign */, 560,
    7 /* SameSign */, 560,
    7 /* SameSign */, 560,
    7 /* SameSign */, 561,
    7 /* SameSign */, 561,
    7 /* SameSign */, 561,
    7 /* SameSign */, 561,
    7 /* SameSign */, 561,
    7 /* SameSign */, 561,
    8 /* AccountFuncDecl */, 587,
    8 /* AccountFuncDecl */, 599,
    8 /* AccountFuncDecl */, 600,
    8 /* AccountFuncDecl */, 601,
    8 /* AccountFuncDecl */, 602,
    8 /* AccountFuncDecl */, 604,
    8 /* AccountFuncDecl */, 606,
    8 /* AccountFuncDecl */, 607,
    8 /* AccountFuncDecl */, 608,
    8 /* AccountFuncDecl */, 609,
    8 /* AccountFuncDecl */, 610,
    8 /* AccountFuncDecl */, 610,
    8 /* AccountFuncDecl */, 613,
    8 /* AccountFuncDecl */, 617,
    8 /* AccountFuncDecl */, 621,
    8 /* AccountFuncDecl */, 622,
    8 /* AccountFuncDecl */, 625,
    9 /* ParseFuncDecl */, 644,
    9 /* ParseFuncDecl */, 649,
    9 /* ParseFuncDecl */, 652,
    9 /* ParseFuncDecl */, 658,
    9 /* ParseFuncDecl */, 663,
    9 /* ParseFuncDecl */, 679,
    9 /* ParseFuncDecl */, 680,
    9 /* ParseFuncDecl */, 681,
    9 /* ParseFuncDecl */, 682,
    9 /* ParseFuncDecl */, 683,
    9 /* ParseFuncDecl */, 684,
    9 /* ParseFuncDecl */, 687,
    9 /* ParseFuncDecl */, 690,
    9 /* ParseFuncDecl */, 691,
    9 /* ParseFuncDecl */, 693,
    9 /* ParseFuncDecl */, 694,
    9 /* ParseFuncDecl */, 718,
    9 /* ParseFuncDecl */, 719,
    9 /* ParseFuncDecl */, 727,
    9 /* ParseFuncDecl */, 727,
    9 /* ParseFuncDecl */, 734,
    9 /* ParseFuncDecl */, 735,
    9 /* ParseFuncDecl */, 738,
    9 /* ParseFuncDecl */, 738,
    9 /* ParseFuncDecl */, 739,
    9 /* ParseFuncDecl */, 739,
    9 /* ParseFuncDecl */, 748,
    9 /* ParseFuncDecl */, 751,
    9 /* ParseFuncDecl */, 752,
    9 /* ParseFuncDecl */, 756,
    9 /* ParseFuncDecl */, 758,
    9 /* ParseFuncDecl */, 758,
    9 /* ParseFuncDecl */, 766,
    9 /* ParseFuncDecl */, 766,
    9 /* ParseFuncDecl */, 770,
    9 /* ParseFuncDecl */, 771,
    9 /* ParseFuncDecl */, 772,
    9 /* ParseFuncDecl */, 775,
    9 /* ParseFuncDecl */, 777,
    9 /* ParseFuncDecl */, 777,
    9 /* ParseFuncDecl */, 783,
    9 /* ParseFuncDecl */, 785,
    9 /* ParseFuncDecl */, 785,
    9 /* ParseFuncDecl */, 789,
    9 /* ParseFuncDecl */, 791,
    9 /* ParseFuncDecl */, 791,
    9 /* ParseFuncDecl */, 795,
    9 /* ParseFuncDecl */, 797,
    9 /* ParseFuncDecl */, 798,
    9 /* ParseFuncDecl */, 798,
    9 /* ParseFuncDecl */, 799,
    9 /* ParseFuncDecl */, 801,
    10 /* ParseForeach */, 975,
    10 /* ParseForeach */, 975,
    10 /* ParseForeach */, 976,
    10 /* ParseForeach */, 976,
    10 /* ParseForeach */, 981,
    10 /* ParseForeach */, 982,
    10 /* ParseForeach */, 982,
    10 /* ParseForeach */, 983,
    10 /* ParseForeach */, 983,
    10 /* ParseForeach */, 985,
    10 /* ParseForeach */, 985,
    10 /* ParseForeach */, 989,
    10 /* ParseForeach */, 1037,
    10 /* ParseForeach */, 1039,
    10 /* ParseForeach */, 1042,
    10 /* ParseForeach */, 1045,
    10 /* ParseForeach */, 1046,
    10 /* ParseForeach */, 1049,
    10 /* ParseForeach */, 1050,
    10 /* ParseForeach */, 1052,
    10 /* ParseForeach */, 1065,
    10 /* ParseForeach */, 1066,
    10 /* ParseForeach */, 1068,
    10 /* ParseForeach */, 1071,
    10 /* ParseForeach */, 1072,
    10 /* ParseForeach */, 1076,
    10 /* ParseForeach */, 1077,
    10 /* ParseForeach */, 1080,
    11 /* ParseSwitch */, 1134,
    11 /* ParseSwitch */, 1158,
    11 /* ParseSwitch */, 1159,
    12 /* ParseClassConstDecl */, 1271,
    12 /* ParseClassConstDecl */, 1274,
    12 /* ParseClassConstDecl */, 1275,
    12 /* ParseClassConstDecl */, 1275,
    12 /* ParseClassConstDecl */, 1281,
    12 /* ParseClassConstDecl */, 1282,
    12 /* ParseClassConstDecl */, 1282,
    12 /* ParseClassConstDecl */, 1285,
    12 /* ParseClassConstDecl */, 1286,
    12 /* ParseClassConstDecl */, 1286,
    12 /* ParseClassConstDecl */, 1289,
    12 /* ParseClassConstDecl */, 1290,
    12 /* ParseClassConstDecl */, 1291,
    12 /* ParseClassConstDecl */, 1293,
    12 /* ParseClassConstDecl */, 1302,
    12 /* ParseClassConstDecl */, 1302,
    12 /* ParseClassConstDecl */, 1305,
    12 /* ParseClassConstDecl */, 1318,
    12 /* ParseClassConstDecl */, 1319,
    12 /* ParseClassConstDecl */, 1322,
    12 /* ParseClassConstDecl */, 1322,
    12 /* ParseClassConstDecl */, 1323,
    12 /* ParseClassConstDecl */, 1323,
    13 /* ParseClassPropertyDecl */, 1347,
    13 /* ParseClassPropertyDecl */, 1352,
    13 /* ParseClassPropertyDecl */, 1354,
    13 /* ParseClassPropertyDecl */, 1357,
    13 /* ParseClassPropertyDecl */, 1359,
    13 /* ParseClassPropertyDecl */, 1361,
    13 /* ParseClassPropertyDecl */, 1363,
    13 /* ParseClassPropertyDecl */, 1373,
    13 /* ParseClassPropertyDecl */, 1374,
    13 /* ParseClassPropertyDecl */, 1374,
    13 /* ParseClassPropertyDecl */, 1375,
    13 /* ParseClassPropertyDecl */, 1375,
    13 /* ParseClassPropertyDecl */, 1377,
    13 /* ParseClassPropertyDecl */, 1377,
    13 /* ParseClassPropertyDecl */, 1380,
    13 /* ParseClassPropertyDecl */, 1381,
    13 /* ParseClassPropertyDecl */, 1382,
    13 /* ParseClassPropertyDecl */, 1384,
    13 /* ParseClassPropertyDecl */, 1385,
    13 /* ParseClassPropertyDecl */, 1386,
    13 /* ParseClassPropertyDecl */, 1387,
    13 /* ParseClassPropertyDecl */, 1388,
    13 /* ParseClassPropertyDecl */, 1388,
    13 /* ParseClassPropertyDecl */, 1391,
    13 /* ParseClassPropertyDecl */, 1393,
    13 /* ParseClassPropertyDecl */, 1394,
    13 /* ParseClassPropertyDecl */, 1397,
    13 /* ParseClassPropertyDecl */, 1397,
    13 /* ParseClassPropertyDecl */, 1412,
    13 /* ParseClassPropertyDecl */, 1413,
    13 /* ParseClassPropertyDecl */, 1416,
    13 /* ParseClassPropertyDecl */, 1416,
    13 /* ParseClassPropertyDecl */, 1417,
    13 /* ParseClassPropertyDecl */, 1417,
    14 /* CheckSpecialMethodSignature */, 1434,
    14 /* CheckSpecialMethodSignature */, 1434,
    14 /* CheckSpecialMethodSignature */, 1434,
    14 /* CheckSpecialMethodSignature */, 1471,
    14 /* CheckSpecialMethodSignature */, 1471,
    14 /* CheckSpecialMethodSignature */, 1471,
    14 /* CheckSpecialMethodSignature */, 1472,
    14 /* CheckSpecialMethodSignature */, 1472,
    14 /* CheckSpecialMethodSignature */, 1472,
    14 /* CheckSpecialMethodSignature */, 1473,
    14 /* CheckSpecialMethodSignature */, 1474,
    14 /* CheckSpecialMethodSignature */, 1474,
    14 /* CheckSpecialMethodSignature */, 1482,
    14 /* CheckSpecialMethodSignature */, 1482,
    14 /* CheckSpecialMethodSignature */, 1482,
    14 /* CheckSpecialMethodSignature */, 1483,
    14 /* CheckSpecialMethodSignature */, 1483,
    14 /* CheckSpecialMethodSignature */, 1491,
    14 /* CheckSpecialMethodSignature */, 1491,
    14 /* CheckSpecialMethodSignature */, 1492,
    14 /* CheckSpecialMethodSignature */, 1492,
    14 /* CheckSpecialMethodSignature */, 1492,
    14 /* CheckSpecialMethodSignature */, 1494,
    14 /* CheckSpecialMethodSignature */, 1494,
    14 /* CheckSpecialMethodSignature */, 1495,
    14 /* CheckSpecialMethodSignature */, 1495,
    14 /* CheckSpecialMethodSignature */, 1495,
    14 /* CheckSpecialMethodSignature */, 1500,
    14 /* CheckSpecialMethodSignature */, 1502,
    14 /* CheckSpecialMethodSignature */, 1504,
    14 /* CheckSpecialMethodSignature */, 1509,
    14 /* CheckSpecialMethodSignature */, 1509,
    14 /* CheckSpecialMethodSignature */, 1510,
    14 /* CheckSpecialMethodSignature */, 1510,
    14 /* CheckSpecialMethodSignature */, 1512,
    14 /* CheckSpecialMethodSignature */, 1512,
    15 /* SameMethodSignature */, 1519,
    15 /* SameMethodSignature */, 1519,
    15 /* SameMethodSignature */, 1520,
    15 /* SameMethodSignature */, 1520,
    15 /* SameMethodSignature */, 1521,
    15 /* SameMethodSignature */, 1521,
    15 /* SameMethodSignature */, 1522,
    15 /* SameMethodSignature */, 1522,
    16 /* ParentConstructor */, 1544,
    16 /* ParentConstructor */, 1545,
    16 /* ParentConstructor */, 1546,
    17 /* ParentDestructor */, 1557,
    17 /* ParentDestructor */, 1558,
    17 /* ParentDestructor */, 1559,
    18 /* ParseClassMethodDecl */, 1568,
    18 /* ParseClassMethodDecl */, 1579,
    18 /* ParseClassMethodDecl */, 1612,
    18 /* ParseClassMethodDecl */, 1613,
    18 /* ParseClassMethodDecl */, 1614,
    18 /* ParseClassMethodDecl */, 1615,
    18 /* ParseClassMethodDecl */, 1617,
    18 /* ParseClassMethodDecl */, 1628,
    18 /* ParseClassMethodDecl */, 1648,
    18 /* ParseClassMethodDecl */, 1648,
    18 /* ParseClassMethodDecl */, 1650,
    18 /* ParseClassMethodDecl */, 1655,
    18 /* ParseClassMethodDecl */, 1655,
    18 /* ParseClassMethodDecl */, 1658,
    18 /* ParseClassMethodDecl */, 1658,
    18 /* ParseClassMethodDecl */, 1661,
    18 /* ParseClassMethodDecl */, 1661,
    18 /* ParseClassMethodDecl */, 1663,
    18 /* ParseClassMethodDecl */, 1664,
    18 /* ParseClassMethodDecl */, 1666,
    18 /* ParseClassMethodDecl */, 1667,
    18 /* ParseClassMethodDecl */, 1674,
    18 /* ParseClassMethodDecl */, 1675,
    18 /* ParseClassMethodDecl */, 1678,
    18 /* ParseClassMethodDecl */, 1678,
    18 /* ParseClassMethodDecl */, 1680,
    18 /* ParseClassMethodDecl */, 1680,
    18 /* ParseClassMethodDecl */, 1680,
    18 /* ParseClassMethodDecl */, 1681,
    18 /* ParseClassMethodDecl */, 1683,
    18 /* ParseClassMethodDecl */, 1685,
    18 /* ParseClassMethodDecl */, 1685,
    18 /* ParseClassMethodDecl */, 1691,
    18 /* ParseClassMethodDecl */, 1691,
    18 /* ParseClassMethodDecl */, 1692,
    18 /* ParseClassMethodDecl */, 1694,
    18 /* ParseClassMethodDecl */, 1695,
    18 /* ParseClassMethodDecl */, 1699,
    18 /* ParseClassMethodDecl */, 1699,
    18 /* ParseClassMethodDecl */, 1699,
    18 /* ParseClassMethodDecl */, 1700,
    18 /* ParseClassMethodDecl */, 1702,
    18 /* ParseClassMethodDecl */, 1704,
    18 /* ParseClassMethodDecl */, 1704,
    18 /* ParseClassMethodDecl */, 1713,
    18 /* ParseClassMethodDecl */, 1715,
    18 /* ParseClassMethodDecl */, 1719,
    18 /* ParseClassMethodDecl */, 1730,
    18 /* ParseClassMethodDecl */, 1731,
    18 /* ParseClassMethodDecl */, 1739,
    18 /* ParseClassMethodDecl */, 1739,
    18 /* ParseClassMethodDecl */, 1748,
    18 /* ParseClassMethodDecl */, 1749,
    18 /* ParseClassMethodDecl */, 1749,
    18 /* ParseClassMethodDecl */, 1776,
    18 /* ParseClassMethodDecl */, 1777,
    18 /* ParseClassMethodDecl */, 1779,
    18 /* ParseClassMethodDecl */, 1781,
    18 /* ParseClassMethodDecl */, 1781,
    18 /* ParseClassMethodDecl */, 1782,
    18 /* ParseClassMethodDecl */, 1785,
    18 /* ParseClassMethodDecl */, 1800,
    18 /* ParseClassMethodDecl */, 1801,
    18 /* ParseClassMethodDecl */, 1804,
    18 /* ParseClassMethodDecl */, 1804,
    18 /* ParseClassMethodDecl */, 1805,
    18 /* ParseClassMethodDecl */, 1805,
    18 /* ParseClassMethodDecl */, 1828,
    18 /* ParseClassMethodDecl */, 1831,
    18 /* ParseClassMethodDecl */, 1832,
    18 /* ParseClassMethodDecl */, 1835,
    18 /* ParseClassMethodDecl */, 1835,
    18 /* ParseClassMethodDecl */, 1847,
    18 /* ParseClassMethodDecl */, 1864,
    18 /* ParseClassMethodDecl */, 1864,
    18 /* ParseClassMethodDecl */, 1865,
    18 /* ParseClassMethodDecl */, 1869,
    18 /* ParseClassMethodDecl */, 1871,
    18 /* ParseClassMethodDecl */, 1871,
    18 /* ParseClassMethodDecl */, 1879,
    18 /* ParseClassMethodDecl */, 1881,
    18 /* ParseClassMethodDecl */, 1881,
    18 /* ParseClassMethodDecl */, 1881,
    18 /* ParseClassMethodDecl */, 1889,
    18 /* ParseClassMethodDecl */, 1891,
    18 /* ParseClassMethodDecl */, 1891,
    18 /* ParseClassMethodDecl */, 1891,
    18 /* ParseClassMethodDecl */, 1899,
    18 /* ParseClassMethodDecl */, 1902,
    18 /* ParseClassMethodDecl */, 1937,
    18 /* ParseClassMethodDecl */, 1940,
    18 /* ParseClassMethodDecl */, 1952,
    18 /* ParseClassMethodDecl */, 1953,
    18 /* ParseClassMethodDecl */, 1958,
    18 /* ParseClassMethodDecl */, 1960,
    18 /* ParseClassMethodDecl */, 1965,
    18 /* ParseClassMethodDecl */, 1970,
    18 /* ParseClassMethodDecl */, 1971,
    18 /* ParseClassMethodDecl */, 1971,
    18 /* ParseClassMethodDecl */, 1973,
    18 /* ParseClassMethodDecl */, 1973,
    18 /* ParseClassMethodDecl */, 1975,
    19 /* ParseClass */, 2014,
    19 /* ParseClass */, 2017,
    19 /* ParseClass */, 2023,
    19 /* ParseClass */, 2023,
    19 /* ParseClass */, 2024,
    19 /* ParseClass */, 2024,
    19 /* ParseClass */, 2025,
    19 /* ParseClass */, 2025,
    19 /* ParseClass */, 2035,
    19 /* ParseClass */, 2038,
    19 /* ParseClass */, 2045,
    19 /* ParseClass */, 2048,
    19 /* ParseClass */, 2055,
    19 /* ParseClass */, 2058,
    19 /* ParseClass */, 2065,
    19 /* ParseClass */, 2068,
    19 /* ParseClass */, 2077,
    19 /* ParseClass */, 2077,
    19 /* ParseClass */, 2090,
    19 /* ParseClass */, 2091,
    19 /* ParseClass */, 2092,
    19 /* ParseClass */, 2093,
    19 /* ParseClass */, 2095,
    19 /* ParseClass */, 2096,
    19 /* ParseClass */, 2096,
    19 /* ParseClass */, 2097,
    19 /* ParseClass */, 2097,
    19 /* ParseClass */, 2098,
    19 /* ParseClass */, 2098,
    19 /* ParseClass */, 2099,
    19 /* ParseClass */, 2099,
    19 /* ParseClass */, 2100,
    19 /* ParseClass */, 2100,
    19 /* ParseClass */, 2101,
    19 /* ParseClass */, 2106,
    19 /* ParseClass */, 2122,
    19 /* ParseClass */, 2123,
    19 /* ParseClass */, 2125,
    19 /* ParseClass */, 2126,
    19 /* ParseClass */, 2127,
    19 /* ParseClass */, 2128,
    19 /* ParseClass */, 2129,
    19 /* ParseClass */, 2130,
    19 /* ParseClass */, 2132,
    19 /* ParseClass */, 2134,
    19 /* ParseClass */, 2135,
    19 /* ParseClass */, 2136,
    19 /* ParseClass */, 2152,
    19 /* ParseClass */, 2155,
    19 /* ParseClass */, 2157,
    19 /* ParseClass */, 2159,
    19 /* ParseClass */, 2159,
    19 /* ParseClass */, 2163,
    19 /* ParseClass */, 2165,
    19 /* ParseClass */, 2165,
    19 /* ParseClass */, 2180,
    19 /* ParseClass */, 2181,
    19 /* ParseClass */, 2184,
    19 /* ParseClass */, 2184,
    19 /* ParseClass */, 2185,
    19 /* ParseClass */, 2185,
    19 /* ParseClass */, 2219,
    19 /* ParseClass */, 2222,
    19 /* ParseClass */, 2225,
    19 /* ParseClass */, 2229,
    19 /* ParseClass */, 2230,
    19 /* ParseClass */, 2231,
    19 /* ParseClass */, 2332,
    19 /* ParseClass */, 2333,
    19 /* ParseClass */, 2334,
    19 /* ParseClass */, 2335,
    19 /* ParseClass */, 2340,
    19 /* ParseClass */, 2340,
    19 /* ParseClass */, 2413,
    19 /* ParseClass */, 2422,
    19 /* ParseClass */, 2435,
    19 /* ParseClass */, 2439,
    19 /* ParseClass */, 2440,
    19 /* ParseClass */, 2441,
    19 /* ParseClass */, 2441,
    19 /* ParseClass */, 2442,
    19 /* ParseClass */, 2443,
    20 /* ParseInterface */, 2465,
    20 /* ParseInterface */, 2466,
    20 /* ParseInterface */, 2467,
    20 /* ParseInterface */, 2469,
    20 /* ParseInterface */, 2479,
    20 /* ParseInterface */, 2481,
    20 /* ParseInterface */, 2484,
    20 /* ParseInterface */, 2490,
    20 /* ParseInterface */, 2491,
    20 /* ParseInterface */, 2492,
    20 /* ParseInterface */, 2493,
    20 /* ParseInterface */, 2510,
    20 /* ParseInterface */, 2511,
    20 /* ParseInterface */, 2512,
    20 /* ParseInterface */, 2515,
    20 /* ParseInterface */, 2517,
    20 /* ParseInterface */, 2519,
    20 /* ParseInterface */, 2519,
    20 /* ParseInterface */, 2521,
    20 /* ParseInterface */, 2523,
    20 /* ParseInterface */, 2523,
    20 /* ParseInterface */, 2537,
    20 /* ParseInterface */, 2538,
    20 /* ParseInterface */, 2541,
    20 /* ParseInterface */, 2541,
    20 /* ParseInterface */, 2542,
    20 /* ParseInterface */, 2542,
    20 /* ParseInterface */, 2561,
    20 /* ParseInterface */, 2561,
    20 /* ParseInterface */, 2561,
    20 /* ParseInterface */, 2564,
    20 /* ParseInterface */, 2567,
    20 /* ParseInterface */, 2604,
    21 /* ParseStatic */, 2642,
    21 /* ParseStatic */, 2651,
    21 /* ParseStatic */, 2665,
    21 /* ParseStatic */, 2665,
    21 /* ParseStatic */, 2667,
    21 /* ParseStatic */, 2670,
    21 /* ParseStatic */, 2675,
    22 /* ParseDefine */, 2751,
    22 /* ParseDefine */, 2754,
    22 /* ParseDefine */, 2770,
    22 /* ParseDefine */, 2774,
    22 /* ParseDefine */, 2821,
    22 /* ParseDefine */, 2822,
    22 /* ParseDefine */, 2824,
    22 /* ParseDefine */, 2824,
    22 /* ParseDefine */, 2825,
    22 /* ParseDefine */, 2825,
    22 /* ParseDefine */, 2826,
    22 /* ParseDefine */, 2826,
    23 /* readable */, 2875,
    23 /* readable */, 2880,
    24 /* AddPackageToIncludePath */, 2891,
    24 /* AddPackageToIncludePath */, 2895,
    25 /* SearchFileOnPaths */, 2915,
    25 /* SearchFileOnPaths */, 2922,
    26 /* RequirePackage */, 2979,
    26 /* RequirePackage */, 2986,
    27 /* ParseRequireOnce */, 3024,
    27 /* ParseRequireOnce */, 3027,
    27 /* ParseRequireOnce */, 3031,
    28 /* ParseInclude */, 3049,
    28 /* ParseInclude */, 3051,
    28 /* ParseInclude */, 3053,
    28 /* ParseInclude */, 3053,
    28 /* ParseInclude */, 3054,
    28 /* ParseInclude */, 3057,
    29 /* ParseThrow */, 3073,
    29 /* ParseThrow */, 3074,
    29 /* ParseThrow */, 3075,
    29 /* ParseThrow */, 3077,
    29 /* ParseThrow */, 3078,
    29 /* ParseThrow */, 3080,
    29 /* ParseThrow */, 3080,
    30 /* ParseTry */, 3144,
    31 /* ParseEchoBlock */, 3174,
    32 /* ParseCodeBlock */, 3243,
    33 /* add */, 3256,
    33 /* add */, 3257,
    33 /* add */, 3258,
    33 /* add */, 3259,
    33 /* add */, 3260,
    33 /* add */, 3261,
    33 /* add */, 3262,
    33 /* add */, 3263,
    34 /* ParsePackage */, 3322,
    34 /* ParsePackage */, 3322,
    34 /* ParsePackage */, 3324,
    34 /* ParsePackage */, 3333,
    34 /* ParsePackage */, 3341,
    34 /* ParsePackage */, 3348,
    34 /* ParsePackage */, 3349,
    34 /* ParsePackage */, 3350,
    34 /* ParsePackage */, 3351,
    34 /* ParsePackage */, 3352,
    34 /* ParsePackage */, 3354,
    34 /* ParsePackage */, 3382,
    34 /* ParsePackage */, 3382,
    34 /* ParsePackage */, 3382,
    34 /* ParsePackage */, 3382,
    34 /* ParsePackage */, 3383,
    34 /* ParsePackage */, 3384,
    34 /* ParsePackage */, 3394,
    34 /* ParsePackage */, 3394,
    34 /* ParsePackage */, 3394,
    34 /* ParsePackage */, 3394,
    34 /* ParsePackage */, 3395,
    34 /* ParsePackage */, 3396,
    34 /* ParsePackage */, 3401,
    35 /* ParseSimpleStatementBeginningWithVar */, 3454,
    35 /* ParseSimpleStatementBeginningWithVar */, 3456,
    35 /* ParseSimpleStatementBeginningWithVar */, 3457,
    35 /* ParseSimpleStatementBeginningWithVar */, 3457,
    35 /* ParseSimpleStatementBeginningWithVar */, 3458,
    35 /* ParseSimpleStatementBeginningWithVar */, 3461,
    35 /* ParseSimpleStatementBeginningWithVar */, 3462,
    35 /* ParseSimpleStatementBeginningWithVar */, 3465,
    35 /* ParseSimpleStatementBeginningWithVar */, 3468,
    35 /* ParseSimpleStatementBeginningWithVar */, 3486,
    35 /* ParseSimpleStatementBeginningWithVar */, 3487,
    35 /* ParseSimpleStatementBeginningWithVar */, 3508,
    35 /* ParseSimpleStatementBeginningWithVar */, 3509,
    35 /* ParseSimpleStatementBeginningWithVar */, 3513,
    35 /* ParseSimpleStatementBeginningWithVar */, 3513,
    35 /* ParseSimpleStatementBeginningWithVar */, 3514,
    35 /* ParseSimpleStatementBeginningWithVar */, 3514,
    36 /* ForwardParseStatement */, 3586,
    36 /* ForwardParseStatement */, 3587,
    36 /* ForwardParseStatement */, 3599,
    36 /* ForwardParseStatement */, 3602,
    36 /* ForwardParseStatement */, 3602,
    36 /* ForwardParseStatement */, 3603,
    36 /* ForwardParseStatement */, 3603,
    36 /* ForwardParseStatement */, 3854
};

void Statements_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Statements";
    *f = Statements_0func[ Statements_0err_entry[2*i] ];
    *l = Statements_0err_entry[2*i + 1];
}
