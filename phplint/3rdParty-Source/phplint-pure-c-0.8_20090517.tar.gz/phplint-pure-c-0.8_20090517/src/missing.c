#define M2_SYSTEM_TYPE "LINUX"
#define M2_SYSTEM_TYPE_LINUX
//#define USE_GC
#define INTSTR(b1,b2,b3,b4) #b1#b2#b3#b4
#define SIZEOFINT 4
