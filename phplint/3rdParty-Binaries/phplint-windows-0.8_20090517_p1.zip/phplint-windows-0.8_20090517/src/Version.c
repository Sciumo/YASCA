/* IMPLEMENTATION MODULE Version */
#define M2_IMPORT_Version

void Version_0err_entry_get(int i, char **m, char **f, int *l);

void Version_0err_entry_get(int i, char **m, char **f, int *l)
{}
