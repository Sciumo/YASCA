/* IMPLEMENTATION MODULE FileName */
#define M2_IMPORT_FileName

#ifndef M2_IMPORT_m2
#    include "/users/umberto/desktop/projects/m2/lib/m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "/users/umberto/desktop/projects/m2/lib/io.c"
#endif

#ifndef M2_IMPORT_str
#    include "/users/umberto/desktop/projects/m2/lib/str.c"
#endif

void FileName_0err_entry_get(int i, char **m, char **f, int *l);

/*  8*/ STRING *
/*  8*/ FileName_slash_convert(STRING *FileName_p)
/*  8*/ {
/*  8*/ 	return str_substitute(FileName_p, m2runtime_CHR(92), m2runtime_CHR(47));
/* 12*/ }


/* 38*/ STRING *
/* 38*/ FileName_Normalize(STRING *FileName_f)
/* 38*/ {
/* 39*/ 	ARRAY * FileName_b = NULL;
/* 39*/ 	ARRAY * FileName_a = NULL;
/* 40*/ 	int FileName_j = 0;
/* 40*/ 	int FileName_i = 0;
/* 41*/ 	STRING * FileName_w = NULL;
/* 43*/ 	int FileName_abs = 0;
/* 43*/ 	if( m2runtime_strcmp(FileName_f, EMPTY_STRING) <= 0 ){
/* 44*/ 		m2runtime_HALT(FileName_0err_entry_get, 0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"path is NIL or empty");
/* 46*/ 	}
/* 46*/ 	FileName_a = str_split(FileName_f, m2runtime_CHR(47));
/* 47*/ 	FileName_j = 0;
/* 48*/ 	{
/* 48*/ 		int m2runtime_for_limit_1;
/* 48*/ 		FileName_i = 0;
/* 48*/ 		m2runtime_for_limit_1 = (m2runtime_count(FileName_a) - 1);
/* 49*/ 		for( ; FileName_i <= m2runtime_for_limit_1; FileName_i += 1 ){
/* 49*/ 			FileName_w = (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_a, FileName_i, FileName_0err_entry_get, 1);
/* 50*/ 			if( m2runtime_strcmp(FileName_w, EMPTY_STRING) == 0 ){
/* 51*/ 				if( (FileName_i == 0) ){
/* 53*/ 					FileName_abs = TRUE;
/* 55*/ 				}
/* 55*/ 			} else if( m2runtime_strcmp(FileName_w, m2runtime_CHR(46)) == 0 ){
/* 57*/ 			} else if( m2runtime_strcmp(FileName_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..") == 0 ){
/* 58*/ 				if( (FileName_j == 0) ){
/* 59*/ 					if( FileName_abs ){
/* 62*/ 					} else {
/* 62*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, 0, FileName_0err_entry_get, 2) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..";
/* 63*/ 						FileName_j = 1;
/* 65*/ 					}
/* 65*/ 				} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, (FileName_j - 1), FileName_0err_entry_get, 3), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..") == 0 ){
/* 66*/ 					*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, FileName_j, FileName_0err_entry_get, 4) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"..";
/* 67*/ 					FileName_j = (FileName_j + 1);
/* 70*/ 				} else {
/* 70*/ 					FileName_j = (FileName_j - 1);
/* 72*/ 				}
/* 73*/ 			} else {
/* 73*/ 				*(STRING **)m2runtime_dereference_lhs_ARRAY(&FileName_b, 4, 1, FileName_j, FileName_0err_entry_get, 5) = FileName_w;
/* 74*/ 				FileName_j = (FileName_j + 1);
/* 77*/ 			}
/* 77*/ 		}
/* 77*/ 	}
/* 77*/ 	if( (FileName_j == 0) ){
/* 78*/ 		if( FileName_abs ){
/* 79*/ 			return m2runtime_CHR(47);
/* 81*/ 		} else {
/* 81*/ 			return m2runtime_CHR(46);
/* 84*/ 		}
/* 84*/ 	} else {
/* 84*/ 		if( FileName_abs ){
/* 85*/ 			FileName_f = m2runtime_concat_STRING(0, m2runtime_CHR(47), (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, 0, FileName_0err_entry_get, 6), 1);
/* 87*/ 		} else {
/* 87*/ 			FileName_f = (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, 0, FileName_0err_entry_get, 7);
/* 89*/ 		}
/* 89*/ 		{
/* 89*/ 			int m2runtime_for_limit_1;
/* 89*/ 			FileName_i = 1;
/* 89*/ 			m2runtime_for_limit_1 = (FileName_j - 1);
/* 90*/ 			for( ; FileName_i <= m2runtime_for_limit_1; FileName_i += 1 ){
/* 90*/ 				FileName_f = m2runtime_concat_STRING(0, FileName_f, m2runtime_CHR(47), (STRING *)m2runtime_dereference_rhs_ARRAY(FileName_b, FileName_i, FileName_0err_entry_get, 8), 1);
/* 93*/ 			}
/* 93*/ 		}
/* 93*/ 	}
/* 93*/ 	return FileName_f;
/* 97*/ }


/* 98*/ STRING *
/* 98*/ FileName_Dirname(STRING *FileName_f)
/* 98*/ {
/*100*/ 	int FileName_i = 0;
/*100*/ 	FileName_f = FileName_slash_convert(FileName_f);
/*101*/ 	{
/*101*/ 		int m2runtime_for_limit_1;
/*101*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/*101*/ 		m2runtime_for_limit_1 = 0;
/*102*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/*102*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 9), m2runtime_CHR(47)) == 0 ){
/*103*/ 				if( (FileName_i == 0) ){
/*104*/ 					return m2runtime_CHR(47);
/*106*/ 				} else {
/*106*/ 					return m2runtime_substr(FileName_f, 0, FileName_i, 1, FileName_0err_entry_get, 10);
/*109*/ 				}
/*110*/ 			}
/*110*/ 		}
/*110*/ 	}
/*110*/ 	return m2runtime_CHR(46);
/*114*/ }


/*115*/ STRING *
/*115*/ FileName_Basename(STRING *FileName_f)
/*115*/ {
/*117*/ 	int FileName_i = 0;
/*117*/ 	FileName_f = FileName_slash_convert(FileName_f);
/*118*/ 	if( m2runtime_strcmp(FileName_f, m2runtime_CHR(47)) == 0 ){
/*119*/ 		return m2runtime_CHR(47);
/*121*/ 	}
/*121*/ 	{
/*121*/ 		int m2runtime_for_limit_1;
/*121*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/*121*/ 		m2runtime_for_limit_1 = 0;
/*122*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/*122*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 11), m2runtime_CHR(47)) == 0 ){
/*123*/ 				return m2runtime_substr(FileName_f, (FileName_i + 1), m2runtime_length(FileName_f), 1, FileName_0err_entry_get, 12);
/*126*/ 			}
/*126*/ 		}
/*126*/ 	}
/*126*/ 	return FileName_f;
/*130*/ }


/*136*/ STRING *
/*136*/ FileName_Absolute(STRING *FileName_cwd, STRING *FileName_f)
/*136*/ {
/*136*/ 	FileName_f = FileName_slash_convert(FileName_f);
/*137*/ 	FileName_cwd = FileName_slash_convert(FileName_cwd);
/*139*/ 	if( m2runtime_strcmp(FileName_f, EMPTY_STRING) <= 0 ){
/*140*/ 		m2runtime_HALT(FileName_0err_entry_get, 13, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"empty path");
/*144*/ 	}
/*144*/ 	if( ((m2runtime_strcmp(m2runtime_substr(FileName_f, 0, 0, 0, FileName_0err_entry_get, 14), m2runtime_CHR(47)) == 0) || m2_match(FileName_f, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"^[a-zA-Z]:")) ){
/*145*/ 		return FileName_Normalize(FileName_f);
/*148*/ 	}
/*148*/ 	if( FileName_cwd == NULL ){
/*149*/ 		m2runtime_ERROR_CODE = 0;
/*149*/ 		FileName_cwd = io_GetCWD(1);
/*150*/ 		switch( m2runtime_ERROR_CODE ){

/*150*/ 		case 0:  break;
/*150*/ 		default:
/*150*/ 			m2runtime_HALT(FileName_0err_entry_get, 15, m2runtime_ERROR_MESSAGE);
/*150*/ 		}
/*150*/ 		FileName_cwd = FileName_slash_convert(FileName_cwd);
/*153*/ 	}
/*153*/ 	return FileName_Normalize(m2runtime_concat_STRING(0, FileName_cwd, m2runtime_CHR(47), FileName_f, 1));
/*157*/ }


/*159*/ STRING *
/*159*/ FileName_Relative(STRING *FileName_a, STRING *FileName_b)
/*159*/ {
/*160*/ 	int FileName_j = 0;
/*160*/ 	int FileName_i = 0;
/*162*/ 	STRING * FileName_c = NULL;
/*162*/ 	FileName_a = FileName_slash_convert(FileName_a);
/*163*/ 	FileName_b = FileName_slash_convert(FileName_b);
/*166*/ 	FileName_j = -1;
/*167*/ 	FileName_i = 0;
/*169*/ 	do{
/*169*/ 		if( (FileName_i == m2runtime_length(FileName_a)) ){
/*170*/ 			if( (((FileName_i == m2runtime_length(FileName_b))) || (m2runtime_strcmp(m2runtime_substr(FileName_b, FileName_i, 0, 0, FileName_0err_entry_get, 16), m2runtime_CHR(47)) == 0)) ){
/*171*/ 				FileName_j = FileName_i;
/*174*/ 			}
/*174*/ 			goto m2runtime_loop_1;
/*174*/ 		} else if( (FileName_i == m2runtime_length(FileName_b)) ){
/*175*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 17), m2runtime_CHR(47)) == 0 ){
/*176*/ 				FileName_j = FileName_i;
/*179*/ 			}
/*179*/ 			goto m2runtime_loop_1;
/*179*/ 		} else if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 18), m2runtime_substr(FileName_b, FileName_i, 0, 0, FileName_0err_entry_get, 19)) == 0 ){
/*180*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 20), m2runtime_CHR(47)) == 0 ){
/*181*/ 				FileName_j = FileName_i;
/*183*/ 			}
/*183*/ 			m2_inc(&FileName_i, 1);
/*186*/ 		} else {
/*187*/ 			goto m2runtime_loop_1;
/*188*/ 		}
/*188*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*188*/ 	if( (FileName_j == -1) ){
/*189*/ 		return FileName_b;
/*191*/ 	}
/*191*/ 	if( (FileName_j == m2runtime_length(FileName_b)) ){
/*192*/ 		return FileName_Basename(FileName_b);
/*196*/ 	}
/*196*/ 	FileName_i = (FileName_j + 1);
/*197*/ 	FileName_c = EMPTY_STRING;
/*198*/ 	while( (FileName_i < m2runtime_length(FileName_a)) ){
/*199*/ 		if( m2runtime_strcmp(m2runtime_substr(FileName_a, FileName_i, 0, 0, FileName_0err_entry_get, 21), m2runtime_CHR(47)) == 0 ){
/*200*/ 			FileName_c = m2runtime_concat_STRING(0, FileName_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"../", 1);
/*202*/ 		}
/*202*/ 		m2_inc(&FileName_i, 1);
/*205*/ 	}
/*205*/ 	return m2runtime_concat_STRING(0, FileName_c, m2runtime_substr(FileName_b, (FileName_j + 1), m2runtime_length(FileName_b), 1, FileName_0err_entry_get, 22), 1);
/*209*/ }


/*210*/ STRING *
/*210*/ FileName_DropExtension(STRING *FileName_f)
/*210*/ {
/*212*/ 	int FileName_i = 0;
/*212*/ 	FileName_f = FileName_slash_convert(FileName_f);
/*213*/ 	{
/*213*/ 		int m2runtime_for_limit_1;
/*213*/ 		FileName_i = (m2runtime_length(FileName_f) - 1);
/*213*/ 		m2runtime_for_limit_1 = 0;
/*214*/ 		for( ; FileName_i >= m2runtime_for_limit_1; FileName_i -= 1 ){
/*214*/ 			if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 23), m2runtime_CHR(46)) == 0 ){
/*215*/ 				return m2runtime_substr(FileName_f, 0, FileName_i, 1, FileName_0err_entry_get, 24);
/*216*/ 			} else if( m2runtime_strcmp(m2runtime_substr(FileName_f, FileName_i, 0, 0, FileName_0err_entry_get, 25), m2runtime_CHR(47)) == 0 ){
/*217*/ 				return FileName_f;
/*220*/ 			}
/*220*/ 		}
/*220*/ 	}
/*220*/ 	return FileName_f;
/*224*/ }


char * FileName_0func[] = {
    "Normalize",
    "Dirname",
    "Basename",
    "Absolute",
    "Relative",
    "DropExtension"
};

int FileName_0err_entry[] = {
    0 /* Normalize */, 44,
    0 /* Normalize */, 50,
    0 /* Normalize */, 62,
    0 /* Normalize */, 65,
    0 /* Normalize */, 66,
    0 /* Normalize */, 73,
    0 /* Normalize */, 86,
    0 /* Normalize */, 88,
    0 /* Normalize */, 91,
    1 /* Dirname */, 102,
    1 /* Dirname */, 106,
    2 /* Basename */, 122,
    2 /* Basename */, 123,
    3 /* Absolute */, 140,
    3 /* Absolute */, 144,
    3 /* Absolute */, 149,
    4 /* Relative */, 170,
    4 /* Relative */, 175,
    4 /* Relative */, 179,
    4 /* Relative */, 179,
    4 /* Relative */, 180,
    4 /* Relative */, 199,
    4 /* Relative */, 205,
    5 /* DropExtension */, 214,
    5 /* DropExtension */, 215,
    5 /* DropExtension */, 216
};

void FileName_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "FileName";
    *f = FileName_0func[ FileName_0err_entry[2*i] ];
    *l = FileName_0err_entry[2*i + 1];
}
