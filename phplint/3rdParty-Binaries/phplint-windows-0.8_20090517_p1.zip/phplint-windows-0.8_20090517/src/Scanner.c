/* IMPLEMENTATION MODULE Scanner */
#define M2_IMPORT_Scanner

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/*227*/ STRING * Scanner_cwd = NULL;
/*231*/ int Scanner_print_file_name = 0;
/*240*/ int Scanner_print_path_fmt = 0;
/*243*/ int Scanner_ctrl_check = 0;
/*246*/ int Scanner_ascii_ext_check = 0;
/*249*/ int Scanner_tab_size = 0;
/*250*/ int Scanner_print_notices = 0;
/*251*/ int Scanner_print_warnings = 0;
/*252*/ int Scanner_print_errors = 0;
/*253*/ int Scanner_print_context = 0;
/*254*/ int Scanner_print_source = 0;
/*258*/ int Scanner_print_line_numbers = 0;
/*261*/ STRING * Scanner_fn = NULL;
/*264*/ int Scanner_sym = 0;
/*268*/ STRING * Scanner_s = NULL;
/*277*/ int Scanner_warning_counter = 0;
/*277*/ int Scanner_error_counter = 0;

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

#ifndef M2_IMPORT_Tokens
#    include "Tokens.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

void Scanner_0err_entry_get(int i, char **m, char **f, int *l);
/* 83*/ void * Scanner_fd = NULL;
/* 85*/ int Scanner_code = 0;
/* 88*/ STRING * Scanner_line = NULL;
/* 91*/ int Scanner_line_n = 0;
/* 94*/ int Scanner_line_idx = 0;
/* 97*/ int Scanner_line_pos = 0;
/*106*/ STRING * Scanner_c = NULL;

/*108*/ STRING *
/*108*/ Scanner_mn(RECORD *Scanner_c, RECORD *Scanner_m)
/*108*/ {
/*108*/ 	return m2runtime_concat_STRING(0, m2runtime_CHR(96), (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_c, 8, Scanner_0err_entry_get, 0), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_m, 8, Scanner_0err_entry_get, 1), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"()'", 1);
/*112*/ }


/*113*/ STRING *
/*113*/ Scanner_fmt_fn(STRING *Scanner_abs_path)
/*113*/ {
/*115*/ 	STRING * Scanner_r = NULL;
/*115*/ 	switch(Scanner_print_path_fmt){

/*117*/ 	case 0:
/*118*/ 	return Scanner_abs_path;
/*120*/ 	break;

/*120*/ 	case 1:
/*121*/ 	return FileName_Relative(m2runtime_concat_STRING(0, Scanner_cwd, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*", 1), Scanner_abs_path);
/*123*/ 	break;

/*123*/ 	case 2:
/*124*/ 	Scanner_r = FileName_Relative(m2runtime_concat_STRING(0, Scanner_cwd, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*", 1), Scanner_abs_path);
/*125*/ 	if( (m2runtime_length(Scanner_r) < m2runtime_length(Scanner_abs_path)) ){
/*126*/ 		return Scanner_r;
/*128*/ 	} else {
/*128*/ 		return Scanner_abs_path;
/*131*/ 	}
/*131*/ 	break;

/*131*/ 	default: m2runtime_missing_case_in_switch(Scanner_0err_entry_get, 2);
/*132*/ 	}
/*132*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 3);
/*132*/ 	return NULL;
/*134*/ }


/*136*/ RECORD *
/*136*/ Scanner_here(void)
/*136*/ {
/*136*/ 	return (
/*136*/ 		push((char*) alloc_RECORD(16, 1)),
/*136*/ 		push((char*) Scanner_fn),
/*136*/ 		*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*136*/ 		*(int*) (tos()+12) = Scanner_line_n,
/*138*/ 		(RECORD*) pop()
/*138*/ 	);
/*140*/ }


/*142*/ STRING *
/*142*/ Scanner_reference(RECORD *Scanner_w)
/*142*/ {
/*142*/ 	if( Scanner_w == NULL ){
/*143*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"?:?";
/*144*/ 	} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 4), Scanner_fn) == 0 ){
/*145*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"line ", m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 5)), 1);
/*147*/ 	} else {
/*147*/ 		return m2runtime_concat_STRING(0, Scanner_fmt_fn((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 6)), m2runtime_CHR(58), m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 7)), 1);
/*150*/ 	}
/*150*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 8);
/*150*/ 	return NULL;
/*152*/ }


/*154*/ void
/*154*/ Scanner_PrintWhere(RECORD *Scanner_w)
/*154*/ {
/*154*/ 	if( (Scanner_print_context || Scanner_print_source) ){
/*156*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"**** ");
/*159*/ 	}
/*159*/ 	if( Scanner_w == NULL ){
/*160*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"?: ");
/*162*/ 	} else {
/*162*/ 		if( (Scanner_print_file_name || !Scanner_print_source || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 9), Scanner_fn) != 0)) ){
/*165*/ 			m2_print(m2runtime_concat_STRING(0, Scanner_fmt_fn((STRING *)m2runtime_dereference_rhs_RECORD(Scanner_w, 8, Scanner_0err_entry_get, 10)), m2runtime_CHR(58), 1));
/*167*/ 		}
/*167*/ 		m2_print(m2runtime_concat_STRING(0, m2runtime_itos( *(int *)m2runtime_dereference_rhs_RECORD(Scanner_w, 12, Scanner_0err_entry_get, 11)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", 1));
/*170*/ 	}
/*172*/ }


/*174*/ void
/*174*/ Scanner_PrintCurrPos(void)
/*174*/ {
/*175*/ 	if( Scanner_print_context ){
/*176*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\011", Scanner_line, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\011", str_repeat(m2runtime_CHR(32), (Scanner_line_pos - 1)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"\134_ HERE\012", 1));
/*179*/ 	}
/*179*/ 	Scanner_PrintWhere(Scanner_here());
/*183*/ }


/*185*/ void
/*185*/ Scanner_Fatal(STRING *Scanner_s)
/*185*/ {
/*185*/ 	Scanner_PrintCurrPos();
/*186*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"FATAL ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*187*/ 	m2runtime_exit(1);
/*191*/ }


/*193*/ void
/*193*/ Scanner_UnexpectedSymbol(void)
/*193*/ {
/*193*/ 	Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"unexpected symbol ", Tokens_CodeToName(Scanner_sym), 1));
/*194*/ 	m2runtime_exit(1);
/*198*/ }


/*200*/ void
/*200*/ Scanner_Error(STRING *Scanner_s)
/*200*/ {
/*200*/ 	m2_inc(&Scanner_error_counter, 1);
/*201*/ 	if( !Scanner_print_errors ){
/*203*/ 		return ;
/*204*/ 	}
/*204*/ 	Scanner_PrintCurrPos();
/*205*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*209*/ }


/*211*/ void
/*211*/ Scanner_Error2(RECORD *Scanner_w, STRING *Scanner_s)
/*211*/ {
/*211*/ 	m2_inc(&Scanner_error_counter, 1);
/*212*/ 	if( !Scanner_print_errors ){
/*214*/ 		return ;
/*215*/ 	}
/*215*/ 	Scanner_PrintWhere(Scanner_w);
/*216*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"ERROR: ", Scanner_s, m2runtime_CHR(10), 1));
/*220*/ }


/*222*/ void
/*222*/ Scanner_Warning(STRING *Scanner_s)
/*222*/ {
/*222*/ 	m2_inc(&Scanner_warning_counter, 1);
/*223*/ 	if( !Scanner_print_warnings ){
/*225*/ 		return ;
/*226*/ 	}
/*226*/ 	Scanner_PrintCurrPos();
/*227*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Warning: ", Scanner_s, m2runtime_CHR(10), 1));
/*231*/ }


/*233*/ void
/*233*/ Scanner_Warning2(RECORD *Scanner_w, STRING *Scanner_s)
/*233*/ {
/*233*/ 	m2_inc(&Scanner_warning_counter, 1);
/*234*/ 	if( !Scanner_print_warnings ){
/*236*/ 		return ;
/*237*/ 	}
/*237*/ 	Scanner_PrintWhere(Scanner_w);
/*238*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Warning: ", Scanner_s, m2runtime_CHR(10), 1));
/*242*/ }


/*244*/ void
/*244*/ Scanner_Notice(STRING *Scanner_s)
/*244*/ {
/*244*/ 	if( !Scanner_print_notices ){
/*246*/ 		return ;
/*247*/ 	}
/*247*/ 	Scanner_PrintCurrPos();
/*248*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"notice: ", Scanner_s, m2runtime_CHR(10), 1));
/*252*/ }


/*254*/ void
/*254*/ Scanner_Notice2(RECORD *Scanner_w, STRING *Scanner_s)
/*254*/ {
/*254*/ 	if( !Scanner_print_notices ){
/*256*/ 		return ;
/*257*/ 	}
/*257*/ 	Scanner_PrintWhere(Scanner_w);
/*258*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"notice: ", Scanner_s, m2runtime_CHR(10), 1));
/*262*/ }


/*264*/ STRING *
/*264*/ Scanner_SymToName(int Scanner_code)
/*264*/ {
/*264*/ 	return Tokens_CodeToName(Scanner_code);
/*268*/ }


/*270*/ void
/*270*/ Scanner_Expect(int Scanner_es, STRING *Scanner_err)
/*270*/ {
/*270*/ 	if( (Scanner_sym == Scanner_es) ){
/*272*/ 		return ;
/*273*/ 	}
/*273*/ 	Scanner_Fatal(m2runtime_concat_STRING(0, Scanner_err, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)", found symbol ", Scanner_SymToName(Scanner_sym), 1));
/*276*/ }


/*278*/ void
/*278*/ Scanner_PrintLineSource(void)
/*278*/ {
/*278*/ 	if( Scanner_print_line_numbers ){
/*279*/ 		m2_print(m2runtime_itos(Scanner_line_n));
/*281*/ 	}
/*281*/ 	m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)":\011");
/*282*/ 	m2_print(Scanner_line);
/*283*/ 	m2_print(m2runtime_CHR(10));
/*287*/ }


/*289*/ void
/*289*/ Scanner_ReadCh(void)
/*289*/ {
/*290*/ 	if( Scanner_c == NULL ){
/*291*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0 ){
/*292*/ 		m2_inc(&Scanner_line_pos, Scanner_tab_size);
/*293*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*294*/ 		m2_inc(&Scanner_line_n, 1);
/*295*/ 		Scanner_line_pos = 1;
/*297*/ 	} else {
/*297*/ 		m2_inc(&Scanner_line_pos, 1);
/*301*/ 	}
/*301*/ 	if( Scanner_line == NULL ){
/*302*/ 		Scanner_c = NULL;
/*303*/ 	} else if( (Scanner_line_idx < m2runtime_length(Scanner_line)) ){
/*304*/ 		Scanner_c = m2runtime_substr(Scanner_line, Scanner_line_idx, 0, 0, Scanner_0err_entry_get, 12);
/*305*/ 		m2_inc(&Scanner_line_idx, 1);
/*306*/ 	} else if( (Scanner_line_idx == m2runtime_length(Scanner_line)) ){
/*307*/ 		Scanner_c = m2runtime_CHR(10);
/*308*/ 		m2_inc(&Scanner_line_idx, 1);
/*310*/ 	} else {
/*310*/ 		m2runtime_ERROR_CODE = 0;
/*310*/ 		Scanner_line = io_ReadLine(1, Scanner_fd);
/*311*/ 		switch( m2runtime_ERROR_CODE ){

/*311*/ 		case 0:  break;
/*311*/ 		default:
/*311*/ 			m2runtime_HALT(Scanner_0err_entry_get, 13, m2runtime_ERROR_MESSAGE);
/*311*/ 		}
/*311*/ 		if( Scanner_line == NULL ){
/*312*/ 			Scanner_c = NULL;
/*313*/ 		} else if( (m2runtime_length(Scanner_line) == 0) ){
/*314*/ 			Scanner_c = m2runtime_CHR(10);
/*316*/ 		} else {
/*316*/ 			Scanner_c = m2runtime_substr(Scanner_line, 0, 0, 0, Scanner_0err_entry_get, 14);
/*318*/ 		}
/*318*/ 		Scanner_line_idx = 1;
/*319*/ 		if( (Scanner_print_source && (Scanner_line != NULL)) ){
/*320*/ 			Scanner_PrintLineSource();
/*323*/ 		}
/*324*/ 	}
/*324*/ 	if( Globals_DEBUG ){
/*325*/ 		m2_print(Scanner_c);
/*328*/ 	}
/*331*/ }

/*336*/ void * Scanner_b = NULL;
/*342*/ ARRAY * Scanner_php_keywords = NULL;
/*346*/ ARRAY * Scanner_phplint_keywords = NULL;

/*351*/ int
/*351*/ Scanner_SearchKeyword(STRING *Scanner_word, ARRAY *Scanner_list)
/*351*/ {
/*351*/ 	int Scanner_r = 0;
/*351*/ 	int Scanner_i = 0;
/*351*/ 	int Scanner_b = 0;
/*351*/ 	int Scanner_a = 0;
/*353*/ 	int Scanner_k = 0;
/*353*/ 	Scanner_a = 0;
/*354*/ 	Scanner_b = (m2runtime_count(Scanner_list) - 1);
/*356*/ 	do{
/*356*/ 		Scanner_i = (((Scanner_a + Scanner_b)) / 2);
/*357*/ 		Scanner_r = m2runtime_strcmp(Scanner_word, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Scanner_list, Scanner_i, Scanner_0err_entry_get, 15), 8, Scanner_0err_entry_get, 16));
/*358*/ 		if( (Scanner_r < 0) ){
/*359*/ 			Scanner_b = (Scanner_i - 1);
/*360*/ 		} else if( (Scanner_r > 0) ){
/*361*/ 			Scanner_a = (Scanner_i + 1);
/*363*/ 		} else {
/*363*/ 			Scanner_k =  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Scanner_list, Scanner_i, Scanner_0err_entry_get, 17), 12, Scanner_0err_entry_get, 18);
/*364*/ 			if( (Scanner_k == 2) ){
/*365*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"unimplemented keyword `", Scanner_word, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"'. I'm sorry...", 1));
/*367*/ 			}
/*367*/ 			return Scanner_k;
/*369*/ 		}
/*369*/ 		if( (Scanner_a > Scanner_b) ){
/*370*/ 			return 1;
/*373*/ 		}
/*374*/ 	}while(TRUE);
/*374*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 19);
/*374*/ 	return 0;
/*376*/ }


/*378*/ int
/*378*/ Scanner_SearchPhpKeyword(STRING *Scanner_k)
/*378*/ {
/*378*/ 	return Scanner_SearchKeyword(Scanner_k, Scanner_php_keywords);
/*382*/ }


/*384*/ void
/*384*/ Scanner_InitScanner(void)
/*384*/ {
/*384*/ 	Scanner_php_keywords = (
/*385*/ 		push((char*) alloc_ARRAY(4, 1)),
/*385*/ 		push((char*) (
/*385*/ 			push((char*) alloc_RECORD(16, 1)),
/*385*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE"),
/*385*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*385*/ 			*(int*) (tos()+12) = 65,
/*386*/ 			(RECORD*) pop()
/*386*/ 		)),
/*386*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*386*/ 		push((char*) (
/*386*/ 			push((char*) alloc_RECORD(16, 1)),
/*386*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*386*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*386*/ 			*(int*) (tos()+12) = 63,
/*387*/ 			(RECORD*) pop()
/*387*/ 		)),
/*387*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*387*/ 		push((char*) (
/*387*/ 			push((char*) alloc_RECORD(16, 1)),
/*387*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE"),
/*387*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*387*/ 			*(int*) (tos()+12) = 66,
/*388*/ 			(RECORD*) pop()
/*388*/ 		)),
/*388*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*388*/ 		push((char*) (
/*388*/ 			push((char*) alloc_RECORD(16, 1)),
/*388*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"abstract"),
/*388*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*388*/ 			*(int*) (tos()+12) = 91,
/*389*/ 			(RECORD*) pop()
/*389*/ 		)),
/*389*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*389*/ 		push((char*) (
/*389*/ 			push((char*) alloc_RECORD(16, 1)),
/*389*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"and"),
/*389*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*389*/ 			*(int*) (tos()+12) = 58,
/*390*/ 			(RECORD*) pop()
/*390*/ 		)),
/*390*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*390*/ 		push((char*) (
/*390*/ 			push((char*) alloc_RECORD(16, 1)),
/*390*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array"),
/*390*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*390*/ 			*(int*) (tos()+12) = 70,
/*391*/ 			(RECORD*) pop()
/*391*/ 		)),
/*391*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*391*/ 		push((char*) (
/*391*/ 			push((char*) alloc_RECORD(16, 1)),
/*391*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"as"),
/*391*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*391*/ 			*(int*) (tos()+12) = 23,
/*392*/ 			(RECORD*) pop()
/*392*/ 		)),
/*392*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*392*/ 		push((char*) (
/*392*/ 			push((char*) alloc_RECORD(16, 1)),
/*392*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool"),
/*392*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*392*/ 			*(int*) (tos()+12) = 64,
/*393*/ 			(RECORD*) pop()
/*393*/ 		)),
/*393*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*393*/ 		push((char*) (
/*393*/ 			push((char*) alloc_RECORD(16, 1)),
/*393*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean"),
/*393*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*393*/ 			*(int*) (tos()+12) = 64,
/*394*/ 			(RECORD*) pop()
/*394*/ 		)),
/*394*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*394*/ 		push((char*) (
/*394*/ 			push((char*) alloc_RECORD(16, 1)),
/*394*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"break"),
/*394*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*394*/ 			*(int*) (tos()+12) = 111,
/*395*/ 			(RECORD*) pop()
/*395*/ 		)),
/*395*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*395*/ 		push((char*) (
/*395*/ 			push((char*) alloc_RECORD(16, 1)),
/*395*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"case"),
/*395*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*395*/ 			*(int*) (tos()+12) = 110,
/*396*/ 			(RECORD*) pop()
/*396*/ 		)),
/*396*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*396*/ 		push((char*) (
/*396*/ 			push((char*) alloc_RECORD(16, 1)),
/*396*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"catch"),
/*396*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*396*/ 			*(int*) (tos()+12) = 119,
/*397*/ 			(RECORD*) pop()
/*397*/ 		)),
/*397*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*397*/ 		push((char*) (
/*397*/ 			push((char*) alloc_RECORD(16, 1)),
/*397*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class"),
/*397*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*397*/ 			*(int*) (tos()+12) = 93,
/*398*/ 			(RECORD*) pop()
/*398*/ 		)),
/*398*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*398*/ 		push((char*) (
/*398*/ 			push((char*) alloc_RECORD(16, 1)),
/*398*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"clone"),
/*398*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*398*/ 			*(int*) (tos()+12) = 106,
/*399*/ 			(RECORD*) pop()
/*399*/ 		)),
/*399*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),13) = (RECORD*) tos(), pop(),
/*399*/ 		push((char*) (
/*399*/ 			push((char*) alloc_RECORD(16, 1)),
/*399*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"const"),
/*399*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*399*/ 			*(int*) (tos()+12) = 96,
/*400*/ 			(RECORD*) pop()
/*400*/ 		)),
/*400*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),14) = (RECORD*) tos(), pop(),
/*400*/ 		push((char*) (
/*400*/ 			push((char*) alloc_RECORD(16, 1)),
/*400*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"continue"),
/*400*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*400*/ 			*(int*) (tos()+12) = 121,
/*401*/ 			(RECORD*) pop()
/*401*/ 		)),
/*401*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),15) = (RECORD*) tos(), pop(),
/*401*/ 		push((char*) (
/*401*/ 			push((char*) alloc_RECORD(16, 1)),
/*401*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"declare"),
/*401*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*401*/ 			*(int*) (tos()+12) = 9,
/*402*/ 			(RECORD*) pop()
/*402*/ 		)),
/*402*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),16) = (RECORD*) tos(), pop(),
/*402*/ 		push((char*) (
/*402*/ 			push((char*) alloc_RECORD(16, 1)),
/*402*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"default"),
/*402*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*402*/ 			*(int*) (tos()+12) = 112,
/*403*/ 			(RECORD*) pop()
/*403*/ 		)),
/*403*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),17) = (RECORD*) tos(), pop(),
/*403*/ 		push((char*) (
/*403*/ 			push((char*) alloc_RECORD(16, 1)),
/*403*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"define"),
/*403*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*403*/ 			*(int*) (tos()+12) = 7,
/*404*/ 			(RECORD*) pop()
/*404*/ 		)),
/*404*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),18) = (RECORD*) tos(), pop(),
/*404*/ 		push((char*) (
/*404*/ 			push((char*) alloc_RECORD(16, 1)),
/*404*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"die"),
/*404*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*404*/ 			*(int*) (tos()+12) = 113,
/*405*/ 			(RECORD*) pop()
/*405*/ 		)),
/*405*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),19) = (RECORD*) tos(), pop(),
/*405*/ 		push((char*) (
/*405*/ 			push((char*) alloc_RECORD(16, 1)),
/*405*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"do"),
/*405*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*405*/ 			*(int*) (tos()+12) = 117,
/*406*/ 			(RECORD*) pop()
/*406*/ 		)),
/*406*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),20) = (RECORD*) tos(), pop(),
/*406*/ 		push((char*) (
/*406*/ 			push((char*) alloc_RECORD(16, 1)),
/*406*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double"),
/*406*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*406*/ 			*(int*) (tos()+12) = 68,
/*407*/ 			(RECORD*) pop()
/*407*/ 		)),
/*407*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),21) = (RECORD*) tos(), pop(),
/*407*/ 		push((char*) (
/*407*/ 			push((char*) alloc_RECORD(16, 1)),
/*407*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"echo"),
/*407*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*407*/ 			*(int*) (tos()+12) = 114,
/*408*/ 			(RECORD*) pop()
/*408*/ 		)),
/*408*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),22) = (RECORD*) tos(), pop(),
/*408*/ 		push((char*) (
/*408*/ 			push((char*) alloc_RECORD(16, 1)),
/*408*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"else"),
/*408*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*408*/ 			*(int*) (tos()+12) = 26,
/*409*/ 			(RECORD*) pop()
/*409*/ 		)),
/*409*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),23) = (RECORD*) tos(), pop(),
/*409*/ 		push((char*) (
/*409*/ 			push((char*) alloc_RECORD(16, 1)),
/*409*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"elseif"),
/*409*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*409*/ 			*(int*) (tos()+12) = 27,
/*410*/ 			(RECORD*) pop()
/*410*/ 		)),
/*410*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),24) = (RECORD*) tos(), pop(),
/*410*/ 		push((char*) (
/*410*/ 			push((char*) alloc_RECORD(16, 1)),
/*410*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"enddeclare"),
/*410*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*410*/ 			*(int*) (tos()+12) = 2,
/*411*/ 			(RECORD*) pop()
/*411*/ 		)),
/*411*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),25) = (RECORD*) tos(), pop(),
/*411*/ 		push((char*) (
/*411*/ 			push((char*) alloc_RECORD(16, 1)),
/*411*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"endfor"),
/*411*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*411*/ 			*(int*) (tos()+12) = 2,
/*412*/ 			(RECORD*) pop()
/*412*/ 		)),
/*412*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),26) = (RECORD*) tos(), pop(),
/*412*/ 		push((char*) (
/*412*/ 			push((char*) alloc_RECORD(16, 1)),
/*412*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"endforeach"),
/*412*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*412*/ 			*(int*) (tos()+12) = 2,
/*413*/ 			(RECORD*) pop()
/*413*/ 		)),
/*413*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),27) = (RECORD*) tos(), pop(),
/*413*/ 		push((char*) (
/*413*/ 			push((char*) alloc_RECORD(16, 1)),
/*413*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"endif"),
/*413*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*413*/ 			*(int*) (tos()+12) = 2,
/*414*/ 			(RECORD*) pop()
/*414*/ 		)),
/*414*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),28) = (RECORD*) tos(), pop(),
/*414*/ 		push((char*) (
/*414*/ 			push((char*) alloc_RECORD(16, 1)),
/*414*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"endswitch"),
/*414*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*414*/ 			*(int*) (tos()+12) = 2,
/*415*/ 			(RECORD*) pop()
/*415*/ 		)),
/*415*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),29) = (RECORD*) tos(), pop(),
/*415*/ 		push((char*) (
/*415*/ 			push((char*) alloc_RECORD(16, 1)),
/*415*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"endwhile"),
/*415*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*415*/ 			*(int*) (tos()+12) = 2,
/*416*/ 			(RECORD*) pop()
/*416*/ 		)),
/*416*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),30) = (RECORD*) tos(), pop(),
/*416*/ 		push((char*) (
/*416*/ 			push((char*) alloc_RECORD(16, 1)),
/*416*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"exit"),
/*416*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*416*/ 			*(int*) (tos()+12) = 113,
/*417*/ 			(RECORD*) pop()
/*417*/ 		)),
/*417*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),31) = (RECORD*) tos(), pop(),
/*417*/ 		push((char*) (
/*417*/ 			push((char*) alloc_RECORD(16, 1)),
/*417*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"extends"),
/*417*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*417*/ 			*(int*) (tos()+12) = 94,
/*418*/ 			(RECORD*) pop()
/*418*/ 		)),
/*418*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),32) = (RECORD*) tos(), pop(),
/*418*/ 		push((char*) (
/*418*/ 			push((char*) alloc_RECORD(16, 1)),
/*418*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"false"),
/*418*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*418*/ 			*(int*) (tos()+12) = 65,
/*419*/ 			(RECORD*) pop()
/*419*/ 		)),
/*419*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),33) = (RECORD*) tos(), pop(),
/*419*/ 		push((char*) (
/*419*/ 			push((char*) alloc_RECORD(16, 1)),
/*419*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"final"),
/*419*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*419*/ 			*(int*) (tos()+12) = 102,
/*420*/ 			(RECORD*) pop()
/*420*/ 		)),
/*420*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),34) = (RECORD*) tos(), pop(),
/*420*/ 		push((char*) (
/*420*/ 			push((char*) alloc_RECORD(16, 1)),
/*420*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float"),
/*420*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*420*/ 			*(int*) (tos()+12) = 68,
/*421*/ 			(RECORD*) pop()
/*421*/ 		)),
/*421*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),35) = (RECORD*) tos(), pop(),
/*421*/ 		push((char*) (
/*421*/ 			push((char*) alloc_RECORD(16, 1)),
/*421*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"for"),
/*421*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*421*/ 			*(int*) (tos()+12) = 21,
/*422*/ 			(RECORD*) pop()
/*422*/ 		)),
/*422*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),36) = (RECORD*) tos(), pop(),
/*422*/ 		push((char*) (
/*422*/ 			push((char*) alloc_RECORD(16, 1)),
/*422*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"foreach"),
/*422*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*422*/ 			*(int*) (tos()+12) = 22,
/*423*/ 			(RECORD*) pop()
/*423*/ 		)),
/*423*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),37) = (RECORD*) tos(), pop(),
/*423*/ 		push((char*) (
/*423*/ 			push((char*) alloc_RECORD(16, 1)),
/*423*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function"),
/*423*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*423*/ 			*(int*) (tos()+12) = 8,
/*424*/ 			(RECORD*) pop()
/*424*/ 		)),
/*424*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),38) = (RECORD*) tos(), pop(),
/*424*/ 		push((char*) (
/*424*/ 			push((char*) alloc_RECORD(16, 1)),
/*424*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"global"),
/*424*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*424*/ 			*(int*) (tos()+12) = 62,
/*425*/ 			(RECORD*) pop()
/*425*/ 		)),
/*425*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),39) = (RECORD*) tos(), pop(),
/*425*/ 		push((char*) (
/*425*/ 			push((char*) alloc_RECORD(16, 1)),
/*425*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"if"),
/*425*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*425*/ 			*(int*) (tos()+12) = 25,
/*426*/ 			(RECORD*) pop()
/*426*/ 		)),
/*426*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),40) = (RECORD*) tos(), pop(),
/*426*/ 		push((char*) (
/*426*/ 			push((char*) alloc_RECORD(16, 1)),
/*426*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"implements"),
/*426*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*426*/ 			*(int*) (tos()+12) = 95,
/*427*/ 			(RECORD*) pop()
/*427*/ 		)),
/*427*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),41) = (RECORD*) tos(), pop(),
/*427*/ 		push((char*) (
/*427*/ 			push((char*) alloc_RECORD(16, 1)),
/*427*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"include"),
/*427*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*427*/ 			*(int*) (tos()+12) = 123,
/*428*/ 			(RECORD*) pop()
/*428*/ 		)),
/*428*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),42) = (RECORD*) tos(), pop(),
/*428*/ 		push((char*) (
/*428*/ 			push((char*) alloc_RECORD(16, 1)),
/*428*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"include_once"),
/*428*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*428*/ 			*(int*) (tos()+12) = 124,
/*429*/ 			(RECORD*) pop()
/*429*/ 		)),
/*429*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),43) = (RECORD*) tos(), pop(),
/*429*/ 		push((char*) (
/*429*/ 			push((char*) alloc_RECORD(16, 1)),
/*429*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"instanceof"),
/*429*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*429*/ 			*(int*) (tos()+12) = 107,
/*430*/ 			(RECORD*) pop()
/*430*/ 		)),
/*430*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),44) = (RECORD*) tos(), pop(),
/*430*/ 		push((char*) (
/*430*/ 			push((char*) alloc_RECORD(16, 1)),
/*430*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*430*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*430*/ 			*(int*) (tos()+12) = 67,
/*431*/ 			(RECORD*) pop()
/*431*/ 		)),
/*431*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),45) = (RECORD*) tos(), pop(),
/*431*/ 		push((char*) (
/*431*/ 			push((char*) alloc_RECORD(16, 1)),
/*431*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer"),
/*431*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*431*/ 			*(int*) (tos()+12) = 67,
/*432*/ 			(RECORD*) pop()
/*432*/ 		)),
/*432*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),46) = (RECORD*) tos(), pop(),
/*432*/ 		push((char*) (
/*432*/ 			push((char*) alloc_RECORD(16, 1)),
/*432*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"interface"),
/*432*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*432*/ 			*(int*) (tos()+12) = 92,
/*433*/ 			(RECORD*) pop()
/*433*/ 		)),
/*433*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),47) = (RECORD*) tos(), pop(),
/*433*/ 		push((char*) (
/*433*/ 			push((char*) alloc_RECORD(16, 1)),
/*433*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"isset"),
/*433*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*433*/ 			*(int*) (tos()+12) = 122,
/*434*/ 			(RECORD*) pop()
/*434*/ 		)),
/*434*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),48) = (RECORD*) tos(), pop(),
/*434*/ 		push((char*) (
/*434*/ 			push((char*) alloc_RECORD(16, 1)),
/*434*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"list"),
/*434*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*434*/ 			*(int*) (tos()+12) = 108,
/*435*/ 			(RECORD*) pop()
/*435*/ 		)),
/*435*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),49) = (RECORD*) tos(), pop(),
/*435*/ 		push((char*) (
/*435*/ 			push((char*) alloc_RECORD(16, 1)),
/*435*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"new"),
/*435*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*435*/ 			*(int*) (tos()+12) = 105,
/*436*/ 			(RECORD*) pop()
/*436*/ 		)),
/*436*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),50) = (RECORD*) tos(), pop(),
/*436*/ 		push((char*) (
/*436*/ 			push((char*) alloc_RECORD(16, 1)),
/*436*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"null"),
/*436*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*436*/ 			*(int*) (tos()+12) = 63,
/*437*/ 			(RECORD*) pop()
/*437*/ 		)),
/*437*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),51) = (RECORD*) tos(), pop(),
/*437*/ 		push((char*) (
/*437*/ 			push((char*) alloc_RECORD(16, 1)),
/*437*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object"),
/*437*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*437*/ 			*(int*) (tos()+12) = 71,
/*438*/ 			(RECORD*) pop()
/*438*/ 		)),
/*438*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),52) = (RECORD*) tos(), pop(),
/*438*/ 		push((char*) (
/*438*/ 			push((char*) alloc_RECORD(16, 1)),
/*438*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"or"),
/*438*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*438*/ 			*(int*) (tos()+12) = 56,
/*439*/ 			(RECORD*) pop()
/*439*/ 		)),
/*439*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),53) = (RECORD*) tos(), pop(),
/*439*/ 		push((char*) (
/*439*/ 			push((char*) alloc_RECORD(16, 1)),
/*439*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"parent"),
/*439*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*439*/ 			*(int*) (tos()+12) = 104,
/*440*/ 			(RECORD*) pop()
/*440*/ 		)),
/*440*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),54) = (RECORD*) tos(), pop(),
/*440*/ 		push((char*) (
/*440*/ 			push((char*) alloc_RECORD(16, 1)),
/*440*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"print"),
/*440*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*440*/ 			*(int*) (tos()+12) = 115,
/*441*/ 			(RECORD*) pop()
/*441*/ 		)),
/*441*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),55) = (RECORD*) tos(), pop(),
/*441*/ 		push((char*) (
/*441*/ 			push((char*) alloc_RECORD(16, 1)),
/*441*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private"),
/*441*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*441*/ 			*(int*) (tos()+12) = 99,
/*442*/ 			(RECORD*) pop()
/*442*/ 		)),
/*442*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),56) = (RECORD*) tos(), pop(),
/*442*/ 		push((char*) (
/*442*/ 			push((char*) alloc_RECORD(16, 1)),
/*442*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected"),
/*442*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*442*/ 			*(int*) (tos()+12) = 100,
/*443*/ 			(RECORD*) pop()
/*443*/ 		)),
/*443*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),57) = (RECORD*) tos(), pop(),
/*443*/ 		push((char*) (
/*443*/ 			push((char*) alloc_RECORD(16, 1)),
/*443*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public"),
/*443*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*443*/ 			*(int*) (tos()+12) = 98,
/*444*/ 			(RECORD*) pop()
/*444*/ 		)),
/*444*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),58) = (RECORD*) tos(), pop(),
/*444*/ 		push((char*) (
/*444*/ 			push((char*) alloc_RECORD(16, 1)),
/*444*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real"),
/*444*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*444*/ 			*(int*) (tos()+12) = 68,
/*445*/ 			(RECORD*) pop()
/*445*/ 		)),
/*445*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),59) = (RECORD*) tos(), pop(),
/*445*/ 		push((char*) (
/*445*/ 			push((char*) alloc_RECORD(16, 1)),
/*445*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"require"),
/*445*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*445*/ 			*(int*) (tos()+12) = 125,
/*446*/ 			(RECORD*) pop()
/*446*/ 		)),
/*446*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),60) = (RECORD*) tos(), pop(),
/*446*/ 		push((char*) (
/*446*/ 			push((char*) alloc_RECORD(16, 1)),
/*446*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"require_once"),
/*446*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*446*/ 			*(int*) (tos()+12) = 126,
/*447*/ 			(RECORD*) pop()
/*447*/ 		)),
/*447*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),61) = (RECORD*) tos(), pop(),
/*447*/ 		push((char*) (
/*447*/ 			push((char*) alloc_RECORD(16, 1)),
/*447*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"return"),
/*447*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*447*/ 			*(int*) (tos()+12) = 28,
/*448*/ 			(RECORD*) pop()
/*448*/ 		)),
/*448*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),62) = (RECORD*) tos(), pop(),
/*448*/ 		push((char*) (
/*448*/ 			push((char*) alloc_RECORD(16, 1)),
/*448*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"self"),
/*448*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*448*/ 			*(int*) (tos()+12) = 103,
/*449*/ 			(RECORD*) pop()
/*449*/ 		)),
/*449*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),63) = (RECORD*) tos(), pop(),
/*449*/ 		push((char*) (
/*449*/ 			push((char*) alloc_RECORD(16, 1)),
/*449*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"static"),
/*449*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*449*/ 			*(int*) (tos()+12) = 101,
/*450*/ 			(RECORD*) pop()
/*450*/ 		)),
/*450*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),64) = (RECORD*) tos(), pop(),
/*450*/ 		push((char*) (
/*450*/ 			push((char*) alloc_RECORD(16, 1)),
/*450*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*450*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*450*/ 			*(int*) (tos()+12) = 69,
/*451*/ 			(RECORD*) pop()
/*451*/ 		)),
/*451*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),65) = (RECORD*) tos(), pop(),
/*451*/ 		push((char*) (
/*451*/ 			push((char*) alloc_RECORD(16, 1)),
/*451*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"switch"),
/*451*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*451*/ 			*(int*) (tos()+12) = 109,
/*452*/ 			(RECORD*) pop()
/*452*/ 		)),
/*452*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),66) = (RECORD*) tos(), pop(),
/*452*/ 		push((char*) (
/*452*/ 			push((char*) alloc_RECORD(16, 1)),
/*452*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"throw"),
/*452*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*452*/ 			*(int*) (tos()+12) = 120,
/*453*/ 			(RECORD*) pop()
/*453*/ 		)),
/*453*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),67) = (RECORD*) tos(), pop(),
/*453*/ 		push((char*) (
/*453*/ 			push((char*) alloc_RECORD(16, 1)),
/*453*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"trigger_error"),
/*453*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*453*/ 			*(int*) (tos()+12) = 116,
/*454*/ 			(RECORD*) pop()
/*454*/ 		)),
/*454*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),68) = (RECORD*) tos(), pop(),
/*454*/ 		push((char*) (
/*454*/ 			push((char*) alloc_RECORD(16, 1)),
/*454*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"true"),
/*454*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*454*/ 			*(int*) (tos()+12) = 66,
/*455*/ 			(RECORD*) pop()
/*455*/ 		)),
/*455*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),69) = (RECORD*) tos(), pop(),
/*455*/ 		push((char*) (
/*455*/ 			push((char*) alloc_RECORD(16, 1)),
/*455*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"try"),
/*455*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*455*/ 			*(int*) (tos()+12) = 118,
/*456*/ 			(RECORD*) pop()
/*456*/ 		)),
/*456*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),70) = (RECORD*) tos(), pop(),
/*456*/ 		push((char*) (
/*456*/ 			push((char*) alloc_RECORD(16, 1)),
/*456*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"use"),
/*456*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*456*/ 			*(int*) (tos()+12) = 2,
/*457*/ 			(RECORD*) pop()
/*457*/ 		)),
/*457*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),71) = (RECORD*) tos(), pop(),
/*457*/ 		push((char*) (
/*457*/ 			push((char*) alloc_RECORD(16, 1)),
/*457*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"var"),
/*457*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*457*/ 			*(int*) (tos()+12) = 97,
/*458*/ 			(RECORD*) pop()
/*458*/ 		)),
/*458*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),72) = (RECORD*) tos(), pop(),
/*458*/ 		push((char*) (
/*458*/ 			push((char*) alloc_RECORD(16, 1)),
/*458*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"while"),
/*458*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*458*/ 			*(int*) (tos()+12) = 24,
/*459*/ 			(RECORD*) pop()
/*459*/ 		)),
/*459*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),73) = (RECORD*) tos(), pop(),
/*459*/ 		push((char*) (
/*459*/ 			push((char*) alloc_RECORD(16, 1)),
/*459*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"xor"),
/*459*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*459*/ 			*(int*) (tos()+12) = 89,
/*461*/ 			(RECORD*) pop()
/*461*/ 		)),
/*461*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),74) = (RECORD*) tos(), pop(),
/*462*/ 		(ARRAY*) pop()
/*462*/ 	);
/*462*/ 	Scanner_phplint_keywords = (
/*463*/ 		push((char*) alloc_ARRAY(4, 1)),
/*463*/ 		push((char*) (
/*463*/ 			push((char*) alloc_RECORD(16, 1)),
/*463*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"abstract"),
/*463*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*463*/ 			*(int*) (tos()+12) = 168,
/*464*/ 			(RECORD*) pop()
/*464*/ 		)),
/*464*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*464*/ 		push((char*) (
/*464*/ 			push((char*) alloc_RECORD(16, 1)),
/*464*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"args"),
/*464*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*464*/ 			*(int*) (tos()+12) = 152,
/*465*/ 			(RECORD*) pop()
/*465*/ 		)),
/*465*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*465*/ 		push((char*) (
/*465*/ 			push((char*) alloc_RECORD(16, 1)),
/*465*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array"),
/*465*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*465*/ 			*(int*) (tos()+12) = 145,
/*466*/ 			(RECORD*) pop()
/*466*/ 		)),
/*466*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*466*/ 		push((char*) (
/*466*/ 			push((char*) alloc_RECORD(16, 1)),
/*466*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool"),
/*466*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*466*/ 			*(int*) (tos()+12) = 141,
/*467*/ 			(RECORD*) pop()
/*467*/ 		)),
/*467*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*467*/ 		push((char*) (
/*467*/ 			push((char*) alloc_RECORD(16, 1)),
/*467*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean"),
/*467*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*467*/ 			*(int*) (tos()+12) = 141,
/*468*/ 			(RECORD*) pop()
/*468*/ 		)),
/*468*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*468*/ 		push((char*) (
/*468*/ 			push((char*) alloc_RECORD(16, 1)),
/*468*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class"),
/*468*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*468*/ 			*(int*) (tos()+12) = 135,
/*469*/ 			(RECORD*) pop()
/*469*/ 		)),
/*469*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*469*/ 		push((char*) (
/*469*/ 			push((char*) alloc_RECORD(16, 1)),
/*469*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"const"),
/*469*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*469*/ 			*(int*) (tos()+12) = 138,
/*470*/ 			(RECORD*) pop()
/*470*/ 		)),
/*470*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*470*/ 		push((char*) (
/*470*/ 			push((char*) alloc_RECORD(16, 1)),
/*470*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double"),
/*470*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*470*/ 			*(int*) (tos()+12) = 143,
/*471*/ 			(RECORD*) pop()
/*471*/ 		)),
/*471*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*471*/ 		push((char*) (
/*471*/ 			push((char*) alloc_RECORD(16, 1)),
/*471*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"else"),
/*471*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*471*/ 			*(int*) (tos()+12) = 161,
/*472*/ 			(RECORD*) pop()
/*472*/ 		)),
/*472*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*472*/ 		push((char*) (
/*472*/ 			push((char*) alloc_RECORD(16, 1)),
/*472*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"end_if_php_ver"),
/*472*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*472*/ 			*(int*) (tos()+12) = 162,
/*473*/ 			(RECORD*) pop()
/*473*/ 		)),
/*473*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*473*/ 		push((char*) (
/*473*/ 			push((char*) alloc_RECORD(16, 1)),
/*473*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"extends"),
/*473*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*473*/ 			*(int*) (tos()+12) = 136,
/*474*/ 			(RECORD*) pop()
/*474*/ 		)),
/*474*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*474*/ 		push((char*) (
/*474*/ 			push((char*) alloc_RECORD(16, 1)),
/*474*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"final"),
/*474*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*474*/ 			*(int*) (tos()+12) = 170,
/*475*/ 			(RECORD*) pop()
/*475*/ 		)),
/*475*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*475*/ 		push((char*) (
/*475*/ 			push((char*) alloc_RECORD(16, 1)),
/*475*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float"),
/*475*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*475*/ 			*(int*) (tos()+12) = 143,
/*476*/ 			(RECORD*) pop()
/*476*/ 		)),
/*476*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*476*/ 		push((char*) (
/*476*/ 			push((char*) alloc_RECORD(16, 1)),
/*476*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"forward"),
/*476*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*476*/ 			*(int*) (tos()+12) = 133,
/*477*/ 			(RECORD*) pop()
/*477*/ 		)),
/*477*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),13) = (RECORD*) tos(), pop(),
/*477*/ 		push((char*) (
/*477*/ 			push((char*) alloc_RECORD(16, 1)),
/*477*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"function"),
/*477*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*477*/ 			*(int*) (tos()+12) = 134,
/*478*/ 			(RECORD*) pop()
/*478*/ 		)),
/*478*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),14) = (RECORD*) tos(), pop(),
/*478*/ 		push((char*) (
/*478*/ 			push((char*) alloc_RECORD(16, 1)),
/*478*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"if_php_ver_4"),
/*478*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*478*/ 			*(int*) (tos()+12) = 159,
/*479*/ 			(RECORD*) pop()
/*479*/ 		)),
/*479*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),15) = (RECORD*) tos(), pop(),
/*479*/ 		push((char*) (
/*479*/ 			push((char*) alloc_RECORD(16, 1)),
/*479*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"if_php_ver_5"),
/*479*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*479*/ 			*(int*) (tos()+12) = 160,
/*480*/ 			(RECORD*) pop()
/*480*/ 		)),
/*480*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),16) = (RECORD*) tos(), pop(),
/*480*/ 		push((char*) (
/*480*/ 			push((char*) alloc_RECORD(16, 1)),
/*480*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"implements"),
/*480*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*480*/ 			*(int*) (tos()+12) = 137,
/*481*/ 			(RECORD*) pop()
/*481*/ 		)),
/*481*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),17) = (RECORD*) tos(), pop(),
/*481*/ 		push((char*) (
/*481*/ 			push((char*) alloc_RECORD(16, 1)),
/*481*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*481*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*481*/ 			*(int*) (tos()+12) = 142,
/*482*/ 			(RECORD*) pop()
/*482*/ 		)),
/*482*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),18) = (RECORD*) tos(), pop(),
/*482*/ 		push((char*) (
/*482*/ 			push((char*) alloc_RECORD(16, 1)),
/*482*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer"),
/*482*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*482*/ 			*(int*) (tos()+12) = 142,
/*483*/ 			(RECORD*) pop()
/*483*/ 		)),
/*483*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),19) = (RECORD*) tos(), pop(),
/*483*/ 		push((char*) (
/*483*/ 			push((char*) alloc_RECORD(16, 1)),
/*483*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"interface"),
/*483*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*483*/ 			*(int*) (tos()+12) = 139,
/*484*/ 			(RECORD*) pop()
/*484*/ 		)),
/*484*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),20) = (RECORD*) tos(), pop(),
/*484*/ 		push((char*) (
/*484*/ 			push((char*) alloc_RECORD(16, 1)),
/*484*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"missing_break"),
/*484*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*484*/ 			*(int*) (tos()+12) = 163,
/*485*/ 			(RECORD*) pop()
/*485*/ 		)),
/*485*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),21) = (RECORD*) tos(), pop(),
/*485*/ 		push((char*) (
/*485*/ 			push((char*) alloc_RECORD(16, 1)),
/*485*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"missing_default"),
/*485*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*485*/ 			*(int*) (tos()+12) = 164,
/*486*/ 			(RECORD*) pop()
/*486*/ 		)),
/*486*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),22) = (RECORD*) tos(), pop(),
/*486*/ 		push((char*) (
/*486*/ 			push((char*) alloc_RECORD(16, 1)),
/*486*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed"),
/*486*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*486*/ 			*(int*) (tos()+12) = 146,
/*487*/ 			(RECORD*) pop()
/*487*/ 		)),
/*487*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),23) = (RECORD*) tos(), pop(),
/*487*/ 		push((char*) (
/*487*/ 			push((char*) alloc_RECORD(16, 1)),
/*487*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object"),
/*487*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*487*/ 			*(int*) (tos()+12) = 148,
/*488*/ 			(RECORD*) pop()
/*488*/ 		)),
/*488*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),24) = (RECORD*) tos(), pop(),
/*488*/ 		push((char*) (
/*488*/ 			push((char*) alloc_RECORD(16, 1)),
/*488*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"parent"),
/*488*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*488*/ 			*(int*) (tos()+12) = 172,
/*489*/ 			(RECORD*) pop()
/*489*/ 		)),
/*489*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),25) = (RECORD*) tos(), pop(),
/*489*/ 		push((char*) (
/*489*/ 			push((char*) alloc_RECORD(16, 1)),
/*489*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private"),
/*489*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*489*/ 			*(int*) (tos()+12) = 167,
/*490*/ 			(RECORD*) pop()
/*490*/ 		)),
/*490*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),26) = (RECORD*) tos(), pop(),
/*490*/ 		push((char*) (
/*490*/ 			push((char*) alloc_RECORD(16, 1)),
/*490*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected"),
/*490*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*490*/ 			*(int*) (tos()+12) = 166,
/*491*/ 			(RECORD*) pop()
/*491*/ 		)),
/*491*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),27) = (RECORD*) tos(), pop(),
/*491*/ 		push((char*) (
/*491*/ 			push((char*) alloc_RECORD(16, 1)),
/*491*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public"),
/*491*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*491*/ 			*(int*) (tos()+12) = 165,
/*492*/ 			(RECORD*) pop()
/*492*/ 		)),
/*492*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),28) = (RECORD*) tos(), pop(),
/*492*/ 		push((char*) (
/*492*/ 			push((char*) alloc_RECORD(16, 1)),
/*492*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"require_module"),
/*492*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*492*/ 			*(int*) (tos()+12) = 127,
/*493*/ 			(RECORD*) pop()
/*493*/ 		)),
/*493*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),29) = (RECORD*) tos(), pop(),
/*493*/ 		push((char*) (
/*493*/ 			push((char*) alloc_RECORD(16, 1)),
/*493*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource"),
/*493*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*493*/ 			*(int*) (tos()+12) = 147,
/*494*/ 			(RECORD*) pop()
/*494*/ 		)),
/*494*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),30) = (RECORD*) tos(), pop(),
/*494*/ 		push((char*) (
/*494*/ 			push((char*) alloc_RECORD(16, 1)),
/*494*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"self"),
/*494*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*494*/ 			*(int*) (tos()+12) = 171,
/*495*/ 			(RECORD*) pop()
/*495*/ 		)),
/*495*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),31) = (RECORD*) tos(), pop(),
/*495*/ 		push((char*) (
/*495*/ 			push((char*) alloc_RECORD(16, 1)),
/*495*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"static"),
/*495*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*495*/ 			*(int*) (tos()+12) = 169,
/*496*/ 			(RECORD*) pop()
/*496*/ 		)),
/*496*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),32) = (RECORD*) tos(), pop(),
/*496*/ 		push((char*) (
/*496*/ 			push((char*) alloc_RECORD(16, 1)),
/*496*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*496*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*496*/ 			*(int*) (tos()+12) = 144,
/*497*/ 			(RECORD*) pop()
/*497*/ 		)),
/*497*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),33) = (RECORD*) tos(), pop(),
/*497*/ 		push((char*) (
/*497*/ 			push((char*) alloc_RECORD(16, 1)),
/*497*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"throws"),
/*497*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*497*/ 			*(int*) (tos()+12) = 173,
/*498*/ 			(RECORD*) pop()
/*498*/ 		)),
/*498*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),34) = (RECORD*) tos(), pop(),
/*498*/ 		push((char*) (
/*498*/ 			push((char*) alloc_RECORD(16, 1)),
/*498*/ 			push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void"),
/*498*/ 			*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*498*/ 			*(int*) (tos()+12) = 140,
/*500*/ 			(RECORD*) pop()
/*500*/ 		)),
/*500*/ 		*(RECORD**) element_ARRAY((ARRAY*) tosn(1),35) = (RECORD*) tos(), pop(),
/*502*/ 		(ARRAY*) pop()
/*502*/ 	);
/*504*/ }


/*507*/ void
/*507*/ Scanner_FindOpenTag(void)
/*507*/ {

/*509*/ 	int
/*509*/ 	Scanner_is_space(STRING *Scanner_c)
/*509*/ 	{
/*509*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0));
/*513*/ 	}

/*515*/ 	do{
/*515*/ 		if( Scanner_c == NULL ){
/*516*/ 			Scanner_sym = 0;
/*518*/ 			return ;
/*518*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*519*/ 			Scanner_ReadCh();
/*520*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(63)) == 0 ){
/*523*/ 				goto m2runtime_loop_1;
/*524*/ 			}
/*524*/ 		} else {
/*524*/ 			Scanner_ReadCh();
/*527*/ 		}
/*527*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*527*/ 	Scanner_ReadCh();
/*528*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*529*/ 		Scanner_sym = 5;
/*530*/ 		Scanner_ReadCh();
/*531*/ 		Scanner_code = 1;
/*533*/ 		return ;
/*534*/ 	}
/*534*/ 	if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(112)) == 0) && (((Scanner_line_idx + 2) <= m2runtime_length(Scanner_line))) && (m2runtime_strcmp(m2runtime_substr(Scanner_line, Scanner_line_idx, (Scanner_line_idx + 2), 1, Scanner_0err_entry_get, 20), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"hp") == 0) && (((((Scanner_line_idx + 2) >= m2runtime_length(Scanner_line))) || Scanner_is_space(m2runtime_substr(Scanner_line, (Scanner_line_idx + 2), 0, 0, Scanner_0err_entry_get, 21))))) ){
/*538*/ 		Scanner_ReadCh();
/*539*/ 		Scanner_ReadCh();
/*540*/ 		Scanner_ReadCh();
/*542*/ 	}
/*542*/ 	Scanner_sym = 4;
/*543*/ 	Scanner_code = 1;
/*545*/ 	return ;
/*548*/ }


/*557*/ void
/*557*/ Scanner_SkipNewLineAfterCloseTag(void)
/*557*/ {
/*557*/ 	Scanner_ReadCh();
/*558*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*559*/ 		Scanner_ReadCh();
/*560*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0 ){
/*561*/ 		Scanner_ReadCh();
/*562*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*563*/ 			Scanner_ReadCh();
/*565*/ 		}
/*567*/ 	}
/*569*/ }


/*573*/ int
/*573*/ Scanner_SkipSingleLineComment(void)
/*573*/ {
/*575*/ 	STRING * Scanner_prev = NULL;
/*576*/ 	do{
/*576*/ 		Scanner_prev = Scanner_c;
/*577*/ 		Scanner_ReadCh();
/*578*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0 ){
/*579*/ 			Scanner_ReadCh();
/*580*/ 			return FALSE;
/*581*/ 		} else if( Scanner_c == NULL ){
/*582*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"premature end of the file or missing closing tag");
/*583*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0) && (m2runtime_strcmp(Scanner_prev, m2runtime_CHR(63)) == 0)) ){
/*584*/ 			Scanner_SkipNewLineAfterCloseTag();
/*585*/ 			return TRUE;
/*588*/ 		}
/*589*/ 	}while(TRUE);
/*589*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 22);
/*589*/ 	return 0;
/*591*/ }


/*597*/ int
/*597*/ Scanner_SkipSpaces(void)
/*597*/ {
/*597*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(35)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0)) ){
/*599*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(35)) == 0 ){
/*600*/ 			if( Scanner_SkipSingleLineComment() ){
/*601*/ 				return TRUE;
/*604*/ 			}
/*604*/ 		} else {
/*604*/ 			Scanner_ReadCh();
/*607*/ 		}
/*607*/ 	}
/*607*/ 	return FALSE;
/*611*/ }


/*617*/ void
/*617*/ Scanner_SkipMultilineComment(void)
/*617*/ {
/*618*/ 	int Scanner_start_line_n = 0;
/*620*/ 	STRING * Scanner_c2 = NULL;
/*620*/ 	STRING * Scanner_c1 = NULL;
/*620*/ 	if( Globals_DEBUG ){
/*621*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"[comment start]");
/*623*/ 	}
/*623*/ 	buffer_Set((void *)&Scanner_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"/*");
/*624*/ 	Scanner_start_line_n = Scanner_line_n;
/*626*/ 	do{
/*626*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*627*/ 		if( Scanner_c == NULL ){
/*628*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"missing closing '*/' in comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*630*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0) && (m2runtime_strcmp(Scanner_c1, m2runtime_CHR(47)) == 0)) ){
/*631*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"possible nested multiline comment in comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*632*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0) && (m2runtime_strcmp(Scanner_c1, m2runtime_CHR(42)) == 0)) ){
/*633*/ 			if( m2runtime_strcmp(Scanner_c2, m2runtime_CHR(46)) == 0 ){
/*634*/ 				Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"possible missing `.' in multiline comment beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*636*/ 			}
/*636*/ 			if( Globals_DEBUG ){
/*637*/ 				m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"[comment end]");
/*639*/ 			}
/*639*/ 			Scanner_ReadCh();
/*640*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*642*/ 			return ;
/*643*/ 		}
/*643*/ 		Scanner_c2 = Scanner_c1;
/*644*/ 		Scanner_c1 = Scanner_c;
/*645*/ 		Scanner_ReadCh();
/*648*/ 	}while(TRUE);
/*650*/ }


/*652*/ STRING *
/*652*/ Scanner_ReportChar(int Scanner_ch)
/*652*/ {
/*652*/ 	if( (((Scanner_ch >= 32)) && ((Scanner_ch <= 126))) ){
/*653*/ 		return m2runtime_concat_STRING(0, m2runtime_CHR(96), m2runtime_CHR(Scanner_ch), m2runtime_CHR(39), 1);
/*654*/ 	} else if( (Scanner_ch == 9) ){
/*655*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"horizontal tabulator, HT, 9";
/*656*/ 	} else if( (Scanner_ch == 10) ){
/*657*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"line feed, LF, 10";
/*658*/ 	} else if( (Scanner_ch == 13) ){
/*659*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"carriage return, CR, 13";
/*660*/ 	} else if( (Scanner_ch == 127) ){
/*661*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"delete, DEL, 127";
/*662*/ 	} else if( (Scanner_ch > 127) ){
/*663*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"code ", m2runtime_itos(Scanner_ch), 1);
/*665*/ 	} else {
/*665*/ 		return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"control code ", m2runtime_itos(Scanner_ch), 1);
/*668*/ 	}
/*668*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 23);
/*668*/ 	return NULL;
/*670*/ }


/*672*/ void
/*672*/ Scanner_ReportCTRL(int Scanner_ch)
/*672*/ {
/*672*/ 	if( !Scanner_ctrl_check ){
/*674*/ 		return ;
/*675*/ 	}
/*675*/ 	Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"found control character (", Scanner_ReportChar(Scanner_ch), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\103,\0,\0,\0)") in literal string. This msg is reported only once for each string", 1));
/*680*/ }


/*682*/ void
/*682*/ Scanner_ReportASCIIExt(int Scanner_ch, STRING *Scanner_in)
/*682*/ {
/*682*/ 	if( !Scanner_ascii_ext_check ){
/*684*/ 		return ;
/*685*/ 	}
/*685*/ 	Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"non-ASCII character code in ", Scanner_in, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" (", Scanner_ReportChar(Scanner_ch), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\53,\0,\0,\0)"). This msg is reported only once for each ", Scanner_in, 1));
/*690*/ }


/*696*/ int
/*696*/ Scanner_is_id_first_char(STRING *Scanner_c)
/*696*/ {
/*697*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0 ){
/*698*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(122)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(128)) >= 0));
/*699*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0 ){
/*700*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(95)) == 0));
/*702*/ 	} else {
/*702*/ 		return FALSE;
/*709*/ 	}
/*709*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 24);
/*709*/ 	return 0;
/*711*/ }


/*713*/ int
/*713*/ Scanner_is_id_char(STRING *Scanner_c)
/*713*/ {
/*713*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0 ){
/*714*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(122)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(127)) >= 0));
/*715*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0 ){
/*716*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(95)) == 0));
/*718*/ 	} else {
/*718*/ 		return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0));
/*726*/ 	}
/*726*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 25);
/*726*/ 	return 0;
/*728*/ }


/*730*/ int
/*730*/ Scanner_is_digit(STRING *Scanner_c)
/*730*/ {
/*730*/ 	return ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0));
/*734*/ }


/*736*/ int
/*736*/ Scanner_is_hex(STRING *Scanner_c)
/*736*/ {
/*736*/ 	return (((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0)) || ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(65)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(70)) <= 0)) || ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(97)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(102)) <= 0)));
/*742*/ }


/*744*/ int
/*744*/ Scanner_hex(STRING *Scanner_c)
/*744*/ {
/*744*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(57)) <= 0 ){
/*745*/ 		return (m2runtime_ASC(Scanner_c) - m2runtime_ASC(m2runtime_CHR(48)));
/*746*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(90)) <= 0 ){
/*747*/ 		return ((10 + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(65)));
/*749*/ 	} else {
/*749*/ 		return ((10 + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(97)));
/*752*/ 	}
/*752*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 26);
/*752*/ 	return 0;
/*755*/ }

/*756*/ STRING * Scanner_here_doc_id = NULL;
/*757*/ STRING * Scanner_end4 = NULL;
/*757*/ STRING * Scanner_end3 = NULL;
/*757*/ STRING * Scanner_end2 = NULL;
/*757*/ STRING * Scanner_end1 = NULL;
/*760*/ int Scanner_start_line_n = 0;

/*775*/ int
/*775*/ Scanner_ParseDoubleQuotedString(void)
/*775*/ {

/*776*/ 	STRING *
/*776*/ 	Scanner_ParseEscapeCode(void)
/*776*/ 	{
/*778*/ 		int Scanner_x = 0;
/*778*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(110)) == 0 ){
/*779*/ 			Scanner_ReadCh();
/*780*/ 			return m2runtime_CHR(10);
/*781*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(114)) == 0 ){
/*782*/ 			Scanner_ReadCh();
/*783*/ 			return m2runtime_CHR(13);
/*784*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(116)) == 0 ){
/*785*/ 			Scanner_ReadCh();
/*786*/ 			return m2runtime_CHR(9);
/*787*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*788*/ 			Scanner_ReadCh();
/*789*/ 			return m2runtime_CHR(92);
/*790*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*791*/ 			Scanner_ReadCh();
/*792*/ 			return m2runtime_CHR(36);
/*793*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0 ){
/*794*/ 			Scanner_ReadCh();
/*795*/ 			return m2runtime_CHR(34);
/*796*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*797*/ 			Scanner_x = (m2runtime_ASC(Scanner_c) - m2runtime_ASC(m2runtime_CHR(48)));
/*798*/ 			Scanner_ReadCh();
/*799*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*800*/ 				Scanner_x = (((8 * Scanner_x) + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(48)));
/*801*/ 				Scanner_ReadCh();
/*802*/ 				if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*803*/ 					Scanner_x = (((8 * Scanner_x) + m2runtime_ASC(Scanner_c)) - m2runtime_ASC(m2runtime_CHR(48)));
/*804*/ 					Scanner_ReadCh();
/*807*/ 				}
/*807*/ 			}
/*807*/ 			if( (Scanner_x > 255) ){
/*808*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"invalid octal code in escape sequence: too big");
/*809*/ 				return NULL;
/*811*/ 			}
/*811*/ 			return m2runtime_CHR(Scanner_x);
/*812*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(120)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(88)) == 0)) ){
/*813*/ 			Scanner_ReadCh();
/*814*/ 			if( !Scanner_is_hex(Scanner_c) ){
/*815*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"invalid hexadecimal digit in escape sequence");
/*816*/ 				return NULL;
/*818*/ 			}
/*818*/ 			Scanner_x = Scanner_hex(Scanner_c);
/*819*/ 			Scanner_ReadCh();
/*820*/ 			if( Scanner_is_hex(Scanner_c) ){
/*821*/ 				Scanner_x = ((16 * Scanner_x) + Scanner_hex(Scanner_c));
/*822*/ 				Scanner_ReadCh();
/*824*/ 			}
/*824*/ 			return m2runtime_CHR(Scanner_x);
/*826*/ 		} else {
/*826*/ 			Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid escape sequence");
/*827*/ 			return m2runtime_concat_STRING(0, m2runtime_CHR(92), Scanner_c, 1);
/*830*/ 		}
/*830*/ 		m2runtime_missing_return(Scanner_0err_entry_get, 27);
/*830*/ 		return NULL;
/*833*/ 	}

/*834*/ 	int Scanner_i = 0;
/*834*/ 	int Scanner_ch = 0;
/*836*/ 	int Scanner_report_ascii_ext = 0;
/*836*/ 	int Scanner_report_ctrl = 0;
/*836*/ 	buffer_Empty((void *)&Scanner_b);
/*837*/ 	Scanner_report_ctrl = Scanner_ctrl_check;
/*838*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*840*/ 	do{
/*840*/ 		if( Scanner_c == NULL ){
/*841*/ 			if( Scanner_here_doc_id == NULL ){
/*842*/ 				Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)"missing terminating \042 character in literal string");
/*844*/ 			} else {
/*844*/ 				Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"here-doc `<<< ", Scanner_here_doc_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"' not closed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)" beginning in line ", m2runtime_itos(Scanner_start_line_n), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)". Expected a line containing exactly `", Scanner_here_doc_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"' possibly followed by `;' then a new-line, no spaces allowed.", 1));
/*850*/ 			}
/*851*/ 		}
/*851*/ 		Scanner_ch = m2runtime_ASC(Scanner_c);
/*854*/ 		if( Scanner_here_doc_id == NULL ){
/*856*/ 			if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127))))) ){
/*857*/ 				Scanner_ReportCTRL(Scanner_ch);
/*858*/ 				Scanner_report_ctrl = FALSE;
/*861*/ 			}
/*862*/ 		} else {
/*862*/ 			if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127)))) && ((Scanner_ch != 10)) && ((Scanner_ch != 13)) && ((Scanner_ch != 9))) ){
/*864*/ 				Scanner_ReportCTRL(Scanner_ch);
/*865*/ 				Scanner_report_ctrl = FALSE;
/*868*/ 			}
/*870*/ 		}
/*870*/ 		if( (Scanner_report_ascii_ext && ((Scanner_ch > 127))) ){
/*871*/ 			Scanner_ReportASCIIExt(Scanner_ch, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"literal string");
/*872*/ 			Scanner_report_ascii_ext = FALSE;
/*878*/ 		}
/*878*/ 		if( ((Scanner_here_doc_id == NULL) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0)) ){
/*881*/ 			Scanner_ReadCh();
/*883*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*884*/ 			if( (Scanner_code == 4) ){
/*885*/ 				Scanner_code = 1;
/*886*/ 				if( m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0 ){
/*890*/ 					return TRUE;
/*893*/ 				} else {
/*893*/ 					Scanner_sym = 36;
/*894*/ 					return FALSE;
/*897*/ 				}
/*897*/ 			} else {
/*897*/ 				Scanner_code = 1;
/*898*/ 				Scanner_sym = 34;
/*899*/ 				return FALSE;
/*905*/ 			}
/*905*/ 		} else if( ((Scanner_here_doc_id != NULL) && ((Scanner_line_idx == 1)) && (((m2runtime_strcmp(Scanner_line, Scanner_end1) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end2) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end3) == 0) || (m2runtime_strcmp(Scanner_line, Scanner_end4) == 0)))) ){
/*910*/ 			{
/*910*/ 				int m2runtime_for_limit_1;
/*910*/ 				Scanner_i = 1;
/*910*/ 				m2runtime_for_limit_1 = m2runtime_length(Scanner_here_doc_id);
/*911*/ 				for( ; Scanner_i <= m2runtime_for_limit_1; Scanner_i += 1 ){
/*911*/ 					Scanner_ReadCh();
/*914*/ 				}
/*914*/ 			}
/*914*/ 			Scanner_here_doc_id = NULL;
/*916*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*917*/ 			if( (Scanner_code == 4) ){
/*918*/ 				Scanner_code = 1;
/*919*/ 				if( m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0 ){
/*923*/ 					return TRUE;
/*926*/ 				} else {
/*926*/ 					Scanner_sym = 36;
/*927*/ 					return FALSE;
/*930*/ 				}
/*930*/ 			} else {
/*930*/ 				Scanner_code = 1;
/*931*/ 				Scanner_sym = 37;
/*932*/ 				return FALSE;
/*935*/ 			}
/*935*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*936*/ 			Scanner_ReadCh();
/*937*/ 			buffer_AddString((void *)&Scanner_b, Scanner_ParseEscapeCode());
/*938*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*939*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*940*/ 			Scanner_ReadCh();
/*941*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*942*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" curly braces notation not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*945*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*946*/ 				Scanner_ReadCh();
/*948*/ 			}
/*948*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*949*/ 			Scanner_ReadCh();
/*950*/ 			if( Scanner_is_id_first_char(Scanner_c) ){
/*956*/ 				Scanner_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"DUMMY_CONTINUATION_DOUBLE_QUOTED_STRING";
/*957*/ 				if( (Scanner_code == 1) ){
/*963*/ 					Scanner_code = 3;
/*964*/ 					if( Scanner_here_doc_id == NULL ){
/*965*/ 						Scanner_sym = 34;
/*967*/ 					} else {
/*967*/ 						Scanner_sym = 37;
/*969*/ 					}
/*969*/ 					return FALSE;
/*976*/ 				} else {
/*976*/ 					Scanner_code = 3;
/*977*/ 					Scanner_sym = 36;
/*978*/ 					return m2runtime_strcmp(Scanner_s, EMPTY_STRING) <= 0;
/*981*/ 				}
/*981*/ 			} else {
/*981*/ 				if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*983*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" array selector not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*986*/ 				} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*988*/ 					Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"embedded variable in string:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)" curly braces notation not allowed", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)" (PHPLint limitation)", 1));
/*992*/ 				}
/*992*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(36));
/*995*/ 			}
/*995*/ 		} else {
/*995*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*996*/ 			Scanner_ReadCh();
/*999*/ 		}
/*1000*/ 	}while(TRUE);
/*1000*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 28);
/*1000*/ 	return 0;
/*1002*/ }


/*1003*/ int
/*1003*/ Scanner_ParseHereDoc(void)
/*1003*/ {
/*1005*/ 	STRING * Scanner_id = NULL;
/*1008*/ 	Scanner_start_line_n = Scanner_line_n;
/*1010*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1011*/ 		Scanner_ReadCh();
/*1015*/ 	}
/*1015*/ 	if( !Scanner_is_id_first_char(Scanner_c) ){
/*1016*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"expected identifier after `<<<'");
/*1018*/ 	}
/*1018*/ 	buffer_Set((void *)&Scanner_b, Scanner_c);
/*1019*/ 	Scanner_ReadCh();
/*1020*/ 	while( Scanner_is_id_char(Scanner_c) ){
/*1021*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1022*/ 		Scanner_ReadCh();
/*1024*/ 	}
/*1024*/ 	Scanner_id = buffer_ToString(Scanner_b);
/*1026*/ 	if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1027*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"spaces not allowed after `<<<", Scanner_id, m2runtime_CHR(39), 1));
/*1029*/ 	}
/*1029*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(13)) == 0)) ){
/*1030*/ 		Scanner_ReadCh();
/*1033*/ 	}
/*1033*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(10)) != 0 ){
/*1034*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\72,\0,\0,\0)"expected end of the line (ASCII code LF) after here-doc ID");
/*1036*/ 	}
/*1036*/ 	Scanner_ReadCh();
/*1038*/ 	Scanner_here_doc_id = Scanner_id;
/*1039*/ 	Scanner_end1 = Scanner_id;
/*1040*/ 	Scanner_end2 = m2runtime_concat_STRING(0, Scanner_id, m2runtime_CHR(13), 1);
/*1041*/ 	Scanner_end3 = m2runtime_concat_STRING(0, Scanner_id, m2runtime_CHR(59), 1);
/*1042*/ 	Scanner_end4 = m2runtime_concat_STRING(0, Scanner_id, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)";\015", 1);
/*1044*/ 	return Scanner_ParseDoubleQuotedString();
/*1048*/ }


/*1050*/ STRING *
/*1050*/ Scanner_ParseSingleQuotedString(void)
/*1050*/ {
/*1051*/ 	int Scanner_ch = 0;
/*1051*/ 	int Scanner_start_line_n = 0;
/*1052*/ 	int Scanner_skip = 0;
/*1054*/ 	int Scanner_report_ascii_ext = 0;
/*1054*/ 	int Scanner_report_ctrl = 0;
/*1054*/ 	buffer_Empty((void *)&Scanner_b);
/*1055*/ 	Scanner_skip = FALSE;
/*1056*/ 	Scanner_report_ctrl = Scanner_ctrl_check;
/*1057*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*1058*/ 	Scanner_start_line_n = Scanner_line_n;
/*1059*/ 	Scanner_ReadCh();
/*1061*/ 	do{
/*1061*/ 		if( Scanner_c == NULL ){
/*1062*/ 			Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)"missing terminating ' character in string beginning in line ", m2runtime_itos(Scanner_start_line_n), 1));
/*1064*/ 		}
/*1064*/ 		Scanner_ch = m2runtime_ASC(Scanner_c);
/*1065*/ 		if( (Scanner_report_ctrl && ((((Scanner_ch < 32)) || ((Scanner_ch == 127))))) ){
/*1066*/ 			Scanner_ReportCTRL(Scanner_ch);
/*1067*/ 			Scanner_report_ctrl = FALSE;
/*1069*/ 		}
/*1069*/ 		if( (Scanner_report_ascii_ext && ((Scanner_ch > 127))) ){
/*1070*/ 			Scanner_ReportASCIIExt(Scanner_ch, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"literal string");
/*1071*/ 			Scanner_report_ascii_ext = FALSE;
/*1073*/ 		}
/*1073*/ 		if( Scanner_skip ){
/*1074*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0)) ){
/*1075*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1077*/ 			} else {
/*1077*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(92));
/*1078*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1079*/ 				Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid escape sequence");
/*1081*/ 			}
/*1081*/ 			Scanner_skip = FALSE;
/*1082*/ 			Scanner_ReadCh();
/*1083*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1084*/ 			Scanner_ReadCh();
/*1085*/ 			return buffer_ToString(Scanner_b);
/*1086*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(92)) == 0 ){
/*1087*/ 			Scanner_skip = TRUE;
/*1088*/ 			Scanner_ReadCh();
/*1090*/ 		} else {
/*1090*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1091*/ 			Scanner_ReadCh();
/*1094*/ 		}
/*1095*/ 	}while(TRUE);
/*1095*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 29);
/*1095*/ 	return NULL;
/*1097*/ }


/*1105*/ void
/*1105*/ Scanner_ParseKeyword(void)
/*1105*/ {
/*1105*/ 	int Scanner_report_ascii_ext = 0;
/*1107*/ 	STRING * Scanner_low = NULL;
/*1107*/ 	buffer_Empty((void *)&Scanner_b);
/*1108*/ 	Scanner_report_ascii_ext = Scanner_ascii_ext_check;
/*1110*/ 	do{
/*1110*/ 		if( (Scanner_report_ascii_ext && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(127)) >= 0)) ){
/*1111*/ 			Scanner_ReportASCIIExt(m2runtime_ASC(Scanner_c), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"identifier");
/*1112*/ 			Scanner_report_ascii_ext = FALSE;
/*1114*/ 		}
/*1114*/ 		buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1115*/ 		Scanner_ReadCh();
/*1116*/ 		if( !Scanner_is_id_char(Scanner_c) ){
/*1117*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*1120*/ 			goto m2runtime_loop_1;
/*1121*/ 		}
/*1124*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1124*/ 	if( (Scanner_code == 2) ){
/*1125*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_phplint_keywords);
/*1126*/ 		if( (Scanner_sym != 1) ){
/*1128*/ 			return ;
/*1129*/ 		}
/*1129*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_php_keywords);
/*1130*/ 		if( (Scanner_sym != 1) ){
/*1131*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"invalid keyword `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"' inside PHPLint meta-code", 1));
/*1132*/ 			Scanner_sym = 1;
/*1134*/ 			return ;
/*1136*/ 		}
/*1136*/ 	} else {
/*1136*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_php_keywords);
/*1137*/ 		if( (Scanner_sym != 1) ){
/*1139*/ 			return ;
/*1140*/ 		}
/*1140*/ 		Scanner_sym = Scanner_SearchKeyword(Scanner_s, Scanner_phplint_keywords);
/*1141*/ 		if( (Scanner_sym != 1) ){
/*1142*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"invalid PHPLint keyword `", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' inside PHP code", 1));
/*1143*/ 			Scanner_sym = 1;
/*1145*/ 			return ;
/*1147*/ 		}
/*1149*/ 	}
/*1149*/ 	Scanner_low = str_tolower(Scanner_s);
/*1150*/ 	Scanner_sym = Scanner_SearchKeyword(Scanner_low, Scanner_php_keywords);
/*1151*/ 	if( (Scanner_sym != 1) ){
/*1152*/ 		Scanner_Warning(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"': invalid identifier similar to the keyword `", Scanner_low, m2runtime_CHR(39), 1));
/*1156*/ 		return ;
/*1159*/ 	}
/*1159*/ 	Scanner_sym = Scanner_SearchKeyword(Scanner_low, Scanner_phplint_keywords);
/*1160*/ 	if( (Scanner_sym != 1) ){
/*1161*/ 		Scanner_Error(m2runtime_concat_STRING(0, m2runtime_CHR(96), Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"': invalid identifier similar to the PHPLint keyword `", Scanner_low, m2runtime_CHR(39), 1));
/*1162*/ 		Scanner_sym = 1;
/*1164*/ 		return ;
/*1167*/ 	}
/*1169*/ }


/*1171*/ int
/*1171*/ Scanner_ParseNumber(void)
/*1171*/ {

/*1174*/ 	void
/*1174*/ 	Scanner_ParseFloat(void)
/*1174*/ 	{
/*1174*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1175*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1176*/ 			Scanner_ReadCh();
/*1177*/ 			if( !Scanner_is_digit(Scanner_c) ){
/*1178*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"literal float number: required digit after decimal point");
/*1180*/ 				return ;
/*1182*/ 			}
/*1182*/ 			do {
/*1182*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1183*/ 				Scanner_ReadCh();
/*1184*/ 			} while( !( !Scanner_is_digit(Scanner_c) ));
/*1186*/ 		}
/*1186*/ 		if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(69)) == 0)) ){
/*1187*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1188*/ 			Scanner_ReadCh();
/*1189*/ 			if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0)) ){
/*1190*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1191*/ 				Scanner_ReadCh();
/*1193*/ 			}
/*1193*/ 			if( !Scanner_is_digit(Scanner_c) ){
/*1194*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"literal float number: required digit in exponent");
/*1197*/ 			}
/*1197*/ 			do {
/*1197*/ 				buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1198*/ 				Scanner_ReadCh();
/*1199*/ 			} while( !( !Scanner_is_digit(Scanner_c) ));
/*1201*/ 		}
/*1201*/ 		Scanner_s = buffer_ToString(Scanner_b);
/*1204*/ 	}

/*1206*/ 	int Scanner_n = 0;
/*1210*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) == 0 ){
/*1211*/ 		Scanner_ReadCh();
/*1212*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(120)) == 0 ){
/*1214*/ 			Scanner_ReadCh();
/*1215*/ 			if( !Scanner_is_hex(Scanner_c) ){
/*1216*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"invalid hexadecimal number");
/*1219*/ 			} else {
/*1219*/ 				do {
/*1219*/ 					Scanner_n = (((unsigned int) Scanner_n << 4) + Scanner_hex(Scanner_c));
/*1220*/ 					Scanner_ReadCh();
/*1221*/ 				} while( !( !Scanner_is_hex(Scanner_c) ));
/*1223*/ 			}
/*1223*/ 			Scanner_s = m2runtime_itos(Scanner_n);
/*1224*/ 			return 38;
/*1225*/ 		} else if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0)) ){
/*1228*/ 			do {
/*1228*/ 				Scanner_n = ((8 * Scanner_n) + m2_stoi(Scanner_c));
/*1229*/ 				Scanner_ReadCh();
/*1230*/ 			} while( !( !(((m2runtime_strcmp(Scanner_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(Scanner_c, m2runtime_CHR(55)) <= 0))) ));
/*1231*/ 			if( Scanner_is_digit(Scanner_c) ){
/*1232*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"invalid digit `", Scanner_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' in octal number", 1));
/*1233*/ 				Scanner_ReadCh();
/*1235*/ 			}
/*1235*/ 			Scanner_s = m2runtime_itos(Scanner_n);
/*1236*/ 			return 38;
/*1237*/ 		} else if( Scanner_is_digit(Scanner_c) ){
/*1238*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"invalid digit `", Scanner_c, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"' in octal number", 1));
/*1239*/ 			Scanner_ReadCh();
/*1240*/ 			Scanner_s = m2runtime_CHR(48);
/*1241*/ 			return 38;
/*1242*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1244*/ 			buffer_Empty((void *)&Scanner_b);
/*1245*/ 			buffer_AddString((void *)&Scanner_b, m2runtime_CHR(48));
/*1246*/ 			Scanner_ParseFloat();
/*1247*/ 			return 39;
/*1250*/ 		} else {
/*1250*/ 			Scanner_s = m2runtime_CHR(48);
/*1251*/ 			return 38;
/*1254*/ 		}
/*1254*/ 	} else {
/*1254*/ 		buffer_Empty((void *)&Scanner_b);
/*1256*/ 		do {
/*1256*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1257*/ 			Scanner_ReadCh();
/*1258*/ 		} while( !( !Scanner_is_digit(Scanner_c) ));
/*1259*/ 		if( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(101)) == 0)) ){
/*1260*/ 			Scanner_ParseFloat();
/*1261*/ 			return 39;
/*1263*/ 		} else {
/*1263*/ 			Scanner_s = buffer_ToString(Scanner_b);
/*1264*/ 			return 38;
/*1267*/ 		}
/*1268*/ 	}
/*1268*/ 	m2runtime_missing_return(Scanner_0err_entry_get, 30);
/*1268*/ 	return 0;
/*1270*/ }


/*1271*/ void
/*1271*/ Scanner_ParseDoc(void)
/*1271*/ {
/*1273*/ 	int Scanner_line_start = 0;
/*1273*/ 	Scanner_line_start = Scanner_line_n;
/*1274*/ 	while( ((m2runtime_strcmp(Scanner_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(9)) == 0)) ){
/*1275*/ 		Scanner_ReadCh();
/*1277*/ 	}
/*1277*/ 	buffer_Empty((void *)&Scanner_b);
/*1279*/ 	do{
/*1279*/ 		if( Scanner_c == NULL ){
/*1280*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"unclosed DOC comment openend in line ", m2runtime_itos(Scanner_line_start), 1));
/*1283*/ 			goto m2runtime_loop_1;
/*1283*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1284*/ 			Scanner_ReadCh();
/*1285*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1286*/ 				Scanner_ReadCh();
/*1287*/ 				if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1288*/ 					Scanner_ReadCh();
/*1291*/ 					goto m2runtime_loop_1;
/*1291*/ 				} else {
/*1291*/ 					buffer_AddString((void *)&Scanner_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)".*");
/*1294*/ 				}
/*1294*/ 			} else {
/*1294*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(46));
/*1296*/ 			}
/*1296*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1297*/ 			Scanner_ReadCh();
/*1298*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1299*/ 				Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"missing `.' in closing `.*/'");
/*1300*/ 				Scanner_ReadCh();
/*1303*/ 				goto m2runtime_loop_1;
/*1303*/ 			} else {
/*1303*/ 				buffer_AddString((void *)&Scanner_b, m2runtime_CHR(42));
/*1306*/ 			}
/*1306*/ 		} else {
/*1306*/ 			buffer_AddString((void *)&Scanner_b, Scanner_c);
/*1307*/ 			Scanner_ReadCh();
/*1310*/ 		}
/*1310*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1310*/ 	Scanner_s = buffer_ToString(Scanner_b);
/*1314*/ }


/*1316*/ void
/*1316*/ Scanner_ParseVarName(void)
/*1316*/ {
/*1316*/ 	Scanner_ReadCh();
/*1317*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1318*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\110,\0,\0,\0)"unsupported variable-variable feature $$var -- trying to continue anyway");
/*1320*/ 		do {
/*1320*/ 			Scanner_ReadCh();
/*1321*/ 		} while( !( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) != 0 ));
/*1323*/ 	}
/*1323*/ 	if( !Scanner_is_id_first_char(Scanner_c) ){
/*1324*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"missing variable name after `$'");
/*1326*/ 	}
/*1326*/ 	Scanner_ParseKeyword();
/*1327*/ 	if( (Scanner_sym != 1) ){
/*1328*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the name `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"' is a keyword.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)" This is deprecated by PHP and forbidden by PHPLint.", 1));
/*1332*/ 	}
/*1334*/ }


/*1343*/ int
/*1343*/ Scanner_ParseXCode(void)
/*1343*/ {
/*1343*/ 	if( Scanner_SkipSpaces() ){
/*1344*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"unexpected closing tag inside meta-code");
/*1347*/ 	}
/*1347*/ 	if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(40)) == 0 ){
/*1348*/ 		Scanner_sym = 153;
/*1349*/ 		Scanner_ReadCh();
/*1350*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(41)) == 0 ){
/*1351*/ 		Scanner_sym = 154;
/*1352*/ 		Scanner_ReadCh();
/*1353*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*1354*/ 		Scanner_sym = 155;
/*1355*/ 		Scanner_ReadCh();
/*1356*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(93)) == 0 ){
/*1357*/ 		Scanner_sym = 156;
/*1358*/ 		Scanner_ReadCh();
/*1359*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*1360*/ 		Scanner_sym = 157;
/*1361*/ 		Scanner_ReadCh();
/*1362*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(125)) == 0 ){
/*1363*/ 		Scanner_sym = 158;
/*1364*/ 		Scanner_ReadCh();
/*1365*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1366*/ 		Scanner_sym = 151;
/*1367*/ 		Scanner_ReadCh();
/*1368*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1369*/ 		Scanner_sym = 132;
/*1370*/ 		Scanner_ReadCh();
/*1371*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1372*/ 		Scanner_ParseVarName();
/*1373*/ 		Scanner_sym = 150;
/*1374*/ 	} else if( Scanner_is_id_first_char(Scanner_c) ){
/*1375*/ 		Scanner_ParseKeyword();
/*1376*/ 		if( (Scanner_sym == 1) ){
/*1377*/ 			if( m2runtime_strcmp(Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"DOC") == 0 ){
/*1378*/ 				Scanner_ParseDoc();
/*1379*/ 				Scanner_code = 1;
/*1380*/ 				Scanner_sym = 174;
/*1382*/ 			} else {
/*1382*/ 				Scanner_sym = 149;
/*1385*/ 			}
/*1385*/ 		}
/*1385*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1386*/ 		Scanner_ReadCh();
/*1387*/ 		if( ((Scanner_c == NULL) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) != 0)) ){
/*1388*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid syntax in extended code");
/*1389*/ 			return TRUE;
/*1391*/ 		}
/*1391*/ 		Scanner_ReadCh();
/*1392*/ 		if( ((Scanner_c == NULL) || (m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) != 0)) ){
/*1393*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"invalid syntax in extended code");
/*1394*/ 			return TRUE;
/*1396*/ 		}
/*1396*/ 		Scanner_ReadCh();
/*1397*/ 		Scanner_code = 1;
/*1398*/ 		return TRUE;
/*1399*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(44)) == 0 ){
/*1400*/ 		Scanner_ReadCh();
/*1401*/ 		Scanner_sym = 131;
/*1402*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1403*/ 		Scanner_s = Scanner_ParseSingleQuotedString();
/*1404*/ 		Scanner_sym = 128;
/*1405*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(59)) == 0 ){
/*1406*/ 		Scanner_ReadCh();
/*1407*/ 		Scanner_sym = 129;
/*1408*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1409*/ 		Scanner_ReadCh();
/*1410*/ 		Scanner_sym = 130;
/*1411*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1412*/ 		Scanner_ReadCh();
/*1413*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1414*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\50,\0,\0,\0)"expected `.*/', found `*/' (missing `.')");
/*1415*/ 			Scanner_ReadCh();
/*1416*/ 			Scanner_code = 1;
/*1417*/ 			return TRUE;
/*1419*/ 		} else {
/*1419*/ 			Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"unexpected char `*' in extended code");
/*1422*/ 		}
/*1422*/ 	} else {
/*1422*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"unexpected char ", Scanner_ReportChar(m2runtime_ASC(Scanner_c)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)" in extended code - ignore", 1));
/*1423*/ 		Scanner_ReadCh();
/*1425*/ 	}
/*1425*/ 	return FALSE;
/*1429*/ }


/*1436*/ int
/*1436*/ Scanner_ParseCode(void)
/*1436*/ {
/*1436*/ 	if( Scanner_SkipSpaces() ){
/*1438*/ 		Scanner_code = 0;
/*1439*/ 		Scanner_sym = 6;
/*1440*/ 		return FALSE;
/*1443*/ 	}
/*1443*/ 	if( Scanner_is_id_first_char(Scanner_c) ){
/*1444*/ 		Scanner_ParseKeyword();
/*1445*/ 		if( (Scanner_sym == 1) ){
/*1446*/ 			Scanner_sym = 29;
/*1449*/ 		}
/*1449*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(36)) == 0 ){
/*1450*/ 		Scanner_ParseVarName();
/*1451*/ 		Scanner_sym = 20;
/*1453*/ 	} else if( Scanner_is_digit(Scanner_c) ){
/*1454*/ 		Scanner_sym = Scanner_ParseNumber();
/*1456*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(34)) == 0 ){
/*1457*/ 		Scanner_ReadCh();
/*1458*/ 		return Scanner_ParseDoubleQuotedString();
/*1460*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(39)) == 0 ){
/*1461*/ 		Scanner_s = Scanner_ParseSingleQuotedString();
/*1462*/ 		Scanner_sym = 33;
/*1464*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(96)) == 0 ){
/*1465*/ 		Scanner_Fatal((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"unimplemented execution operator \042`\042. Use shell_exec() instead.");
/*1466*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(64)) == 0 ){
/*1466*/ 		Scanner_sym = 59;
/*1466*/ 		Scanner_ReadCh();
/*1467*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(123)) == 0 ){
/*1467*/ 		Scanner_sym = 10;
/*1467*/ 		Scanner_ReadCh();
/*1468*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(125)) == 0 ){
/*1468*/ 		Scanner_sym = 11;
/*1468*/ 		Scanner_ReadCh();
/*1469*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(91)) == 0 ){
/*1469*/ 		Scanner_sym = 14;
/*1469*/ 		Scanner_ReadCh();
/*1470*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(93)) == 0 ){
/*1470*/ 		Scanner_sym = 15;
/*1470*/ 		Scanner_ReadCh();
/*1471*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(40)) == 0 ){
/*1471*/ 		Scanner_sym = 12;
/*1471*/ 		Scanner_ReadCh();
/*1472*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(41)) == 0 ){
/*1472*/ 		Scanner_sym = 13;
/*1472*/ 		Scanner_ReadCh();
/*1473*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(44)) == 0 ){
/*1473*/ 		Scanner_sym = 16;
/*1473*/ 		Scanner_ReadCh();
/*1474*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(59)) == 0 ){
/*1474*/ 		Scanner_sym = 17;
/*1474*/ 		Scanner_ReadCh();
/*1475*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(126)) == 0 ){
/*1475*/ 		Scanner_sym = 90;
/*1475*/ 		Scanner_ReadCh();
/*1477*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1478*/ 		Scanner_ReadCh();
/*1479*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(58)) == 0 ){
/*1480*/ 			Scanner_ReadCh();
/*1481*/ 			Scanner_sym = 19;
/*1483*/ 		} else {
/*1483*/ 			Scanner_sym = 18;
/*1486*/ 		}
/*1486*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(63)) == 0 ){
/*1487*/ 		Scanner_ReadCh();
/*1488*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1489*/ 			Scanner_SkipNewLineAfterCloseTag();
/*1490*/ 			Scanner_code = 0;
/*1491*/ 			Scanner_sym = 6;
/*1493*/ 		} else {
/*1493*/ 			Scanner_sym = 30;
/*1496*/ 		}
/*1496*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0 ){
/*1497*/ 		Scanner_ReadCh();
/*1498*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(43)) == 0 ){
/*1499*/ 			Scanner_ReadCh();
/*1500*/ 			Scanner_sym = 52;
/*1501*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1502*/ 			Scanner_ReadCh();
/*1503*/ 			Scanner_sym = 76;
/*1505*/ 		} else {
/*1505*/ 			Scanner_sym = 40;
/*1508*/ 		}
/*1508*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0 ){
/*1509*/ 		Scanner_ReadCh();
/*1510*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1511*/ 			Scanner_ReadCh();
/*1512*/ 			Scanner_sym = 61;
/*1513*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(45)) == 0 ){
/*1514*/ 			Scanner_ReadCh();
/*1515*/ 			Scanner_sym = 53;
/*1516*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1517*/ 			Scanner_ReadCh();
/*1518*/ 			Scanner_sym = 77;
/*1520*/ 		} else {
/*1520*/ 			Scanner_sym = 41;
/*1523*/ 		}
/*1523*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1524*/ 		Scanner_ReadCh();
/*1525*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1526*/ 			Scanner_ReadCh();
/*1527*/ 			Scanner_sym = 78;
/*1529*/ 		} else {
/*1529*/ 			Scanner_sym = 42;
/*1532*/ 		}
/*1532*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1533*/ 		Scanner_ReadCh();
/*1534*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(42)) == 0 ){
/*1535*/ 			Scanner_ReadCh();
/*1536*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1538*/ 				Scanner_code = 2;
/*1539*/ 				Scanner_ReadCh();
/*1540*/ 				return TRUE;
/*1542*/ 			} else {
/*1542*/ 				Scanner_SkipMultilineComment();
/*1543*/ 				if( (((m2runtime_length(Scanner_s) > 5)) && (m2runtime_strcmp(m2runtime_substr(Scanner_s, 0, 3, 1, Scanner_0err_entry_get, 31), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"/**") == 0)) ){
/*1545*/ 					Scanner_sym = 175;
/*1548*/ 				} else {
/*1548*/ 					return TRUE;
/*1551*/ 				}
/*1551*/ 			}
/*1551*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(47)) == 0 ){
/*1552*/ 			if( Scanner_SkipSingleLineComment() ){
/*1554*/ 				Scanner_code = 0;
/*1555*/ 				Scanner_sym = 6;
/*1556*/ 				return FALSE;
/*1558*/ 			}
/*1558*/ 			return TRUE;
/*1559*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1560*/ 			Scanner_sym = 79;
/*1561*/ 			Scanner_ReadCh();
/*1563*/ 		} else {
/*1563*/ 			Scanner_sym = 43;
/*1566*/ 		}
/*1566*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(37)) == 0 ){
/*1567*/ 		Scanner_ReadCh();
/*1568*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1569*/ 			Scanner_sym = 80;
/*1570*/ 			Scanner_ReadCh();
/*1572*/ 		} else {
/*1572*/ 			Scanner_sym = 74;
/*1575*/ 		}
/*1575*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1576*/ 		Scanner_ReadCh();
/*1577*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1578*/ 			Scanner_ReadCh();
/*1579*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1580*/ 				Scanner_ReadCh();
/*1581*/ 				Scanner_sym = 45;
/*1583*/ 			} else {
/*1583*/ 				Scanner_sym = 44;
/*1585*/ 			}
/*1585*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1586*/ 			Scanner_ReadCh();
/*1587*/ 			Scanner_sym = 32;
/*1589*/ 		} else {
/*1589*/ 			Scanner_sym = 31;
/*1592*/ 		}
/*1592*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1593*/ 		Scanner_ReadCh();
/*1594*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1595*/ 			Scanner_sym = 51;
/*1596*/ 			Scanner_ReadCh();
/*1597*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1598*/ 			Scanner_sym = 46;
/*1599*/ 			Scanner_ReadCh();
/*1600*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1601*/ 			Scanner_ReadCh();
/*1602*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1603*/ 				Scanner_ReadCh();
/*1604*/ 				Scanner_sym = 84;
/*1605*/ 			} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(60)) == 0 ){
/*1606*/ 				Scanner_ReadCh();
/*1607*/ 				return Scanner_ParseHereDoc();
/*1609*/ 			} else {
/*1609*/ 				Scanner_sym = 86;
/*1612*/ 			}
/*1612*/ 		} else {
/*1612*/ 			Scanner_sym = 50;
/*1615*/ 		}
/*1615*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1616*/ 		Scanner_ReadCh();
/*1617*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1618*/ 			Scanner_sym = 49;
/*1619*/ 			Scanner_ReadCh();
/*1620*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(62)) == 0 ){
/*1621*/ 			Scanner_ReadCh();
/*1622*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1623*/ 				Scanner_ReadCh();
/*1624*/ 				Scanner_sym = 85;
/*1626*/ 			} else {
/*1626*/ 				Scanner_sym = 87;
/*1629*/ 			}
/*1629*/ 		} else {
/*1629*/ 			Scanner_sym = 48;
/*1632*/ 		}
/*1632*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(33)) == 0 ){
/*1633*/ 		Scanner_ReadCh();
/*1634*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1635*/ 			Scanner_ReadCh();
/*1636*/ 			if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1637*/ 				Scanner_ReadCh();
/*1638*/ 				Scanner_sym = 47;
/*1640*/ 			} else {
/*1640*/ 				Scanner_sym = 46;
/*1643*/ 			}
/*1643*/ 		} else {
/*1643*/ 			Scanner_sym = 54;
/*1646*/ 		}
/*1646*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(124)) == 0 ){
/*1647*/ 		Scanner_ReadCh();
/*1648*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(124)) == 0 ){
/*1649*/ 			Scanner_ReadCh();
/*1650*/ 			Scanner_sym = 55;
/*1651*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1652*/ 			Scanner_sym = 82;
/*1653*/ 			Scanner_ReadCh();
/*1655*/ 		} else {
/*1655*/ 			Scanner_sym = 72;
/*1658*/ 		}
/*1658*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1659*/ 		Scanner_ReadCh();
/*1660*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(38)) == 0 ){
/*1661*/ 			Scanner_ReadCh();
/*1662*/ 			Scanner_sym = 57;
/*1663*/ 		} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1664*/ 			Scanner_sym = 81;
/*1665*/ 			Scanner_ReadCh();
/*1667*/ 		} else {
/*1667*/ 			Scanner_sym = 73;
/*1670*/ 		}
/*1670*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(46)) == 0 ){
/*1671*/ 		Scanner_ReadCh();
/*1672*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1673*/ 			Scanner_ReadCh();
/*1674*/ 			Scanner_sym = 75;
/*1676*/ 		} else {
/*1676*/ 			Scanner_sym = 60;
/*1679*/ 		}
/*1679*/ 	} else if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(94)) == 0 ){
/*1680*/ 		Scanner_ReadCh();
/*1681*/ 		if( m2runtime_strcmp(Scanner_c, m2runtime_CHR(61)) == 0 ){
/*1682*/ 			Scanner_sym = 83;
/*1683*/ 			Scanner_ReadCh();
/*1685*/ 		} else {
/*1685*/ 			Scanner_sym = 88;
/*1688*/ 		}
/*1688*/ 	} else if( Scanner_c == NULL ){
/*1689*/ 		Scanner_sym = 0;
/*1692*/ 	} else {
/*1692*/ 		Scanner_Fatal(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unexpected character ", Scanner_ReportChar(m2runtime_ASC(Scanner_c)), 1));
/*1695*/ 	}
/*1695*/ 	return FALSE;
/*1699*/ }


/*1700*/ void
/*1700*/ Scanner_ReadSym(void)
/*1700*/ {
/*1702*/ 	int Scanner_new_sym_found = 0;
/*1703*/ 	do {
/*1704*/ 		Scanner_new_sym_found = FALSE;
/*1706*/ 		switch(Scanner_code){

/*1708*/ 		case 0:
/*1709*/ 		Scanner_FindOpenTag();
/*1711*/ 		break;

/*1711*/ 		case 1:
/*1712*/ 		Scanner_new_sym_found = Scanner_ParseCode();
/*1714*/ 		break;

/*1714*/ 		case 2:
/*1715*/ 		Scanner_new_sym_found = Scanner_ParseXCode();
/*1717*/ 		break;

/*1717*/ 		case 3:
/*1724*/ 		Scanner_ParseKeyword();
/*1725*/ 		if( (Scanner_sym != 1) ){
/*1726*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"the name `$", Scanner_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"' is a keyword.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)" This is deprecated by PHP and forbidden by PHPLint.", 1));
/*1729*/ 		}
/*1729*/ 		Scanner_sym = 35;
/*1730*/ 		Scanner_code = 4;
/*1732*/ 		break;

/*1732*/ 		case 4:
/*1739*/ 		Scanner_new_sym_found = Scanner_ParseDoubleQuotedString();
/*1742*/ 		break;

/*1742*/ 		default: m2runtime_missing_case_in_switch(Scanner_0err_entry_get, 32);
/*1743*/ 		}
/*1743*/ 	} while( !( !Scanner_new_sym_found ));
/*1745*/ 	if( Globals_DEBUG ){
/*1746*/ 		m2_print(m2runtime_CHR(91));
/*1747*/ 		m2_print(Tokens_CodeToName(Scanner_sym));
/*1748*/ 		m2_print((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"]\012");
/*1751*/ 	}
/*1753*/ }


/*1755*/ int
/*1755*/ Scanner_Open(STRING *Scanner_abs_fn)
/*1755*/ {
/*1755*/ 	Scanner_fn = Scanner_abs_fn;
/*1756*/ 	m2runtime_ERROR_CODE = 0;
/*1756*/ 	io_Open(1, (void *)&Scanner_fd, Scanner_fn, m2runtime_CHR(114));
/*1758*/ 	switch( m2runtime_ERROR_CODE ){

/*1758*/ 	case 0:  break;
/*1758*/ 	default:
/*1758*/ 		Scanner_Error(m2runtime_ERROR_MESSAGE);
/*1759*/ 		return FALSE;
/*1762*/ 	}
/*1762*/ 	if( Scanner_print_source ){
/*1763*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"\012BEGIN parsing of ", Scanner_fmt_fn(Scanner_abs_fn), m2runtime_CHR(10), 1));
/*1766*/ 	}
/*1766*/ 	Scanner_code = 0;
/*1767*/ 	m2runtime_ERROR_CODE = 0;
/*1767*/ 	Scanner_line = io_ReadLine(1, Scanner_fd);
/*1768*/ 	switch( m2runtime_ERROR_CODE ){

/*1768*/ 	case 0:  break;
/*1768*/ 	default:
/*1768*/ 		m2runtime_HALT(Scanner_0err_entry_get, 33, m2runtime_ERROR_MESSAGE);
/*1768*/ 	}
/*1768*/ 	Scanner_line_n = 1;
/*1769*/ 	Scanner_line_idx = 0;
/*1770*/ 	Scanner_line_pos = 0;
/*1771*/ 	Scanner_c = NULL;
/*1773*/ 	if( Scanner_print_source ){
/*1774*/ 		Scanner_PrintLineSource();
/*1777*/ 	}
/*1777*/ 	Scanner_ReadCh();
/*1778*/ 	Scanner_ReadSym();
/*1779*/ 	return TRUE;
/*1783*/ }


/*1784*/ RECORD *
/*1784*/ Scanner_Suspend(void)
/*1784*/ {
/*1786*/ 	RECORD * Scanner_r = NULL;
/*1786*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 28, Scanner_0err_entry_get, 34) = Scanner_code;
/*1787*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 48, Scanner_0err_entry_get, 35) = Scanner_sym;
/*1788*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 12, Scanner_0err_entry_get, 36) = Scanner_fn;
/*1789*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 16, Scanner_0err_entry_get, 37) = Scanner_fd;
/*1790*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 20, Scanner_0err_entry_get, 38) = Scanner_line;
/*1791*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 52, Scanner_0err_entry_get, 39) = Scanner_line_n;
/*1792*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 56, Scanner_0err_entry_get, 40) = Scanner_line_idx;
/*1793*/ 	*(int *)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 60, Scanner_0err_entry_get, 41) = Scanner_line_pos;
/*1794*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 24, Scanner_0err_entry_get, 42) = Scanner_c;
/*1795*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Scanner_r, 64, 5, 8, Scanner_0err_entry_get, 43) = Scanner_s;
/*1796*/ 	return Scanner_r;
/*1800*/ }


/*1802*/ void
/*1802*/ Scanner_Resume(RECORD *Scanner_r)
/*1802*/ {
/*1802*/ 	Scanner_code =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 28, Scanner_0err_entry_get, 44);
/*1803*/ 	Scanner_sym =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 48, Scanner_0err_entry_get, 45);
/*1804*/ 	Scanner_fn = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 12, Scanner_0err_entry_get, 46);
/*1805*/ 	Scanner_fd = (void *)m2runtime_dereference_rhs_RECORD(Scanner_r, 16, Scanner_0err_entry_get, 47);
/*1806*/ 	Scanner_line = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 20, Scanner_0err_entry_get, 48);
/*1807*/ 	Scanner_line_n =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 52, Scanner_0err_entry_get, 49);
/*1808*/ 	Scanner_line_idx =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 56, Scanner_0err_entry_get, 50);
/*1809*/ 	Scanner_line_pos =  *(int *)m2runtime_dereference_rhs_RECORD(Scanner_r, 60, Scanner_0err_entry_get, 51);
/*1810*/ 	Scanner_c = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 24, Scanner_0err_entry_get, 52);
/*1811*/ 	Scanner_s = (STRING *)m2runtime_dereference_rhs_RECORD(Scanner_r, 8, Scanner_0err_entry_get, 53);
/*1815*/ }


/*1817*/ void
/*1817*/ Scanner_Close(void)
/*1817*/ {
/*1817*/ 	if( Scanner_print_source ){
/*1818*/ 		m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"END parsing of ", Scanner_fmt_fn(Scanner_fn), m2runtime_CHR(10), 1));
/*1820*/ 	}
/*1820*/ 	m2runtime_ERROR_CODE = 0;
/*1820*/ 	io_Close(1, (void *)&Scanner_fd);
/*1821*/ 	switch( m2runtime_ERROR_CODE ){

/*1821*/ 	case 0:  break;
/*1821*/ 	default:
/*1821*/ 		m2runtime_HALT(Scanner_0err_entry_get, 54, m2runtime_ERROR_MESSAGE);
/*1821*/ 	}
/*1821*/ 	Scanner_fn = NULL;
/*1826*/ }


char * Scanner_0func[] = {
    "mn",
    "fmt_fn",
    "reference",
    "PrintWhere",
    "ReadCh",
    "SearchKeyword",
    "FindOpenTag",
    "SkipSingleLineComment",
    "ReportChar",
    "is_id_first_char",
    "is_id_char",
    "hex",
    "ParseEscapeCode",
    "ParseDoubleQuotedString",
    "ParseSingleQuotedString",
    "ParseNumber",
    "ParseCode",
    "ReadSym",
    "Open",
    "Suspend",
    "Resume",
    "Close"
};

int Scanner_0err_entry[] = {
    0 /* mn */, 108,
    0 /* mn */, 108,
    1 /* fmt_fn */, 130,
    1 /* fmt_fn */, 131,
    2 /* reference */, 144,
    2 /* reference */, 145,
    2 /* reference */, 147,
    2 /* reference */, 147,
    2 /* reference */, 149,
    3 /* PrintWhere */, 164,
    3 /* PrintWhere */, 165,
    3 /* PrintWhere */, 167,
    4 /* ReadCh */, 304,
    4 /* ReadCh */, 310,
    4 /* ReadCh */, 316,
    5 /* SearchKeyword */, 357,
    5 /* SearchKeyword */, 357,
    5 /* SearchKeyword */, 363,
    5 /* SearchKeyword */, 363,
    5 /* SearchKeyword */, 373,
    6 /* FindOpenTag */, 535,
    6 /* FindOpenTag */, 537,
    7 /* SkipSingleLineComment */, 588,
    8 /* ReportChar */, 667,
    9 /* is_id_first_char */, 708,
    10 /* is_id_char */, 725,
    11 /* hex */, 751,
    12 /* ParseEscapeCode */, 829,
    13 /* ParseDoubleQuotedString */, 999,
    14 /* ParseSingleQuotedString */, 1094,
    15 /* ParseNumber */, 1267,
    16 /* ParseCode */, 1543,
    17 /* ReadSym */, 1741,
    18 /* Open */, 1767,
    19 /* Suspend */, 1786,
    19 /* Suspend */, 1787,
    19 /* Suspend */, 1788,
    19 /* Suspend */, 1789,
    19 /* Suspend */, 1790,
    19 /* Suspend */, 1791,
    19 /* Suspend */, 1792,
    19 /* Suspend */, 1793,
    19 /* Suspend */, 1794,
    19 /* Suspend */, 1795,
    20 /* Resume */, 1802,
    20 /* Resume */, 1803,
    20 /* Resume */, 1804,
    20 /* Resume */, 1805,
    20 /* Resume */, 1806,
    20 /* Resume */, 1807,
    20 /* Resume */, 1808,
    20 /* Resume */, 1809,
    20 /* Resume */, 1810,
    20 /* Resume */, 1811,
    21 /* Close */, 1820
};

void Scanner_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Scanner";
    *f = Scanner_0func[ Scanner_0err_entry[2*i] ];
    *l = Scanner_0err_entry[2*i + 1];
}
