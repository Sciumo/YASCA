/* IMPLEMENTATION MODULE Search */
#define M2_IMPORT_Search

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

void Search_0err_entry_get(int i, char **m, char **f, int *l);

/*  8*/ RECORD *
/*  8*/ Search_SearchConst(STRING *Search_name)
/*  8*/ {
/* 10*/ 	int Search_i = 0;
/* 10*/ 	{
/* 10*/ 		int m2runtime_for_limit_1;
/* 10*/ 		Search_i = 0;
/* 10*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_consts) - 1);
/* 11*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/* 11*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_consts, Search_i, Search_0err_entry_get, 0), 8, Search_0err_entry_get, 1), Search_name) == 0 ){
/* 12*/ 				return (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_consts, Search_i, Search_0err_entry_get, 2);
/* 15*/ 			}
/* 15*/ 		}
/* 15*/ 	}
/* 15*/ 	return NULL;
/* 19*/ }


/* 24*/ RECORD *
/* 24*/ Search_SearchVar(STRING *Search_name, int Search_scope)
/* 24*/ {
/* 25*/ 	int Search_i = 0;
/* 27*/ 	RECORD * Search_v = NULL;
/* 28*/ 	Search_i = (Globals_vars_n - 1);
/* 30*/ 	do{
/* 30*/ 		if( (Search_i < 0) ){
/* 33*/ 			goto m2runtime_loop_1;
/* 33*/ 		}
/* 33*/ 		Search_v = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_vars, Search_i, Search_0err_entry_get, 3);
/* 34*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Search_v, 40, Search_0err_entry_get, 4) < Search_scope) ){
/* 37*/ 			goto m2runtime_loop_1;
/* 37*/ 		}
/* 37*/ 		if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Search_v, 40, Search_0err_entry_get, 5) == Search_scope)) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Search_v, 8, Search_0err_entry_get, 6), Search_name) == 0)) ){
/* 38*/ 			return Search_v;
/* 40*/ 		}
/* 40*/ 		m2_inc(&Search_i, -1);
/* 44*/ 	}while(TRUE);
m2runtime_loop_1: ;
/* 44*/ 	{
/* 44*/ 		int m2runtime_for_limit_1;
/* 44*/ 		Search_i = 0;
/* 44*/ 		m2runtime_for_limit_1 = (Globals_vars_n - 1);
/* 45*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/* 45*/ 			Search_v = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_vars, Search_i, Search_0err_entry_get, 7);
/* 46*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Search_v, 40, Search_0err_entry_get, 8) > -1) ){
/* 47*/ 				return NULL;
/* 49*/ 			}
/* 49*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Search_v, 8, Search_0err_entry_get, 9), Search_name) == 0 ){
/* 50*/ 				return Search_v;
/* 53*/ 			}
/* 54*/ 		}
/* 54*/ 	}
/* 54*/ 	return NULL;
/* 58*/ }


/* 64*/ RECORD *
/* 64*/ Search_SearchFunc(STRING *Search_name, int Search_warn)
/* 64*/ {
/* 65*/ 	STRING * Search_name_upper = NULL;
/* 66*/ 	int Search_i = 0;
/* 68*/ 	RECORD * Search_f = NULL;
/* 68*/ 	Search_name_upper = str_toupper(Search_name);
/* 69*/ 	{
/* 69*/ 		int m2runtime_for_limit_1;
/* 69*/ 		Search_i = 0;
/* 69*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_funcs) - 1);
/* 70*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/* 70*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_funcs, Search_i, Search_0err_entry_get, 10), 12, Search_0err_entry_get, 11), Search_name_upper) == 0 ){
/* 71*/ 				Search_f = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_funcs, Search_i, Search_0err_entry_get, 12);
/* 72*/ 				if( (Search_warn && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Search_f, 8, Search_0err_entry_get, 13), Search_name) != 0)) ){
/* 73*/ 					if( (RECORD *)m2runtime_dereference_rhs_RECORD(Search_f, 16, Search_0err_entry_get, 14) == NULL ){
/* 74*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already spelled as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_f, 8, Search_0err_entry_get, 15), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/* 78*/ 					} else {
/* 78*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"function `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"' was declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Search_f, 16, Search_0err_entry_get, 16)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_f, 8, Search_0err_entry_get, 17), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/* 83*/ 					}
/* 83*/ 				}
/* 83*/ 				return Search_f;
/* 86*/ 			}
/* 86*/ 		}
/* 86*/ 	}
/* 86*/ 	return NULL;
/* 90*/ }


/* 96*/ RECORD *
/* 96*/ Search_SearchClass(STRING *Search_name, int Search_warn)
/* 96*/ {
/* 97*/ 	STRING * Search_name_upper = NULL;
/* 98*/ 	int Search_i = 0;
/*100*/ 	RECORD * Search_class = NULL;
/*100*/ 	Search_name_upper = str_toupper(Search_name);
/*101*/ 	{
/*101*/ 		int m2runtime_for_limit_1;
/*101*/ 		Search_i = (m2runtime_count(Globals_classes) - 1);
/*101*/ 		m2runtime_for_limit_1 = 0;
/*102*/ 		for( ; Search_i >= m2runtime_for_limit_1; Search_i -= 1 ){
/*102*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_classes, Search_i, Search_0err_entry_get, 18), 12, Search_0err_entry_get, 19), Search_name_upper) == 0 ){
/*103*/ 				Search_class = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_classes, Search_i, Search_0err_entry_get, 20);
/*104*/ 				if( (Search_warn && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Search_class, 8, Search_0err_entry_get, 21), Search_name) != 0)) ){
/*105*/ 					if( (RECORD *)m2runtime_dereference_rhs_RECORD(Search_class, 48, Search_0err_entry_get, 22) == NULL ){
/*106*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already spelled as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_class, 8, Search_0err_entry_get, 23), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/*110*/ 					} else {
/*110*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"class `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"' was declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Search_class, 48, Search_0err_entry_get, 24)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_class, 8, Search_0err_entry_get, 25), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/*115*/ 					}
/*115*/ 				}
/*115*/ 				return Search_class;
/*118*/ 			}
/*118*/ 		}
/*118*/ 	}
/*118*/ 	return NULL;
/*122*/ }


/*152*/ void
/*152*/ Search_SearchClassProperty(RECORD *Search_class, STRING *Search_id, RECORD **Search_P, RECORD **Search_p)
/*152*/ {
/*153*/ 	ARRAY * Search_properties = NULL;
/*155*/ 	int Search_i = 0;
/*155*/ 	Search_properties = (ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 32, Search_0err_entry_get, 26);
/*156*/ 	{
/*156*/ 		int m2runtime_for_limit_1;
/*156*/ 		Search_i = 0;
/*156*/ 		m2runtime_for_limit_1 = (m2runtime_count(Search_properties) - 1);
/*157*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/*157*/ 			if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Search_properties, Search_i, Search_0err_entry_get, 27), 8, Search_0err_entry_get, 28), Search_id) == 0) && (((( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Search_properties, Search_i, Search_0err_entry_get, 29), 32, Search_0err_entry_get, 30) == 2)) || (( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Search_properties, Search_i, Search_0err_entry_get, 31), 32, Search_0err_entry_get, 32) == 1)) || ((( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Search_properties, Search_i, Search_0err_entry_get, 33), 32, Search_0err_entry_get, 34) == 0)) && ((((Globals_php_ver == 4)) || (Globals_curr_class == Search_class))))))) ){
/*163*/ 				*Search_P = Search_class;
/*164*/ 				*Search_p = (RECORD *)m2runtime_dereference_rhs_ARRAY(Search_properties, Search_i, Search_0err_entry_get, 35);
/*166*/ 				return ;
/*168*/ 			}
/*170*/ 		}
/*170*/ 	}
/*170*/ 	{
/*170*/ 		int m2runtime_for_limit_1;
/*170*/ 		Search_i = 0;
/*170*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 20, Search_0err_entry_get, 36)) - 1);
/*171*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/*171*/ 			Search_SearchClassProperty((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 20, Search_0err_entry_get, 37), Search_i, Search_0err_entry_get, 38), Search_id, Search_P, Search_p);
/*172*/ 			if( *Search_p != NULL ){
/*174*/ 				return ;
/*176*/ 			}
/*178*/ 		}
/*178*/ 	}
/*178*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Search_class, 16, Search_0err_entry_get, 39) != NULL ){
/*179*/ 		Search_SearchClassProperty((RECORD *)m2runtime_dereference_rhs_RECORD(Search_class, 16, Search_0err_entry_get, 40), Search_id, Search_P, Search_p);
/*180*/ 		if( *Search_p != NULL ){
/*182*/ 			return ;
/*184*/ 		}
/*186*/ 	}
/*186*/ 	*Search_P = NULL;
/*187*/ 	*Search_p = NULL;
/*189*/ 	return ;
/*192*/ }


/*198*/ RECORD *
/*198*/ Search_SearchClassMethod(RECORD *Search_class, STRING *Search_name, int Search_warn)
/*198*/ {
/*199*/ 	STRING * Search_name_upper = NULL;
/*200*/ 	ARRAY * Search_methods = NULL;
/*201*/ 	int Search_i = 0;
/*203*/ 	RECORD * Search_m = NULL;
/*203*/ 	if( Search_class == NULL ){
/*204*/ 		return NULL;
/*206*/ 	}
/*206*/ 	Search_name_upper = str_toupper(Search_name);
/*207*/ 	Search_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 36, Search_0err_entry_get, 41);
/*208*/ 	{
/*208*/ 		int m2runtime_for_limit_1;
/*208*/ 		Search_i = 0;
/*208*/ 		m2runtime_for_limit_1 = (m2runtime_count(Search_methods) - 1);
/*209*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/*209*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Search_methods, Search_i, Search_0err_entry_get, 42), 12, Search_0err_entry_get, 43), Search_name_upper) == 0 ){
/*210*/ 				Search_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Search_methods, Search_i, Search_0err_entry_get, 44);
/*211*/ 				if( (Search_warn && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Search_m, 8, Search_0err_entry_get, 45), Search_name) != 0)) ){
/*212*/ 					if( (RECORD *)m2runtime_dereference_rhs_RECORD(Search_m, 20, Search_0err_entry_get, 46) == NULL ){
/*213*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already spelled as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_m, 8, Search_0err_entry_get, 47), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/*217*/ 					} else {
/*217*/ 						Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"method `", Search_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"' was declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Search_m, 20, Search_0err_entry_get, 48)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" as `", (STRING *)m2runtime_dereference_rhs_RECORD(Search_m, 8, Search_0err_entry_get, 49), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"' that differ by upper/lower-case letters only", 1));
/*222*/ 					}
/*222*/ 				}
/*222*/ 				return Search_m;
/*225*/ 			}
/*225*/ 		}
/*225*/ 	}
/*225*/ 	return NULL;
/*229*/ }


/*231*/ void
/*231*/ Search_ResolveClassConst(RECORD *Search_class, STRING *Search_id, RECORD **Search_res_class, RECORD **Search_res_const)
/*231*/ {
/*233*/ 	int Search_i = 0;
/*233*/ 	*Search_res_class = NULL;
/*234*/ 	*Search_res_const = NULL;
/*236*/ 	if( Search_class == NULL ){
/*238*/ 		return ;
/*243*/ 	}
/*243*/ 	{
/*243*/ 		int m2runtime_for_limit_1;
/*243*/ 		Search_i = 0;
/*243*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 28, Search_0err_entry_get, 50)) - 1);
/*244*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/*244*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 28, Search_0err_entry_get, 51), Search_i, Search_0err_entry_get, 52), 8, Search_0err_entry_get, 53), Search_id) == 0 ){
/*245*/ 				*Search_res_class = Search_class;
/*246*/ 				*Search_res_const = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 28, Search_0err_entry_get, 54), Search_i, Search_0err_entry_get, 55);
/*248*/ 				return ;
/*250*/ 			}
/*254*/ 		}
/*254*/ 	}
/*254*/ 	Search_ResolveClassConst((RECORD *)m2runtime_dereference_rhs_RECORD(Search_class, 16, Search_0err_entry_get, 56), Search_id, Search_res_class, Search_res_const);
/*255*/ 	if( *Search_res_const != NULL ){
/*257*/ 		return ;
/*262*/ 	}
/*262*/ 	{
/*262*/ 		int m2runtime_for_limit_1;
/*262*/ 		Search_i = 0;
/*262*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 20, Search_0err_entry_get, 57)) - 1);
/*263*/ 		for( ; Search_i <= m2runtime_for_limit_1; Search_i += 1 ){
/*263*/ 			Search_ResolveClassConst((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Search_class, 20, Search_0err_entry_get, 58), Search_i, Search_0err_entry_get, 59), Search_id, Search_res_class, Search_res_const);
/*264*/ 			if( *Search_res_const != NULL ){
/*266*/ 				return ;
/*268*/ 			}
/*269*/ 		}
/*269*/ 	}
/*272*/ }


char * Search_0func[] = {
    "SearchConst",
    "SearchVar",
    "SearchFunc",
    "SearchClass",
    "SearchClassProperty",
    "SearchClassMethod",
    "ResolveClassConst"
};

int Search_0err_entry[] = {
    0 /* SearchConst */, 11,
    0 /* SearchConst */, 11,
    0 /* SearchConst */, 13,
    1 /* SearchVar */, 34,
    1 /* SearchVar */, 34,
    1 /* SearchVar */, 37,
    1 /* SearchVar */, 37,
    1 /* SearchVar */, 46,
    1 /* SearchVar */, 46,
    1 /* SearchVar */, 49,
    2 /* SearchFunc */, 70,
    2 /* SearchFunc */, 70,
    2 /* SearchFunc */, 72,
    2 /* SearchFunc */, 72,
    2 /* SearchFunc */, 73,
    2 /* SearchFunc */, 75,
    2 /* SearchFunc */, 79,
    2 /* SearchFunc */, 79,
    3 /* SearchClass */, 102,
    3 /* SearchClass */, 102,
    3 /* SearchClass */, 104,
    3 /* SearchClass */, 104,
    3 /* SearchClass */, 105,
    3 /* SearchClass */, 107,
    3 /* SearchClass */, 111,
    3 /* SearchClass */, 111,
    4 /* SearchClassProperty */, 155,
    4 /* SearchClassProperty */, 157,
    4 /* SearchClassProperty */, 157,
    4 /* SearchClassProperty */, 158,
    4 /* SearchClassProperty */, 158,
    4 /* SearchClassProperty */, 159,
    4 /* SearchClassProperty */, 159,
    4 /* SearchClassProperty */, 160,
    4 /* SearchClassProperty */, 160,
    4 /* SearchClassProperty */, 165,
    4 /* SearchClassProperty */, 170,
    4 /* SearchClassProperty */, 171,
    4 /* SearchClassProperty */, 171,
    4 /* SearchClassProperty */, 178,
    4 /* SearchClassProperty */, 179,
    5 /* SearchClassMethod */, 207,
    5 /* SearchClassMethod */, 209,
    5 /* SearchClassMethod */, 209,
    5 /* SearchClassMethod */, 211,
    5 /* SearchClassMethod */, 211,
    5 /* SearchClassMethod */, 212,
    5 /* SearchClassMethod */, 214,
    5 /* SearchClassMethod */, 218,
    5 /* SearchClassMethod */, 218,
    6 /* ResolveClassConst */, 243,
    6 /* ResolveClassConst */, 244,
    6 /* ResolveClassConst */, 244,
    6 /* ResolveClassConst */, 244,
    6 /* ResolveClassConst */, 246,
    6 /* ResolveClassConst */, 247,
    6 /* ResolveClassConst */, 254,
    6 /* ResolveClassConst */, 262,
    6 /* ResolveClassConst */, 263,
    6 /* ResolveClassConst */, 263
};

void Search_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Search";
    *f = Search_0func[ Search_0err_entry[2*i] ];
    *l = Search_0err_entry[2*i + 1];
}
