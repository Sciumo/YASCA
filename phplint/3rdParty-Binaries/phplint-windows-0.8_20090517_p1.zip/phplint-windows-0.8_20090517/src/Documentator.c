/* IMPLEMENTATION MODULE Documentator */
#define M2_IMPORT_Documentator

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_io
#    include "io.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_FileName
#    include "FileName.c"
#endif

void Documentator_0err_entry_get(int i, char **m, char **f, int *l);
/* 19*/ int Documentator_generate = 0;
/* 22*/ STRING * Documentator_extension = NULL;
/* 25*/ STRING * Documentator_page_footer = NULL;
/* 25*/ STRING * Documentator_page_header = NULL;
/* 34*/ ARRAY * Documentator_ref_remap = NULL;
/* 35*/ int Documentator_php_ver = 0;
/* 37*/ STRING * Documentator_fn = NULL;
/* 38*/ STRING * Documentator_package_descr = NULL;
/* 39*/ ARRAY * Documentator_required_packages = NULL;
/* 40*/ ARRAY * Documentator_include_path = NULL;
/* 41*/ ARRAY * Documentator_consts = NULL;
/* 42*/ ARRAY * Documentator_vars = NULL;
/* 43*/ ARRAY * Documentator_funcs = NULL;
/* 45*/ ARRAY * Documentator_classes = NULL;
/* 48*/ void * Documentator_fd = NULL;
/* 52*/ STRING * Documentator_fn_remapped = NULL;
/* 60*/ RECORD * Documentator_curr_class = NULL;
/* 68*/ STRING * Documentator_see = NULL;
/* 68*/ STRING * Documentator_deprecated = NULL;
/* 68*/ STRING * Documentator_since = NULL;
/* 68*/ STRING * Documentator_authors = NULL;
/* 68*/ STRING * Documentator_license = NULL;
/* 68*/ STRING * Documentator_copyright = NULL;
/* 68*/ STRING * Documentator_version = NULL;
/* 68*/ STRING * Documentator_package = NULL;
/* 71*/ int Documentator_prev_item_big_vspace = 0;
/* 74*/ STRING * Documentator_private_items = NULL;

/* 76*/ void
/* 76*/ Documentator_DocError(STRING *Documentator_msg)
/* 76*/ {
/* 76*/ 	m2_print(m2runtime_concat_STRING(0, Documentator_fn, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)": DOC ERROR: ", Documentator_msg, m2runtime_CHR(10), 1));
/* 80*/ }


/* 82*/ void
/* 82*/ Documentator_p(STRING *Documentator_s)
/* 82*/ {
/* 82*/ 	m2runtime_ERROR_CODE = 0;
/* 82*/ 	io_Write(1, *(void **)(void *)&Documentator_fd, Documentator_s);
/* 83*/ 	switch( m2runtime_ERROR_CODE ){

/* 83*/ 	case 0:  break;
/* 83*/ 	default:
/* 83*/ 		m2runtime_HALT(Documentator_0err_entry_get, 0, m2runtime_ERROR_MESSAGE);
/* 84*/ 	}
/* 86*/ }


/* 88*/ int
/* 88*/ Documentator_is_space(STRING *Documentator_c)
/* 88*/ {
/* 88*/ 	return ((m2runtime_strcmp(Documentator_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(10)) == 0) || (m2runtime_strcmp(Documentator_c, m2runtime_CHR(13)) == 0));
/* 92*/ }


/* 94*/ STRING *
/* 94*/ Documentator_Anchor(STRING *Documentator_url, STRING *Documentator_text)
/* 94*/ {
/* 94*/ 	return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<a href=\042", Documentator_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"\042><code>", Documentator_text, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"</code></a>", 1);
/* 98*/ }


/*108*/ STRING *
/*108*/ Documentator_RefMap(STRING *Documentator_f)
/*108*/ {
/*109*/ 	STRING * Documentator_t = NULL;
/*111*/ 	int Documentator_i = 0;
/*111*/ 	{
/*111*/ 		int m2runtime_for_limit_1;
/*111*/ 		Documentator_i = 0;
/*111*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_ref_remap) - 1);
/*112*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 2 ){
/*112*/ 			Documentator_t = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_ref_remap, Documentator_i, Documentator_0err_entry_get, 1);
/*113*/ 			if( (((m2runtime_length(Documentator_t) <= m2runtime_length(Documentator_f))) && (m2runtime_strcmp(m2runtime_substr(Documentator_f, 0, m2runtime_length(Documentator_t), 1, Documentator_0err_entry_get, 2), Documentator_t) == 0)) ){
/*114*/ 				return m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_ref_remap, (Documentator_i + 1), Documentator_0err_entry_get, 3), m2runtime_substr(Documentator_f, m2runtime_length(Documentator_t), m2runtime_length(Documentator_f), 1, Documentator_0err_entry_get, 4), 1);
/*117*/ 			}
/*117*/ 		}
/*117*/ 	}
/*117*/ 	return Documentator_f;
/*121*/ }


/*137*/ STRING *
/*137*/ Documentator_ItemToUrl(STRING *Documentator_t)
/*137*/ {

/*139*/ 	STRING *
/*139*/ 	Documentator_err(STRING *Documentator_msg)
/*139*/ 	{
/*139*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"<@item ", Documentator_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)">: ", Documentator_msg, m2runtime_CHR(10), 1));
/*140*/ 		return m2runtime_CHR(35);
/*144*/ 	}


/*145*/ 	RECORD *
/*145*/ 	Documentator_SearchConst(STRING *Documentator_n)
/*145*/ 	{
/*147*/ 		int Documentator_i = 0;
/*147*/ 		{
/*147*/ 			int m2runtime_for_limit_1;
/*147*/ 			Documentator_i = 0;
/*147*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*148*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*148*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 5), 8, Documentator_0err_entry_get, 6), Documentator_n) == 0 ){
/*149*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 7);
/*152*/ 				}
/*152*/ 			}
/*152*/ 		}
/*152*/ 		return NULL;
/*156*/ 	}


/*157*/ 	RECORD *
/*157*/ 	Documentator_SearchVar(STRING *Documentator_n)
/*157*/ 	{
/*159*/ 		int Documentator_i = 0;
/*159*/ 		{
/*159*/ 			int m2runtime_for_limit_1;
/*159*/ 			Documentator_i = 0;
/*159*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_vars) - 1);
/*160*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*160*/ 				if( (((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 8) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 9), 8, Documentator_0err_entry_get, 10), Documentator_n) == 0)) ){
/*161*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 11);
/*164*/ 				}
/*164*/ 			}
/*164*/ 		}
/*164*/ 		return NULL;
/*168*/ 	}


/*169*/ 	RECORD *
/*169*/ 	Documentator_SearchFunc(STRING *Documentator_n)
/*169*/ 	{
/*171*/ 		int Documentator_i = 0;
/*171*/ 		{
/*171*/ 			int m2runtime_for_limit_1;
/*171*/ 			Documentator_i = 0;
/*171*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_funcs) - 1);
/*172*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*172*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 12), 8, Documentator_0err_entry_get, 13), Documentator_n) == 0 ){
/*173*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 14);
/*176*/ 				}
/*176*/ 			}
/*176*/ 		}
/*176*/ 		return NULL;
/*180*/ 	}


/*181*/ 	RECORD *
/*181*/ 	Documentator_SearchClass(STRING *Documentator_n)
/*181*/ 	{
/*183*/ 		int Documentator_i = 0;
/*183*/ 		{
/*183*/ 			int m2runtime_for_limit_1;
/*183*/ 			Documentator_i = 0;
/*183*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_classes) - 1);
/*184*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*184*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 15), 8, Documentator_0err_entry_get, 16), Documentator_n) == 0 ){
/*185*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 17);
/*188*/ 				}
/*188*/ 			}
/*188*/ 		}
/*188*/ 		return NULL;
/*192*/ 	}


/*193*/ 	RECORD *
/*193*/ 	Documentator_SearchClassConst(RECORD *Documentator_cl, STRING *Documentator_n)
/*193*/ 	{
/*193*/ 		int Documentator_i = 0;
/*195*/ 		ARRAY * Documentator_consts = NULL;
/*195*/ 		Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 28, Documentator_0err_entry_get, 18);
/*196*/ 		{
/*196*/ 			int m2runtime_for_limit_1;
/*196*/ 			Documentator_i = 0;
/*196*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*197*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*197*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 19), 8, Documentator_0err_entry_get, 20), Documentator_n) == 0 ){
/*198*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 21);
/*201*/ 				}
/*201*/ 			}
/*201*/ 		}
/*201*/ 		return NULL;
/*205*/ 	}


/*206*/ 	RECORD *
/*206*/ 	Documentator_SearchClassVar(RECORD *Documentator_cl, STRING *Documentator_n)
/*206*/ 	{
/*206*/ 		int Documentator_i = 0;
/*208*/ 		ARRAY * Documentator_p = NULL;
/*208*/ 		Documentator_p = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 32, Documentator_0err_entry_get, 22);
/*209*/ 		{
/*209*/ 			int m2runtime_for_limit_1;
/*209*/ 			Documentator_i = 0;
/*209*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_p) - 1);
/*210*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*210*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_p, Documentator_i, Documentator_0err_entry_get, 23), 8, Documentator_0err_entry_get, 24), Documentator_n) == 0 ){
/*211*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_p, Documentator_i, Documentator_0err_entry_get, 25);
/*214*/ 				}
/*214*/ 			}
/*214*/ 		}
/*214*/ 		return NULL;
/*218*/ 	}


/*219*/ 	RECORD *
/*219*/ 	Documentator_SearchClassFunc(RECORD *Documentator_cl, STRING *Documentator_n)
/*219*/ 	{
/*219*/ 		int Documentator_i = 0;
/*221*/ 		ARRAY * Documentator_m = NULL;
/*221*/ 		Documentator_m = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 36, Documentator_0err_entry_get, 26);
/*222*/ 		{
/*222*/ 			int m2runtime_for_limit_1;
/*222*/ 			Documentator_i = 0;
/*222*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_m) - 1);
/*223*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*223*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_m, Documentator_i, Documentator_0err_entry_get, 27), 8, Documentator_0err_entry_get, 28), Documentator_n) == 0 ){
/*224*/ 					return (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_m, Documentator_i, Documentator_0err_entry_get, 29);
/*227*/ 				}
/*227*/ 			}
/*227*/ 		}
/*227*/ 		return NULL;
/*231*/ 	}


/*232*/ 	STRING *
/*232*/ 	Documentator_report(RECORD *Documentator_decl_in)
/*232*/ 	{
/*234*/ 		int Documentator_i = 0;
/*234*/ 		if( Documentator_decl_in == NULL ){
/*235*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"not declared / not assigned");
/*237*/ 		}
/*237*/ 		Documentator_i = str_find(Documentator_t, m2runtime_CHR(40));
/*238*/ 		if( (Documentator_i >= 0) ){
/*239*/ 			Documentator_t = m2runtime_concat_STRING(0, m2runtime_substr(Documentator_t, 0, Documentator_i, 1, Documentator_0err_entry_get, 30), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1);
/*241*/ 		}
/*241*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_decl_in, 8, Documentator_0err_entry_get, 31), Documentator_fn) == 0 ){
/*242*/ 			return m2runtime_concat_STRING(0, m2runtime_CHR(35), Documentator_t, 1);
/*244*/ 		} else {
/*244*/ 			return FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_decl_in, 8, Documentator_0err_entry_get, 32)), Documentator_extension, m2runtime_CHR(35), Documentator_t, 1)));
/*248*/ 		}
/*248*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 33);
/*248*/ 		return NULL;
/*250*/ 	}

/*251*/ 	STRING * Documentator_n = NULL;
/*252*/ 	int Documentator_j = 0;
/*253*/ 	int Documentator_tlen = 0;
/*254*/ 	RECORD * Documentator_c = NULL;
/*255*/ 	RECORD * Documentator_v = NULL;
/*256*/ 	RECORD * Documentator_f = NULL;
/*257*/ 	RECORD * Documentator_cl = NULL;
/*260*/ 	RECORD * Documentator_cl_c = NULL;
/*260*/ 	Documentator_tlen = m2runtime_length(Documentator_t);
/*261*/ 	if( (Documentator_tlen == 0) ){
/*262*/ 		return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"empty target");
/*265*/ 	}
/*265*/ 	if( m2runtime_strcmp(m2runtime_substr(Documentator_t, 0, 0, 0, Documentator_0err_entry_get, 34), m2runtime_CHR(36)) == 0 ){
/*266*/ 		Documentator_v = Documentator_SearchVar(m2runtime_substr(Documentator_t, 1, Documentator_tlen, 1, Documentator_0err_entry_get, 35));
/*267*/ 		if( Documentator_v == NULL ){
/*268*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"variable not found in global scope");
/*270*/ 		} else {
/*270*/ 			return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 36));
/*273*/ 		}
/*274*/ 	}
/*274*/ 	Documentator_j = str_find(Documentator_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::");
/*275*/ 	if( (Documentator_j >= 0) ){
/*278*/ 		if( (Documentator_j == 0) ){
/*279*/ 			if( Documentator_curr_class == NULL ){
/*280*/ 				Documentator_DocError((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"missing class name");
/*281*/ 				Documentator_cl = NULL;
/*283*/ 			} else {
/*283*/ 				Documentator_cl = Documentator_curr_class;
/*284*/ 				Documentator_t = m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 37), Documentator_t, 1);
/*285*/ 				Documentator_j = m2runtime_length((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 38));
/*286*/ 				Documentator_tlen = m2runtime_length(Documentator_t);
/*289*/ 			}
/*289*/ 		} else {
/*289*/ 			Documentator_cl = Documentator_SearchClass(m2runtime_substr(Documentator_t, 0, Documentator_j, 1, Documentator_0err_entry_get, 39));
/*291*/ 		}
/*291*/ 		if( Documentator_cl == NULL ){
/*292*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"class not found");
/*297*/ 		}
/*297*/ 		Documentator_n = m2runtime_substr(Documentator_t, (Documentator_j + 2), Documentator_tlen, 1, Documentator_0err_entry_get, 40);
/*299*/ 		if( (((m2runtime_length(Documentator_n) >= 1)) && (m2runtime_strcmp(m2runtime_substr(Documentator_n, 0, 0, 0, Documentator_0err_entry_get, 41), m2runtime_CHR(36)) == 0)) ){
/*300*/ 			if( Documentator_SearchClassVar(Documentator_cl, m2runtime_substr(Documentator_n, 1, m2runtime_length(Documentator_n), 1, Documentator_0err_entry_get, 42)) == NULL ){
/*301*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"property not found");
/*303*/ 			} else {
/*303*/ 				return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 43));
/*306*/ 			}
/*307*/ 		}
/*307*/ 		if( (((m2runtime_length(Documentator_n) >= 2)) && (m2runtime_strcmp(m2runtime_substr(Documentator_n, (m2runtime_length(Documentator_n) - 1), 0, 0, Documentator_0err_entry_get, 44), m2runtime_CHR(41)) == 0)) ){
/*308*/ 			Documentator_j = str_find(Documentator_n, m2runtime_CHR(40));
/*309*/ 			if( (Documentator_j < 0) ){
/*310*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"missing ( in method name");
/*312*/ 			}
/*312*/ 			if( Documentator_SearchClassFunc(Documentator_cl, m2runtime_substr(Documentator_n, 0, Documentator_j, 1, Documentator_0err_entry_get, 45)) == NULL ){
/*313*/ 				return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"method not found");
/*315*/ 			} else {
/*315*/ 				return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 46));
/*318*/ 			}
/*319*/ 		}
/*319*/ 		Documentator_cl_c = Documentator_SearchClassConst(Documentator_cl, Documentator_n);
/*320*/ 		if( Documentator_cl_c != NULL ){
/*321*/ 			return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl_c, 16, Documentator_0err_entry_get, 47));
/*324*/ 		}
/*324*/ 		return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"class constant not found");
/*327*/ 	}
/*327*/ 	if( (((Documentator_tlen > 2)) && (m2runtime_strcmp(m2runtime_substr(Documentator_t, (Documentator_tlen - 1), 0, 0, Documentator_0err_entry_get, 48), m2runtime_CHR(41)) == 0)) ){
/*328*/ 		Documentator_j = str_find(Documentator_t, m2runtime_CHR(40));
/*329*/ 		if( (Documentator_j < 0) ){
/*330*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"missing ( in function name");
/*332*/ 		}
/*332*/ 		Documentator_f = Documentator_SearchFunc(m2runtime_substr(Documentator_t, 0, Documentator_j, 1, Documentator_0err_entry_get, 49));
/*333*/ 		if( Documentator_f == NULL ){
/*334*/ 			return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"function not found");
/*336*/ 		}
/*336*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 50));
/*339*/ 	}
/*339*/ 	Documentator_cl = Documentator_SearchClass(Documentator_t);
/*340*/ 	if( Documentator_cl != NULL ){
/*341*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 51));
/*344*/ 	}
/*344*/ 	Documentator_c = Documentator_SearchConst(Documentator_t);
/*345*/ 	if( Documentator_c != NULL ){
/*346*/ 		return Documentator_report((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 52));
/*349*/ 	}
/*349*/ 	return Documentator_err((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"constant / class not found");
/*353*/ }


/*354*/ void
/*354*/ Documentator_AnchorToClass(RECORD *Documentator_c)
/*354*/ {
/*356*/ 	STRING * Documentator_name = NULL;
/*356*/ 	Documentator_name = (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 53);
/*357*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 54) ){
/*358*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"the class ", Documentator_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)" is private and cannot be referenced", 1));
/*359*/ 		Documentator_p(Documentator_name);
/*361*/ 	} else {
/*361*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(Documentator_name), Documentator_name));
/*364*/ 	}
/*366*/ }


/*367*/ STRING *
/*367*/ Documentator_ResolveTag(STRING *Documentator_tag, STRING *Documentator_arg)
/*367*/ {
/*369*/ 	STRING * Documentator_s = NULL;
/*369*/ 	if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"package") == 0 ){
/*370*/ 		Documentator_package = Documentator_arg;
/*371*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"version") == 0 ){
/*372*/ 		Documentator_version = Documentator_arg;
/*373*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"copyright") == 0 ){
/*374*/ 		Documentator_copyright = Documentator_arg;
/*375*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"license") == 0 ){
/*376*/ 		Documentator_license = Documentator_arg;
/*377*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"author") == 0 ){
/*378*/ 		if( (m2runtime_length(Documentator_authors) == 0) ){
/*379*/ 			Documentator_authors = Documentator_arg;
/*381*/ 		} else {
/*381*/ 			Documentator_authors = m2runtime_concat_STRING(0, Documentator_authors, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", Documentator_arg, 1);
/*383*/ 		}
/*383*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"since") == 0 ){
/*384*/ 		Documentator_since = Documentator_arg;
/*385*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"item") == 0 ){
/*386*/ 		return Documentator_Anchor(Documentator_ItemToUrl(Documentator_arg), Documentator_arg);
/*387*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"deprecated") == 0 ){
/*388*/ 		Documentator_deprecated = Documentator_arg;
/*389*/ 	} else if( m2runtime_strcmp(Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"see") == 0 ){
/*390*/ 		Documentator_s = Documentator_Anchor(Documentator_ItemToUrl(Documentator_arg), Documentator_arg);
/*391*/ 		if( (m2runtime_length(Documentator_see) == 0) ){
/*392*/ 			Documentator_see = Documentator_s;
/*394*/ 		} else {
/*394*/ 			Documentator_see = m2runtime_concat_STRING(0, Documentator_see, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", Documentator_s, 1);
/*397*/ 		}
/*397*/ 	} else {
/*397*/ 		Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"undefined tag <@", Documentator_tag, m2runtime_CHR(62), 1));
/*399*/ 	}
/*399*/ 	return EMPTY_STRING;
/*403*/ }


/*408*/ STRING *
/*408*/ Documentator_ResolveTags(STRING *Documentator_s)
/*408*/ {
/*409*/ 	int Documentator_i = 0;
/*410*/ 	STRING * Documentator_r = NULL;
/*410*/ 	STRING * Documentator_arg = NULL;
/*410*/ 	STRING * Documentator_tag = NULL;
/*411*/ 	int Documentator_l = 0;
/*413*/ 	int Documentator_recursive_tags = 0;
/*414*/ 	do {
/*414*/ 		Documentator_i = str_find(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<@");
/*415*/ 		if( (Documentator_i < 0) ){
/*416*/ 			return m2runtime_concat_STRING(0, Documentator_r, Documentator_s, 1);
/*418*/ 		}
/*418*/ 		Documentator_r = m2runtime_concat_STRING(0, Documentator_r, m2runtime_substr(Documentator_s, 0, Documentator_i, 1, Documentator_0err_entry_get, 55), 1);
/*419*/ 		m2_inc(&Documentator_i, 2);
/*422*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 56))) ){
/*423*/ 			m2_inc(&Documentator_i, 1);
/*427*/ 		}
/*427*/ 		Documentator_tag = NULL;
/*428*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && !Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 57)) && (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 58), m2runtime_CHR(62)) != 0)) ){
/*429*/ 			Documentator_tag = m2runtime_concat_STRING(0, Documentator_tag, m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 59), 1);
/*430*/ 			m2_inc(&Documentator_i, 1);
/*434*/ 		}
/*434*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 60))) ){
/*435*/ 			m2_inc(&Documentator_i, 1);
/*439*/ 		}
/*439*/ 		Documentator_arg = NULL;
/*440*/ 		Documentator_recursive_tags = FALSE;
/*441*/ 		Documentator_l = 0;
/*442*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && ((((Documentator_l > 0)) || (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 61), m2runtime_CHR(62)) != 0)))) ){
/*443*/ 			Documentator_arg = m2runtime_concat_STRING(0, Documentator_arg, m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 62), 1);
/*444*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 63), m2runtime_CHR(60)) == 0 ){
/*445*/ 				Documentator_recursive_tags = TRUE;
/*446*/ 				m2_inc(&Documentator_l, 1);
/*448*/ 			}
/*448*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 64), m2runtime_CHR(62)) == 0 ){
/*449*/ 				m2_inc(&Documentator_l, -1);
/*451*/ 			}
/*451*/ 			m2_inc(&Documentator_i, 1);
/*455*/ 		}
/*455*/ 		while( (((Documentator_i < m2runtime_length(Documentator_s))) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 65))) ){
/*456*/ 			m2_inc(&Documentator_i, 1);
/*459*/ 		}
/*459*/ 		if( (((Documentator_i == m2runtime_length(Documentator_s))) || (m2runtime_strcmp(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 66), m2runtime_CHR(62)) != 0)) ){
/*460*/ 			Documentator_DocError(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"missing closing > IN <@", Documentator_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"...>\012", 1));
/*462*/ 		} else {
/*462*/ 			m2_inc(&Documentator_i, 1);
/*465*/ 		}
/*465*/ 		if( Documentator_recursive_tags ){
/*466*/ 			Documentator_arg = Documentator_ResolveTags(Documentator_arg);
/*469*/ 		}
/*469*/ 		Documentator_r = m2runtime_concat_STRING(0, Documentator_r, Documentator_ResolveTag(Documentator_tag, Documentator_arg), 1);
/*470*/ 		Documentator_s = m2runtime_substr(Documentator_s, Documentator_i, m2runtime_length(Documentator_s), 1, Documentator_0err_entry_get, 67);
/*471*/ 	} while( !( (m2runtime_length(Documentator_s) == 0) ));
/*472*/ 	return Documentator_r;
/*476*/ }


/*477*/ STRING *
/*477*/ Documentator_trim(STRING *Documentator_s)
/*477*/ {
/*479*/ 	int Documentator_len = 0;
/*479*/ 	int Documentator_j = 0;
/*479*/ 	int Documentator_i = 0;
/*479*/ 	Documentator_len = m2runtime_length(Documentator_s);
/*480*/ 	if( (Documentator_len == 0) ){
/*481*/ 		return NULL;
/*484*/ 	}
/*484*/ 	Documentator_i = 0;
/*485*/ 	while( (((Documentator_i < Documentator_len)) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 68))) ){
/*486*/ 		m2_inc(&Documentator_i, 1);
/*489*/ 	}
/*489*/ 	Documentator_j = (Documentator_len - 1);
/*490*/ 	while( (((Documentator_j >= Documentator_i)) && Documentator_is_space(m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 69))) ){
/*491*/ 		m2_inc(&Documentator_j, -1);
/*494*/ 	}
/*494*/ 	return m2runtime_substr(Documentator_s, Documentator_i, (Documentator_j + 1), 1, Documentator_0err_entry_get, 70);
/*498*/ }


/*500*/ void
/*500*/ Documentator_VSpaceBeforeItem(int Documentator_big)
/*500*/ {
/*500*/ 	if( Documentator_prev_item_big_vspace ){
/*502*/ 		return ;
/*502*/ 	} else if( Documentator_big ){
/*503*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"<PRE>\012\012</PRE>\012");
/*505*/ 	} else {
/*505*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*508*/ 	}
/*510*/ }


/*512*/ void
/*512*/ Documentator_VSpaceAfterItem(int Documentator_big)
/*512*/ {
/*512*/ 	if( Documentator_big ){
/*513*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"<PRE>\012\012</PRE>\012");
/*515*/ 	}
/*515*/ 	Documentator_prev_item_big_vspace = Documentator_big;
/*519*/ }


/*521*/ void
/*521*/ Documentator_ItemAnchor(STRING *Documentator_s)
/*521*/ {
/*521*/ 	Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"\012<A name=\042", Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"\042></A>\012", 1));
/*525*/ }


/*533*/ void
/*533*/ Documentator_DocString(STRING *Documentator_s)
/*533*/ {

/*535*/ 	STRING *
/*535*/ 	Documentator_hex(int Documentator_h)
/*535*/ 	{
/*535*/ 		if( (Documentator_h < 10) ){
/*536*/ 			return m2runtime_CHR((m2runtime_ASC(m2runtime_CHR(48)) + Documentator_h));
/*538*/ 		} else {
/*538*/ 			return m2runtime_CHR(((m2runtime_ASC(m2runtime_CHR(65)) + Documentator_h) - 10));
/*541*/ 		}
/*541*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 71);
/*541*/ 		return NULL;
/*543*/ 	}

/*544*/ 	STRING * Documentator_c = NULL;
/*546*/ 	int Documentator_ch = 0;
/*546*/ 	int Documentator_i = 0;
/*546*/ 	if( m2runtime_strcmp(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL") == 0 ){
/*548*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*550*/ 		return ;
/*551*/ 	}
/*551*/ 	Documentator_p(m2runtime_CHR(34));
/*552*/ 	{
/*552*/ 		int m2runtime_for_limit_1;
/*552*/ 		Documentator_i = 0;
/*552*/ 		m2runtime_for_limit_1 = (m2runtime_length(Documentator_s) - 1);
/*553*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*553*/ 			Documentator_c = m2runtime_substr(Documentator_s, Documentator_i, 0, 0, Documentator_0err_entry_get, 72);
/*554*/ 			Documentator_ch = m2runtime_ASC(Documentator_c);
/*556*/ 			if( (((Documentator_ch <= 31)) || ((Documentator_ch >= 127))) ){
/*557*/ 				if( (Documentator_ch == 10) ){
/*557*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134n");
/*558*/ 				} else if( (Documentator_ch == 13) ){
/*558*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134r");
/*559*/ 				} else if( (Documentator_ch == 9) ){
/*559*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134t");
/*561*/ 				} else {
/*561*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134x");
/*562*/ 					Documentator_p(Documentator_hex((Documentator_ch / 16)));
/*563*/ 					Documentator_p(Documentator_hex((Documentator_ch % 16)));
/*566*/ 				}
/*566*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(32)) == 0 ){
/*566*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&nbsp;");
/*567*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(92)) == 0 ){
/*567*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134\134");
/*568*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(34)) == 0 ){
/*568*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\134\042");
/*569*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(38)) == 0 ){
/*569*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"&amp;");
/*570*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(60)) == 0 ){
/*570*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*571*/ 			} else if( m2runtime_strcmp(Documentator_c, m2runtime_CHR(62)) == 0 ){
/*571*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&gt;");
/*572*/ 			} else {
/*572*/ 				Documentator_p(Documentator_c);
/*575*/ 			}
/*575*/ 		}
/*575*/ 	}
/*575*/ 	Documentator_p(m2runtime_CHR(34));
/*579*/ }


/*581*/ void
/*581*/ Documentator_DocValue(RECORD *Documentator_t, STRING *Documentator_v)
/*581*/ {
/*581*/ 	if( Documentator_t == NULL ){
/*582*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"<I>FIXME_UNKNOWN_TYPE</I>");
/*584*/ 		return ;
/*585*/ 	}
/*585*/ 	if( Documentator_v == NULL ){
/*586*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"<I>FIXME_UNKNOWN_VALUE</I>");
/*588*/ 		return ;
/*589*/ 	}
/*589*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 73) == 5) ){
/*590*/ 		if( m2runtime_strcmp(Documentator_v, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"NIL") == 0 ){
/*591*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*594*/ 		} else {
/*594*/ 			Documentator_DocString(Documentator_v);
/*596*/ 		}
/*596*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 74) == 0) ){
/*597*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL");
/*599*/ 	} else {
/*599*/ 		Documentator_p(Documentator_v);
/*602*/ 	}
/*604*/ }


/*606*/ void
/*606*/ Documentator_sort(ARRAY *Documentator_a)
/*606*/ {
/*607*/ 	int Documentator_j = 0;
/*607*/ 	int Documentator_i = 0;
/*609*/ 	STRING * Documentator_t = NULL;
/*609*/ 	{
/*609*/ 		int m2runtime_for_limit_1;
/*609*/ 		Documentator_i = 0;
/*609*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_a) - 2);
/*610*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*610*/ 			{
/*610*/ 				int m2runtime_for_limit_2;
/*610*/ 				Documentator_j = (Documentator_i + 1);
/*610*/ 				m2runtime_for_limit_2 = (m2runtime_count(Documentator_a) - 1);
/*611*/ 				for( ; Documentator_j <= m2runtime_for_limit_2; Documentator_j += 1 ){
/*611*/ 					if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_j, Documentator_0err_entry_get, 75), (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_i, Documentator_0err_entry_get, 76)) > 0 ){
/*612*/ 						Documentator_t = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_j, Documentator_0err_entry_get, 77);
/*612*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_a, 4, 1, Documentator_j, Documentator_0err_entry_get, 78) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_a, Documentator_i, Documentator_0err_entry_get, 79);
/*612*/ 						*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_a, 4, 1, Documentator_i, Documentator_0err_entry_get, 80) = Documentator_t;
/*615*/ 					}
/*616*/ 				}
/*616*/ 			}
/*617*/ 		}
/*617*/ 	}
/*620*/ }

/*623*/ void * Documentator_descr = NULL;

/*632*/ void
/*632*/ Documentator_DocDescr(int Documentator_pkg_descr, STRING *Documentator_s)
/*632*/ {
/*633*/ 	int Documentator_i = 0;
/*634*/ 	STRING * Documentator_long = NULL;
/*634*/ 	STRING * Documentator_short = NULL;
/*635*/ 	STRING * Documentator_path = NULL;
/*636*/ 	RECORD * Documentator_pkg = NULL;
/*638*/ 	int Documentator_none = 0;
/*641*/ 	if( (!Documentator_pkg_descr && (Documentator_s == NULL)) ){
/*643*/ 		return ;
/*646*/ 	}
/*646*/ 	Documentator_package = NULL;
/*647*/ 	Documentator_version = NULL;
/*648*/ 	Documentator_copyright = NULL;
/*649*/ 	Documentator_license = NULL;
/*650*/ 	Documentator_authors = NULL;
/*651*/ 	Documentator_since = NULL;
/*652*/ 	Documentator_deprecated = NULL;
/*653*/ 	Documentator_see = NULL;
/*659*/ 	Documentator_i = str_find(Documentator_s, m2runtime_CHR(10));
/*660*/ 	if( (Documentator_i < 0) ){
/*661*/ 		Documentator_short = Documentator_ResolveTags(Documentator_trim(Documentator_s));
/*662*/ 		Documentator_long = EMPTY_STRING;
/*664*/ 	} else {
/*664*/ 		Documentator_short = Documentator_ResolveTags(Documentator_trim(m2runtime_substr(Documentator_s, 0, Documentator_i, 1, Documentator_0err_entry_get, 81)));
/*665*/ 		Documentator_long = Documentator_ResolveTags(Documentator_trim(m2runtime_substr(Documentator_s, (Documentator_i + 1), m2runtime_length(Documentator_s), 1, Documentator_0err_entry_get, 82)));
/*672*/ 	}
/*672*/ 	buffer_Empty((void *)&Documentator_descr);
/*674*/ 	if( Documentator_pkg_descr ){
/*675*/ 		if( Documentator_package == NULL ){
/*676*/ 			Documentator_package = FileName_DropExtension(FileName_Basename(Documentator_fn));
/*678*/ 		}
/*678*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<H1>", Documentator_package, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</H1>\012", 1));
/*682*/ 	} else {
/*683*/ 	}
/*683*/ 	if( m2runtime_strcmp(Documentator_short, EMPTY_STRING) > 0 ){
/*684*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<P>", Documentator_short, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</P>", 1));
/*687*/ 	}
/*687*/ 	if( Documentator_version != NULL ){
/*688*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"<P><B>Version:</B> ", Documentator_version, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*691*/ 	}
/*691*/ 	if( Documentator_copyright != NULL ){
/*692*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"<P><B>Copyright:</B> ", Documentator_copyright, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*695*/ 	}
/*695*/ 	if( Documentator_license != NULL ){
/*696*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"<P><B>License:</B> ", Documentator_license, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*699*/ 	}
/*699*/ 	if( Documentator_pkg_descr ){
/*701*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"<P><B>PHP version:</B> ");
/*702*/ 		if( (Documentator_php_ver == 4) ){
/*703*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"4</P>\012");
/*705*/ 		} else {
/*705*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"5</P>\012");
/*708*/ 		}
/*708*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"<P><B>Required modules:</B>\012");
/*709*/ 		Documentator_none = TRUE;
/*710*/ 		{
/*710*/ 			int m2runtime_for_limit_1;
/*710*/ 			Documentator_i = 0;
/*710*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_required_packages) - 1);
/*711*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*711*/ 				Documentator_pkg = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_required_packages, Documentator_i, Documentator_0err_entry_get, 83);
/*712*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 84), Documentator_fn) != 0) &&  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 20, Documentator_0err_entry_get, 85)) ){
/*713*/ 					if( !Documentator_none ){
/*714*/ 						buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*716*/ 					}
/*716*/ 					Documentator_none = FALSE;
/*717*/ 					Documentator_path = FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 86), Documentator_extension, 1)));
/*719*/ 					buffer_AddString((void *)&Documentator_descr, Documentator_Anchor(Documentator_path, FileName_Basename((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 87))));
/*722*/ 				}
/*722*/ 			}
/*722*/ 		}
/*722*/ 		if( Documentator_none ){
/*723*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"<I>none</I>");
/*725*/ 		}
/*725*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*727*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<P><B>Required packages:</B>\012");
/*728*/ 		Documentator_none = TRUE;
/*729*/ 		{
/*729*/ 			int m2runtime_for_limit_1;
/*729*/ 			Documentator_i = 0;
/*729*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_required_packages) - 1);
/*730*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*730*/ 				Documentator_pkg = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_required_packages, Documentator_i, Documentator_0err_entry_get, 88);
/*731*/ 				if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 89), Documentator_fn) != 0) && ! *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 20, Documentator_0err_entry_get, 90)) ){
/*732*/ 					if( !Documentator_none ){
/*733*/ 						buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*735*/ 					}
/*735*/ 					Documentator_none = FALSE;
/*736*/ 					Documentator_path = FileName_Relative(Documentator_fn_remapped, Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 91)), Documentator_extension, 1)));
/*738*/ 					buffer_AddString((void *)&Documentator_descr, Documentator_Anchor(Documentator_path, FileName_Basename(FileName_Relative(Documentator_fn_remapped, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pkg, 8, Documentator_0err_entry_get, 92)))));
/*746*/ 				}
/*746*/ 			}
/*746*/ 		}
/*746*/ 		if( Documentator_none ){
/*747*/ 			buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"<I>none</I>");
/*749*/ 		}
/*749*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012");
/*752*/ 	}
/*752*/ 	if( (m2runtime_count(Documentator_include_path) > 0) ){
/*753*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)"<P><B>include_path must resolve these packages:</B>\012");
/*754*/ 		{
/*754*/ 			int m2runtime_for_limit_1;
/*754*/ 			Documentator_i = 0;
/*754*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_include_path) - 1);
/*755*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*755*/ 				if( (Documentator_i > 0) ){
/*756*/ 					buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*758*/ 				}
/*758*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<code>");
/*759*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_include_path, Documentator_i, Documentator_0err_entry_get, 93));
/*760*/ 				buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</code>");
/*762*/ 			}
/*762*/ 		}
/*762*/ 		buffer_AddString((void *)&Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012");
/*765*/ 	}
/*765*/ 	if( Documentator_authors != NULL ){
/*766*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"<P><B>Author:</B> ", Documentator_authors, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*769*/ 	}
/*769*/ 	if( Documentator_since != NULL ){
/*770*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"<P><B>Since:</B> ", Documentator_since, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*773*/ 	}
/*773*/ 	if( Documentator_deprecated != NULL ){
/*774*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"<P><B>Deprecated:</B> ", Documentator_deprecated, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</P>\012", 1));
/*777*/ 	}
/*777*/ 	if( m2runtime_strcmp(Documentator_long, EMPTY_STRING) > 0 ){
/*778*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<P>\012", Documentator_long, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</P>\012", 1));
/*781*/ 	}
/*781*/ 	if( m2runtime_strcmp(Documentator_see, EMPTY_STRING) > 0 ){
/*782*/ 		buffer_AddString((void *)&Documentator_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"<P><b>See also:</b> ", Documentator_see, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</P>\012", 1));
/*785*/ 	}
/*785*/ 	if( Documentator_pkg_descr ){
/*786*/ 		Documentator_p(buffer_ToString(Documentator_descr));
/*787*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"<HR>\012");
/*789*/ 	} else {
/*789*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"<BLOCKQUOTE>\012");
/*790*/ 		Documentator_p(buffer_ToString(Documentator_descr));
/*791*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"</BLOCKQUOTE>\012");
/*794*/ 	}
/*796*/ }


/*798*/ void
/*798*/ Documentator_AddPrivateItem(STRING *Documentator_item)
/*798*/ {
/*798*/ 	Documentator_private_items = m2runtime_concat_STRING(0, Documentator_private_items, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<code>", Documentator_item, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"</code><br>\012", 1);
/*802*/ }


/*804*/ void
/*804*/ Documentator_DocConst(RECORD *Documentator_c)
/*804*/ {
/*804*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 94) ){
/*805*/ 		Documentator_AddPrivateItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 95));
/*807*/ 		return ;
/*808*/ 	}
/*808*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 96) != NULL);
/*809*/ 	Documentator_ItemAnchor((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 97));
/*810*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<CODE><B>");
/*811*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 98));
/*812*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</B> = ");
/*813*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 99) == NULL ){
/*814*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"<i>FAILED_TO_PARSE</i>");
/*816*/ 	} else {
/*816*/ 		Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 100), 8, Documentator_0err_entry_get, 101), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 102), 12, Documentator_0err_entry_get, 103));
/*818*/ 	}
/*818*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*819*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 104));
/*820*/ 	Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 24, Documentator_0err_entry_get, 105), NULL) > 0);
/*824*/ }


/*830*/ STRING *
/*830*/ Documentator_DocType(RECORD *Documentator_t)
/*830*/ {

/*831*/ 	STRING *
/*831*/ 	Documentator_ArrayToString(RECORD *Documentator_t)
/*831*/ 	{
/*833*/ 		STRING * Documentator_x = NULL;
/*833*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 20, Documentator_0err_entry_get, 106)){

/*834*/ 		case 1:
/*834*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"[]";
/*835*/ 		break;

/*835*/ 		case 3:
/*835*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"[int]";
/*836*/ 		break;

/*836*/ 		case 5:
/*836*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"[string]";
/*837*/ 		break;

/*837*/ 		case 7:
/*837*/ 		Documentator_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"[mixed]";
/*839*/ 		break;

/*839*/ 		default: m2runtime_missing_case_in_switch(Documentator_0err_entry_get, 107);
/*839*/ 		}
/*839*/ 		Documentator_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 8, Documentator_0err_entry_get, 108);
/*840*/ 		if( Documentator_t == NULL ){
/*841*/ 			return Documentator_x;
/*842*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 109) == 6) ){
/*843*/ 			return m2runtime_concat_STRING(0, Documentator_x, Documentator_ArrayToString(Documentator_t), 1);
/*845*/ 		} else {
/*845*/ 			return m2runtime_concat_STRING(0, Documentator_x, Documentator_DocType(Documentator_t), 1);
/*848*/ 		}
/*848*/ 		m2runtime_missing_return(Documentator_0err_entry_get, 110);
/*848*/ 		return NULL;
/*849*/ 	}

/*851*/ 	RECORD * Documentator_c = NULL;
/*851*/ 	if( Documentator_t == NULL ){
/*852*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"FIXME_UNKNOWN_TYPE";
/*854*/ 	} else {
/*854*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 16, Documentator_0err_entry_get, 111)){

/*855*/ 		case 0:
/*855*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"null";
/*856*/ 		break;

/*856*/ 		case 1:
/*856*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void";
/*857*/ 		break;

/*857*/ 		case 2:
/*857*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean";
/*858*/ 		break;

/*858*/ 		case 3:
/*858*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int";
/*859*/ 		break;

/*859*/ 		case 4:
/*859*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float";
/*860*/ 		break;

/*860*/ 		case 5:
/*860*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string";
/*861*/ 		break;

/*861*/ 		case 6:
/*862*/ 		if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_t, 20, Documentator_0err_entry_get, 112) == 1)) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 8, Documentator_0err_entry_get, 113) == NULL)) ){
/*863*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array";
/*865*/ 		} else {
/*865*/ 			return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array", Documentator_ArrayToString(Documentator_t), 1);
/*867*/ 		}
/*867*/ 		break;

/*867*/ 		case 7:
/*867*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed";
/*868*/ 		break;

/*868*/ 		case 8:
/*868*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource";
/*869*/ 		break;

/*869*/ 		case 9:
/*870*/ 		Documentator_c = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_t, 12, Documentator_0err_entry_get, 114);
/*871*/ 		if( Documentator_c == NULL ){
/*872*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object";
/*873*/ 		} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 115) ){
/*874*/ 			return (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 116);
/*876*/ 		} else {
/*876*/ 			return Documentator_Anchor(Documentator_ItemToUrl((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 117)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 118));
/*879*/ 		}
/*879*/ 		break;

/*879*/ 		default: m2runtime_missing_case_in_switch(Documentator_0err_entry_get, 119);
/*880*/ 		}
/*881*/ 	}
/*881*/ 	m2runtime_missing_return(Documentator_0err_entry_get, 120);
/*881*/ 	return NULL;
/*883*/ }


/*885*/ void
/*885*/ Documentator_DocVar(RECORD *Documentator_v)
/*885*/ {
/*885*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_v, 36, Documentator_0err_entry_get, 121) ){
/*886*/ 		Documentator_AddPrivateItem(m2runtime_concat_STRING(0, m2runtime_CHR(36), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 122), 1));
/*888*/ 		return ;
/*889*/ 	}
/*889*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 123) != NULL);
/*890*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, m2runtime_CHR(36), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 124), 1));
/*891*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<CODE><I>");
/*892*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 20, Documentator_0err_entry_get, 125)));
/*893*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</I> <B>$");
/*894*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 8, Documentator_0err_entry_get, 126));
/*895*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*900*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*901*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 127));
/*902*/ 	Documentator_VSpaceAfterItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_v, 28, Documentator_0err_entry_get, 128) != NULL);
/*906*/ }


/*908*/ void
/*908*/ Documentator_DocSignature(STRING *Documentator_name, RECORD *Documentator_s)
/*908*/ {
/*909*/ 	int Documentator_i = 0;
/*910*/ 	ARRAY * Documentator_args = NULL;
/*912*/ 	RECORD * Documentator_a = NULL;
/*912*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*913*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_s, 8, Documentator_0err_entry_get, 129)));
/*914*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</I> ");
/*915*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 16, Documentator_0err_entry_get, 130) ){
/*916*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&amp; ");
/*918*/ 	}
/*918*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<B>");
/*919*/ 	Documentator_p(Documentator_name);
/*920*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</B>(");
/*921*/ 	Documentator_args = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_s, 12, Documentator_0err_entry_get, 131);
/*922*/ 	{
/*922*/ 		int m2runtime_for_limit_1;
/*922*/ 		Documentator_i = 0;
/*922*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_args) - 1);
/*923*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*923*/ 			Documentator_a = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 132);
/*924*/ 			if( (Documentator_i > 0) ){
/*925*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*927*/ 			}
/*927*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*928*/ 			Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_a, 12, Documentator_0err_entry_get, 133)));
/*929*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"</I>&nbsp;");
/*930*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_a, 20, Documentator_0err_entry_get, 134) ){
/*931*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"&amp; ");
/*933*/ 			}
/*933*/ 			Documentator_p(m2runtime_CHR(36));
/*934*/ 			Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_a, 8, Documentator_0err_entry_get, 135));
/*935*/ 			if( (Documentator_i >=  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 20, Documentator_0err_entry_get, 136)) ){
/*936*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)" = ");
/*937*/ 				Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_a, 12, Documentator_0err_entry_get, 137), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_a, 16, Documentator_0err_entry_get, 138));
/*940*/ 			}
/*940*/ 		}
/*940*/ 	}
/*940*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_s, 24, Documentator_0err_entry_get, 139) ){
/*941*/ 		if( (Documentator_i == 0) ){
/*942*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"...");
/*944*/ 		} else {
/*944*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)", ...");
/*947*/ 		}
/*947*/ 	}
/*947*/ 	Documentator_p(m2runtime_CHR(41));
/*952*/ }

/*958*/ ARRAY * Documentator_errors = NULL;

/*960*/ void
/*960*/ Documentator_DocRaisedErrors(int Documentator_errs)
/*960*/ {
/*961*/ 	int Documentator_i = 0;
/*963*/ 	int Documentator_more = 0;
/*963*/ 	if( (Documentator_errs == 0) ){
/*965*/ 		return ;
/*967*/ 	}
/*967*/ 	if( Documentator_errors == NULL ){
/*968*/ 		Documentator_errors = (
/*969*/ 			push((char*) alloc_ARRAY(4, 1)),
/*969*/ 			push((char*) (
/*969*/ 				push((char*) alloc_RECORD(16, 1)),
/*969*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_ERROR "),
/*969*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*969*/ 				*(int*) (tos()+12) = 1,
/*970*/ 				(RECORD*) pop()
/*970*/ 			)),
/*970*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*970*/ 			push((char*) (
/*970*/ 				push((char*) alloc_RECORD(16, 1)),
/*970*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"E_WARNING "),
/*970*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*970*/ 				*(int*) (tos()+12) = 2,
/*971*/ 				(RECORD*) pop()
/*971*/ 			)),
/*971*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*971*/ 			push((char*) (
/*971*/ 				push((char*) alloc_RECORD(16, 1)),
/*971*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_PARSE "),
/*971*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*971*/ 				*(int*) (tos()+12) = 4,
/*972*/ 				(RECORD*) pop()
/*972*/ 			)),
/*972*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),2) = (RECORD*) tos(), pop(),
/*972*/ 			push((char*) (
/*972*/ 				push((char*) alloc_RECORD(16, 1)),
/*972*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_NOTICE"),
/*972*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*972*/ 				*(int*) (tos()+12) = 8,
/*973*/ 				(RECORD*) pop()
/*973*/ 			)),
/*973*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),3) = (RECORD*) tos(), pop(),
/*973*/ 			push((char*) (
/*973*/ 				push((char*) alloc_RECORD(16, 1)),
/*973*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"E_CORE_ERROR"),
/*973*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*973*/ 				*(int*) (tos()+12) = 16,
/*974*/ 				(RECORD*) pop()
/*974*/ 			)),
/*974*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),4) = (RECORD*) tos(), pop(),
/*974*/ 			push((char*) (
/*974*/ 				push((char*) alloc_RECORD(16, 1)),
/*974*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"E_CORE_WARNING "),
/*974*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*974*/ 				*(int*) (tos()+12) = 32,
/*975*/ 				(RECORD*) pop()
/*975*/ 			)),
/*975*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),5) = (RECORD*) tos(), pop(),
/*975*/ 			push((char*) (
/*975*/ 				push((char*) alloc_RECORD(16, 1)),
/*975*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"E_COMPILE_ERROR"),
/*975*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*975*/ 				*(int*) (tos()+12) = 64,
/*976*/ 				(RECORD*) pop()
/*976*/ 			)),
/*976*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),6) = (RECORD*) tos(), pop(),
/*976*/ 			push((char*) (
/*976*/ 				push((char*) alloc_RECORD(16, 1)),
/*976*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"E_COMPILE_WARNING"),
/*976*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*976*/ 				*(int*) (tos()+12) = 128,
/*977*/ 				(RECORD*) pop()
/*977*/ 			)),
/*977*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),7) = (RECORD*) tos(), pop(),
/*977*/ 			push((char*) (
/*977*/ 				push((char*) alloc_RECORD(16, 1)),
/*977*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"E_USER_ERROR"),
/*977*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*977*/ 				*(int*) (tos()+12) = 256,
/*978*/ 				(RECORD*) pop()
/*978*/ 			)),
/*978*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),8) = (RECORD*) tos(), pop(),
/*978*/ 			push((char*) (
/*978*/ 				push((char*) alloc_RECORD(16, 1)),
/*978*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"E_USER_WARNING"),
/*978*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*978*/ 				*(int*) (tos()+12) = 512,
/*979*/ 				(RECORD*) pop()
/*979*/ 			)),
/*979*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),9) = (RECORD*) tos(), pop(),
/*979*/ 			push((char*) (
/*979*/ 				push((char*) alloc_RECORD(16, 1)),
/*979*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"E_USER_NOTICE"),
/*979*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*979*/ 				*(int*) (tos()+12) = 1024,
/*980*/ 				(RECORD*) pop()
/*980*/ 			)),
/*980*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),10) = (RECORD*) tos(), pop(),
/*980*/ 			push((char*) (
/*980*/ 				push((char*) alloc_RECORD(16, 1)),
/*980*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"E_STRICT"),
/*980*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*980*/ 				*(int*) (tos()+12) = 2048,
/*981*/ 				(RECORD*) pop()
/*981*/ 			)),
/*981*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),11) = (RECORD*) tos(), pop(),
/*981*/ 			push((char*) (
/*981*/ 				push((char*) alloc_RECORD(16, 1)),
/*981*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"E_RECOVERABLE_ERROR"),
/*981*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*981*/ 				*(int*) (tos()+12) = 4096,
/*983*/ 				(RECORD*) pop()
/*983*/ 			)),
/*983*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),12) = (RECORD*) tos(), pop(),
/*984*/ 			(ARRAY*) pop()
/*984*/ 		);
/*985*/ 	}
/*985*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"<br><i>triggers</i> ");
/*986*/ 	{
/*986*/ 		int m2runtime_for_limit_1;
/*986*/ 		Documentator_i = 0;
/*986*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_errors) - 1);
/*987*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*987*/ 			if( ((Documentator_errs &  *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_errors, Documentator_i, Documentator_0err_entry_get, 140), 12, Documentator_0err_entry_get, 141)) != 0) ){
/*988*/ 				if( Documentator_more ){
/*989*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*991*/ 				}
/*991*/ 				Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>", (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_errors, Documentator_i, Documentator_0err_entry_get, 142), 8, Documentator_0err_entry_get, 143), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</CODE>", 1));
/*992*/ 				Documentator_more = TRUE;
/*995*/ 			}
/*995*/ 		}
/*995*/ 	}
/*995*/ 	Documentator_p(m2runtime_CHR(10));
/*999*/ }


/*1007*/ void
/*1007*/ Documentator_SortExceptions(ARRAY *Documentator_exc)
/*1007*/ {
/*1008*/ 	int Documentator_j = 0;
/*1008*/ 	int Documentator_i = 0;
/*1010*/ 	RECORD * Documentator_t = NULL;
/*1010*/ 	{
/*1010*/ 		int m2runtime_for_limit_1;
/*1010*/ 		Documentator_i = 0;
/*1010*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_exc) - 2);
/*1011*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1011*/ 			{
/*1011*/ 				int m2runtime_for_limit_2;
/*1011*/ 				Documentator_j = (Documentator_i + 1);
/*1011*/ 				m2runtime_for_limit_2 = (m2runtime_count(Documentator_exc) - 1);
/*1012*/ 				for( ; Documentator_j <= m2runtime_for_limit_2; Documentator_j += 1 ){
/*1012*/ 					if( Classes_IsSubclassOf((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_j, Documentator_0err_entry_get, 144), (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_i, Documentator_0err_entry_get, 145)) ){
/*1013*/ 						Documentator_t = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_i, Documentator_0err_entry_get, 146);
/*1013*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Documentator_exc, 4, 1, Documentator_i, Documentator_0err_entry_get, 147) = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_j, Documentator_0err_entry_get, 148);
/*1013*/ 						*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Documentator_exc, 4, 1, Documentator_j, Documentator_0err_entry_get, 149) = Documentator_t;
/*1016*/ 					}
/*1017*/ 				}
/*1017*/ 			}
/*1018*/ 		}
/*1018*/ 	}
/*1020*/ }


/*1023*/ void
/*1023*/ Documentator_DocThrownExceptions(ARRAY *Documentator_exc)
/*1023*/ {
/*1024*/ 	int Documentator_i = 0;
/*1026*/ 	RECORD * Documentator_e = NULL;
/*1026*/ 	if( (m2runtime_count(Documentator_exc) == 0) ){
/*1028*/ 		return ;
/*1029*/ 	}
/*1029*/ 	Documentator_SortExceptions(Documentator_exc);
/*1030*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"<br><i>throws</i> ");
/*1031*/ 	Documentator_exc = Classes_Sort(Documentator_exc);
/*1032*/ 	{
/*1032*/ 		int m2runtime_for_limit_1;
/*1032*/ 		Documentator_i = 0;
/*1032*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_exc) - 1);
/*1033*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1033*/ 			if( (Documentator_i > 0) ){
/*1034*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*1036*/ 			}
/*1036*/ 			Documentator_e = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_i, Documentator_0err_entry_get, 150);
/*1037*/ 			if( Documentator_e == NULL ){
/*1038*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"<i>FIXME_UNKNOWN_EXCEPTION</i>");
/*1040*/ 			} else {
/*1040*/ 				Documentator_AnchorToClass(Documentator_e);
/*1043*/ 			}
/*1044*/ 		}
/*1044*/ 	}
/*1046*/ }


/*1051*/ void
/*1051*/ Documentator_DocThrownExceptionsDescr(ARRAY *Documentator_exc, ARRAY *Documentator_descrs)
/*1051*/ {
/*1052*/ 	int Documentator_j = 0;
/*1052*/ 	int Documentator_i = 0;
/*1054*/ 	RECORD * Documentator_e = NULL;
/*1054*/ 	if( (m2runtime_count(Documentator_exc) == 0) ){
/*1056*/ 		return ;
/*1057*/ 	}
/*1057*/ 	Documentator_SortExceptions(Documentator_exc);
/*1058*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"<blockquote>\012<b>Thrown exceptions:</b>\012");
/*1059*/ 	{
/*1059*/ 		int m2runtime_for_limit_1;
/*1059*/ 		Documentator_i = 0;
/*1059*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_exc) - 1);
/*1060*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1061*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<li>");
/*1064*/ 			Documentator_e = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_exc, Documentator_i, Documentator_0err_entry_get, 151);
/*1065*/ 			if( Documentator_e == NULL ){
/*1066*/ 				Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"<i>FIXME_UNKNOWN_EXCEPTION</i>");
/*1068*/ 			} else {
/*1068*/ 				Documentator_AnchorToClass(Documentator_e);
/*1072*/ 			}
/*1072*/ 			Documentator_j = (m2runtime_count(Documentator_descrs) - 1);
/*1074*/ 			do{
/*1074*/ 				if( (Documentator_j < 0) ){
/*1077*/ 					goto m2runtime_loop_1;
/*1077*/ 				}
/*1077*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_descrs, Documentator_j, Documentator_0err_entry_get, 152), 8, Documentator_0err_entry_get, 153), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_e, 12, Documentator_0err_entry_get, 154)) == 0 ){
/*1080*/ 					goto m2runtime_loop_1;
/*1080*/ 				}
/*1080*/ 				m2_inc(&Documentator_j, -1);
/*1082*/ 			}while(TRUE);
m2runtime_loop_1: ;
/*1082*/ 			if( (Documentator_j >= 0) ){
/*1083*/ 				Documentator_p(m2runtime_concat_STRING(0, m2runtime_CHR(32), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_descrs, Documentator_j, Documentator_0err_entry_get, 155), 12, Documentator_0err_entry_get, 156), 1));
/*1086*/ 			}
/*1086*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"\012</li>\012");
/*1088*/ 		}
/*1088*/ 	}
/*1088*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"</ul>\012</blockquote>\012");
/*1092*/ }


/*1094*/ void
/*1094*/ Documentator_DocFunc(RECORD *Documentator_f)
/*1094*/ {
/*1094*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_f, 52, Documentator_0err_entry_get, 157) ){
/*1095*/ 		Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 158), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1097*/ 		return ;
/*1098*/ 	}
/*1098*/ 	Documentator_VSpaceBeforeItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 40, Documentator_0err_entry_get, 159) != NULL);
/*1099*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 160), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1100*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1101*/ 	Documentator_DocSignature((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 8, Documentator_0err_entry_get, 161), (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 28, Documentator_0err_entry_get, 162));
/*1102*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1103*/ 	Documentator_DocRaisedErrors( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_f, 60, Documentator_0err_entry_get, 163));
/*1104*/ 	Documentator_DocThrownExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_f, 32, Documentator_0err_entry_get, 164));
/*1105*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 40, Documentator_0err_entry_get, 165));
/*1106*/ 	Documentator_DocThrownExceptionsDescr((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_f, 32, Documentator_0err_entry_get, 166), (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_f, 36, Documentator_0err_entry_get, 167));
/*1107*/ 	Documentator_VSpaceAfterItem(((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_f, 40, Documentator_0err_entry_get, 168), NULL) > 0) || ((m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_f, 36, Documentator_0err_entry_get, 169)) > 0))));
/*1112*/ }


/*1119*/ void
/*1119*/ Documentator_DocClassConst(RECORD *Documentator_cl, RECORD *Documentator_parent, RECORD *Documentator_c)
/*1119*/ {
/*1119*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 170) == 0) ){
/*1121*/ 		return ;
/*1122*/ 	}
/*1122*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 171) != NULL)));
/*1123*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 8, Documentator_0err_entry_get, 172), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 173), 1));
/*1124*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"<CODE>const <B>");
/*1125*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 174));
/*1126*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</B> = ");
/*1127*/ 	Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 175), 8, Documentator_0err_entry_get, 176), (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 177), 12, Documentator_0err_entry_get, 178));
/*1128*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1129*/ 	if( Documentator_parent == NULL ){
/*1130*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 179));
/*1131*/ 		Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 180), NULL) > 0);
/*1133*/ 	} else {
/*1133*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"<BR><I>inherited from</i> <CODE>");
/*1134*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 181), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 182), 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 183)));
/*1135*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1136*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1139*/ 	}
/*1141*/ }


/*1143*/ void
/*1143*/ Documentator_DocClassProperty(RECORD *Documentator_c, RECORD *Documentator_parent, RECORD *Documentator_pr)
/*1143*/ {
/*1143*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 32, Documentator_0err_entry_get, 184) == 0) ){
/*1144*/ 		if( ((Documentator_parent == NULL) && ((Documentator_php_ver == 4))) ){
/*1145*/ 			Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 185), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 186), 1));
/*1148*/ 		}
/*1148*/ 		return ;
/*1149*/ 	}
/*1149*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 187) != NULL)));
/*1150*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 188), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 189), 1));
/*1151*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1152*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 32, Documentator_0err_entry_get, 190) == 1) ){
/*1153*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"protected ");
/*1155*/ 	}
/*1155*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 36, Documentator_0err_entry_get, 191) ){
/*1156*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"static ");
/*1163*/ 	}
/*1163*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<I>");
/*1164*/ 	Documentator_p(Documentator_DocType((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 192)));
/*1165*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</I> <B>$");
/*1166*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 193));
/*1167*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*1168*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 194) != NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 16, Documentator_0err_entry_get, 195) != NULL)) ){
/*1169*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)" = ");
/*1170*/ 		Documentator_DocValue((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 12, Documentator_0err_entry_get, 196), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 16, Documentator_0err_entry_get, 197));
/*1172*/ 	}
/*1172*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1173*/ 	if( Documentator_parent == NULL ){
/*1174*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 198));
/*1175*/ 		Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 24, Documentator_0err_entry_get, 199), NULL) > 0);
/*1177*/ 	} else {
/*1177*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"<BR><I>inherited from</i> ");
/*1178*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 200), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_pr, 8, Documentator_0err_entry_get, 201), 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 202)));
/*1179*/ 		Documentator_p(m2runtime_CHR(10));
/*1180*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1183*/ 	}
/*1185*/ }


/*1187*/ void
/*1187*/ Documentator_DocClassMethod(RECORD *Documentator_c, RECORD *Documentator_parent, RECORD *Documentator_m)
/*1187*/ {
/*1187*/ 	if( ((Documentator_parent == NULL) && (( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 52, Documentator_0err_entry_get, 203) == 0))) ){
/*1188*/ 		if( (Documentator_php_ver == 4) ){
/*1189*/ 			Documentator_AddPrivateItem(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 204), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 205), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1192*/ 		}
/*1192*/ 		return ;
/*1194*/ 	}
/*1194*/ 	Documentator_VSpaceBeforeItem(((Documentator_parent == NULL) && ((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 36, Documentator_0err_entry_get, 206) != NULL)));
/*1195*/ 	Documentator_ItemAnchor(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 207), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 208), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1));
/*1196*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1197*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 48, Documentator_0err_entry_get, 209) && ! *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 210)) ){
/*1197*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"abstract ");
/*1198*/ 	}
/*1198*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 52, Documentator_0err_entry_get, 211) == 1) ){
/*1198*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"protected ");
/*1199*/ 	}
/*1199*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 56, Documentator_0err_entry_get, 212) ){
/*1199*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"static ");
/*1200*/ 	}
/*1200*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 60, Documentator_0err_entry_get, 213) ){
/*1200*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"final ");
/*1201*/ 	}
/*1201*/ 	Documentator_DocSignature((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 214), (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_m, 16, Documentator_0err_entry_get, 215));
/*1202*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1203*/ 	Documentator_DocRaisedErrors( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 72, Documentator_0err_entry_get, 216));
/*1204*/ 	Documentator_DocThrownExceptions((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_m, 28, Documentator_0err_entry_get, 217));
/*1205*/ 	if( Documentator_parent == NULL ){
/*1206*/ 		Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 36, Documentator_0err_entry_get, 218));
/*1207*/ 		Documentator_DocThrownExceptionsDescr((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_m, 28, Documentator_0err_entry_get, 219), (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_m, 32, Documentator_0err_entry_get, 220));
/*1208*/ 		Documentator_VSpaceAfterItem(((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 36, Documentator_0err_entry_get, 221), NULL) > 0) || ((m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_m, 32, Documentator_0err_entry_get, 222)) > 0))));
/*1211*/ 	} else {
/*1211*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"<BR><I>inherited from</i> ");
/*1212*/ 		Documentator_p(Documentator_Anchor(Documentator_ItemToUrl(m2runtime_concat_STRING(0, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 223), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 224), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"()", 1)), (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_parent, 8, Documentator_0err_entry_get, 225)));
/*1213*/ 		Documentator_p(m2runtime_CHR(10));
/*1214*/ 		Documentator_VSpaceAfterItem(FALSE);
/*1217*/ 	}
/*1219*/ }


/*1220*/ int
/*1220*/ Documentator_NotInList(STRING *Documentator_name, ARRAY **Documentator_l)
/*1220*/ {
/*1222*/ 	int Documentator_i = 0;
/*1222*/ 	{
/*1222*/ 		int m2runtime_for_limit_1;
/*1222*/ 		Documentator_i = 0;
/*1222*/ 		m2runtime_for_limit_1 = (m2runtime_count(*Documentator_l) - 1);
/*1223*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1223*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(*Documentator_l, Documentator_i, Documentator_0err_entry_get, 226), Documentator_name) == 0 ){
/*1224*/ 				return FALSE;
/*1227*/ 			}
/*1227*/ 		}
/*1227*/ 	}
/*1227*/ 	*(STRING **)m2runtime_dereference_lhs_ARRAY(Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 227) = Documentator_name;
/*1228*/ 	return TRUE;
/*1232*/ }


/*1234*/ void
/*1234*/ Documentator_DocInheritedConsts(RECORD *Documentator_cl)
/*1234*/ {
/*1235*/ 	ARRAY * Documentator_l = NULL;
/*1236*/ 	ARRAY * Documentator_consts = NULL;
/*1237*/ 	RECORD * Documentator_p = NULL;
/*1239*/ 	int Documentator_i = 0;
/*1239*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 228) == NULL ){
/*1241*/ 		return ;
/*1242*/ 	}
/*1242*/ 	Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 28, Documentator_0err_entry_get, 229);
/*1243*/ 	{
/*1243*/ 		int m2runtime_for_limit_1;
/*1243*/ 		Documentator_i = 0;
/*1243*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1244*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1244*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 230) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 231), 8, Documentator_0err_entry_get, 232);
/*1246*/ 		}
/*1246*/ 	}
/*1246*/ 	Documentator_p = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 233);
/*1248*/ 	do {
/*1248*/ 		Documentator_consts = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_p, 28, Documentator_0err_entry_get, 234);
/*1249*/ 		{
/*1249*/ 			int m2runtime_for_limit_1;
/*1249*/ 			Documentator_i = 0;
/*1249*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1250*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1250*/ 				if( ((( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 235), 28, Documentator_0err_entry_get, 236) != 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 237), 8, Documentator_0err_entry_get, 238), &Documentator_l)) ){
/*1252*/ 					Documentator_DocClassConst(Documentator_cl, Documentator_p, (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 239));
/*1255*/ 				}
/*1255*/ 			}
/*1255*/ 		}
/*1255*/ 		Documentator_p = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_p, 16, Documentator_0err_entry_get, 240);
/*1256*/ 	} while( !( Documentator_p == NULL ));
/*1260*/ }


/*1262*/ void
/*1262*/ Documentator_DocInheritedProperties(RECORD *Documentator_cl)
/*1262*/ {
/*1263*/ 	ARRAY * Documentator_l = NULL;
/*1264*/ 	ARRAY * Documentator_properties = NULL;
/*1266*/ 	int Documentator_i = 0;

/*1268*/ 	void
/*1268*/ 	Documentator_ScanProperties(RECORD *Documentator_c)
/*1268*/ 	{
/*1269*/ 		ARRAY * Documentator_properties = NULL;
/*1271*/ 		int Documentator_i = 0;
/*1271*/ 		if( Documentator_c == NULL ){
/*1273*/ 			return ;
/*1274*/ 		}
/*1274*/ 		Documentator_properties = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 241);
/*1275*/ 		{
/*1275*/ 			int m2runtime_for_limit_1;
/*1275*/ 			Documentator_i = 0;
/*1275*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_properties) - 1);
/*1276*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1276*/ 				if( (!(( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 242), 32, Documentator_0err_entry_get, 243) == 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 244), 8, Documentator_0err_entry_get, 245), &Documentator_l)) ){
/*1278*/ 					Documentator_DocClassProperty(Documentator_cl, Documentator_c, (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 246));
/*1281*/ 				}
/*1282*/ 			}
/*1282*/ 		}
/*1283*/ 	}


/*1284*/ 	void
/*1284*/ 	Documentator_ScanPropertiesRecursive(RECORD *Documentator_c)
/*1284*/ 	{
/*1286*/ 		int Documentator_i = 0;
/*1286*/ 		if( Documentator_c == NULL ){
/*1288*/ 			return ;
/*1289*/ 		}
/*1289*/ 		Documentator_ScanProperties(Documentator_c);
/*1290*/ 		Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 247));
/*1291*/ 		{
/*1291*/ 			int m2runtime_for_limit_1;
/*1291*/ 			Documentator_i = 0;
/*1291*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 248)) - 1);
/*1292*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1292*/ 				Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 249), Documentator_i, Documentator_0err_entry_get, 250));
/*1295*/ 			}
/*1295*/ 		}
/*1297*/ 	}

/*1297*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 251) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 252) == NULL)) ){
/*1299*/ 		return ;
/*1302*/ 	}
/*1302*/ 	Documentator_properties = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 32, Documentator_0err_entry_get, 253);
/*1303*/ 	{
/*1303*/ 		int m2runtime_for_limit_1;
/*1303*/ 		Documentator_i = 0;
/*1303*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_properties) - 1);
/*1304*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1304*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 254) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_properties, Documentator_i, Documentator_0err_entry_get, 255), 8, Documentator_0err_entry_get, 256);
/*1308*/ 		}
/*1308*/ 	}
/*1308*/ 	Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 257));
/*1311*/ 	if( !(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 72, Documentator_0err_entry_get, 258) ||  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 76, Documentator_0err_entry_get, 259))) ){
/*1313*/ 		return ;
/*1314*/ 	}
/*1314*/ 	{
/*1314*/ 		int m2runtime_for_limit_1;
/*1314*/ 		Documentator_i = 0;
/*1314*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 260)) - 1);
/*1315*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1315*/ 			Documentator_ScanPropertiesRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 261), Documentator_i, Documentator_0err_entry_get, 262));
/*1318*/ 		}
/*1318*/ 	}
/*1320*/ }


/*1322*/ void
/*1322*/ Documentator_DocInheritedMethods(RECORD *Documentator_cl)
/*1322*/ {
/*1323*/ 	ARRAY * Documentator_l = NULL;
/*1324*/ 	ARRAY * Documentator_methods = NULL;
/*1326*/ 	int Documentator_i = 0;

/*1328*/ 	void
/*1328*/ 	Documentator_ScanMethods(RECORD *Documentator_c)
/*1328*/ 	{
/*1329*/ 		ARRAY * Documentator_methods = NULL;
/*1330*/ 		int Documentator_i = 0;
/*1332*/ 		RECORD * Documentator_m = NULL;
/*1332*/ 		if( Documentator_c == NULL ){
/*1334*/ 			return ;
/*1335*/ 		}
/*1335*/ 		Documentator_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 263);
/*1336*/ 		{
/*1336*/ 			int m2runtime_for_limit_1;
/*1336*/ 			Documentator_i = 0;
/*1336*/ 			m2runtime_for_limit_1 = (m2runtime_count(Documentator_methods) - 1);
/*1337*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1337*/ 				Documentator_m = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_methods, Documentator_i, Documentator_0err_entry_get, 264);
/*1338*/ 				if( (!(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_m, 52, Documentator_0err_entry_get, 265) == 0)) && Documentator_NotInList((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_m, 8, Documentator_0err_entry_get, 266), &Documentator_l)) ){
/*1339*/ 					Documentator_DocClassMethod(Documentator_cl, Documentator_c, Documentator_m);
/*1342*/ 				}
/*1343*/ 			}
/*1343*/ 		}
/*1344*/ 	}


/*1345*/ 	void
/*1345*/ 	Documentator_ScanMethodsRecursive(RECORD *Documentator_c)
/*1345*/ 	{
/*1347*/ 		int Documentator_i = 0;
/*1347*/ 		if( Documentator_c == NULL ){
/*1349*/ 			return ;
/*1350*/ 		}
/*1350*/ 		Documentator_ScanMethods(Documentator_c);
/*1351*/ 		Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 267));
/*1352*/ 		{
/*1352*/ 			int m2runtime_for_limit_1;
/*1352*/ 			Documentator_i = 0;
/*1352*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 268)) - 1);
/*1353*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1353*/ 				Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 269), Documentator_i, Documentator_0err_entry_get, 270));
/*1356*/ 			}
/*1356*/ 		}
/*1358*/ 	}

/*1358*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 271) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 272) == NULL)) ){
/*1360*/ 		return ;
/*1363*/ 	}
/*1363*/ 	Documentator_methods = (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 36, Documentator_0err_entry_get, 273);
/*1364*/ 	{
/*1364*/ 		int m2runtime_for_limit_1;
/*1364*/ 		Documentator_i = 0;
/*1364*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_methods) - 1);
/*1365*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1365*/ 			*(STRING **)m2runtime_dereference_lhs_ARRAY(&Documentator_l, 4, 1, Documentator_i, Documentator_0err_entry_get, 274) = (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_methods, Documentator_i, Documentator_0err_entry_get, 275), 8, Documentator_0err_entry_get, 276);
/*1369*/ 		}
/*1369*/ 	}
/*1369*/ 	Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 16, Documentator_0err_entry_get, 277));
/*1372*/ 	if( !(( *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 72, Documentator_0err_entry_get, 278) ||  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 76, Documentator_0err_entry_get, 279))) ){
/*1374*/ 		return ;
/*1375*/ 	}
/*1375*/ 	{
/*1375*/ 		int m2runtime_for_limit_1;
/*1375*/ 		Documentator_i = 0;
/*1375*/ 		m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 280)) - 1);
/*1376*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1376*/ 			Documentator_ScanMethodsRecursive((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 20, Documentator_0err_entry_get, 281), Documentator_i, Documentator_0err_entry_get, 282));
/*1379*/ 		}
/*1379*/ 	}
/*1381*/ }


/*1383*/ void
/*1383*/ Documentator_DocClassHierarchy(RECORD *Documentator_c)
/*1383*/ {

/*1385*/ 	void
/*1385*/ 	Documentator_recurse(RECORD *Documentator_c, STRING *Documentator_indent_this, STRING *Documentator_indent_next)
/*1385*/ 	{
/*1386*/ 		int Documentator_i = 0;
/*1388*/ 		STRING * Documentator_b = NULL;
/*1388*/ 		STRING * Documentator_a = NULL;
/*1388*/ 		Documentator_p(Documentator_indent_this);
/*1389*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 283) ){
/*1390*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<i>");
/*1392*/ 		}
/*1392*/ 		Documentator_AnchorToClass(Documentator_c);
/*1393*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 284) ){
/*1394*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</i>");
/*1396*/ 		}
/*1396*/ 		Documentator_p(m2runtime_CHR(10));
/*1398*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 285) != NULL ){
/*1399*/ 			if( (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 286) == NULL ){
/*1400*/ 				Documentator_a = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" `--";
/*1401*/ 				Documentator_b = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"    ";
/*1403*/ 			} else {
/*1403*/ 				Documentator_a = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" |`-";
/*1404*/ 				Documentator_b = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" |  ";
/*1406*/ 			}
/*1406*/ 			Documentator_recurse((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 287), m2runtime_concat_STRING(0, Documentator_indent_next, Documentator_a, 1), m2runtime_concat_STRING(0, Documentator_indent_next, Documentator_b, 1));
/*1409*/ 		}
/*1409*/ 		{
/*1409*/ 			int m2runtime_for_limit_1;
/*1409*/ 			Documentator_i = 0;
/*1409*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 288)) - 1);
/*1410*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1410*/ 				if( (Documentator_i == (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 289)) - 1)) ){
/*1411*/ 					Documentator_a = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" `--";
/*1412*/ 					Documentator_b = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"    ";
/*1414*/ 				} else {
/*1414*/ 					Documentator_a = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" |`-";
/*1415*/ 					Documentator_b = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" |  ";
/*1417*/ 				}
/*1417*/ 				Documentator_recurse((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 290), Documentator_i, Documentator_0err_entry_get, 291), m2runtime_concat_STRING(0, Documentator_indent_next, Documentator_a, 1), m2runtime_concat_STRING(0, Documentator_indent_next, Documentator_b, 1));
/*1420*/ 			}
/*1420*/ 		}
/*1422*/ 	}

/*1422*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 292) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 293) == NULL)) ){
/*1424*/ 		return ;
/*1425*/ 	}
/*1425*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"<blockquote>\012<b>Hierarchy:</b><pre>");
/*1426*/ 	Documentator_recurse(Documentator_c, EMPTY_STRING, NULL);
/*1427*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"</pre>\012</blockquote>\012");
/*1431*/ }


/*1433*/ void
/*1433*/ Documentator_DocClass(RECORD *Documentator_c)
/*1433*/ {
/*1434*/ 	int Documentator_i = 0;
/*1436*/ 	RECORD * Documentator_parent = NULL;
/*1436*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 64, Documentator_0err_entry_get, 294) ){
/*1437*/ 		Documentator_AddPrivateItem((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 295));
/*1439*/ 		return ;
/*1440*/ 	}
/*1440*/ 	Documentator_VSpaceBeforeItem(TRUE);
/*1441*/ 	Documentator_curr_class = Documentator_c;
/*1442*/ 	Documentator_ItemAnchor((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 296));
/*1443*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<CODE>");
/*1444*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 72, Documentator_0err_entry_get, 297) ){
/*1445*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"abstract ");
/*1447*/ 	}
/*1447*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 68, Documentator_0err_entry_get, 298) ){
/*1448*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"final ");
/*1450*/ 	}
/*1450*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 299) ){
/*1451*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"interface");
/*1453*/ 	} else {
/*1453*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"class");
/*1455*/ 	}
/*1455*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" <B>");
/*1456*/ 	Documentator_p((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 8, Documentator_0err_entry_get, 300));
/*1457*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</B>");
/*1459*/ 	Documentator_parent = (RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 301);
/*1460*/ 	if( Documentator_parent != NULL ){
/*1461*/ 		Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"<br>\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"&nbsp;&nbsp;&nbsp;&nbsp;", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"extends ", 1));
/*1462*/ 		Documentator_AnchorToClass(Documentator_parent);
/*1465*/ 	}
/*1465*/ 	if( (ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 302) != NULL ){
/*1466*/ 		Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"<br>\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"&nbsp;&nbsp;&nbsp;&nbsp;", 1));
/*1467*/ 		if(  *(int *)m2runtime_dereference_rhs_RECORD(Documentator_c, 76, Documentator_0err_entry_get, 303) ){
/*1468*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"extends ");
/*1470*/ 		} else {
/*1470*/ 			Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"implements ");
/*1472*/ 		}
/*1472*/ 		{
/*1472*/ 			int m2runtime_for_limit_1;
/*1472*/ 			Documentator_i = 0;
/*1472*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 304)) - 1);
/*1473*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1473*/ 				if( (Documentator_i > 0) ){
/*1474*/ 					Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ");
/*1476*/ 				}
/*1476*/ 				Documentator_AnchorToClass((RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 305), Documentator_i, Documentator_0err_entry_get, 306));
/*1479*/ 			}
/*1479*/ 		}
/*1480*/ 	}
/*1480*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"</CODE>\012");
/*1481*/ 	Documentator_DocClassHierarchy(Documentator_c);
/*1482*/ 	Documentator_DocDescr(FALSE, (STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 52, Documentator_0err_entry_get, 307));
/*1483*/ 	Documentator_VSpaceAfterItem(m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Documentator_c, 52, Documentator_0err_entry_get, 308), NULL) > 0);
/*1485*/ 	Documentator_VSpaceBeforeItem(FALSE);
/*1486*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"<CODE>{</CODE>\012<BLOCKQUOTE>\012");
/*1487*/ 	Documentator_VSpaceAfterItem(FALSE);
/*1496*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 16, Documentator_0err_entry_get, 309) != NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 20, Documentator_0err_entry_get, 310) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 311) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 312) == NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 313) == NULL)) ){
/*1503*/ 		Documentator_p(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"<i>This class merely extends another class and does not add any", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)" new member. Please see the extended class for details.</i>", 1));
/*1510*/ 	} else {
/*1510*/ 		{
/*1510*/ 			int m2runtime_for_limit_1;
/*1510*/ 			Documentator_i = 0;
/*1510*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 314)) - 1);
/*1511*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1511*/ 				Documentator_DocClassConst(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 28, Documentator_0err_entry_get, 315), Documentator_i, Documentator_0err_entry_get, 316));
/*1513*/ 			}
/*1513*/ 		}
/*1513*/ 		Documentator_DocInheritedConsts(Documentator_c);
/*1515*/ 		{
/*1515*/ 			int m2runtime_for_limit_1;
/*1515*/ 			Documentator_i = 0;
/*1515*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 317)) - 1);
/*1516*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1516*/ 				Documentator_DocClassProperty(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 32, Documentator_0err_entry_get, 318), Documentator_i, Documentator_0err_entry_get, 319));
/*1518*/ 			}
/*1518*/ 		}
/*1518*/ 		Documentator_DocInheritedProperties(Documentator_c);
/*1520*/ 		{
/*1520*/ 			int m2runtime_for_limit_1;
/*1520*/ 			Documentator_i = 0;
/*1520*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 320)) - 1);
/*1521*/ 			for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1521*/ 				Documentator_DocClassMethod(Documentator_c, NULL, (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Documentator_c, 36, Documentator_0err_entry_get, 321), Documentator_i, Documentator_0err_entry_get, 322));
/*1523*/ 			}
/*1523*/ 		}
/*1523*/ 		Documentator_DocInheritedMethods(Documentator_c);
/*1527*/ 	}
/*1527*/ 	Documentator_VSpaceBeforeItem(FALSE);
/*1528*/ 	Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"</BLOCKQUOTE>\012<CODE>}</CODE>\012");
/*1529*/ 	Documentator_VSpaceAfterItem(TRUE);
/*1531*/ 	Documentator_curr_class = NULL;
/*1535*/ }


/*1537*/ void
/*1537*/ Documentator_Help(void)
/*1537*/ {
/*1537*/ 	m2_print(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"PHPLint Documentator\012\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"Options:\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"  --doc                 generate documentation\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\114,\0,\0,\0)"  --doc-extension EXT   extension of the generated documents (def. \042.html\042)\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"  --doc-page-header H   header text of the generated HTML page\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"  --doc-page-footer F   footer text of the generated HTML page\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\104,\0,\0,\0)"  --doc-ref-remap A B   remap HTML anchors references from A* to B*\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"\012More help: www.icosaedro.it/phplint/\012\012", 1));
/*1552*/ }


/*1554*/ void
/*1554*/ Documentator_Init(void)
/*1554*/ {
/*1561*/ 	Documentator_extension = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)".html";
/*1562*/ 	Documentator_page_header = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"<HTML><BODY>\012";
/*1563*/ 	Documentator_page_footer = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"\012<HR><P align=right>", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<FONT size='-2'>Generated by ", Documentator_Anchor((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"http://www.icosaedro.it/phplint/", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"PHPLint Documentator"), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"</FONT></P>\012", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"</BODY></HTML>\012", 1);
/*1571*/ }


/*1572*/ int
/*1572*/ Documentator_ParseParameter(int Documentator_i, ARRAY *Documentator_args)
/*1572*/ {
/*1574*/ 	STRING * Documentator_arg = NULL;
/*1574*/ 	Documentator_arg = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 323);
/*1575*/ 	if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"--doc-help") == 0 ){
/*1576*/ 		Documentator_Help();
/*1577*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"--doc") == 0 ){
/*1578*/ 		Documentator_generate = TRUE;
/*1579*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"--doc-extension") == 0 ){
/*1580*/ 		m2_inc(&Documentator_i, 1);
/*1581*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1582*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\56,\0,\0,\0)"phplint: missing argument for --doc-extension\012");
/*1583*/ 			m2runtime_exit(1);
/*1585*/ 		}
/*1585*/ 		Documentator_extension = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 324);
/*1586*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"--doc-page-header") == 0 ){
/*1587*/ 		m2_inc(&Documentator_i, 1);
/*1588*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1589*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: missing argument for --doc-page-header\012");
/*1590*/ 			m2runtime_exit(1);
/*1592*/ 		}
/*1592*/ 		Documentator_page_header = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 325);
/*1593*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\21,\0,\0,\0)"--doc-page-footer") == 0 ){
/*1594*/ 		m2_inc(&Documentator_i, 1);
/*1595*/ 		if( (Documentator_i >= m2runtime_count(Documentator_args)) ){
/*1596*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: missing argument for --doc-page-footer\012");
/*1597*/ 			m2runtime_exit(1);
/*1599*/ 		}
/*1599*/ 		Documentator_page_footer = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, Documentator_i, Documentator_0err_entry_get, 326);
/*1600*/ 	} else if( m2runtime_strcmp(Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"--doc-ref-remap") == 0 ){
/*1601*/ 		if( ((Documentator_i + 2) >= m2runtime_count(Documentator_args)) ){
/*1602*/ 			m2_error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"phplint: more args required for --doc-ref-remap\012");
/*1603*/ 			m2runtime_exit(1);
/*1605*/ 		}
/*1605*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Documentator_ref_remap, 4, 1, Documentator_0err_entry_get, 327) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, (Documentator_i + 1), Documentator_0err_entry_get, 328);
/*1606*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&Documentator_ref_remap, 4, 1, Documentator_0err_entry_get, 329) = (STRING *)m2runtime_dereference_rhs_ARRAY(Documentator_args, (Documentator_i + 2), Documentator_0err_entry_get, 330);
/*1607*/ 		m2_inc(&Documentator_i, 2);
/*1609*/ 	} else {
/*1609*/ 		m2_error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"phplint: unknown option `", Documentator_arg, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"'\012", 1));
/*1610*/ 		m2runtime_exit(1);
/*1613*/ 	}
/*1613*/ 	return Documentator_i;
/*1617*/ }


/*1628*/ void
/*1628*/ Documentator_Generate(int Documentator__php_ver, STRING *Documentator__fn, STRING *Documentator__package_descr, ARRAY *Documentator__required_packages, ARRAY *Documentator__include_path, ARRAY *Documentator__consts, ARRAY *Documentator__vars, ARRAY *Documentator__funcs, ARRAY *Documentator__classes)
/*1628*/ {
/*1629*/ 	int Documentator_i = 0;
/*1630*/ 	RECORD * Documentator_c = NULL;
/*1631*/ 	RECORD * Documentator_v = NULL;
/*1632*/ 	RECORD * Documentator_f = NULL;
/*1634*/ 	RECORD * Documentator_cl = NULL;
/*1635*/ 	if( !Documentator_generate ){
/*1637*/ 		return ;
/*1639*/ 	}
/*1639*/ 	Documentator_php_ver = Documentator__php_ver;
/*1640*/ 	Documentator_fn = Documentator__fn;
/*1641*/ 	Documentator_package_descr = Documentator__package_descr;
/*1642*/ 	Documentator_required_packages = Documentator__required_packages;
/*1643*/ 	Documentator_sort(Documentator__include_path);
/*1644*/ 	Documentator_include_path = Documentator__include_path;
/*1645*/ 	Documentator_consts = Documentator__consts;
/*1646*/ 	Documentator_vars = Documentator__vars;
/*1647*/ 	Documentator_funcs = Documentator__funcs;
/*1648*/ 	Documentator_classes = Documentator__classes;
/*1650*/ 	Documentator_prev_item_big_vspace = FALSE;
/*1651*/ 	Documentator_private_items = NULL;
/*1653*/ 	Documentator_fn_remapped = Documentator_RefMap(m2runtime_concat_STRING(0, FileName_DropExtension(Documentator_fn), Documentator_extension, 1));
/*1655*/ 	m2runtime_ERROR_CODE = 0;
/*1655*/ 	io_Open(1, (void *)&Documentator_fd, m2runtime_concat_STRING(0, FileName_DropExtension(Documentator_fn), Documentator_extension, 1), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"cwt");
/*1656*/ 	switch( m2runtime_ERROR_CODE ){

/*1656*/ 	case 0:  break;
/*1656*/ 	default:
/*1656*/ 		m2runtime_HALT(Documentator_0err_entry_get, 331, m2runtime_ERROR_MESSAGE);
/*1657*/ 	}
/*1657*/ 	Documentator_p(Documentator_page_header);
/*1659*/ 	Documentator_DocDescr(TRUE, Documentator_package_descr);
/*1661*/ 	{
/*1661*/ 		int m2runtime_for_limit_1;
/*1661*/ 		Documentator_i = 0;
/*1661*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_consts) - 1);
/*1662*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1662*/ 			Documentator_c = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_consts, Documentator_i, Documentator_0err_entry_get, 332);
/*1663*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 333) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_c, 12, Documentator_0err_entry_get, 334), 8, Documentator_0err_entry_get, 335), Documentator_fn) == 0)) ){
/*1664*/ 				Documentator_DocConst(Documentator_c);
/*1667*/ 			}
/*1668*/ 		}
/*1668*/ 	}
/*1668*/ 	{
/*1668*/ 		int m2runtime_for_limit_1;
/*1668*/ 		Documentator_i = 0;
/*1668*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_vars) - 1);
/*1669*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1669*/ 			Documentator_v = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_vars, Documentator_i, Documentator_0err_entry_get, 336);
/*1670*/ 			if( ((Documentator_v != NULL) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 337) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_v, 12, Documentator_0err_entry_get, 338), 8, Documentator_0err_entry_get, 339), Documentator_fn) == 0)) ){
/*1671*/ 				Documentator_DocVar(Documentator_v);
/*1674*/ 			}
/*1675*/ 		}
/*1675*/ 	}
/*1675*/ 	{
/*1675*/ 		int m2runtime_for_limit_1;
/*1675*/ 		Documentator_i = 0;
/*1675*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_funcs) - 1);
/*1676*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1676*/ 			Documentator_f = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_funcs, Documentator_i, Documentator_0err_entry_get, 340);
/*1677*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 341) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_f, 16, Documentator_0err_entry_get, 342), 8, Documentator_0err_entry_get, 343), Documentator_fn) == 0)) ){
/*1678*/ 				Documentator_DocFunc(Documentator_f);
/*1681*/ 			}
/*1682*/ 		}
/*1682*/ 	}
/*1682*/ 	{
/*1682*/ 		int m2runtime_for_limit_1;
/*1682*/ 		Documentator_i = 0;
/*1682*/ 		m2runtime_for_limit_1 = (m2runtime_count(Documentator_classes) - 1);
/*1683*/ 		for( ; Documentator_i <= m2runtime_for_limit_1; Documentator_i += 1 ){
/*1683*/ 			Documentator_cl = (RECORD *)m2runtime_dereference_rhs_ARRAY(Documentator_classes, Documentator_i, Documentator_0err_entry_get, 344);
/*1684*/ 			if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 345) != NULL) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Documentator_cl, 48, Documentator_0err_entry_get, 346), 8, Documentator_0err_entry_get, 347), Documentator_fn) == 0)) ){
/*1685*/ 				Documentator_DocClass(Documentator_cl);
/*1688*/ 			}
/*1689*/ 		}
/*1689*/ 	}
/*1689*/ 	if( m2runtime_strcmp(Documentator_private_items, NULL) > 0 ){
/*1690*/ 		Documentator_VSpaceBeforeItem(TRUE);
/*1691*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"<h2>Private items</h2>\012<blockquote>\012");
/*1692*/ 		Documentator_p(Documentator_private_items);
/*1693*/ 		Documentator_p((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)"\012</blockquote>\012");
/*1696*/ 	}
/*1696*/ 	Documentator_p(Documentator_page_footer);
/*1698*/ 	m2runtime_ERROR_CODE = 0;
/*1698*/ 	io_Close(1, (void *)&Documentator_fd);
/*1699*/ 	switch( m2runtime_ERROR_CODE ){

/*1699*/ 	case 0:  break;
/*1699*/ 	default:
/*1699*/ 		m2runtime_HALT(Documentator_0err_entry_get, 348, m2runtime_ERROR_MESSAGE);
/*1700*/ 	}
/*1702*/ }


/*1705*/ STRING *
/*1705*/ Documentator_ExtractDeprecated(STRING *Documentator_descr)
/*1705*/ {

/*1708*/ 	STRING *
/*1708*/ 	Documentator_trim_to_linear_string(STRING *Documentator_s)
/*1708*/ 	{
/*1708*/ 		int Documentator_len = 0;
/*1710*/ 		STRING * Documentator_s2 = NULL;
/*1710*/ 		Documentator_s = Documentator_trim(Documentator_s);
/*1711*/ 		Documentator_len = m2runtime_length(Documentator_s);
/*1712*/ 		if( (Documentator_len > 240) ){
/*1713*/ 			Documentator_s = m2runtime_concat_STRING(0, m2runtime_substr(Documentator_s, 0, (240 - 5), 1, Documentator_0err_entry_get, 349), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"[...]", 1);
/*1715*/ 		}
/*1715*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(9), m2runtime_CHR(32));
/*1716*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(13), m2runtime_CHR(32));
/*1717*/ 		Documentator_s = str_substitute(Documentator_s, m2runtime_CHR(10), m2runtime_CHR(32));
/*1719*/ 		do{
/*1719*/ 			Documentator_s2 = str_substitute(Documentator_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"  ", m2runtime_CHR(32));
/*1720*/ 			if( m2runtime_strcmp(Documentator_s2, Documentator_s) == 0 ){
/*1723*/ 				goto m2runtime_loop_1;
/*1723*/ 			}
/*1723*/ 			Documentator_s = Documentator_s2;
/*1725*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*1725*/ 		return Documentator_s;
/*1730*/ 	}

/*1733*/ 	int Documentator_nest_level = 0;
/*1733*/ 	int Documentator_len = 0;
/*1733*/ 	int Documentator_j = 0;
/*1733*/ 	int Documentator_i = 0;
/*1735*/ 	STRING * Documentator_deprecated = NULL;
/*1738*/ 	do{
/*1738*/ 		Documentator_i = str_find(Documentator_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@deprecated");
/*1739*/ 		if( (Documentator_i < 0) ){
/*1740*/ 			return Documentator_trim_to_linear_string(Documentator_deprecated);
/*1746*/ 		}
/*1746*/ 		Documentator_i = (Documentator_i + m2runtime_length((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@deprecated"));
/*1747*/ 		Documentator_j = Documentator_i;
/*1748*/ 		Documentator_len = m2runtime_length(Documentator_descr);
/*1749*/ 		Documentator_nest_level = 1;
/*1751*/ 		do{
/*1751*/ 			if( (Documentator_j >= Documentator_len) ){
/*1752*/ 				Documentator_j = Documentator_len;
/*1755*/ 				goto m2runtime_loop_2;
/*1755*/ 			}
/*1755*/ 			if( m2runtime_strcmp(m2runtime_substr(Documentator_descr, Documentator_j, 0, 0, Documentator_0err_entry_get, 350), m2runtime_CHR(60)) == 0 ){
/*1756*/ 				m2_inc(&Documentator_nest_level, 1);
/*1757*/ 			} else if( m2runtime_strcmp(m2runtime_substr(Documentator_descr, Documentator_j, 0, 0, Documentator_0err_entry_get, 351), m2runtime_CHR(62)) == 0 ){
/*1758*/ 				m2_inc(&Documentator_nest_level, -1);
/*1759*/ 				if( (Documentator_nest_level <= 0) ){
/*1762*/ 					goto m2runtime_loop_2;
/*1763*/ 				}
/*1763*/ 			}
/*1763*/ 			m2_inc(&Documentator_j, 1);
/*1765*/ 		}while(TRUE);
m2runtime_loop_2: ;
/*1765*/ 		if( m2runtime_strcmp(Documentator_deprecated, EMPTY_STRING) > 0 ){
/*1766*/ 			Documentator_deprecated = m2runtime_concat_STRING(0, Documentator_deprecated, m2runtime_CHR(32), 1);
/*1768*/ 		}
/*1768*/ 		Documentator_deprecated = m2runtime_concat_STRING(0, Documentator_deprecated, m2runtime_substr(Documentator_descr, Documentator_i, Documentator_j, 1, Documentator_0err_entry_get, 352), 1);
/*1769*/ 		if( (Documentator_j >= Documentator_len) ){
/*1770*/ 			return Documentator_trim_to_linear_string(Documentator_deprecated);
/*1774*/ 		}
/*1774*/ 		Documentator_descr = m2runtime_substr(Documentator_descr, Documentator_j, Documentator_len, 1, Documentator_0err_entry_get, 353);
/*1777*/ 	}while(TRUE);
/*1777*/ 	m2runtime_missing_return(Documentator_0err_entry_get, 354);
/*1777*/ 	return NULL;
/*1780*/ }


char * Documentator_0func[] = {
    "p",
    "RefMap",
    "SearchConst",
    "SearchVar",
    "SearchFunc",
    "SearchClass",
    "SearchClassConst",
    "SearchClassVar",
    "SearchClassFunc",
    "report",
    "ItemToUrl",
    "AnchorToClass",
    "ResolveTags",
    "trim",
    "hex",
    "DocString",
    "DocValue",
    "sort",
    "DocDescr",
    "DocConst",
    "ArrayToString",
    "DocType",
    "DocVar",
    "DocSignature",
    "DocRaisedErrors",
    "SortExceptions",
    "DocThrownExceptions",
    "DocThrownExceptionsDescr",
    "DocFunc",
    "DocClassConst",
    "DocClassProperty",
    "DocClassMethod",
    "NotInList",
    "DocInheritedConsts",
    "ScanProperties",
    "ScanPropertiesRecursive",
    "DocInheritedProperties",
    "ScanMethods",
    "ScanMethodsRecursive",
    "DocInheritedMethods",
    "recurse",
    "DocClassHierarchy",
    "DocClass",
    "ParseParameter",
    "Generate",
    "trim_to_linear_string",
    "ExtractDeprecated"
};

int Documentator_0err_entry[] = {
    0 /* p */, 82,
    1 /* RefMap */, 113,
    1 /* RefMap */, 113,
    1 /* RefMap */, 114,
    1 /* RefMap */, 114,
    2 /* SearchConst */, 148,
    2 /* SearchConst */, 148,
    2 /* SearchConst */, 150,
    3 /* SearchVar */, 160,
    3 /* SearchVar */, 160,
    3 /* SearchVar */, 160,
    3 /* SearchVar */, 162,
    4 /* SearchFunc */, 172,
    4 /* SearchFunc */, 172,
    4 /* SearchFunc */, 174,
    5 /* SearchClass */, 184,
    5 /* SearchClass */, 184,
    5 /* SearchClass */, 186,
    6 /* SearchClassConst */, 195,
    6 /* SearchClassConst */, 197,
    6 /* SearchClassConst */, 197,
    6 /* SearchClassConst */, 199,
    7 /* SearchClassVar */, 208,
    7 /* SearchClassVar */, 210,
    7 /* SearchClassVar */, 210,
    7 /* SearchClassVar */, 212,
    8 /* SearchClassFunc */, 221,
    8 /* SearchClassFunc */, 223,
    8 /* SearchClassFunc */, 223,
    8 /* SearchClassFunc */, 225,
    9 /* report */, 239,
    9 /* report */, 241,
    9 /* report */, 245,
    9 /* report */, 247,
    10 /* ItemToUrl */, 265,
    10 /* ItemToUrl */, 266,
    10 /* ItemToUrl */, 270,
    10 /* ItemToUrl */, 284,
    10 /* ItemToUrl */, 285,
    10 /* ItemToUrl */, 289,
    10 /* ItemToUrl */, 297,
    10 /* ItemToUrl */, 299,
    10 /* ItemToUrl */, 300,
    10 /* ItemToUrl */, 303,
    10 /* ItemToUrl */, 307,
    10 /* ItemToUrl */, 312,
    10 /* ItemToUrl */, 315,
    10 /* ItemToUrl */, 321,
    10 /* ItemToUrl */, 327,
    10 /* ItemToUrl */, 332,
    10 /* ItemToUrl */, 336,
    10 /* ItemToUrl */, 341,
    10 /* ItemToUrl */, 346,
    11 /* AnchorToClass */, 356,
    11 /* AnchorToClass */, 357,
    12 /* ResolveTags */, 418,
    12 /* ResolveTags */, 422,
    12 /* ResolveTags */, 428,
    12 /* ResolveTags */, 428,
    12 /* ResolveTags */, 429,
    12 /* ResolveTags */, 434,
    12 /* ResolveTags */, 442,
    12 /* ResolveTags */, 443,
    12 /* ResolveTags */, 444,
    12 /* ResolveTags */, 448,
    12 /* ResolveTags */, 455,
    12 /* ResolveTags */, 459,
    12 /* ResolveTags */, 470,
    13 /* trim */, 485,
    13 /* trim */, 490,
    13 /* trim */, 494,
    14 /* hex */, 540,
    15 /* DocString */, 553,
    16 /* DocValue */, 589,
    16 /* DocValue */, 596,
    17 /* sort */, 611,
    17 /* sort */, 611,
    17 /* sort */, 612,
    17 /* sort */, 612,
    17 /* sort */, 612,
    17 /* sort */, 612,
    18 /* DocDescr */, 664,
    18 /* DocDescr */, 665,
    18 /* DocDescr */, 712,
    18 /* DocDescr */, 712,
    18 /* DocDescr */, 712,
    18 /* DocDescr */, 718,
    18 /* DocDescr */, 719,
    18 /* DocDescr */, 731,
    18 /* DocDescr */, 731,
    18 /* DocDescr */, 731,
    18 /* DocDescr */, 737,
    18 /* DocDescr */, 741,
    18 /* DocDescr */, 759,
    19 /* DocConst */, 804,
    19 /* DocConst */, 805,
    19 /* DocConst */, 808,
    19 /* DocConst */, 809,
    19 /* DocConst */, 811,
    19 /* DocConst */, 813,
    19 /* DocConst */, 816,
    19 /* DocConst */, 816,
    19 /* DocConst */, 816,
    19 /* DocConst */, 816,
    19 /* DocConst */, 819,
    19 /* DocConst */, 820,
    20 /* ArrayToString */, 833,
    20 /* ArrayToString */, 838,
    20 /* ArrayToString */, 839,
    20 /* ArrayToString */, 842,
    20 /* ArrayToString */, 847,
    21 /* DocType */, 854,
    21 /* DocType */, 862,
    21 /* DocType */, 862,
    21 /* DocType */, 870,
    21 /* DocType */, 873,
    21 /* DocType */, 874,
    21 /* DocType */, 876,
    21 /* DocType */, 876,
    21 /* DocType */, 878,
    21 /* DocType */, 880,
    22 /* DocVar */, 885,
    22 /* DocVar */, 886,
    22 /* DocVar */, 889,
    22 /* DocVar */, 890,
    22 /* DocVar */, 892,
    22 /* DocVar */, 894,
    22 /* DocVar */, 901,
    22 /* DocVar */, 902,
    23 /* DocSignature */, 913,
    23 /* DocSignature */, 915,
    23 /* DocSignature */, 921,
    23 /* DocSignature */, 924,
    23 /* DocSignature */, 928,
    23 /* DocSignature */, 930,
    23 /* DocSignature */, 934,
    23 /* DocSignature */, 935,
    23 /* DocSignature */, 937,
    23 /* DocSignature */, 937,
    23 /* DocSignature */, 940,
    24 /* DocRaisedErrors */, 987,
    24 /* DocRaisedErrors */, 987,
    24 /* DocRaisedErrors */, 991,
    24 /* DocRaisedErrors */, 991,
    25 /* SortExceptions */, 1012,
    25 /* SortExceptions */, 1012,
    25 /* SortExceptions */, 1013,
    25 /* SortExceptions */, 1013,
    25 /* SortExceptions */, 1013,
    25 /* SortExceptions */, 1013,
    26 /* DocThrownExceptions */, 1037,
    27 /* DocThrownExceptionsDescr */, 1065,
    27 /* DocThrownExceptionsDescr */, 1077,
    27 /* DocThrownExceptionsDescr */, 1077,
    27 /* DocThrownExceptionsDescr */, 1077,
    27 /* DocThrownExceptionsDescr */, 1083,
    27 /* DocThrownExceptionsDescr */, 1083,
    28 /* DocFunc */, 1094,
    28 /* DocFunc */, 1095,
    28 /* DocFunc */, 1098,
    28 /* DocFunc */, 1099,
    28 /* DocFunc */, 1101,
    28 /* DocFunc */, 1101,
    28 /* DocFunc */, 1103,
    28 /* DocFunc */, 1104,
    28 /* DocFunc */, 1105,
    28 /* DocFunc */, 1106,
    28 /* DocFunc */, 1106,
    28 /* DocFunc */, 1107,
    28 /* DocFunc */, 1108,
    29 /* DocClassConst */, 1119,
    29 /* DocClassConst */, 1122,
    29 /* DocClassConst */, 1123,
    29 /* DocClassConst */, 1123,
    29 /* DocClassConst */, 1125,
    29 /* DocClassConst */, 1127,
    29 /* DocClassConst */, 1127,
    29 /* DocClassConst */, 1127,
    29 /* DocClassConst */, 1127,
    29 /* DocClassConst */, 1130,
    29 /* DocClassConst */, 1131,
    29 /* DocClassConst */, 1134,
    29 /* DocClassConst */, 1134,
    29 /* DocClassConst */, 1134,
    30 /* DocClassProperty */, 1143,
    30 /* DocClassProperty */, 1145,
    30 /* DocClassProperty */, 1145,
    30 /* DocClassProperty */, 1149,
    30 /* DocClassProperty */, 1150,
    30 /* DocClassProperty */, 1150,
    30 /* DocClassProperty */, 1152,
    30 /* DocClassProperty */, 1155,
    30 /* DocClassProperty */, 1164,
    30 /* DocClassProperty */, 1166,
    30 /* DocClassProperty */, 1168,
    30 /* DocClassProperty */, 1168,
    30 /* DocClassProperty */, 1170,
    30 /* DocClassProperty */, 1170,
    30 /* DocClassProperty */, 1174,
    30 /* DocClassProperty */, 1175,
    30 /* DocClassProperty */, 1178,
    30 /* DocClassProperty */, 1178,
    30 /* DocClassProperty */, 1178,
    31 /* DocClassMethod */, 1187,
    31 /* DocClassMethod */, 1189,
    31 /* DocClassMethod */, 1189,
    31 /* DocClassMethod */, 1194,
    31 /* DocClassMethod */, 1195,
    31 /* DocClassMethod */, 1195,
    31 /* DocClassMethod */, 1197,
    31 /* DocClassMethod */, 1197,
    31 /* DocClassMethod */, 1198,
    31 /* DocClassMethod */, 1199,
    31 /* DocClassMethod */, 1200,
    31 /* DocClassMethod */, 1201,
    31 /* DocClassMethod */, 1201,
    31 /* DocClassMethod */, 1203,
    31 /* DocClassMethod */, 1204,
    31 /* DocClassMethod */, 1206,
    31 /* DocClassMethod */, 1207,
    31 /* DocClassMethod */, 1207,
    31 /* DocClassMethod */, 1208,
    31 /* DocClassMethod */, 1209,
    31 /* DocClassMethod */, 1212,
    31 /* DocClassMethod */, 1212,
    31 /* DocClassMethod */, 1212,
    32 /* NotInList */, 1223,
    32 /* NotInList */, 1227,
    33 /* DocInheritedConsts */, 1239,
    33 /* DocInheritedConsts */, 1242,
    33 /* DocInheritedConsts */, 1244,
    33 /* DocInheritedConsts */, 1244,
    33 /* DocInheritedConsts */, 1244,
    33 /* DocInheritedConsts */, 1246,
    33 /* DocInheritedConsts */, 1248,
    33 /* DocInheritedConsts */, 1250,
    33 /* DocInheritedConsts */, 1250,
    33 /* DocInheritedConsts */, 1251,
    33 /* DocInheritedConsts */, 1251,
    33 /* DocInheritedConsts */, 1252,
    33 /* DocInheritedConsts */, 1255,
    34 /* ScanProperties */, 1274,
    34 /* ScanProperties */, 1276,
    34 /* ScanProperties */, 1276,
    34 /* ScanProperties */, 1277,
    34 /* ScanProperties */, 1277,
    34 /* ScanProperties */, 1278,
    35 /* ScanPropertiesRecursive */, 1290,
    35 /* ScanPropertiesRecursive */, 1291,
    35 /* ScanPropertiesRecursive */, 1292,
    35 /* ScanPropertiesRecursive */, 1292,
    36 /* DocInheritedProperties */, 1297,
    36 /* DocInheritedProperties */, 1297,
    36 /* DocInheritedProperties */, 1302,
    36 /* DocInheritedProperties */, 1304,
    36 /* DocInheritedProperties */, 1304,
    36 /* DocInheritedProperties */, 1304,
    36 /* DocInheritedProperties */, 1308,
    36 /* DocInheritedProperties */, 1311,
    36 /* DocInheritedProperties */, 1311,
    36 /* DocInheritedProperties */, 1314,
    36 /* DocInheritedProperties */, 1315,
    36 /* DocInheritedProperties */, 1315,
    37 /* ScanMethods */, 1335,
    37 /* ScanMethods */, 1338,
    37 /* ScanMethods */, 1338,
    37 /* ScanMethods */, 1338,
    38 /* ScanMethodsRecursive */, 1351,
    38 /* ScanMethodsRecursive */, 1352,
    38 /* ScanMethodsRecursive */, 1353,
    38 /* ScanMethodsRecursive */, 1353,
    39 /* DocInheritedMethods */, 1358,
    39 /* DocInheritedMethods */, 1358,
    39 /* DocInheritedMethods */, 1363,
    39 /* DocInheritedMethods */, 1365,
    39 /* DocInheritedMethods */, 1365,
    39 /* DocInheritedMethods */, 1365,
    39 /* DocInheritedMethods */, 1369,
    39 /* DocInheritedMethods */, 1372,
    39 /* DocInheritedMethods */, 1372,
    39 /* DocInheritedMethods */, 1375,
    39 /* DocInheritedMethods */, 1376,
    39 /* DocInheritedMethods */, 1376,
    40 /* recurse */, 1389,
    40 /* recurse */, 1393,
    40 /* recurse */, 1398,
    40 /* recurse */, 1399,
    40 /* recurse */, 1406,
    40 /* recurse */, 1409,
    40 /* recurse */, 1410,
    40 /* recurse */, 1417,
    40 /* recurse */, 1417,
    41 /* DocClassHierarchy */, 1422,
    41 /* DocClassHierarchy */, 1422,
    42 /* DocClass */, 1436,
    42 /* DocClass */, 1437,
    42 /* DocClass */, 1442,
    42 /* DocClass */, 1444,
    42 /* DocClass */, 1447,
    42 /* DocClass */, 1450,
    42 /* DocClass */, 1456,
    42 /* DocClass */, 1459,
    42 /* DocClass */, 1465,
    42 /* DocClass */, 1467,
    42 /* DocClass */, 1472,
    42 /* DocClass */, 1476,
    42 /* DocClass */, 1476,
    42 /* DocClass */, 1482,
    42 /* DocClass */, 1483,
    42 /* DocClass */, 1496,
    42 /* DocClass */, 1497,
    42 /* DocClass */, 1498,
    42 /* DocClass */, 1499,
    42 /* DocClass */, 1500,
    42 /* DocClass */, 1510,
    42 /* DocClass */, 1511,
    42 /* DocClass */, 1511,
    42 /* DocClass */, 1515,
    42 /* DocClass */, 1516,
    42 /* DocClass */, 1516,
    42 /* DocClass */, 1520,
    42 /* DocClass */, 1521,
    42 /* DocClass */, 1521,
    43 /* ParseParameter */, 1575,
    43 /* ParseParameter */, 1586,
    43 /* ParseParameter */, 1593,
    43 /* ParseParameter */, 1600,
    43 /* ParseParameter */, 1605,
    43 /* ParseParameter */, 1606,
    43 /* ParseParameter */, 1606,
    43 /* ParseParameter */, 1607,
    44 /* Generate */, 1655,
    44 /* Generate */, 1663,
    44 /* Generate */, 1663,
    44 /* Generate */, 1663,
    44 /* Generate */, 1663,
    44 /* Generate */, 1670,
    44 /* Generate */, 1670,
    44 /* Generate */, 1670,
    44 /* Generate */, 1670,
    44 /* Generate */, 1677,
    44 /* Generate */, 1677,
    44 /* Generate */, 1677,
    44 /* Generate */, 1677,
    44 /* Generate */, 1684,
    44 /* Generate */, 1684,
    44 /* Generate */, 1684,
    44 /* Generate */, 1684,
    44 /* Generate */, 1698,
    45 /* trim_to_linear_string */, 1713,
    46 /* ExtractDeprecated */, 1755,
    46 /* ExtractDeprecated */, 1757,
    46 /* ExtractDeprecated */, 1768,
    46 /* ExtractDeprecated */, 1774,
    46 /* ExtractDeprecated */, 1776
};

void Documentator_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Documentator";
    *f = Documentator_0func[ Documentator_0err_entry[2*i] ];
    *l = Documentator_0err_entry[2*i + 1];
}
