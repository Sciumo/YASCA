/* IMPLEMENTATION MODULE ParseDocBlock */
#define M2_IMPORT_ParseDocBlock

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/* 53*/ int ParseDocBlock_parse_phpdoc = 0;

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_buffer
#    include "buffer.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

void ParseDocBlock_0err_entry_get(int i, char **m, char **f, int *l);
/*  9*/ RECORD * ParseDocBlock_pdb = NULL;
/* 10*/ STRING * ParseDocBlock_in = NULL;
/* 11*/ int ParseDocBlock_pos = 0;
/* 12*/ int ParseDocBlock_line_n = 0;
/* 13*/ int ParseDocBlock_len = 0;
/* 15*/ STRING * ParseDocBlock_c = NULL;
/* 16*/ STRING * ParseDocBlock_return_descr = NULL;
/* 18*/ void * ParseDocBlock_descr = NULL;
/* 23*/ ARRAY * ParseDocBlock_types = NULL;

/* 25*/ int
/* 25*/ ParseDocBlock_isLWSP(STRING *ParseDocBlock_c)
/* 25*/ {
/* 25*/ 	return ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(9)) == 0));
/* 29*/ }


/* 31*/ int
/* 31*/ ParseDocBlock_isBlank(STRING *ParseDocBlock_c)
/* 31*/ {
/* 31*/ 	return ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(32)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(9)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0));
/* 35*/ }


/* 40*/ STRING *
/* 40*/ ParseDocBlock_trim(STRING *ParseDocBlock_s)
/* 40*/ {
/* 42*/ 	int ParseDocBlock_i2 = 0;
/* 42*/ 	int ParseDocBlock_i1 = 0;
/* 42*/ 	if( ParseDocBlock_s == NULL ){
/* 43*/ 		return NULL;
/* 45*/ 	}
/* 45*/ 	ParseDocBlock_i1 = 0;
/* 46*/ 	while( (((ParseDocBlock_i1 < m2runtime_length(ParseDocBlock_s))) && ParseDocBlock_isBlank(m2runtime_substr(ParseDocBlock_s, ParseDocBlock_i1, 0, 0, ParseDocBlock_0err_entry_get, 0))) ){
/* 47*/ 		m2_inc(&ParseDocBlock_i1, 1);
/* 49*/ 	}
/* 49*/ 	ParseDocBlock_i2 = m2runtime_length(ParseDocBlock_s);
/* 50*/ 	while( (((ParseDocBlock_i2 > ParseDocBlock_i1)) && ParseDocBlock_isBlank(m2runtime_substr(ParseDocBlock_s, (ParseDocBlock_i2 - 1), 0, 0, ParseDocBlock_0err_entry_get, 1))) ){
/* 51*/ 		m2_inc(&ParseDocBlock_i2, -1);
/* 53*/ 	}
/* 53*/ 	return m2runtime_substr(ParseDocBlock_s, ParseDocBlock_i1, ParseDocBlock_i2, 1, ParseDocBlock_0err_entry_get, 2);
/* 57*/ }


/* 67*/ void
/* 67*/ ParseDocBlock_readCh(void)
/* 67*/ {

/* 75*/ 	void
/* 75*/ 	ParseDocBlock_lowLevelReadCh(void)
/* 75*/ 	{
/* 75*/ 		if( ParseDocBlock_c == NULL ){
/* 76*/ 			m2runtime_HALT(ParseDocBlock_0err_entry_get, 3, NULL);
/* 78*/ 		}
/* 78*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/* 79*/ 			m2_inc(&ParseDocBlock_line_n, 1);
/* 81*/ 		}
/* 81*/ 		if( (ParseDocBlock_pos >= ParseDocBlock_len) ){
/* 82*/ 			ParseDocBlock_c = NULL;
/* 84*/ 			return ;
/* 85*/ 		}
/* 85*/ 		ParseDocBlock_c = m2runtime_substr(ParseDocBlock_in, ParseDocBlock_pos, 0, 0, ParseDocBlock_0err_entry_get, 4);
/* 86*/ 		m2_inc(&ParseDocBlock_pos, 1);
/* 87*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(13)) == 0 ){
/* 89*/ 			if( (((ParseDocBlock_pos < ParseDocBlock_len)) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_in, ParseDocBlock_pos, 0, 0, ParseDocBlock_0err_entry_get, 5), m2runtime_CHR(10)) == 0)) ){
/* 90*/ 				m2_inc(&ParseDocBlock_pos, 1);
/* 92*/ 			}
/* 92*/ 			ParseDocBlock_c = m2runtime_CHR(10);
/* 95*/ 		}
/* 98*/ 	}

/* 98*/ 	if( ParseDocBlock_c == NULL ){
/*100*/ 		return ;
/*101*/ 	}
/*101*/ 	if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/*103*/ 		do{
/*103*/ 			ParseDocBlock_lowLevelReadCh();
/*104*/ 			while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/*105*/ 				ParseDocBlock_lowLevelReadCh();
/*107*/ 			}
/*107*/ 			if( ParseDocBlock_c == NULL ){
/*110*/ 				goto m2runtime_loop_1;
/*110*/ 			}
/*110*/ 			if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(42)) == 0 ){
/*111*/ 				ParseDocBlock_lowLevelReadCh();
/*112*/ 				while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/*113*/ 					ParseDocBlock_lowLevelReadCh();
/*116*/ 				}
/*117*/ 				goto m2runtime_loop_1;
/*117*/ 			}
/*117*/ 			Scanner_Notice2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"missing `*' at the beginning of the line -- ignoring line");
/*118*/ 			while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0)) ){
/*119*/ 				ParseDocBlock_lowLevelReadCh();
/*121*/ 			}
/*121*/ 			if( ParseDocBlock_c == NULL ){
/*124*/ 				goto m2runtime_loop_1;
/*125*/ 			}
/*126*/ 		}while(TRUE);
m2runtime_loop_1: ;
/*126*/ 	} else {
/*126*/ 		ParseDocBlock_lowLevelReadCh();
/*129*/ 	}
/*131*/ }

/*134*/ void * ParseDocBlock_b = NULL;

/*140*/ STRING *
/*140*/ ParseDocBlock_textToHtml(STRING *ParseDocBlock_s)
/*140*/ {
/*141*/ 	int ParseDocBlock_i = 0;
/*142*/ 	STRING * ParseDocBlock_c = NULL;
/*144*/ 	void * ParseDocBlock_b = NULL;
/*144*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*145*/ 	{
/*145*/ 		int m2runtime_for_limit_1;
/*145*/ 		ParseDocBlock_i = 0;
/*145*/ 		m2runtime_for_limit_1 = (m2runtime_length(ParseDocBlock_s) - 1);
/*146*/ 		for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*146*/ 			ParseDocBlock_c = m2runtime_substr(ParseDocBlock_s, ParseDocBlock_i, 0, 0, ParseDocBlock_0err_entry_get, 6);
/*147*/ 			if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(60)) == 0 ){
/*148*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*149*/ 			} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(62)) == 0 ){
/*150*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&gt;");
/*151*/ 			} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(38)) == 0 ){
/*152*/ 				buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"&amp;");
/*154*/ 			} else {
/*154*/ 				buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*157*/ 			}
/*157*/ 		}
/*157*/ 	}
/*157*/ 	return buffer_ToString(ParseDocBlock_b);
/*161*/ }


/*163*/ STRING *
/*163*/ ParseDocBlock_expandInlineTags(STRING *ParseDocBlock_htmlText)
/*163*/ {
/*164*/ 	int ParseDocBlock_i = 0;
/*164*/ 	int ParseDocBlock_n = 0;
/*164*/ 	int ParseDocBlock_i2 = 0;
/*164*/ 	int ParseDocBlock_i1 = 0;
/*165*/ 	void * ParseDocBlock_b = NULL;
/*166*/ 	STRING * ParseDocBlock_w = NULL;
/*166*/ 	STRING * ParseDocBlock_result = NULL;
/*166*/ 	STRING * ParseDocBlock_content = NULL;
/*166*/ 	STRING * ParseDocBlock_tag = NULL;
/*168*/ 	ARRAY * ParseDocBlock_words = NULL;
/*168*/ 	ARRAY * ParseDocBlock_a = NULL;
/*170*/ 	do {
/*172*/ 		ParseDocBlock_i1 = str_find(ParseDocBlock_htmlText, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"{@");
/*173*/ 		if( (ParseDocBlock_i1 < 0) ){
/*175*/ 			if( ParseDocBlock_b == NULL ){
/*176*/ 				return ParseDocBlock_htmlText;
/*178*/ 			} else {
/*178*/ 				buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_htmlText);
/*179*/ 				return buffer_ToString(ParseDocBlock_b);
/*182*/ 			}
/*184*/ 		}
/*184*/ 		ParseDocBlock_i2 = str_index(ParseDocBlock_htmlText, ParseDocBlock_i1, m2runtime_CHR(125));
/*185*/ 		if( (ParseDocBlock_i2 < 0) ){
/*187*/ 			buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_htmlText);
/*188*/ 			return buffer_ToString(ParseDocBlock_b);
/*192*/ 		}
/*192*/ 		ParseDocBlock_content = m2runtime_substr(ParseDocBlock_htmlText, (ParseDocBlock_i1 + 2), ParseDocBlock_i2, 1, ParseDocBlock_0err_entry_get, 7);
/*195*/ 		ParseDocBlock_a = str_split(ParseDocBlock_content, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)" \011\012");
/*196*/ 		ParseDocBlock_words = (
/*197*/ 			push((char*) alloc_ARRAY(4, 1)),
/*197*/ 			(ARRAY*) pop()
/*197*/ 		);
/*197*/ 		{
/*197*/ 			int m2runtime_for_limit_1;
/*197*/ 			ParseDocBlock_i = 0;
/*197*/ 			m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_a) - 1);
/*198*/ 			for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*198*/ 				ParseDocBlock_w = ParseDocBlock_trim((STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 8));
/*199*/ 				if( (m2runtime_length(ParseDocBlock_w) > 0) ){
/*200*/ 					*(STRING **)m2runtime_dereference_lhs_ARRAY_next(&ParseDocBlock_words, 4, 1, ParseDocBlock_0err_entry_get, 9) = ParseDocBlock_w;
/*203*/ 				}
/*205*/ 			}
/*205*/ 		}
/*205*/ 		ParseDocBlock_n = m2runtime_count(ParseDocBlock_words);
/*206*/ 		if( (ParseDocBlock_n > 0) ){
/*207*/ 			ParseDocBlock_tag = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, 0, ParseDocBlock_0err_entry_get, 10);
/*209*/ 		}
/*209*/ 		if( (ParseDocBlock_n == 0) ){
/*210*/ 			ParseDocBlock_result = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"{@";
/*212*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_tag, m2runtime_CHR(42)) == 0) && ((ParseDocBlock_n == 1))) ){
/*213*/ 			ParseDocBlock_result = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"*/";
/*215*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"link") == 0) && ((ParseDocBlock_n >= 2))) ){
/*217*/ 			if( m2_match((STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, 1, ParseDocBlock_0err_entry_get, 11), m2runtime_concat_STRING(0, m2runtime_CHR(94), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"(mailto:)|([a-z]+://)", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"|(\134./)|(\134.\134./)", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"|/", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"|([a-zA-Z]:)", 1)) ){
/*225*/ 				ParseDocBlock_result = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<a href=\042", (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, 1, ParseDocBlock_0err_entry_get, 12), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", 1);
/*226*/ 				if( (ParseDocBlock_n >= 3) ){
/*228*/ 					{
/*228*/ 						int m2runtime_for_limit_1;
/*228*/ 						ParseDocBlock_i = 2;
/*228*/ 						m2runtime_for_limit_1 = (ParseDocBlock_n - 1);
/*229*/ 						for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*229*/ 							if( (ParseDocBlock_i > 2) ){
/*230*/ 								ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, m2runtime_CHR(32), 1);
/*232*/ 							}
/*232*/ 							ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 13), 1);
/*235*/ 						}
/*235*/ 					}
/*235*/ 				} else {
/*235*/ 					ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, 1, ParseDocBlock_0err_entry_get, 14), 1);
/*237*/ 				}
/*237*/ 				ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"</a>", 1);
/*241*/ 			} else {
/*241*/ 				ParseDocBlock_result = m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"<@item ", (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, 1, ParseDocBlock_0err_entry_get, 15), m2runtime_CHR(62), 1);
/*242*/ 				if( (ParseDocBlock_n >= 3) ){
/*245*/ 					ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" (", 1);
/*246*/ 					{
/*246*/ 						int m2runtime_for_limit_1;
/*246*/ 						ParseDocBlock_i = 2;
/*246*/ 						m2runtime_for_limit_1 = (ParseDocBlock_n - 1);
/*247*/ 						for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*247*/ 							if( (ParseDocBlock_i > 2) ){
/*248*/ 								ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, m2runtime_CHR(32), 1);
/*250*/ 							}
/*250*/ 							ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_words, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 16), 1);
/*252*/ 						}
/*252*/ 					}
/*252*/ 					ParseDocBlock_result = m2runtime_concat_STRING(0, ParseDocBlock_result, m2runtime_CHR(41), 1);
/*255*/ 				}
/*256*/ 			}
/*256*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"id") == 0) || (m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"toc") == 0)) ){
/*259*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"the {@", ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"} inline tag not allowed in DocBlock", 1));
/*261*/ 			ParseDocBlock_result = m2runtime_substr(ParseDocBlock_htmlText, ParseDocBlock_i1, (ParseDocBlock_i2 + 1), 1, ParseDocBlock_0err_entry_get, 17);
/*263*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"example") == 0) || (m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"internal") == 0) || (m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"inheritdoc") == 0) || (m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"source") == 0) || (m2runtime_strcmp(ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"tutorial") == 0)) ){
/*269*/ 			Scanner_Notice2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"the {@", ParseDocBlock_tag, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"} inline tag still unsupported by PHPLint, sorry", 1));
/*271*/ 			ParseDocBlock_result = m2runtime_substr(ParseDocBlock_htmlText, ParseDocBlock_i1, (ParseDocBlock_i2 + 1), 1, ParseDocBlock_0err_entry_get, 18);
/*274*/ 		} else {
/*274*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unknown inline tag {@", ParseDocBlock_tag, m2runtime_CHR(125), 1));
/*275*/ 			ParseDocBlock_result = m2runtime_substr(ParseDocBlock_htmlText, ParseDocBlock_i1, (ParseDocBlock_i2 + 1), 1, ParseDocBlock_0err_entry_get, 19);
/*280*/ 		}
/*280*/ 		buffer_AddString((void *)&ParseDocBlock_b, m2runtime_substr(ParseDocBlock_htmlText, 0, ParseDocBlock_i1, 1, ParseDocBlock_0err_entry_get, 20));
/*283*/ 		buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_result);
/*286*/ 		ParseDocBlock_htmlText = m2runtime_substr(ParseDocBlock_htmlText, (ParseDocBlock_i2 + 1), m2runtime_length(ParseDocBlock_htmlText), 1, ParseDocBlock_0err_entry_get, 21);
/*288*/ 	} while( !( (m2runtime_length(ParseDocBlock_htmlText) == 0) ));
/*290*/ 	return buffer_ToString(ParseDocBlock_b);
/*300*/ }

/*301*/ ARRAY * ParseDocBlock_tags = NULL;
/*303*/ void * ParseDocBlock_eb = NULL;

/*316*/ STRING *
/*316*/ ParseDocBlock_filterValidHtmlEntities(STRING *ParseDocBlock_s)
/*316*/ {
/*318*/ 	ARRAY * ParseDocBlock_a = NULL;
/*319*/ 	int ParseDocBlock_i = 0;
/*320*/ 	STRING * ParseDocBlock_l = NULL;
/*322*/ 	STRING * ParseDocBlock_t = NULL;

/*331*/ 	void
/*331*/ 	ParseDocBlock_nextTag(void)
/*331*/ 	{

/*332*/ 		STRING *
/*332*/ 		ParseDocBlock_detectTag(STRING *ParseDocBlock_s)
/*332*/ 		{
/*332*/ 			int ParseDocBlock_i = 0;
/*334*/ 			STRING * ParseDocBlock_t = NULL;
/*334*/ 			{
/*334*/ 				int m2runtime_for_limit_1;
/*334*/ 				ParseDocBlock_i = 0;
/*334*/ 				m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_tags) - 1);
/*335*/ 				for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*335*/ 					ParseDocBlock_t = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_tags, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 22);
/*336*/ 					if( (((m2runtime_length(ParseDocBlock_s) >= m2runtime_length(ParseDocBlock_t))) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_s, 0, m2runtime_length(ParseDocBlock_t), 1, ParseDocBlock_0err_entry_get, 23), ParseDocBlock_t) == 0)) ){
/*338*/ 						return ParseDocBlock_t;
/*341*/ 					}
/*341*/ 				}
/*341*/ 			}
/*341*/ 			return NULL;
/*345*/ 		}

/*345*/ 		if( (ParseDocBlock_i >= m2runtime_count(ParseDocBlock_a)) ){
/*346*/ 			ParseDocBlock_t = NULL;
/*347*/ 			ParseDocBlock_l = NULL;
/*349*/ 			return ;
/*350*/ 		}
/*350*/ 		ParseDocBlock_l = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 24);
/*351*/ 		ParseDocBlock_t = ParseDocBlock_detectTag(ParseDocBlock_l);
/*352*/ 		m2_inc(&ParseDocBlock_i, 1);
/*356*/ 	}


/*357*/ 	STRING *
/*357*/ 	ParseDocBlock_short(STRING *ParseDocBlock_s)
/*357*/ 	{
/*359*/ 		int ParseDocBlock_l = 0;
/*359*/ 		ParseDocBlock_l = m2runtime_length(ParseDocBlock_s);
/*360*/ 		if( (ParseDocBlock_l > 30) ){
/*362*/ 			ParseDocBlock_s = m2runtime_concat_STRING(0, m2runtime_substr(ParseDocBlock_s, 0, 25, 1, ParseDocBlock_0err_entry_get, 25), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"...", 1);
/*364*/ 		}
/*364*/ 		return m2runtime_StringToLiteral(ParseDocBlock_s);
/*368*/ 	}


/*373*/ 	STRING *
/*373*/ 	ParseDocBlock_splitParagraphes(STRING *ParseDocBlock_text)
/*373*/ 	{
/*374*/ 		ARRAY * ParseDocBlock_a = NULL;
/*375*/ 		int ParseDocBlock_i = 0;
/*377*/ 		void * ParseDocBlock_b = NULL;
/*377*/ 		ParseDocBlock_a = str_split(ParseDocBlock_text, m2runtime_CHR(10));
/*378*/ 		{
/*378*/ 			int m2runtime_for_limit_1;
/*378*/ 			ParseDocBlock_i = 0;
/*378*/ 			m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_a) - 1);
/*379*/ 			for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*379*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 26), EMPTY_STRING) == 0 ){
/*381*/ 					if( (((ParseDocBlock_i > 0)) && ((ParseDocBlock_i < (m2runtime_count(ParseDocBlock_a) - 1)))) ){
/*382*/ 						buffer_AddString((void *)&ParseDocBlock_b, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<p>\012");
/*385*/ 					}
/*385*/ 				} else {
/*385*/ 					if( (buffer_Length(ParseDocBlock_b) > 0) ){
/*386*/ 						buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*388*/ 					}
/*388*/ 					buffer_AddString((void *)&ParseDocBlock_b, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 27));
/*391*/ 				}
/*391*/ 			}
/*391*/ 		}
/*391*/ 		return buffer_ToString(ParseDocBlock_b);
/*395*/ 	}


/*400*/ 	void
/*400*/ 	ParseDocBlock_addChunk(void)
/*400*/ 	{
/*400*/ 		buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_CHR(60));
/*401*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_t);
/*402*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_splitParagraphes(m2runtime_substr(ParseDocBlock_l, m2runtime_length(ParseDocBlock_t), m2runtime_length(ParseDocBlock_l), 1, ParseDocBlock_0err_entry_get, 28)));
/*403*/ 		ParseDocBlock_nextTag();
/*406*/ 	}


/*411*/ 	void
/*411*/ 	ParseDocBlock_addBareText(STRING *ParseDocBlock_text)
/*411*/ 	{
/*411*/ 		buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_splitParagraphes(ParseDocBlock_textToHtml(ParseDocBlock_text)));
/*414*/ 	}


/*423*/ 	void
/*423*/ 	ParseDocBlock_parseHtml(void)
/*423*/ 	{

/*432*/ 		int
/*432*/ 		ParseDocBlock_isSimpleTag(void)
/*432*/ 		{
/*432*/ 			return ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"b>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"i>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"code>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"kbd>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"samp>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"var>") == 0));
/*436*/ 		}


/*437*/ 		void
/*437*/ 		ParseDocBlock_parseSimpleTag(void)
/*437*/ 		{
/*439*/ 			STRING * ParseDocBlock_q_end = NULL;
/*439*/ 			STRING * ParseDocBlock_q = NULL;
/*439*/ 			ParseDocBlock_q = ParseDocBlock_t;
/*440*/ 			ParseDocBlock_q_end = m2runtime_concat_STRING(0, m2runtime_CHR(47), ParseDocBlock_q, 1);
/*441*/ 			ParseDocBlock_addChunk();
/*443*/ 			do{
/*443*/ 				if( ParseDocBlock_t == NULL ){
/*444*/ 					if( ParseDocBlock_l == NULL ){
/*445*/ 						Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"missing closing tag `<", ParseDocBlock_q_end, m2runtime_CHR(39), 1));
/*446*/ 						buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_q_end, 1));
/*448*/ 						return ;
/*449*/ 					} else {
/*449*/ 						ParseDocBlock_addBareText(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1));
/*450*/ 						ParseDocBlock_nextTag();
/*452*/ 					}
/*452*/ 				} else if( m2runtime_strcmp(ParseDocBlock_t, ParseDocBlock_q_end) == 0 ){
/*453*/ 					ParseDocBlock_addChunk();
/*455*/ 					return ;
/*455*/ 				} else if( ParseDocBlock_isSimpleTag() ){
/*456*/ 					ParseDocBlock_parseSimpleTag();
/*458*/ 				} else {
/*458*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"expected closing tag `<", ParseDocBlock_q_end, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"' near the line `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), 1));
/*459*/ 					buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_q_end, 1));
/*461*/ 					return ;
/*463*/ 				}
/*465*/ 			}while(TRUE);
/*466*/ 		}


/*474*/ 		void
/*474*/ 		ParseDocBlock_checkEmptyAfterTag(void)
/*474*/ 		{
/*474*/ 			if( !m2_match(ParseDocBlock_l, m2runtime_concat_STRING(0, ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"[ \011\012\015]*$", 1)) ){
/*475*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"trailing chars after tag `<", ParseDocBlock_short(ParseDocBlock_l), m2runtime_CHR(39), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", m2runtime_StringToLiteral(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1)), 1));
/*478*/ 			}
/*478*/ 			buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_CHR(60));
/*479*/ 			buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_t);
/*480*/ 			buffer_AddString((void *)&ParseDocBlock_eb, m2runtime_CHR(10));
/*481*/ 			ParseDocBlock_nextTag();
/*484*/ 		}


/*487*/ 		void
/*487*/ 		ParseDocBlock_parseLi(void)
/*487*/ 		{
/*487*/ 			ParseDocBlock_addChunk();
/*488*/ 			ParseDocBlock_parseHtml();
/*489*/ 			if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/li>") == 0 ){
/*490*/ 				ParseDocBlock_checkEmptyAfterTag();
/*492*/ 			} else {
/*492*/ 				buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</li>\012");
/*496*/ 			}
/*498*/ 		}

/*499*/ 		do{
/*499*/ 			if( ParseDocBlock_t == NULL ){
/*500*/ 				if( ParseDocBlock_l == NULL ){
/*502*/ 					return ;
/*503*/ 				} else {
/*503*/ 					ParseDocBlock_addBareText(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1));
/*504*/ 					ParseDocBlock_nextTag();
/*507*/ 				}
/*507*/ 			} else if( ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"br>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/br>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"p>") == 0) || (m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"/p>") == 0)) ){
/*510*/ 				ParseDocBlock_addChunk();
/*512*/ 			} else if( ParseDocBlock_isSimpleTag() ){
/*513*/ 				ParseDocBlock_parseSimpleTag();
/*515*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"pre>") == 0 ){
/*516*/ 				ParseDocBlock_addChunk();
/*517*/ 				while( ((m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"/pre>") != 0) && (ParseDocBlock_l != NULL)) ){
/*518*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;");
/*519*/ 					buffer_AddString((void *)&ParseDocBlock_eb, ParseDocBlock_textToHtml(ParseDocBlock_l));
/*520*/ 					ParseDocBlock_nextTag();
/*522*/ 				}
/*522*/ 				if( ParseDocBlock_l == NULL ){
/*523*/ 					Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"unclosed <pre> entity");
/*524*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"</pre>\012");
/*526*/ 					return ;
/*527*/ 				}
/*527*/ 				ParseDocBlock_addChunk();
/*529*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"ul>") == 0 ){
/*530*/ 				ParseDocBlock_checkEmptyAfterTag();
/*531*/ 				while( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"li>") == 0 ){
/*532*/ 					ParseDocBlock_parseLi();
/*534*/ 				}
/*534*/ 				if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/ul>") == 0 ){
/*535*/ 					ParseDocBlock_addChunk();
/*537*/ 				} else {
/*537*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected `</ul>' near or at ", ParseDocBlock_short(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1)), 1));
/*539*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</ul>\012");
/*542*/ 				}
/*542*/ 			} else if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"ol>") == 0 ){
/*543*/ 				ParseDocBlock_checkEmptyAfterTag();
/*544*/ 				while( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"li>") == 0 ){
/*545*/ 					ParseDocBlock_parseLi();
/*547*/ 				}
/*547*/ 				if( m2runtime_strcmp(ParseDocBlock_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/ol>") == 0 ){
/*548*/ 					ParseDocBlock_addChunk();
/*550*/ 				} else {
/*550*/ 					Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"expected `</ol>' near or at ", ParseDocBlock_short(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1)), 1));
/*552*/ 					buffer_AddString((void *)&ParseDocBlock_eb, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</ol>\012");
/*556*/ 				}
/*558*/ 			} else {
/*558*/ 				return ;
/*561*/ 			}
/*562*/ 		}while(TRUE);
/*564*/ 	}

/*565*/ 	if( m2runtime_strcmp(ParseDocBlock_s, EMPTY_STRING) <= 0 ){
/*566*/ 		return ParseDocBlock_s;
/*569*/ 	}
/*569*/ 	if( ParseDocBlock_tags == NULL ){
/*570*/ 		ParseDocBlock_tags = str_split(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\100,\0,\0,\0)"b> /b> i> /i> code> /code> br> kbd> /kbd> p> /p> pre> /pre> /br>", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)" ul> /ul> ol> /ol> li> /li> samp> /samp> var> /var>", 1), m2runtime_CHR(32));
/*579*/ 	}
/*579*/ 	ParseDocBlock_a = str_split(ParseDocBlock_s, m2runtime_CHR(60));
/*580*/ 	ParseDocBlock_i = 0;
/*581*/ 	ParseDocBlock_nextTag();
/*582*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_eb);
/*585*/ 	ParseDocBlock_addBareText(ParseDocBlock_l);
/*586*/ 	ParseDocBlock_nextTag();
/*589*/ 	do{
/*589*/ 		ParseDocBlock_parseHtml();
/*590*/ 		if( ParseDocBlock_l == NULL ){
/*594*/ 			goto m2runtime_loop_1;
/*595*/ 		} else {
/*595*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"unknown or unexpected HTML entity ", ParseDocBlock_short(m2runtime_concat_STRING(0, m2runtime_CHR(60), ParseDocBlock_l, 1)), 1));
/*597*/ 			ParseDocBlock_addBareText(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"&lt;", ParseDocBlock_l, 1));
/*598*/ 			ParseDocBlock_nextTag();
/*601*/ 		}
/*602*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*602*/ 	return buffer_ToString(ParseDocBlock_eb);
/*606*/ }


/*608*/ void
/*608*/ ParseDocBlock_skipLWSP(void)
/*608*/ {
/*608*/ 	while( ParseDocBlock_isLWSP(ParseDocBlock_c) ){
/*609*/ 		ParseDocBlock_readCh();
/*612*/ 	}
/*614*/ }


/*620*/ STRING *
/*620*/ ParseDocBlock_upToEndOfLine(void)
/*620*/ {
/*620*/ 	ParseDocBlock_skipLWSP();
/*621*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*622*/ 	while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0)) ){
/*623*/ 		buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*624*/ 		ParseDocBlock_readCh();
/*626*/ 	}
/*626*/ 	if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/*627*/ 		ParseDocBlock_readCh();
/*629*/ 	}
/*629*/ 	return buffer_ToString(ParseDocBlock_b);
/*633*/ }


/*657*/ RECORD *
/*657*/ ParseDocBlock_parseType(STRING *ParseDocBlock_w)
/*657*/ {
/*658*/ 	int ParseDocBlock_i = 0;
/*659*/ 	STRING * ParseDocBlock_c = NULL;
/*661*/ 	STRING * ParseDocBlock_sym_lc = NULL;
/*661*/ 	STRING * ParseDocBlock_sym = NULL;

/*663*/ 	void
/*663*/ 	ParseDocBlock_next_char(void)
/*663*/ 	{
/*663*/ 		if( (ParseDocBlock_i >= m2runtime_length(ParseDocBlock_w)) ){
/*664*/ 			ParseDocBlock_c = NULL;
/*666*/ 		} else {
/*666*/ 			ParseDocBlock_c = m2runtime_substr(ParseDocBlock_w, ParseDocBlock_i, 0, 0, ParseDocBlock_0err_entry_get, 29);
/*668*/ 		}
/*668*/ 		m2_inc(&ParseDocBlock_i, 1);
/*671*/ 	}


/*673*/ 	int
/*673*/ 	ParseDocBlock_isDigit(STRING *ParseDocBlock_c)
/*673*/ 	{
/*673*/ 		return ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(57)) <= 0));
/*676*/ 	}


/*678*/ 	int
/*678*/ 	ParseDocBlock_is_id_char(STRING *ParseDocBlock_c)
/*678*/ 	{
/*678*/ 		return (((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(48)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(57)) <= 0)) || ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(97)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(122)) <= 0)) || ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(65)) >= 0) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(90)) <= 0)) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(95)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(128)) > 0));
/*685*/ 	}


/*686*/ 	void
/*686*/ 	ParseDocBlock_next_sym(void)
/*686*/ 	{
/*688*/ 		int ParseDocBlock_j = 0;
/*688*/ 		if( ParseDocBlock_c == NULL ){
/*689*/ 			ParseDocBlock_sym = NULL;
/*690*/ 		} else if( ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(124)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(91)) == 0) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(93)) == 0)) ){
/*691*/ 			ParseDocBlock_sym = ParseDocBlock_c;
/*692*/ 			ParseDocBlock_next_char();
/*693*/ 		} else if( (ParseDocBlock_is_id_char(ParseDocBlock_c) && !ParseDocBlock_isDigit(ParseDocBlock_c)) ){
/*694*/ 			ParseDocBlock_j = ParseDocBlock_i;
/*696*/ 			do {
/*696*/ 				ParseDocBlock_next_char();
/*697*/ 			} while( !( !ParseDocBlock_is_id_char(ParseDocBlock_c) ));
/*698*/ 			ParseDocBlock_sym = m2runtime_substr(ParseDocBlock_w, (ParseDocBlock_j - 1), (ParseDocBlock_i - 1), 1, ParseDocBlock_0err_entry_get, 30);
/*699*/ 			ParseDocBlock_sym_lc = str_tolower(ParseDocBlock_sym);
/*701*/ 		} else {
/*701*/ 			ParseDocBlock_sym = ParseDocBlock_c;
/*702*/ 			ParseDocBlock_next_char();
/*705*/ 		}
/*706*/ 	}


/*708*/ 	void
/*708*/ 	ParseDocBlock_checkMispelled(STRING *ParseDocBlock_expect, STRING *ParseDocBlock_found)
/*708*/ 	{
/*708*/ 		if( m2runtime_strcmp(ParseDocBlock_expect, ParseDocBlock_found) == 0 ){
/*710*/ 			return ;
/*711*/ 		}
/*711*/ 		Scanner_Notice2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"mispelled type identifier `", ParseDocBlock_found, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"', expected `", ParseDocBlock_expect, m2runtime_CHR(39), 1));
/*715*/ 	}


/*717*/ 	RECORD *
/*717*/ 	ParseDocBlock_next_type(void)
/*717*/ 	{

/*718*/ 		RECORD *
/*718*/ 		ParseDocBlock_parse_array(void)
/*718*/ 		{
/*720*/ 			RECORD * ParseDocBlock_t = NULL;
/*720*/ 			ParseDocBlock_t = (
/*720*/ 				push((char*) alloc_RECORD(24, 2)),
/*720*/ 				*(int*) (tos()+16) = 6,
/*720*/ 				*(int*) (tos()+20) = 1,
/*720*/ 				push((char*) NULL),
/*720*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*720*/ 				push((char*) NULL),
/*721*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*721*/ 				(RECORD*) pop()
/*721*/ 			);
/*721*/ 			ParseDocBlock_next_sym();
/*722*/ 			if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int") == 0 ){
/*723*/ 				ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int", ParseDocBlock_sym);
/*724*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 20, ParseDocBlock_0err_entry_get, 31) = 3;
/*725*/ 				ParseDocBlock_next_sym();
/*726*/ 			} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string") == 0 ){
/*727*/ 				ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string", ParseDocBlock_sym);
/*728*/ 				*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 20, ParseDocBlock_0err_entry_get, 32) = 5;
/*729*/ 				ParseDocBlock_next_sym();
/*731*/ 			}
/*731*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(93)) != 0 ){
/*732*/ 				Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\73,\0,\0,\0)"in type declaration, expected `[]' or `[int]' or `[string]'");
/*733*/ 				return ParseDocBlock_t;
/*735*/ 			}
/*735*/ 			ParseDocBlock_next_sym();
/*736*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(91)) == 0 ){
/*737*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 8, ParseDocBlock_0err_entry_get, 33) = ParseDocBlock_parse_array();
/*739*/ 			} else {
/*739*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_t, 24, 2, 8, ParseDocBlock_0err_entry_get, 34) = ParseDocBlock_next_type();
/*741*/ 			}
/*741*/ 			return ParseDocBlock_t;
/*744*/ 		}

/*746*/ 		RECORD * ParseDocBlock_cl = NULL;
/*746*/ 		if( ParseDocBlock_sym == NULL ){
/*747*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid or missing type");
/*748*/ 			ParseDocBlock_next_sym();
/*749*/ 			return NULL;
/*750*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void") == 0 ){
/*751*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void", ParseDocBlock_sym);
/*752*/ 			ParseDocBlock_next_sym();
/*753*/ 			return Globals_void_type;
/*754*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool") == 0 ){
/*755*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"bool", ParseDocBlock_sym);
/*756*/ 			ParseDocBlock_next_sym();
/*757*/ 			return Globals_boolean_type;
/*758*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean") == 0 ){
/*759*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean", ParseDocBlock_sym);
/*760*/ 			ParseDocBlock_next_sym();
/*761*/ 			return Globals_boolean_type;
/*762*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"false") == 0 ){
/*763*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE", ParseDocBlock_sym);
/*764*/ 			ParseDocBlock_next_sym();
/*765*/ 			return Globals_boolean_type;
/*766*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int") == 0 ){
/*767*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int", ParseDocBlock_sym);
/*768*/ 			ParseDocBlock_next_sym();
/*769*/ 			return Globals_int_type;
/*770*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer") == 0 ){
/*771*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"integer", ParseDocBlock_sym);
/*772*/ 			ParseDocBlock_next_sym();
/*773*/ 			return Globals_int_type;
/*774*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float") == 0 ){
/*775*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float", ParseDocBlock_sym);
/*776*/ 			ParseDocBlock_next_sym();
/*777*/ 			return Globals_float_type;
/*778*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double") == 0 ){
/*779*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"double", ParseDocBlock_sym);
/*780*/ 			ParseDocBlock_next_sym();
/*781*/ 			return Globals_float_type;
/*782*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real") == 0 ){
/*783*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"real", ParseDocBlock_sym);
/*784*/ 			ParseDocBlock_next_sym();
/*785*/ 			return Globals_float_type;
/*786*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"number") == 0 ){
/*787*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)"unsupported type `number', assuming `float' instead");
/*788*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"number", ParseDocBlock_sym);
/*789*/ 			ParseDocBlock_next_sym();
/*790*/ 			return Globals_float_type;
/*791*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string") == 0 ){
/*792*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string", ParseDocBlock_sym);
/*793*/ 			ParseDocBlock_next_sym();
/*794*/ 			return Globals_string_type;
/*795*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array") == 0 ){
/*796*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array", ParseDocBlock_sym);
/*797*/ 			ParseDocBlock_next_sym();
/*798*/ 			if( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(91)) == 0 ){
/*799*/ 				return ParseDocBlock_parse_array();
/*801*/ 			} else {
/*801*/ 				return (
/*801*/ 					push((char*) alloc_RECORD(24, 2)),
/*801*/ 					*(int*) (tos()+16) = 6,
/*801*/ 					*(int*) (tos()+20) = 1,
/*801*/ 					push((char*) NULL),
/*801*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*801*/ 					push((char*) NULL),
/*802*/ 					*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*803*/ 					(RECORD*) pop()
/*803*/ 				);
/*803*/ 			}
/*803*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource") == 0 ){
/*804*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource", ParseDocBlock_sym);
/*805*/ 			ParseDocBlock_next_sym();
/*806*/ 			return Globals_resource_type;
/*807*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed") == 0 ){
/*808*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed", ParseDocBlock_sym);
/*809*/ 			ParseDocBlock_next_sym();
/*810*/ 			return Globals_mixed_type;
/*811*/ 		} else if( m2runtime_strcmp(ParseDocBlock_sym_lc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object") == 0 ){
/*812*/ 			ParseDocBlock_checkMispelled((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object", ParseDocBlock_sym);
/*813*/ 			ParseDocBlock_next_sym();
/*814*/ 			return (
/*814*/ 				push((char*) alloc_RECORD(24, 2)),
/*814*/ 				*(int*) (tos()+16) = 9,
/*814*/ 				*(int*) (tos()+20) = 1,
/*814*/ 				push((char*) NULL),
/*814*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*814*/ 				push((char*) NULL),
/*815*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*815*/ 				(RECORD*) pop()
/*815*/ 			);
/*815*/ 		} else if( m2_match(ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"^[_a-zA-Z\200-\377][_0-9a-zA-Z\200-\377]*$") ){
/*816*/ 			ParseDocBlock_cl = Search_SearchClass(ParseDocBlock_sym, TRUE);
/*817*/ 			if( ParseDocBlock_cl == NULL ){
/*818*/ 				Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"unknown type/class `", ParseDocBlock_sym, m2runtime_CHR(39), 1));
/*819*/ 				ParseDocBlock_next_sym();
/*820*/ 				return (
/*820*/ 					push((char*) alloc_RECORD(24, 2)),
/*820*/ 					*(int*) (tos()+16) = 9,
/*820*/ 					*(int*) (tos()+20) = 1,
/*820*/ 					push((char*) NULL),
/*820*/ 					*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*820*/ 					push((char*) NULL),
/*821*/ 					*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*822*/ 					(RECORD*) pop()
/*822*/ 				);
/*822*/ 			} else {
/*822*/ 				ParseDocBlock_next_sym();
/*823*/ 				return (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_cl, 24, ParseDocBlock_0err_entry_get, 35);
/*826*/ 			}
/*826*/ 		} else {
/*826*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"invalid type `", ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"', presuming mixed and trying to continue anyway", 1));
/*827*/ 			ParseDocBlock_next_sym();
/*828*/ 			return Globals_mixed_type;
/*831*/ 		}
/*831*/ 		m2runtime_missing_return(ParseDocBlock_0err_entry_get, 36);
/*831*/ 		return NULL;
/*832*/ 	}

/*834*/ 	RECORD * ParseDocBlock_ignore = NULL;
/*834*/ 	RECORD * ParseDocBlock_res = NULL;
/*834*/ 	ParseDocBlock_i = 0;
/*835*/ 	ParseDocBlock_next_char();
/*836*/ 	ParseDocBlock_next_sym();
/*837*/ 	ParseDocBlock_res = ParseDocBlock_next_type();
/*838*/ 	while( m2runtime_strcmp(ParseDocBlock_sym, m2runtime_CHR(124)) == 0 ){
/*839*/ 		ParseDocBlock_next_sym();
/*840*/ 		ParseDocBlock_ignore = ParseDocBlock_next_type();
/*842*/ 	}
/*842*/ 	if( ParseDocBlock_sym != NULL ){
/*843*/ 		Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"unknown/unexpected symbol `", ParseDocBlock_sym, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"' in type", 1));
/*845*/ 	}
/*845*/ 	return ParseDocBlock_res;
/*849*/ }


/*854*/ void
/*854*/ ParseDocBlock_parseLineTag(void)
/*854*/ {

/*855*/ 	void
/*855*/ 	ParseDocBlock_check_eol(STRING *ParseDocBlock_tag_name)
/*855*/ 	{
/*857*/ 		STRING * ParseDocBlock_s = NULL;
/*857*/ 		ParseDocBlock_skipLWSP();
/*858*/ 		if( ParseDocBlock_c == NULL ){
/*860*/ 			return ;
/*860*/ 		} else if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0 ){
/*863*/ 			do {
/*863*/ 				ParseDocBlock_readCh();
/*864*/ 				ParseDocBlock_skipLWSP();
/*865*/ 			} while( !( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0 ));
/*866*/ 			if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*868*/ 				return ;
/*869*/ 			}
/*869*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"unexpected continuation lines for `", ParseDocBlock_tag_name, m2runtime_CHR(39), 1));
/*870*/ 			while( ((m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0) && (ParseDocBlock_c != NULL)) ){
/*871*/ 				ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*874*/ 			}
/*874*/ 		} else {
/*874*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)"unexpected trailing words inside `", ParseDocBlock_tag_name, m2runtime_CHR(39), 1));
/*875*/ 			ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*878*/ 		}
/*880*/ 	}


/*889*/ 	STRING *
/*889*/ 	ParseDocBlock_getWord(void)
/*889*/ 	{
/*889*/ 		ParseDocBlock_skipLWSP();
/*890*/ 		buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*891*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) != 0) && !ParseDocBlock_isLWSP(ParseDocBlock_c)) ){
/*892*/ 			buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_c);
/*893*/ 			ParseDocBlock_readCh();
/*895*/ 		}
/*895*/ 		return ParseDocBlock_textToHtml(buffer_ToString(ParseDocBlock_b));
/*899*/ 	}


/*900*/ 	STRING *
/*900*/ 	ParseDocBlock_getDescr(void)
/*900*/ 	{
/*902*/ 		STRING * ParseDocBlock_l = NULL;
/*902*/ 		STRING * ParseDocBlock_s = NULL;
/*902*/ 		while( (ParseDocBlock_isLWSP(ParseDocBlock_c) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0)) ){
/*903*/ 			ParseDocBlock_readCh();
/*905*/ 		}
/*905*/ 		if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*906*/ 			return NULL;
/*909*/ 		}
/*909*/ 		ParseDocBlock_s = ParseDocBlock_filterValidHtmlEntities(ParseDocBlock_upToEndOfLine());
/*912*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*913*/ 			ParseDocBlock_l = ParseDocBlock_filterValidHtmlEntities(ParseDocBlock_upToEndOfLine());
/*914*/ 			if( m2runtime_strcmp(ParseDocBlock_l, EMPTY_STRING) <= 0 ){
/*915*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<p>", 1);
/*917*/ 			} else {
/*917*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, m2runtime_CHR(10), ParseDocBlock_l, 1);
/*920*/ 			}
/*920*/ 		}
/*920*/ 		return ParseDocBlock_s;
/*924*/ 	}


/*925*/ 	STRING *
/*925*/ 	ParseDocBlock_getText(void)
/*925*/ 	{
/*927*/ 		STRING * ParseDocBlock_l = NULL;
/*927*/ 		STRING * ParseDocBlock_s = NULL;
/*927*/ 		ParseDocBlock_s = ParseDocBlock_textToHtml(ParseDocBlock_upToEndOfLine());
/*929*/ 		while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*930*/ 			ParseDocBlock_l = ParseDocBlock_textToHtml(ParseDocBlock_upToEndOfLine());
/*931*/ 			if( m2runtime_strcmp(ParseDocBlock_l, EMPTY_STRING) <= 0 ){
/*932*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"<p>", 1);
/*934*/ 			} else {
/*934*/ 				ParseDocBlock_s = m2runtime_concat_STRING(0, ParseDocBlock_s, m2runtime_CHR(10), ParseDocBlock_l, 1);
/*937*/ 			}
/*937*/ 		}
/*937*/ 		return ParseDocBlock_s;
/*941*/ 	}


/*943*/ 	void
/*943*/ 	ParseDocBlock_parseGlobal(void)
/*943*/ 	{
/*946*/ 		RECORD * ParseDocBlock_t = NULL;
/*948*/ 		STRING * ParseDocBlock_n = NULL;
/*951*/ 		ParseDocBlock_n = ParseDocBlock_getWord();
/*952*/ 		if( m2runtime_strcmp(ParseDocBlock_n, EMPTY_STRING) <= 0 ){
/*953*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"missing type in @global");
/*954*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*956*/ 			return ;
/*957*/ 		}
/*957*/ 		ParseDocBlock_t = ParseDocBlock_parseType(ParseDocBlock_n);
/*958*/ 		if( ParseDocBlock_t == NULL ){
/*960*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*962*/ 			return ;
/*967*/ 		}
/*967*/ 		ParseDocBlock_n = ParseDocBlock_getWord();
/*968*/ 		if( m2runtime_strcmp(ParseDocBlock_n, EMPTY_STRING) <= 0 ){
/*969*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"missing variable name in @global");
/*970*/ 			ParseDocBlock_n = ParseDocBlock_getText();
/*972*/ 			return ;
/*973*/ 		}
/*973*/ 		if( (m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"^\134$GLOBALS\134[\042", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"\042\134]$", 1)) || m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)"^\134$GLOBALS\134['", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"'\134]$", 1))) ){
/*975*/ 			ParseDocBlock_n = m2runtime_substr(ParseDocBlock_n, 10, (m2runtime_length(ParseDocBlock_n) - 2), 1, ParseDocBlock_0err_entry_get, 37);
/*976*/ 		} else if( m2_match(ParseDocBlock_n, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"^\134$", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*", m2runtime_CHR(36), 1)) ){
/*977*/ 			ParseDocBlock_n = m2runtime_substr(ParseDocBlock_n, 1, m2runtime_length(ParseDocBlock_n), 1, ParseDocBlock_0err_entry_get, 38);
/*979*/ 		} else {
/*979*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"invalid variable name `", ParseDocBlock_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"' in @global", 1));
/*980*/ 			ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*982*/ 			return ;
/*983*/ 		}
/*983*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global");
/*984*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 12, ParseDocBlock_0err_entry_get, 39) = ParseDocBlock_t;
/*985*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 16, ParseDocBlock_0err_entry_get, 40) = ParseDocBlock_n;
/*989*/ 	}


/*990*/ 	RECORD *
/*990*/ 	ParseDocBlock_parseParam(int ParseDocBlock_position)
/*990*/ 	{
/*991*/ 		RECORD * ParseDocBlock_p = NULL;
/*993*/ 		STRING * ParseDocBlock_w = NULL;
/*996*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*997*/ 		if( ((m2runtime_strcmp(ParseDocBlock_w, EMPTY_STRING) > 0) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_w, 0, 0, 0, ParseDocBlock_0err_entry_get, 41), m2runtime_CHR(36)) == 0)) ){
/*998*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\65,\0,\0,\0)"invalid @param declaration: expected @param TYPE $var");
/*999*/ 			ParseDocBlock_w = ParseDocBlock_getDescr();
/*1000*/ 			return NULL;
/*1002*/ 		} else {
/*1002*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 12, ParseDocBlock_0err_entry_get, 42) = ParseDocBlock_parseType(ParseDocBlock_w);
/*1003*/ 			if( (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 12, ParseDocBlock_0err_entry_get, 43) == Globals_void_type ){
/*1004*/ 				Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"@param cannot be `void'");
/*1005*/ 				*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 12, ParseDocBlock_0err_entry_get, 44) = NULL;
/*1008*/ 			}
/*1012*/ 		}
/*1012*/ 		ParseDocBlock_skipLWSP();
/*1013*/ 		if( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(38)) == 0 ){
/*1014*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 20, ParseDocBlock_0err_entry_get, 45) = TRUE;
/*1015*/ 			ParseDocBlock_readCh();
/*1021*/ 		}
/*1021*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*1022*/ 		if( m2runtime_strcmp(ParseDocBlock_w, EMPTY_STRING) <= 0 ){
/*1023*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"missing parameter name for @param no. ", m2runtime_itos(((ParseDocBlock_position + 1))), 1));
/*1024*/ 		} else if( !m2_match(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)"^\134$[a-zA-Z_\177-\377][a-zA-Z_0-9\177-\377]*$") ){
/*1025*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"invalid parameter name `", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"', expected variable name `$varname'", 1));
/*1028*/ 		} else {
/*1028*/ 			*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 8, ParseDocBlock_0err_entry_get, 46) = m2runtime_substr(ParseDocBlock_w, 1, m2runtime_length(ParseDocBlock_w), 1, ParseDocBlock_0err_entry_get, 47);
/*1035*/ 		}
/*1035*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_p, 24, 3, 16, ParseDocBlock_0err_entry_get, 48) = ParseDocBlock_getDescr();
/*1037*/ 		return ParseDocBlock_p;
/*1040*/ 	}


/*1045*/ 	void
/*1045*/ 	ParseDocBlock_ParseThrows(void)
/*1045*/ 	{
/*1047*/ 		STRING * ParseDocBlock_descr = NULL;
/*1047*/ 		STRING * ParseDocBlock_w = NULL;
/*1052*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*1053*/ 		if( m2runtime_strcmp(ParseDocBlock_w, EMPTY_STRING) <= 0 ){
/*1054*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"missing class in @throws");
/*1056*/ 			return ;
/*1057*/ 		}
/*1057*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 32, ParseDocBlock_0err_entry_get, 49), 4, 1, ParseDocBlock_0err_entry_get, 50) = ParseDocBlock_w;
/*1063*/ 		ParseDocBlock_descr = ParseDocBlock_getDescr();
/*1064*/ 		if( m2runtime_strcmp(ParseDocBlock_descr, EMPTY_STRING) > 0 ){
/*1065*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 36, ParseDocBlock_0err_entry_get, 51), 4, 1, ParseDocBlock_0err_entry_get, 52) = (
/*1065*/ 				push((char*) alloc_RECORD(16, 2)),
/*1065*/ 				push((char*) str_toupper(ParseDocBlock_w)),
/*1065*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1065*/ 				push((char*) ParseDocBlock_descr),
/*1066*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*1067*/ 				(RECORD*) pop()
/*1067*/ 			);
/*1068*/ 		}
/*1070*/ 	}


/*1072*/ 	void
/*1072*/ 	ParseDocBlock_parseUnsupportedUnimplementedLineTag(STRING *ParseDocBlock_w)
/*1072*/ 	{
/*1072*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"<br>", ParseDocBlock_textToHtml(m2runtime_concat_STRING(0, ParseDocBlock_w, m2runtime_CHR(32), ParseDocBlock_getText(), 1)), 1));
/*1077*/ 	}

/*1078*/ 	RECORD * ParseDocBlock_p = NULL;
/*1079*/ 	int ParseDocBlock_position = 0;
/*1081*/ 	STRING * ParseDocBlock_url = NULL;
/*1081*/ 	STRING * ParseDocBlock_w = NULL;
/*1081*/ 	ParseDocBlock_w = ParseDocBlock_getWord();
/*1091*/ 	if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract") == 0 ){
/*1092*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 44, ParseDocBlock_0err_entry_get, 53) = TRUE;
/*1093*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@abstract");
/*1096*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@access") == 0 ){
/*1097*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*1098*/ 		if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private") == 0 ){
/*1099*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 48, ParseDocBlock_0err_entry_get, 54) = TRUE;
/*1100*/ 		} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected") == 0 ){
/*1101*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 52, ParseDocBlock_0err_entry_get, 55) = TRUE;
/*1102*/ 		} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public") == 0 ){
/*1103*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 56, ParseDocBlock_0err_entry_get, 56) = TRUE;
/*1105*/ 		} else {
/*1105*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"expected public|protected|private after @access");
/*1107*/ 		}
/*1107*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@access");
/*1110*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@author") == 0 ){
/*1111*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"<@author ", ParseDocBlock_getText(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1114*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@copyright") == 0 ){
/*1115*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\14,\0,\0,\0)"<@copyright ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1118*/ 	} else if( ((m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@deprecated") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@deprec") == 0)) ){
/*1119*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"\012<@deprecated ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1122*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final") == 0 ){
/*1123*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 60, ParseDocBlock_0err_entry_get, 57) = TRUE;
/*1124*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@final");
/*1127*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@global") == 0 ){
/*1128*/ 		ParseDocBlock_parseGlobal();
/*1131*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@license") == 0 ){
/*1132*/ 		ParseDocBlock_url = ParseDocBlock_getWord();
/*1133*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*1134*/ 		if( (m2runtime_length(ParseDocBlock_w) == 0) ){
/*1135*/ 			ParseDocBlock_w = ParseDocBlock_url;
/*1137*/ 		}
/*1137*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"\012<@license <a href=\042", ParseDocBlock_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"</a>>\012", 1));
/*1140*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@link") == 0 ){
/*1141*/ 		ParseDocBlock_url = ParseDocBlock_getWord();
/*1142*/ 		ParseDocBlock_w = ParseDocBlock_getText();
/*1143*/ 		if( (m2runtime_length(ParseDocBlock_w) == 0) ){
/*1144*/ 			ParseDocBlock_w = ParseDocBlock_url;
/*1146*/ 		}
/*1146*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\32,\0,\0,\0)"\012<p><b>Link:</b> <a href=\042", ParseDocBlock_url, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\042>", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"</a></p>\012", 1));
/*1149*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package") == 0 ){
/*1150*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 40, ParseDocBlock_0err_entry_get, 58) = TRUE;
/*1151*/ 		ParseDocBlock_w = ParseDocBlock_getWord();
/*1152*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"<@package ", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1153*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@package");
/*1156*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@param") == 0 ){
/*1157*/ 		if( ParseDocBlock_pdb == NULL ){
/*1158*/ 			ParseDocBlock_position = 0;
/*1160*/ 		} else {
/*1160*/ 			ParseDocBlock_position = m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 59));
/*1162*/ 		}
/*1162*/ 		ParseDocBlock_p = ParseDocBlock_parseParam(ParseDocBlock_position);
/*1163*/ 		if( ParseDocBlock_p != NULL ){
/*1164*/ 			if( ParseDocBlock_pdb == NULL ){
/*1165*/ 				*(ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 28, ParseDocBlock_0err_entry_get, 60) = NULL;
/*1167*/ 			}
/*1167*/ 			*(RECORD **)m2runtime_dereference_lhs_ARRAY_next((ARRAY **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 28, ParseDocBlock_0err_entry_get, 61), 4, 1, ParseDocBlock_0err_entry_get, 62) = ParseDocBlock_p;
/*1171*/ 		}
/*1171*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@return") == 0 ){
/*1172*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 24, ParseDocBlock_0err_entry_get, 63) = ParseDocBlock_parseType(ParseDocBlock_getWord());
/*1173*/ 		ParseDocBlock_return_descr = ParseDocBlock_getDescr();
/*1178*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@see") == 0 ){
/*1179*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"<@see ", ParseDocBlock_getWord(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1180*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@see");
/*1183*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"@since") == 0 ){
/*1184*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"\012<@since ", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1187*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static") == 0 ){
/*1188*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 64, ParseDocBlock_0err_entry_get, 64) = TRUE;
/*1189*/ 		ParseDocBlock_check_eol((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@static");
/*1192*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@throws") == 0 ){
/*1193*/ 		ParseDocBlock_ParseThrows();
/*1196*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@todo") == 0 ){
/*1197*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"\012<p>\012<b>To-do:</b>\012", ParseDocBlock_getDescr(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"\012</p>\012", 1));
/*1201*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"@var") == 0 ){
/*1202*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 20, ParseDocBlock_0err_entry_get, 65) = ParseDocBlock_parseType(ParseDocBlock_getWord());
/*1203*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 20, ParseDocBlock_0err_entry_get, 66) == Globals_void_type ){
/*1204*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"@var cannot be `void'");
/*1205*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 20, ParseDocBlock_0err_entry_get, 67) = NULL;
/*1207*/ 		}
/*1207*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, ParseDocBlock_getDescr(), m2runtime_CHR(10), 1));
/*1210*/ 	} else if( m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@version") == 0 ){
/*1211*/ 		ParseDocBlock_w = ParseDocBlock_getDescr();
/*1212*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"<@version ", ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">\012", 1));
/*1215*/ 	} else if( ((m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@example") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@category") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"@example") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@exception") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@filesource") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"@ignore") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@internal") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@name") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"@staticvar") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"@subpackage") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"@tutorial") == 0) || (m2runtime_strcmp(ParseDocBlock_w, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"@uses") == 0)) ){
/*1228*/ 		Scanner_Notice2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"unsupported line tag `", ParseDocBlock_w, m2runtime_CHR(39), 1));
/*1229*/ 		ParseDocBlock_parseUnsupportedUnimplementedLineTag(ParseDocBlock_w);
/*1232*/ 	} else {
/*1232*/ 		Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)"unknown line tag `", ParseDocBlock_w, m2runtime_CHR(39), 1));
/*1233*/ 		ParseDocBlock_parseUnsupportedUnimplementedLineTag(ParseDocBlock_w);
/*1237*/ 	}
/*1239*/ }


/*1241*/ void
/*1241*/ ParseDocBlock_parseShortAndLongDescr(STRING **ParseDocBlock_short, STRING **ParseDocBlock_long)
/*1241*/ {

/*1246*/ 	int
/*1246*/ 	ParseDocBlock_findPeriod(STRING *ParseDocBlock_s)
/*1246*/ 	{
/*1248*/ 		int ParseDocBlock_j = 0;
/*1248*/ 		int ParseDocBlock_i = 0;
/*1248*/ 		ParseDocBlock_i = str_find(ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)". ");
/*1249*/ 		ParseDocBlock_j = str_find(ParseDocBlock_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)".\011");
/*1250*/ 		if( (ParseDocBlock_i == -1) ){
/*1251*/ 			ParseDocBlock_i = ParseDocBlock_j;
/*1252*/ 		} else if( (ParseDocBlock_j == -1) ){
/*1255*/ 		} else {
/*1255*/ 			ParseDocBlock_i = m2_min(ParseDocBlock_i, ParseDocBlock_j);
/*1258*/ 		}
/*1258*/ 		if( (ParseDocBlock_i >= 0) ){
/*1259*/ 			return ParseDocBlock_i;
/*1261*/ 		} else {
/*1261*/ 			if( m2runtime_strcmp(m2runtime_substr(ParseDocBlock_s, (m2runtime_length(ParseDocBlock_s) - 1), 0, 0, ParseDocBlock_0err_entry_get, 68), m2runtime_CHR(46)) == 0 ){
/*1262*/ 				return (m2runtime_length(ParseDocBlock_s) - 1);
/*1264*/ 			} else {
/*1264*/ 				return -1;
/*1267*/ 			}
/*1268*/ 		}
/*1268*/ 		m2runtime_missing_return(ParseDocBlock_0err_entry_get, 69);
/*1268*/ 		return 0;
/*1270*/ 	}

/*1271*/ 	int ParseDocBlock_x = 0;
/*1271*/ 	int ParseDocBlock_i = 0;
/*1271*/ 	int ParseDocBlock_n = 0;
/*1272*/ 	void * ParseDocBlock_b = NULL;
/*1273*/ 	STRING * ParseDocBlock_s = NULL;
/*1276*/ 	ARRAY * ParseDocBlock_a = NULL;
/*1276*/ 	*ParseDocBlock_short = NULL;
/*1277*/ 	*ParseDocBlock_long = NULL;
/*1279*/ 	while( (ParseDocBlock_isLWSP(ParseDocBlock_c) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(10)) == 0)) ){
/*1280*/ 		ParseDocBlock_readCh();
/*1283*/ 	}
/*1283*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*1286*/ 	do{
/*1286*/ 		if( ((ParseDocBlock_c == NULL) || (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0)) ){
/*1287*/ 			*ParseDocBlock_short = str_join(ParseDocBlock_a, m2runtime_CHR(32));
/*1290*/ 			goto m2runtime_loop_1;
/*1291*/ 		}
/*1291*/ 		ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*1293*/ 		if( m2runtime_strcmp(ParseDocBlock_s, EMPTY_STRING) <= 0 ){
/*1294*/ 			*ParseDocBlock_short = str_join(ParseDocBlock_a, m2runtime_CHR(32));
/*1297*/ 			goto m2runtime_loop_1;
/*1298*/ 		}
/*1298*/ 		if( (ParseDocBlock_n >= 3) ){
/*1299*/ 			*ParseDocBlock_short = (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, 0, ParseDocBlock_0err_entry_get, 70);
/*1300*/ 			{
/*1300*/ 				int m2runtime_for_limit_1;
/*1300*/ 				ParseDocBlock_i = 1;
/*1300*/ 				m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_a) - 1);
/*1301*/ 				for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1301*/ 					buffer_AddString((void *)&ParseDocBlock_b, (STRING *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_a, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 71));
/*1302*/ 					buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1305*/ 				}
/*1305*/ 			}
/*1306*/ 			goto m2runtime_loop_1;
/*1307*/ 		}
/*1307*/ 		ParseDocBlock_x = ParseDocBlock_findPeriod(ParseDocBlock_s);
/*1309*/ 		if( (ParseDocBlock_x > 0) ){
/*1310*/ 			*ParseDocBlock_short = m2runtime_concat_STRING(0, str_join(ParseDocBlock_a, m2runtime_CHR(32)), m2runtime_CHR(32), m2runtime_substr(ParseDocBlock_s, 0, ParseDocBlock_x, 1, ParseDocBlock_0err_entry_get, 72), 1);
/*1311*/ 			buffer_AddString((void *)&ParseDocBlock_b, m2runtime_substr(ParseDocBlock_s, (ParseDocBlock_x + 1), m2runtime_length(ParseDocBlock_s), 1, ParseDocBlock_0err_entry_get, 73));
/*1312*/ 			buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1315*/ 			goto m2runtime_loop_1;
/*1316*/ 		}
/*1316*/ 		*(STRING **)m2runtime_dereference_lhs_ARRAY(&ParseDocBlock_a, 4, 1, ParseDocBlock_n, ParseDocBlock_0err_entry_get, 74) = ParseDocBlock_s;
/*1317*/ 		m2_inc(&ParseDocBlock_n, 1);
/*1320*/ 	}while(TRUE);
m2runtime_loop_1: ;
/*1320*/ 	while( ((ParseDocBlock_c != NULL) && (m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) != 0)) ){
/*1321*/ 		ParseDocBlock_s = ParseDocBlock_upToEndOfLine();
/*1322*/ 		buffer_AddString((void *)&ParseDocBlock_b, ParseDocBlock_s);
/*1323*/ 		buffer_AddString((void *)&ParseDocBlock_b, m2runtime_CHR(10));
/*1326*/ 	}
/*1326*/ 	*ParseDocBlock_short = ParseDocBlock_expandInlineTags(ParseDocBlock_filterValidHtmlEntities(*ParseDocBlock_short));
/*1327*/ 	*ParseDocBlock_long = ParseDocBlock_expandInlineTags(ParseDocBlock_filterValidHtmlEntities(buffer_ToString(ParseDocBlock_b)));
/*1332*/ }

/*1336*/ RECORD * ParseDocBlock_template = NULL;
/*1340*/ RECORD * ParseDocBlock_template_where = NULL;

/*1344*/ RECORD *
/*1344*/ ParseDocBlock_ParseDocBlock(STRING *ParseDocBlock_doc)
/*1344*/ {
/*1345*/ 	RECORD * ParseDocBlock_p = NULL;
/*1347*/ 	int ParseDocBlock_i = 0;
/*1351*/ 	int ParseDocBlock_is_template = 0;
/*1354*/ 	STRING * ParseDocBlock_long = NULL;
/*1354*/ 	STRING * ParseDocBlock_short = NULL;
/*1354*/ 	if( !ParseDocBlock_parse_phpdoc ){
/*1355*/ 		return NULL;
/*1361*/ 	}
/*1361*/ 	if( (((m2runtime_length(ParseDocBlock_doc) >= 8)) && (m2runtime_strcmp(m2runtime_substr(ParseDocBlock_doc, 0, 6, 1, ParseDocBlock_0err_entry_get, 75), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"/**#@+") == 0)) ){
/*1362*/ 		if( ParseDocBlock_template != NULL ){
/*1363*/ 			Scanner_Error2(Scanner_here(), m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\60,\0,\0,\0)"missing closing /**#@-*/ for template opened in ", Scanner_reference(ParseDocBlock_template_where), 1));
/*1366*/ 		}
/*1366*/ 		ParseDocBlock_is_template = TRUE;
/*1367*/ 		ParseDocBlock_template = NULL;
/*1368*/ 		ParseDocBlock_template_where = Scanner_here();
/*1374*/ 	}
/*1374*/ 	if( m2runtime_strcmp(ParseDocBlock_doc, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"/**#@-*/") == 0 ){
/*1375*/ 		if( ParseDocBlock_template == NULL ){
/*1376*/ 			Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"no previous template opened");
/*1378*/ 		}
/*1378*/ 		ParseDocBlock_template = NULL;
/*1381*/ 	}
/*1381*/ 	if( ParseDocBlock_types == NULL ){
/*1382*/ 		ParseDocBlock_types = (
/*1383*/ 			push((char*) alloc_ARRAY(4, 1)),
/*1383*/ 			push((char*) (
/*1383*/ 				push((char*) alloc_RECORD(16, 2)),
/*1383*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int"),
/*1383*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1383*/ 				push((char*) Globals_int_type),
/*1383*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1384*/ 				(RECORD*) pop()
/*1384*/ 			)),
/*1384*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),0) = (RECORD*) tos(), pop(),
/*1384*/ 			push((char*) (
/*1384*/ 				push((char*) alloc_RECORD(16, 2)),
/*1384*/ 				push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string"),
/*1384*/ 				*(STRING**) (tosn(1)+8) = (STRING*) tos(), pop(),
/*1384*/ 				push((char*) Globals_string_type),
/*1385*/ 				*(RECORD**) (tosn(1)+12) = (RECORD*) tos(), pop(),
/*1386*/ 				(RECORD*) pop()
/*1386*/ 			)),
/*1386*/ 			*(RECORD**) element_ARRAY((ARRAY*) tosn(1),1) = (RECORD*) tos(), pop(),
/*1387*/ 			(ARRAY*) pop()
/*1387*/ 		);
/*1389*/ 	}
/*1389*/ 	ParseDocBlock_in = ParseDocBlock_doc;
/*1390*/ 	if( ParseDocBlock_is_template ){
/*1392*/ 		ParseDocBlock_pos = 6;
/*1394*/ 	} else {
/*1394*/ 		ParseDocBlock_pos = 3;
/*1396*/ 	}
/*1396*/ 	ParseDocBlock_line_n = 1;
/*1397*/ 	ParseDocBlock_len = m2runtime_length(ParseDocBlock_doc);
/*1398*/ 	if( (ParseDocBlock_len <= 5) ){
/*1399*/ 		return NULL;
/*1401*/ 	}
/*1401*/ 	ParseDocBlock_len = (ParseDocBlock_len - 2);
/*1402*/ 	ParseDocBlock_c = m2runtime_CHR(32);
/*1403*/ 	ParseDocBlock_readCh();
/*1406*/ 	ParseDocBlock_pdb = NULL;
/*1407*/ 	ParseDocBlock_return_descr = NULL;
/*1408*/ 	buffer_Reset(*(void **)(void *)&ParseDocBlock_descr);
/*1410*/ 	ParseDocBlock_parseShortAndLongDescr(&ParseDocBlock_short, &ParseDocBlock_long);
/*1411*/ 	if( ((m2runtime_strcmp(ParseDocBlock_short, EMPTY_STRING) > 0) || (m2runtime_strcmp(ParseDocBlock_long, EMPTY_STRING) > 0)) ){
/*1412*/ 		buffer_AddString((void *)&ParseDocBlock_descr, ParseDocBlock_short);
/*1413*/ 		buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"\012\012");
/*1414*/ 		buffer_AddString((void *)&ParseDocBlock_descr, ParseDocBlock_long);
/*1421*/ 	}
/*1421*/ 	while( m2runtime_strcmp(ParseDocBlock_c, m2runtime_CHR(64)) == 0 ){
/*1422*/ 		ParseDocBlock_parseLineTag();
/*1425*/ 	}
/*1425*/ 	if( ParseDocBlock_c != NULL ){
/*1426*/ 		m2runtime_HALT(ParseDocBlock_0err_entry_get, 76, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"expected @ in DocBlock, found ", ParseDocBlock_c, 1));
/*1433*/ 	}
/*1433*/ 	if( ((ParseDocBlock_pdb != NULL) && ((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 77) != NULL)) ){
/*1434*/ 		buffer_Reset(*(void **)(void *)&ParseDocBlock_b);
/*1435*/ 		{
/*1435*/ 			int m2runtime_for_limit_1;
/*1435*/ 			ParseDocBlock_i = 0;
/*1435*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 78)) - 1);
/*1436*/ 			for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1436*/ 				ParseDocBlock_p = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 79), ParseDocBlock_i, ParseDocBlock_0err_entry_get, 80);
/*1437*/ 				if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 16, ParseDocBlock_0err_entry_get, 81), EMPTY_STRING) > 0 ){
/*1438*/ 					buffer_AddString((void *)&ParseDocBlock_b, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"<tr><td valign=top><b><code>$", (STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 8, ParseDocBlock_0err_entry_get, 82), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"&nbsp;&nbsp;</code></b></td> <td valign=top>", (STRING *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_p, 16, ParseDocBlock_0err_entry_get, 83), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"</td></tr>\012", 1));
/*1443*/ 				}
/*1443*/ 			}
/*1443*/ 		}
/*1443*/ 		if( (buffer_Length(ParseDocBlock_b) > 0) ){
/*1444*/ 			buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"\012<p><b>Parameters:</b>\012<table>\012");
/*1445*/ 			buffer_AddString((void *)&ParseDocBlock_descr, buffer_ToString(ParseDocBlock_b));
/*1446*/ 			buffer_AddString((void *)&ParseDocBlock_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"</table>\012</p>\012");
/*1449*/ 		}
/*1453*/ 	}
/*1453*/ 	if( m2runtime_strcmp(ParseDocBlock_return_descr, EMPTY_STRING) > 0 ){
/*1454*/ 		buffer_AddString((void *)&ParseDocBlock_descr, m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)"\012<p><b>Return:</b> ", ParseDocBlock_return_descr, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"</a>\012", 1));
/*1457*/ 	}
/*1457*/ 	if( (buffer_Length(ParseDocBlock_descr) > 0) ){
/*1458*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&ParseDocBlock_pdb, 68, 8, 8, ParseDocBlock_0err_entry_get, 84) = buffer_ToString(ParseDocBlock_descr);
/*1461*/ 	}
/*1461*/ 	if( ParseDocBlock_pdb == NULL ){
/*1462*/ 		if( ParseDocBlock_is_template ){
/*1463*/ 			Scanner_Notice2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"unuseful empty template");
/*1465*/ 		}
/*1465*/ 		return NULL;
/*1471*/ 	}
/*1471*/ 	if( (( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 48, ParseDocBlock_0err_entry_get, 85) && (( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 52, ParseDocBlock_0err_entry_get, 86) ||  *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 56, ParseDocBlock_0err_entry_get, 87)))) || ( *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 52, ParseDocBlock_0err_entry_get, 88) &&  *(int *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 56, ParseDocBlock_0err_entry_get, 89))) ){
/*1473*/ 		Scanner_Error2(Scanner_here(), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\35,\0,\0,\0)"multiple @access declarations");
/*1476*/ 	}
/*1476*/ 	if( ParseDocBlock_is_template ){
/*1477*/ 		ParseDocBlock_template = ParseDocBlock_pdb;
/*1480*/ 	}
/*1480*/ 	return ParseDocBlock_pdb;
/*1484*/ }


/*1486*/ RECORD *
/*1486*/ ParseDocBlock_SearchParam(RECORD *ParseDocBlock_pdb, STRING *ParseDocBlock_name)
/*1486*/ {
/*1487*/ 	ARRAY * ParseDocBlock_params = NULL;
/*1489*/ 	int ParseDocBlock_i = 0;
/*1489*/ 	if( ParseDocBlock_pdb == NULL ){
/*1490*/ 		return NULL;
/*1492*/ 	}
/*1492*/ 	ParseDocBlock_params = (ARRAY *)m2runtime_dereference_rhs_RECORD(ParseDocBlock_pdb, 28, ParseDocBlock_0err_entry_get, 90);
/*1493*/ 	{
/*1493*/ 		int m2runtime_for_limit_1;
/*1493*/ 		ParseDocBlock_i = 0;
/*1493*/ 		m2runtime_for_limit_1 = (m2runtime_count(ParseDocBlock_params) - 1);
/*1494*/ 		for( ; ParseDocBlock_i <= m2runtime_for_limit_1; ParseDocBlock_i += 1 ){
/*1494*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_params, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 91), 8, ParseDocBlock_0err_entry_get, 92), ParseDocBlock_name) == 0 ){
/*1495*/ 				return (RECORD *)m2runtime_dereference_rhs_ARRAY(ParseDocBlock_params, ParseDocBlock_i, ParseDocBlock_0err_entry_get, 93);
/*1498*/ 			}
/*1499*/ 		}
/*1499*/ 	}
/*1499*/ 	return NULL;
/*1504*/ }


char * ParseDocBlock_0func[] = {
    "trim",
    "lowLevelReadCh",
    "textToHtml",
    "expandInlineTags",
    "detectTag",
    "nextTag",
    "short",
    "splitParagraphes",
    "addChunk",
    "next_char",
    "next_sym",
    "parse_array",
    "next_type",
    "parseGlobal",
    "parseParam",
    "ParseThrows",
    "parseLineTag",
    "findPeriod",
    "parseShortAndLongDescr",
    "ParseDocBlock",
    "SearchParam"
};

int ParseDocBlock_0err_entry[] = {
    0 /* trim */, 46,
    0 /* trim */, 50,
    0 /* trim */, 53,
    1 /* lowLevelReadCh */, 76,
    1 /* lowLevelReadCh */, 85,
    1 /* lowLevelReadCh */, 89,
    2 /* textToHtml */, 146,
    3 /* expandInlineTags */, 192,
    3 /* expandInlineTags */, 198,
    3 /* expandInlineTags */, 200,
    3 /* expandInlineTags */, 208,
    3 /* expandInlineTags */, 217,
    3 /* expandInlineTags */, 225,
    3 /* expandInlineTags */, 233,
    3 /* expandInlineTags */, 236,
    3 /* expandInlineTags */, 241,
    3 /* expandInlineTags */, 251,
    3 /* expandInlineTags */, 261,
    3 /* expandInlineTags */, 271,
    3 /* expandInlineTags */, 275,
    3 /* expandInlineTags */, 280,
    3 /* expandInlineTags */, 286,
    4 /* detectTag */, 336,
    4 /* detectTag */, 336,
    5 /* nextTag */, 351,
    6 /* short */, 362,
    7 /* splitParagraphes */, 379,
    7 /* splitParagraphes */, 388,
    8 /* addChunk */, 402,
    9 /* next_char */, 666,
    10 /* next_sym */, 698,
    11 /* parse_array */, 724,
    11 /* parse_array */, 728,
    11 /* parse_array */, 737,
    11 /* parse_array */, 739,
    12 /* next_type */, 823,
    12 /* next_type */, 830,
    13 /* parseGlobal */, 975,
    13 /* parseGlobal */, 977,
    13 /* parseGlobal */, 984,
    13 /* parseGlobal */, 985,
    14 /* parseParam */, 997,
    14 /* parseParam */, 1002,
    14 /* parseParam */, 1003,
    14 /* parseParam */, 1005,
    14 /* parseParam */, 1014,
    14 /* parseParam */, 1028,
    14 /* parseParam */, 1028,
    14 /* parseParam */, 1035,
    15 /* ParseThrows */, 1057,
    15 /* ParseThrows */, 1057,
    15 /* ParseThrows */, 1065,
    15 /* ParseThrows */, 1065,
    16 /* parseLineTag */, 1092,
    16 /* parseLineTag */, 1099,
    16 /* parseLineTag */, 1101,
    16 /* parseLineTag */, 1103,
    16 /* parseLineTag */, 1123,
    16 /* parseLineTag */, 1150,
    16 /* parseLineTag */, 1160,
    16 /* parseLineTag */, 1165,
    16 /* parseLineTag */, 1167,
    16 /* parseLineTag */, 1167,
    16 /* parseLineTag */, 1172,
    16 /* parseLineTag */, 1188,
    16 /* parseLineTag */, 1202,
    16 /* parseLineTag */, 1203,
    16 /* parseLineTag */, 1205,
    17 /* findPeriod */, 1261,
    17 /* findPeriod */, 1267,
    18 /* parseShortAndLongDescr */, 1300,
    18 /* parseShortAndLongDescr */, 1301,
    18 /* parseShortAndLongDescr */, 1310,
    18 /* parseShortAndLongDescr */, 1311,
    18 /* parseShortAndLongDescr */, 1316,
    19 /* ParseDocBlock */, 1361,
    19 /* ParseDocBlock */, 1426,
    19 /* ParseDocBlock */, 1433,
    19 /* ParseDocBlock */, 1435,
    19 /* ParseDocBlock */, 1436,
    19 /* ParseDocBlock */, 1437,
    19 /* ParseDocBlock */, 1437,
    19 /* ParseDocBlock */, 1439,
    19 /* ParseDocBlock */, 1440,
    19 /* ParseDocBlock */, 1458,
    19 /* ParseDocBlock */, 1471,
    19 /* ParseDocBlock */, 1471,
    19 /* ParseDocBlock */, 1471,
    19 /* ParseDocBlock */, 1472,
    19 /* ParseDocBlock */, 1472,
    20 /* SearchParam */, 1492,
    20 /* SearchParam */, 1494,
    20 /* SearchParam */, 1494,
    20 /* SearchParam */, 1496
};

void ParseDocBlock_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "ParseDocBlock";
    *f = ParseDocBlock_0func[ ParseDocBlock_0err_entry[2*i] ];
    *l = ParseDocBlock_0err_entry[2*i + 1];
}
