/* IMPLEMENTATION MODULE Operators */
#define M2_IMPORT_Operators

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Classes
#    include "Classes.c"
#endif

#ifndef M2_IMPORT_Accounting
#    include "Accounting.c"
#endif

void Operators_0err_entry_get(int i, char **m, char **f, int *l);

/* 34*/ RECORD *
/* 34*/ Operators_EvalValueConversion(RECORD *Operators_from_r, RECORD *Operators_to)
/* 34*/ {

/* 36*/ 	void
/* 36*/ 	Operators_invalid(STRING *Operators_s)
/* 36*/ 	{
/* 36*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"value conversion operator from ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 8, Operators_0err_entry_get, 0)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" to ", Types_TypeToString(Operators_to), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Operators_s, 1));
/* 41*/ 	}

/* 42*/ 	RECORD * Operators_from = NULL;
/* 43*/ 	RECORD * Operators_C = NULL;
/* 46*/ 	RECORD * Operators_m = NULL;
/* 46*/ 	if( Operators_from_r == NULL ){
/* 47*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\70,\0,\0,\0)"value conversion operator applied to an unknow data type");
/* 48*/ 		return (
/* 48*/ 			push((char*) alloc_RECORD(16, 2)),
/* 48*/ 			push((char*) Operators_to),
/* 48*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/* 48*/ 			push((char*) NULL),
/* 49*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/* 50*/ 			(RECORD*) pop()
/* 50*/ 		);
/* 51*/ 	}
/* 51*/ 	Operators_from = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 8, Operators_0err_entry_get, 1);
/* 52*/ 	if( Operators_from == NULL ){
/* 53*/ 		return (
/* 53*/ 			push((char*) alloc_RECORD(16, 2)),
/* 53*/ 			push((char*) Operators_to),
/* 53*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/* 53*/ 			push((char*) NULL),
/* 54*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/* 55*/ 			(RECORD*) pop()
/* 55*/ 		);
/* 56*/ 	}
/* 56*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_from, 16, Operators_0err_entry_get, 2)){

/* 58*/ 	case 2:
/* 59*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 3) == 3) ){
/* 60*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 4), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE") == 0 ){
/* 61*/ 			return (
/* 61*/ 				push((char*) alloc_RECORD(16, 2)),
/* 61*/ 				push((char*) Globals_int_type),
/* 61*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/* 61*/ 				push((char*) m2runtime_CHR(48)),
/* 62*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/* 62*/ 				(RECORD*) pop()
/* 62*/ 			);
/* 62*/ 		} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 5), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0 ){
/* 63*/ 			return (
/* 63*/ 				push((char*) alloc_RECORD(16, 2)),
/* 63*/ 				push((char*) Globals_int_type),
/* 63*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/* 63*/ 				push((char*) m2runtime_CHR(49)),
/* 64*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/* 65*/ 				(RECORD*) pop()
/* 65*/ 			);
/* 65*/ 		} else {
/* 65*/ 			return (
/* 65*/ 				push((char*) alloc_RECORD(16, 2)),
/* 65*/ 				push((char*) Globals_int_type),
/* 65*/ 				*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/* 65*/ 				push((char*) NULL),
/* 66*/ 				*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/* 67*/ 				(RECORD*) pop()
/* 67*/ 			);
/* 68*/ 		}
/* 68*/ 	} else {
/* 68*/ 		Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/* 71*/ 	}
/* 71*/ 	break;

/* 71*/ 	case 3:
/* 72*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 6)){

/* 73*/ 	case 2:
/* 73*/ 	case 4:
/* 73*/ 	case 5:
/* 75*/ 	break;

/* 75*/ 	default:
/* 75*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/* 78*/ 	}
/* 78*/ 	break;

/* 78*/ 	case 4:
/* 79*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 7)){

/* 80*/ 	case 3:
/* 80*/ 	case 5:
/* 81*/ 	break;

/* 81*/ 	default:
/* 81*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/* 84*/ 	}
/* 84*/ 	break;

/* 84*/ 	case 5:
/* 85*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 8)){

/* 86*/ 	case 3:
/* 86*/ 	case 4:
/* 87*/ 	break;

/* 87*/ 	default:
/* 87*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/* 90*/ 	}
/* 90*/ 	break;

/* 90*/ 	case 7:
/* 91*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 9)){

/* 92*/ 	case 2:
/* 92*/ 	case 3:
/* 92*/ 	case 4:
/* 92*/ 	case 5:
/* 93*/ 	break;

/* 93*/ 	default:
/* 93*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/* 96*/ 	}
/* 96*/ 	break;

/* 96*/ 	case 9:
/* 97*/ 	if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 10) == 5)) && ((Globals_php_ver == 5)) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from, 12, Operators_0err_entry_get, 11) != NULL)) ){
/* 99*/ 		Classes_ResolveClassMethod((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from, 12, Operators_0err_entry_get, 12), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"__toString", &Operators_C, &Operators_m);
/*100*/ 		if( Operators_m == NULL ){
/*101*/ 			Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*104*/ 		} else {
/*104*/ 			Accounting_AccountClassMethod(Operators_C, Operators_m);
/*107*/ 		}
/*107*/ 	} else {
/*107*/ 		Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*110*/ 	}
/*110*/ 	break;

/*110*/ 	case 0:
/*111*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 13)){

/*112*/ 	case 5:
/*112*/ 	case 6:
/*112*/ 	case 8:
/*112*/ 	case 9:
/*113*/ 	return (
/*113*/ 		push((char*) alloc_RECORD(16, 2)),
/*113*/ 		push((char*) Operators_to),
/*113*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*113*/ 		push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*114*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*114*/ 		(RECORD*) pop()
/*114*/ 	);
/*114*/ 	break;

/*114*/ 	default:
/*114*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*118*/ 	}
/*118*/ 	break;

/*118*/ 	default:
/*118*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*123*/ 	}
/*123*/ 	if( (STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 14) == NULL ){
/*124*/ 		return (
/*124*/ 			push((char*) alloc_RECORD(16, 2)),
/*124*/ 			push((char*) Operators_to),
/*124*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*124*/ 			push((char*) m2runtime_concat_STRING(0, m2runtime_CHR(40), Types_TypeToString(Operators_to), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)") ", (STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 15), 1)),
/*125*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*126*/ 			(RECORD*) pop()
/*126*/ 		);
/*126*/ 	} else {
/*126*/ 		return (
/*126*/ 			push((char*) alloc_RECORD(16, 2)),
/*126*/ 			push((char*) Operators_to),
/*126*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*126*/ 			push((char*) NULL),
/*127*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*128*/ 			(RECORD*) pop()
/*128*/ 		);
/*129*/ 	}
/*129*/ 	m2runtime_missing_return(Operators_0err_entry_get, 16);
/*129*/ 	return NULL;
/*131*/ }


/*133*/ RECORD *
/*133*/ Operators_EvalTypeConversion(RECORD *Operators_from_r, RECORD *Operators_to)
/*133*/ {

/*135*/ 	void
/*135*/ 	Operators_invalid(STRING *Operators_s)
/*135*/ 	{
/*135*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)"type conversion operator from ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 8, Operators_0err_entry_get, 17)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)" to ", Types_TypeToString(Operators_to), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", Operators_s, 1));
/*140*/ 	}


/*141*/ 	void
/*141*/ 	Operators_EvalFormalTypecastArray(int Operators_fi, RECORD *Operators_fe, int Operators_ti, RECORD *Operators_te)
/*141*/ 	{
/*143*/ 		RECORD * Operators_r = NULL;
/*143*/ 		switch(Operators_fi){

/*144*/ 		case 1:
/*145*/ 		break;

/*145*/ 		case 3:
/*146*/ 		if( (Operators_ti != 3) ){
/*147*/ 			Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"incompatible index type");
/*149*/ 		}
/*149*/ 		break;

/*149*/ 		case 5:
/*150*/ 		if( (Operators_ti != 5) ){
/*151*/ 			Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"incompatible index type");
/*153*/ 		}
/*153*/ 		break;

/*153*/ 		case 7:
/*155*/ 		break;

/*155*/ 		default: m2runtime_missing_case_in_switch(Operators_0err_entry_get, 18);
/*155*/ 		}
/*155*/ 		Operators_r = Operators_EvalTypeConversion((
/*155*/ 			push((char*) alloc_RECORD(16, 2)),
/*155*/ 			push((char*) Operators_fe),
/*155*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*155*/ 			push((char*) NULL),
/*155*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*155*/ 			(RECORD*) pop()
/*155*/ 		), Operators_te);
/*158*/ 	}

/*161*/ 	RECORD * Operators_from = NULL;
/*161*/ 	if( Operators_from_r == NULL ){
/*162*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\67,\0,\0,\0)"type conversion operator applied to an unknow data type");
/*163*/ 		return (
/*163*/ 			push((char*) alloc_RECORD(16, 2)),
/*163*/ 			push((char*) Operators_to),
/*163*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*163*/ 			push((char*) NULL),
/*164*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*165*/ 			(RECORD*) pop()
/*165*/ 		);
/*166*/ 	}
/*166*/ 	Operators_from = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 8, Operators_0err_entry_get, 19);
/*167*/ 	if( Operators_from == NULL ){
/*168*/ 		return (
/*168*/ 			push((char*) alloc_RECORD(16, 2)),
/*168*/ 			push((char*) Operators_to),
/*168*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*168*/ 			push((char*) NULL),
/*169*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*170*/ 			(RECORD*) pop()
/*170*/ 		);
/*171*/ 	}
/*171*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_from, 16, Operators_0err_entry_get, 20)){

/*173*/ 	case 0:
/*174*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 21)){

/*175*/ 	case 5:
/*175*/ 	case 6:
/*175*/ 	case 8:
/*175*/ 	case 9:
/*176*/ 	return (
/*176*/ 		push((char*) alloc_RECORD(16, 2)),
/*176*/ 		push((char*) Operators_to),
/*176*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*176*/ 		push((char*) (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"NULL"),
/*177*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*177*/ 		(RECORD*) pop()
/*177*/ 	);
/*177*/ 	break;

/*177*/ 	default:
/*177*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*180*/ 	}
/*180*/ 	break;

/*180*/ 	case 7:
/*181*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 22)){

/*182*/ 	case 2:
/*182*/ 	case 3:
/*182*/ 	case 4:
/*182*/ 	case 5:
/*182*/ 	case 6:
/*182*/ 	case 8:
/*182*/ 	case 9:
/*183*/ 	break;

/*183*/ 	default:
/*183*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*186*/ 	}
/*186*/ 	break;

/*186*/ 	case 6:
/*187*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 23) != 6) ){
/*188*/ 		Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*190*/ 	} else {
/*190*/ 		Operators_EvalFormalTypecastArray( *(int *)m2runtime_dereference_rhs_RECORD(Operators_from, 20, Operators_0err_entry_get, 24), (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from, 8, Operators_0err_entry_get, 25),  *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 20, Operators_0err_entry_get, 26), (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_to, 8, Operators_0err_entry_get, 27));
/*194*/ 	}
/*194*/ 	break;

/*194*/ 	case 9:
/*195*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_to, 16, Operators_0err_entry_get, 28) == 9) ){
/*202*/ 	} else {
/*202*/ 		Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*204*/ 	}
/*204*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_from, 12, Operators_0err_entry_get, 29) != NULL ){
/*205*/ 		Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"the term must be a generic `object'");
/*209*/ 	}
/*209*/ 	break;

/*209*/ 	default:
/*209*/ 	Operators_invalid((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"undefined");
/*214*/ 	}
/*214*/ 	if( (STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 30) == NULL ){
/*215*/ 		return (
/*215*/ 			push((char*) alloc_RECORD(16, 2)),
/*215*/ 			push((char*) Operators_to),
/*215*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*215*/ 			push((char*) NULL),
/*216*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*217*/ 			(RECORD*) pop()
/*217*/ 		);
/*217*/ 	} else {
/*217*/ 		return (
/*217*/ 			push((char*) alloc_RECORD(16, 2)),
/*217*/ 			push((char*) Operators_to),
/*217*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*217*/ 			push((char*) m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"/*.(", Types_TypeToString(Operators_to), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)").*/ ", (STRING *)m2runtime_dereference_rhs_RECORD(Operators_from_r, 12, Operators_0err_entry_get, 31), 1)),
/*218*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*219*/ 			(RECORD*) pop()
/*219*/ 		);
/*220*/ 	}
/*220*/ 	m2runtime_missing_return(Operators_0err_entry_get, 32);
/*220*/ 	return NULL;
/*222*/ }


/*227*/ void
/*227*/ Operators_eval_res_type(RECORD *Operators_a, RECORD *Operators_b, STRING *Operators_op_name, RECORD **Operators_res_type, STRING **Operators_res_as, STRING **Operators_res_bs)
/*227*/ {
/*227*/ 	RECORD * Operators_t = NULL;
/*227*/ 	RECORD * Operators_bt = NULL;
/*227*/ 	RECORD * Operators_at = NULL;
/*229*/ 	STRING * Operators_bs = NULL;
/*229*/ 	STRING * Operators_as = NULL;
/*229*/ 	if( Operators_a == NULL ){
/*233*/ 	} else {
/*233*/ 		Operators_at = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 33);
/*234*/ 		if( Operators_at == Globals_int_type ){
/*235*/ 			Operators_as = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 34);
/*236*/ 		} else if( Operators_at == Globals_float_type ){
/*237*/ 			Operators_as = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 35);
/*239*/ 		} else {
/*239*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"`EXPR ", Operators_op_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" ...': found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 36)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)", expected a number.", 1));
/*243*/ 		}
/*244*/ 	}
/*244*/ 	if( Operators_b == NULL ){
/*247*/ 	} else {
/*247*/ 		Operators_bt = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 37);
/*248*/ 		if( Operators_bt == Globals_int_type ){
/*249*/ 			Operators_bs = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 38);
/*250*/ 		} else if( Operators_bt == Globals_float_type ){
/*251*/ 			Operators_bs = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 39);
/*253*/ 		} else {
/*253*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"`... ", Operators_op_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)" EXPR': found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 40)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)", expected a number.", 1));
/*257*/ 		}
/*259*/ 	}
/*259*/ 	if( Operators_at == Globals_int_type ){
/*260*/ 		if( Operators_bt == Globals_int_type ){
/*261*/ 			Operators_t = Globals_int_type;
/*262*/ 		} else if( Operators_bt == Globals_float_type ){
/*263*/ 			Operators_t = Globals_float_type;
/*265*/ 		}
/*265*/ 	} else if( Operators_at == Globals_float_type ){
/*266*/ 		if( Operators_bt == Globals_int_type ){
/*267*/ 			Operators_t = Globals_float_type;
/*268*/ 		} else if( Operators_bt == Globals_float_type ){
/*269*/ 			Operators_t = Globals_float_type;
/*272*/ 		}
/*273*/ 	}
/*273*/ 	*Operators_res_type = Operators_t;
/*274*/ 	*Operators_res_as = Operators_as;
/*275*/ 	*Operators_res_bs = Operators_bs;
/*280*/ }


/*281*/ RECORD *
/*281*/ Operators_EvalPlus(RECORD *Operators_a, RECORD *Operators_b)
/*281*/ {
/*281*/ 	RECORD * Operators_t = NULL;
/*283*/ 	STRING * Operators_v = NULL;
/*283*/ 	STRING * Operators_bs = NULL;
/*283*/ 	STRING * Operators_as = NULL;
/*283*/ 	Operators_eval_res_type(Operators_a, Operators_b, m2runtime_CHR(43), &Operators_t, &Operators_as, &Operators_bs);
/*285*/ 	if( ((Operators_as != NULL) && (Operators_bs != NULL)) ){
/*286*/ 		if( Operators_t == Globals_int_type ){
/*287*/ 			Operators_v = m2runtime_itos((m2_stoi(Operators_as) + m2_stoi(Operators_bs)));
/*289*/ 		} else if( Operators_t == Globals_float_type ){
/*290*/ 			Operators_v = m2runtime_rtos(m2_stor(Operators_as) + m2_stor(Operators_bs));
/*293*/ 		}
/*294*/ 	}
/*294*/ 	if( Operators_t == NULL ){
/*295*/ 		return NULL;
/*297*/ 	}
/*297*/ 	return (
/*297*/ 		push((char*) alloc_RECORD(16, 2)),
/*297*/ 		push((char*) Operators_t),
/*297*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*297*/ 		push((char*) Operators_v),
/*298*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*299*/ 		(RECORD*) pop()
/*299*/ 	);
/*301*/ }


/*302*/ RECORD *
/*302*/ Operators_EvalMinus(RECORD *Operators_a, RECORD *Operators_b)
/*302*/ {
/*302*/ 	RECORD * Operators_t = NULL;
/*304*/ 	STRING * Operators_v = NULL;
/*304*/ 	STRING * Operators_bs = NULL;
/*304*/ 	STRING * Operators_as = NULL;
/*304*/ 	Operators_eval_res_type(Operators_a, Operators_b, m2runtime_CHR(45), &Operators_t, &Operators_as, &Operators_bs);
/*306*/ 	if( ((Operators_as != NULL) && (Operators_bs != NULL)) ){
/*307*/ 		if( Operators_t == Globals_int_type ){
/*308*/ 			Operators_v = m2runtime_itos((m2_stoi(Operators_as) - m2_stoi(Operators_bs)));
/*310*/ 		} else if( Operators_t == Globals_float_type ){
/*311*/ 			Operators_v = m2runtime_rtos(m2_stor(Operators_as) - m2_stor(Operators_bs));
/*314*/ 		}
/*315*/ 	}
/*315*/ 	if( Operators_t == NULL ){
/*316*/ 		return NULL;
/*318*/ 	}
/*318*/ 	return (
/*318*/ 		push((char*) alloc_RECORD(16, 2)),
/*318*/ 		push((char*) Operators_t),
/*318*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*318*/ 		push((char*) Operators_v),
/*319*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*320*/ 		(RECORD*) pop()
/*320*/ 	);
/*322*/ }


/*323*/ RECORD *
/*323*/ Operators_EvalMult(RECORD *Operators_a, RECORD *Operators_b)
/*323*/ {
/*323*/ 	RECORD * Operators_t = NULL;
/*325*/ 	STRING * Operators_v = NULL;
/*325*/ 	STRING * Operators_bs = NULL;
/*325*/ 	STRING * Operators_as = NULL;
/*325*/ 	Operators_eval_res_type(Operators_a, Operators_b, m2runtime_CHR(42), &Operators_t, &Operators_as, &Operators_bs);
/*327*/ 	if( ((Operators_as != NULL) && (Operators_bs != NULL)) ){
/*328*/ 		if( Operators_t == Globals_int_type ){
/*329*/ 			Operators_v = m2runtime_itos((m2_stoi(Operators_as) * m2_stoi(Operators_bs)));
/*331*/ 		} else if( Operators_t == Globals_float_type ){
/*332*/ 			Operators_v = m2runtime_rtos(m2_stor(Operators_as) * m2_stor(Operators_bs));
/*335*/ 		}
/*336*/ 	}
/*336*/ 	if( Operators_t == NULL ){
/*337*/ 		return NULL;
/*339*/ 	}
/*339*/ 	return (
/*339*/ 		push((char*) alloc_RECORD(16, 2)),
/*339*/ 		push((char*) Operators_t),
/*339*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*339*/ 		push((char*) Operators_v),
/*340*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*341*/ 		(RECORD*) pop()
/*341*/ 	);
/*343*/ }


/*344*/ RECORD *
/*344*/ Operators_EvalDiv(RECORD *Operators_a, RECORD *Operators_b)
/*344*/ {
/*344*/ 	RECORD * Operators_t = NULL;
/*346*/ 	STRING * Operators_v = NULL;
/*346*/ 	STRING * Operators_bs = NULL;
/*346*/ 	STRING * Operators_as = NULL;
/*346*/ 	Operators_eval_res_type(Operators_a, Operators_b, m2runtime_CHR(47), &Operators_t, &Operators_as, &Operators_bs);
/*348*/ 	if( Operators_t == Globals_int_type ){
/*349*/ 		Operators_t = Globals_float_type;
/*353*/ 	}
/*353*/ 	if( ((Operators_t == Globals_float_type) && (Operators_as != NULL) && (Operators_bs != NULL)) ){
/*354*/ 		Operators_v = m2runtime_rtos(m2_stor(Operators_as) / m2_stor(Operators_bs));
/*357*/ 	}
/*357*/ 	if( Operators_t == NULL ){
/*358*/ 		return NULL;
/*360*/ 	}
/*360*/ 	return (
/*360*/ 		push((char*) alloc_RECORD(16, 2)),
/*360*/ 		push((char*) Operators_t),
/*360*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*360*/ 		push((char*) Operators_v),
/*361*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*362*/ 		(RECORD*) pop()
/*362*/ 	);
/*364*/ }


/*365*/ RECORD *
/*365*/ Operators_EvalMod(RECORD *Operators_a, RECORD *Operators_b)
/*365*/ {
/*365*/ 	RECORD * Operators_t = NULL;
/*367*/ 	STRING * Operators_v = NULL;
/*367*/ 	STRING * Operators_bs = NULL;
/*367*/ 	STRING * Operators_as = NULL;
/*367*/ 	Operators_eval_res_type(Operators_a, Operators_b, m2runtime_CHR(37), &Operators_t, &Operators_as, &Operators_bs);
/*369*/ 	if( Operators_t == Globals_float_type ){
/*370*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"operator `%' applied to non-integer numbers might give", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)" unpredictable results", 1));
/*374*/ 	}
/*374*/ 	if( ((Operators_t == Globals_int_type) && (Operators_as != NULL) && (Operators_bs != NULL)) ){
/*375*/ 		Operators_v = m2runtime_itos((m2_stoi(Operators_as) % m2_stoi(Operators_bs)));
/*378*/ 	}
/*378*/ 	if( Operators_t == NULL ){
/*379*/ 		return NULL;
/*381*/ 	}
/*381*/ 	return (
/*381*/ 		push((char*) alloc_RECORD(16, 2)),
/*381*/ 		push((char*) Operators_t),
/*381*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*381*/ 		push((char*) Operators_v),
/*382*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*383*/ 		(RECORD*) pop()
/*383*/ 	);
/*385*/ }


/*387*/ RECORD *
/*387*/ Operators_EvalPeriod(RECORD *Operators_a, RECORD *Operators_b)
/*387*/ {
/*388*/ 	STRING * Operators_bs = NULL;
/*388*/ 	STRING * Operators_as = NULL;
/*390*/ 	RECORD * Operators_t = NULL;
/*390*/ 	if( Operators_a != NULL ){
/*391*/ 		Operators_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 41);
/*393*/ 	}
/*393*/ 	if( Operators_a == NULL ){
/*395*/ 	} else if( Operators_t == Globals_boolean_type ){
/*396*/ 		Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\201,\0,\0,\0)"found boolean value in string concatenation: remember that FALSE gets rendered as empty string \042\042 while TRUE gets rendered as \0421\042");
/*397*/ 	} else if( Operators_t == Globals_int_type ){
/*398*/ 		Operators_as = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 42);
/*399*/ 	} else if( Operators_t == Globals_float_type ){
/*400*/ 		Operators_as = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 43);
/*401*/ 	} else if( Operators_t == Globals_string_type ){
/*402*/ 		Operators_as = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 44);
/*404*/ 	} else {
/*404*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\44,\0,\0,\0)"`EXPR . ...': invalid value of type ", Types_TypeToString(Operators_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)", expected a string", 1));
/*408*/ 	}
/*408*/ 	if( Operators_b != NULL ){
/*409*/ 		Operators_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 45);
/*411*/ 	}
/*411*/ 	if( Operators_b == NULL ){
/*413*/ 	} else if( Operators_t == Globals_boolean_type ){
/*414*/ 		Scanner_Notice((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\201,\0,\0,\0)"found boolean value in string concatenation: remember that FALSE gets rendered as empty string \042\042 while TRUE gets rendered as \0421\042");
/*415*/ 	} else if( Operators_t == Globals_int_type ){
/*416*/ 		Operators_bs = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 46);
/*417*/ 	} else if( Operators_t == Globals_float_type ){
/*418*/ 		Operators_bs = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 47);
/*419*/ 	} else if( Operators_t == Globals_string_type ){
/*420*/ 		Operators_bs = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 48);
/*422*/ 	} else {
/*422*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"`... . EXPR': found ", Types_TypeToString(Operators_t), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\23,\0,\0,\0)", expected a string", 1));
/*426*/ 	}
/*426*/ 	if( ((Operators_as == NULL) || (Operators_bs == NULL)) ){
/*427*/ 		return (
/*427*/ 			push((char*) alloc_RECORD(16, 2)),
/*427*/ 			push((char*) Globals_string_type),
/*427*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*427*/ 			push((char*) NULL),
/*428*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*429*/ 			(RECORD*) pop()
/*429*/ 		);
/*429*/ 	} else {
/*429*/ 		return (
/*429*/ 			push((char*) alloc_RECORD(16, 2)),
/*429*/ 			push((char*) Globals_string_type),
/*429*/ 			*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*429*/ 			push((char*) m2runtime_concat_STRING(0, Operators_as, Operators_bs, 1)),
/*430*/ 			*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*431*/ 			(RECORD*) pop()
/*431*/ 		);
/*432*/ 	}
/*432*/ 	m2runtime_missing_return(Operators_0err_entry_get, 49);
/*432*/ 	return NULL;
/*434*/ }


/*435*/ RECORD *
/*435*/ Operators_EvalNot(RECORD *Operators_x)
/*435*/ {
/*437*/ 	RECORD * Operators_r = NULL;
/*437*/ 	Operators_r = (
/*437*/ 		push((char*) alloc_RECORD(16, 2)),
/*437*/ 		push((char*) Globals_boolean_type),
/*437*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*437*/ 		push((char*) NULL),
/*438*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*438*/ 		(RECORD*) pop()
/*438*/ 	);
/*438*/ 	if( Operators_x == NULL ){
/*439*/ 		return Operators_r;
/*440*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_x, 8, Operators_0err_entry_get, 50) != Globals_boolean_type ){
/*441*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"invalid argument of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_x, 8, Operators_0err_entry_get, 51)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)" for the boolean operator `!'. Expected boolean value.", 1));
/*443*/ 		return Operators_r;
/*444*/ 	} else if( (STRING *)m2runtime_dereference_rhs_RECORD(Operators_x, 12, Operators_0err_entry_get, 52) == NULL ){
/*445*/ 		return Operators_r;
/*447*/ 	}
/*447*/ 	if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_x, 12, Operators_0err_entry_get, 53), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0 ){
/*448*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 54) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*450*/ 	} else {
/*450*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 55) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*452*/ 	}
/*452*/ 	return Operators_r;
/*456*/ }


/*457*/ RECORD *
/*457*/ Operators_EvalUnaryPlusMinus(int Operators_is_minus, RECORD *Operators_r)
/*457*/ {
/*457*/ 	RECORD * Operators_t = NULL;
/*459*/ 	STRING * Operators_v = NULL;
/*459*/ 	if( Operators_r == NULL ){
/*460*/ 		return NULL;
/*461*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 56) == Globals_int_type ){
/*462*/ 		Operators_t = Globals_int_type;
/*463*/ 		Operators_v = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 57);
/*464*/ 		if( (Operators_is_minus && (Operators_v != NULL)) ){
/*465*/ 			Operators_v = m2runtime_itos(-m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 58)));
/*467*/ 		}
/*467*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 59) == Globals_float_type ){
/*468*/ 		Operators_t = Globals_float_type;
/*469*/ 		Operators_v = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 60);
/*470*/ 		if( (Operators_is_minus && (Operators_v != NULL)) ){
/*471*/ 			Operators_v = m2runtime_rtos(-m2_stor((STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 61)));
/*474*/ 		}
/*474*/ 	} else {
/*474*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"invalid value of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 62)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" for the unary operator +/-", 1));
/*476*/ 		return NULL;
/*478*/ 	}
/*478*/ 	return (
/*478*/ 		push((char*) alloc_RECORD(16, 2)),
/*478*/ 		push((char*) Operators_t),
/*478*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*478*/ 		push((char*) Operators_v),
/*479*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*480*/ 		(RECORD*) pop()
/*480*/ 	);
/*482*/ }


/*487*/ int
/*487*/ Operators_check_args_bit_binary_op(STRING *Operators_n, RECORD *Operators_a, RECORD *Operators_b)
/*487*/ {
/*489*/ 	int Operators_good = 0;
/*489*/ 	if( ((Operators_a == NULL) || (Operators_b == NULL)) ){
/*490*/ 		return FALSE;
/*494*/ 	}
/*494*/ 	Operators_good = TRUE;
/*495*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 63) != Globals_int_type ){
/*496*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"`EXPR ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\15,\0,\0,\0)" ...': found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 64)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)", expected int", 1));
/*498*/ 		Operators_good = FALSE;
/*500*/ 	}
/*500*/ 	if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 65) != Globals_int_type ){
/*501*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"`... ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)" EXPR': found ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 66)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)", expected int", 1));
/*503*/ 		Operators_good = FALSE;
/*505*/ 	}
/*505*/ 	if( !Operators_good ){
/*506*/ 		return FALSE;
/*510*/ 	}
/*510*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 67) == NULL) || ((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 68) == NULL)) ){
/*511*/ 		return FALSE;
/*514*/ 	}
/*514*/ 	return TRUE;
/*518*/ }


/*519*/ RECORD *
/*519*/ Operators_EvalLShift(RECORD *Operators_a, RECORD *Operators_b)
/*519*/ {
/*521*/ 	RECORD * Operators_r = NULL;
/*521*/ 	Operators_r = (
/*521*/ 		push((char*) alloc_RECORD(16, 2)),
/*521*/ 		push((char*) Globals_int_type),
/*521*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*521*/ 		push((char*) NULL),
/*522*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*522*/ 		(RECORD*) pop()
/*522*/ 	);
/*522*/ 	if( Operators_check_args_bit_binary_op((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<<", Operators_a, Operators_b) ){
/*523*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 69) = m2runtime_itos(((unsigned int) m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 70)) << m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 71))));
/*525*/ 	}
/*525*/ 	return Operators_r;
/*529*/ }


/*530*/ RECORD *
/*530*/ Operators_EvalRShift(RECORD *Operators_a, RECORD *Operators_b)
/*530*/ {
/*532*/ 	RECORD * Operators_r = NULL;
/*532*/ 	Operators_r = (
/*532*/ 		push((char*) alloc_RECORD(16, 2)),
/*532*/ 		push((char*) Globals_int_type),
/*532*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*532*/ 		push((char*) NULL),
/*533*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*533*/ 		(RECORD*) pop()
/*533*/ 	);
/*533*/ 	if( Operators_check_args_bit_binary_op((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<<", Operators_a, Operators_b) ){
/*534*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 72) = m2runtime_itos(((unsigned int) m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 73)) >> m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 74))));
/*536*/ 	}
/*536*/ 	return Operators_r;
/*540*/ }


/*541*/ RECORD *
/*541*/ Operators_EvalBitNot(RECORD *Operators_r)
/*541*/ {
/*543*/ 	STRING * Operators_v = NULL;
/*543*/ 	if( Operators_r == NULL ){
/*545*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 75), 16, Operators_0err_entry_get, 76) == 3) ){
/*546*/ 		if( (STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 77) != NULL ){
/*547*/ 			Operators_v = m2runtime_itos(~m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_r, 12, Operators_0err_entry_get, 78)));
/*550*/ 		}
/*550*/ 	} else {
/*550*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"invalid value of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 79)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)" for the bitwise not operator `~'", 1));
/*553*/ 	}
/*553*/ 	return (
/*553*/ 		push((char*) alloc_RECORD(16, 2)),
/*553*/ 		push((char*) Globals_int_type),
/*553*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*553*/ 		push((char*) Operators_v),
/*554*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*555*/ 		(RECORD*) pop()
/*555*/ 	);
/*557*/ }


/*558*/ RECORD *
/*558*/ Operators_EvalBitAnd(RECORD *Operators_a, RECORD *Operators_b)
/*558*/ {
/*560*/ 	RECORD * Operators_r = NULL;
/*560*/ 	Operators_r = (
/*560*/ 		push((char*) alloc_RECORD(16, 2)),
/*560*/ 		push((char*) Globals_int_type),
/*560*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*560*/ 		push((char*) NULL),
/*561*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*561*/ 		(RECORD*) pop()
/*561*/ 	);
/*561*/ 	if( Operators_check_args_bit_binary_op(m2runtime_CHR(38), Operators_a, Operators_b) ){
/*562*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 80) = m2runtime_itos((m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 81)) & m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 82))));
/*564*/ 	}
/*564*/ 	return Operators_r;
/*568*/ }


/*569*/ RECORD *
/*569*/ Operators_EvalBitXor(RECORD *Operators_a, RECORD *Operators_b)
/*569*/ {
/*571*/ 	RECORD * Operators_r = NULL;
/*571*/ 	Operators_r = (
/*571*/ 		push((char*) alloc_RECORD(16, 2)),
/*571*/ 		push((char*) Globals_int_type),
/*571*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*571*/ 		push((char*) NULL),
/*572*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*572*/ 		(RECORD*) pop()
/*572*/ 	);
/*572*/ 	if( Operators_check_args_bit_binary_op(m2runtime_CHR(94), Operators_a, Operators_b) ){
/*573*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 83) = m2runtime_itos((m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 84)) ^ m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 85))));
/*575*/ 	}
/*575*/ 	return Operators_r;
/*579*/ }


/*580*/ RECORD *
/*580*/ Operators_EvalBitOr(RECORD *Operators_a, RECORD *Operators_b)
/*580*/ {
/*582*/ 	RECORD * Operators_r = NULL;
/*582*/ 	Operators_r = (
/*582*/ 		push((char*) alloc_RECORD(16, 2)),
/*582*/ 		push((char*) Globals_int_type),
/*582*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*582*/ 		push((char*) NULL),
/*583*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*583*/ 		(RECORD*) pop()
/*583*/ 	);
/*583*/ 	if( Operators_check_args_bit_binary_op(m2runtime_CHR(124), Operators_a, Operators_b) ){
/*584*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 86) = m2runtime_itos((m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 87)) | m2_stoi((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 88))));
/*586*/ 	}
/*586*/ 	return Operators_r;
/*590*/ }


/*594*/ RECORD *
/*594*/ Operators_EvalCmp(STRING *Operators_n, RECORD *Operators_a, RECORD *Operators_b)
/*594*/ {
/*594*/ 	RECORD * Operators_r = NULL;
/*594*/ 	RECORD * Operators_bt = NULL;
/*594*/ 	RECORD * Operators_at = NULL;
/*594*/ 	STRING * Operators_rv = NULL;
/*594*/ 	STRING * Operators_bv = NULL;
/*594*/ 	STRING * Operators_av = NULL;
/*596*/ 	int Operators_x = 0;

/*598*/ 	void
/*598*/ 	Operators_W(STRING *Operators_s)
/*598*/ 	{
/*598*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"comparing (", Types_TypeToString(Operators_at), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)") ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" (", Types_TypeToString(Operators_bt), m2runtime_CHR(41), Operators_s, 1));
/*602*/ 	}


/*604*/ 	void
/*604*/ 	Operators_E(STRING *Operators_s)
/*604*/ 	{
/*604*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"comparing (", Types_TypeToString(Operators_at), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)") ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" (", Types_TypeToString(Operators_bt), m2runtime_CHR(41), Operators_s, 1));
/*609*/ 	}

/*609*/ 	Operators_r = (
/*609*/ 		push((char*) alloc_RECORD(16, 2)),
/*609*/ 		push((char*) Globals_boolean_type),
/*609*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*609*/ 		push((char*) NULL),
/*610*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*612*/ 		(RECORD*) pop()
/*612*/ 	);
/*612*/ 	if( Operators_a != NULL ){
/*613*/ 		Operators_at = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 89);
/*613*/ 		Operators_av = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 90);
/*615*/ 	}
/*615*/ 	if( Operators_b != NULL ){
/*616*/ 		Operators_bt = (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 91);
/*616*/ 		Operators_bv = (STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 92);
/*619*/ 	}
/*619*/ 	if( ((Operators_a == NULL) || (Operators_b == NULL)) ){
/*620*/ 		Operators_W((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\63,\0,\0,\0)": cannot check the comparison between unknown types");
/*621*/ 		return Operators_r;
/*624*/ 	}
/*624*/ 	if( ((Operators_at == Globals_void_type) || (Operators_bt == Globals_void_type)) ){
/*625*/ 		Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)": `void' type cannot be compared");
/*627*/ 	} else if( ((Operators_at == Globals_mixed_type) || (Operators_bt == Globals_mixed_type)) ){
/*628*/ 		Operators_W((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)": `mixed' type cannot be compared");
/*630*/ 	} else if( Operators_at == Globals_boolean_type ){
/*631*/ 		if( Operators_bt == Globals_boolean_type ){
/*632*/ 			if( ((m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") != 0) && (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") != 0)) ){
/*633*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\22,\0,\0,\0)": invalid operator");
/*636*/ 			}
/*636*/ 		} else {
/*636*/ 			Operators_E(NULL);
/*638*/ 		}
/*638*/ 	} else if( Operators_at == Globals_int_type ){
/*639*/ 		if( Operators_bt == Globals_int_type ){
/*640*/ 		} else if( Operators_bt == Globals_float_type ){
/*641*/ 			Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)" - Hint: you might use a typecast to (int) or to (float).");
/*643*/ 		} else {
/*643*/ 			Operators_E(NULL);
/*646*/ 		}
/*646*/ 	} else if( Operators_at == Globals_float_type ){
/*647*/ 		if( Operators_bt == Globals_float_type ){
/*648*/ 			if( ((m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0) || (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0)) ){
/*649*/ 				Scanner_Notice(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"comparison by equality/inequality between float numbers. ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\75,\0,\0,\0)"Remember that float numbers have limited precision, and that ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)"expressions algebrically equivalent might give different ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\66,\0,\0,\0)"results. For example, 0.57-0.56==0.1 would give FALSE.", 1));
/*655*/ 			}
/*655*/ 		} else {
/*655*/ 			Operators_E(NULL);
/*658*/ 		}
/*658*/ 	} else if( Operators_at == Globals_null_type ){
/*659*/ 		if( Operators_bt == Globals_null_type ){
/*660*/ 			Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)": unusefull");
/*662*/ 		} else {
/*662*/ 			return Operators_EvalCmp(Operators_n, Operators_b, Operators_a);
/*665*/ 		}
/*665*/ 	} else if( Operators_at == Globals_string_type ){
/*666*/ 		if( Operators_bt == Globals_null_type ){
/*667*/ 			if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*668*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `===' instead.");
/*669*/ 			} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*670*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `!==' instead.");
/*672*/ 			} else {
/*672*/ 				Operators_E(NULL);
/*674*/ 			}
/*674*/ 		} else if( Operators_bt == Globals_string_type ){
/*675*/ 			if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*676*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `===' instead.");
/*677*/ 			} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"===") == 0 ){
/*678*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `!==' instead.");
/*679*/ 			} else if( ((m2runtime_strcmp(Operators_n, m2runtime_CHR(60)) == 0) || (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<=") == 0) || (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">=") == 0) || (m2runtime_strcmp(Operators_n, m2runtime_CHR(62)) == 0)) ){
/*680*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\36,\0,\0,\0)" - Hint: use strcmp() instead.");
/*683*/ 			}
/*683*/ 		} else {
/*683*/ 			Operators_E(NULL);
/*686*/ 		}
/*686*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_at, 16, Operators_0err_entry_get, 93) == 6) ){
/*687*/ 		if( Operators_bt == Globals_null_type ){
/*688*/ 			if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*689*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `===' instead.");
/*690*/ 			} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*691*/ 				Operators_E((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `!==' instead.");
/*693*/ 			} else {
/*693*/ 				Operators_E(NULL);
/*696*/ 			}
/*696*/ 		} else {
/*696*/ 			Operators_E(NULL);
/*699*/ 		}
/*699*/ 	} else if( Operators_at == Globals_resource_type ){
/*700*/ 		if( Operators_bt == Globals_null_type ){
/*701*/ 			if( ((m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") != 0) && (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") != 0)) ){
/*702*/ 				Operators_E(NULL);
/*704*/ 			}
/*704*/ 		} else if( Operators_bt == Globals_resource_type ){
/*705*/ 			if( ((m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") != 0) && (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") != 0)) ){
/*706*/ 				Operators_E(NULL);
/*709*/ 			}
/*709*/ 		} else {
/*709*/ 			Operators_E(NULL);
/*712*/ 		}
/*712*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_at, 16, Operators_0err_entry_get, 94) == 9) ){
/*713*/ 		if( Operators_bt == Globals_null_type ){
/*714*/ 			if( ((m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") != 0) && (m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") != 0)) ){
/*715*/ 				Operators_E(NULL);
/*717*/ 			}
/*717*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Operators_bt, 16, Operators_0err_entry_get, 95) == 9) ){
/*718*/ 			if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*719*/ 				Operators_W((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `===' instead.");
/*720*/ 			} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*721*/ 				Operators_W((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - Hint: use `!==' instead.");
/*723*/ 			} else {
/*723*/ 				Operators_E(NULL);
/*726*/ 			}
/*726*/ 		} else {
/*726*/ 			Operators_E(NULL);
/*730*/ 		}
/*730*/ 	} else {
/*730*/ 		m2runtime_HALT(Operators_0err_entry_get, 96, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\20,\0,\0,\0)"unexpected types");
/*736*/ 	}
/*736*/ 	if( ((Operators_av == NULL) || (Operators_bv == NULL)) ){
/*737*/ 		return Operators_r;
/*739*/ 	}
/*739*/ 	if( ((Operators_at == Globals_int_type) && (Operators_bt == Globals_int_type)) ){
/*740*/ 		if( m2runtime_strcmp(Operators_n, m2runtime_CHR(60)) == 0 ){
/*741*/ 			Operators_x = (m2_stoi(Operators_av) < m2_stoi(Operators_bv));
/*742*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<=") == 0 ){
/*743*/ 			Operators_x = (m2_stoi(Operators_av) <= m2_stoi(Operators_bv));
/*744*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*745*/ 			Operators_x = (m2_stoi(Operators_av) == m2_stoi(Operators_bv));
/*746*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*747*/ 			Operators_x = (m2_stoi(Operators_av) != m2_stoi(Operators_bv));
/*748*/ 		} else if( m2runtime_strcmp(Operators_n, m2runtime_CHR(62)) == 0 ){
/*749*/ 			Operators_x = (m2_stoi(Operators_av) > m2_stoi(Operators_bv));
/*750*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">=") == 0 ){
/*751*/ 			Operators_x = (m2_stoi(Operators_av) >= m2_stoi(Operators_bv));
/*753*/ 		}
/*753*/ 		if( Operators_x ){
/*754*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*756*/ 		} else {
/*756*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*758*/ 		}
/*758*/ 	} else if( (((Operators_at == Globals_int_type) && (Operators_bt == Globals_float_type)) || ((Operators_at == Globals_float_type) && (Operators_bt == Globals_int_type))) ){
/*760*/ 		if( m2runtime_strcmp(Operators_n, m2runtime_CHR(60)) == 0 ){
/*761*/ 			Operators_x = (m2_stor(Operators_av) < m2_stor(Operators_bv));
/*762*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<=") == 0 ){
/*763*/ 			Operators_x = (m2_stor(Operators_av) <= m2_stor(Operators_bv));
/*764*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*765*/ 			return Operators_r;
/*766*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*767*/ 			return Operators_r;
/*768*/ 		} else if( m2runtime_strcmp(Operators_n, m2runtime_CHR(62)) == 0 ){
/*769*/ 			Operators_x = (m2_stor(Operators_av) > m2_stor(Operators_bv));
/*770*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">=") == 0 ){
/*771*/ 			Operators_x = (m2_stor(Operators_av) >= m2_stor(Operators_bv));
/*773*/ 		}
/*773*/ 		if( Operators_x ){
/*774*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*776*/ 		} else {
/*776*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*778*/ 		}
/*778*/ 	} else if( ((Operators_at == Globals_float_type) && (Operators_bt == Globals_float_type)) ){
/*779*/ 		if( m2runtime_strcmp(Operators_n, m2runtime_CHR(60)) == 0 ){
/*780*/ 			Operators_x = (m2_stor(Operators_av) < m2_stor(Operators_bv));
/*781*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"<=") == 0 ){
/*782*/ 			Operators_x = (m2_stor(Operators_av) <= m2_stor(Operators_bv));
/*783*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"==") == 0 ){
/*784*/ 			return Operators_r;
/*785*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"!=") == 0 ){
/*786*/ 			return Operators_r;
/*787*/ 		} else if( m2runtime_strcmp(Operators_n, m2runtime_CHR(62)) == 0 ){
/*788*/ 			Operators_x = (m2_stor(Operators_av) > m2_stor(Operators_bv));
/*789*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)">=") == 0 ){
/*790*/ 			Operators_x = (m2_stor(Operators_av) >= m2_stor(Operators_bv));
/*792*/ 		}
/*792*/ 		if( Operators_x ){
/*793*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*795*/ 		} else {
/*795*/ 			Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*797*/ 		}
/*797*/ 	} else if( ((Operators_at == Globals_string_type) && (Operators_bt == Globals_string_type)) ){
/*798*/ 		if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"===") == 0 ){
/*799*/ 			if( m2runtime_strcmp(Operators_av, Operators_bv) == 0 ){
/*800*/ 				Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*802*/ 			} else {
/*802*/ 				Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*804*/ 			}
/*804*/ 		} else if( m2runtime_strcmp(Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"!==") == 0 ){
/*805*/ 			if( m2runtime_strcmp(Operators_av, Operators_bv) != 0 ){
/*806*/ 				Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*808*/ 			} else {
/*808*/ 				Operators_rv = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*811*/ 			}
/*812*/ 		}
/*813*/ 	}
/*813*/ 	*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 97) = Operators_rv;
/*814*/ 	return Operators_r;
/*818*/ }


/*820*/ RECORD *
/*820*/ Operators_EvalEq(STRING *Operators_n, RECORD *Operators_a, RECORD *Operators_b)
/*820*/ {
/*820*/ 	return Operators_EvalCmp(Operators_n, Operators_a, Operators_b);
/*824*/ }


/*826*/ void
/*826*/ Operators_RequireBoolean(STRING *Operators_where, RECORD *Operators_r)
/*826*/ {
/*826*/ 	if( Operators_r == NULL ){
/*827*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Operators_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\42,\0,\0,\0)": undefined type of the expression", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - expected a boolean value", 1));
/*829*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 98) == Globals_mixed_type ){
/*830*/ 		Scanner_Warning(m2runtime_concat_STRING(0, Operators_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)": found a value of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 99)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - expected a boolean value", 1));
/*832*/ 	} else if( (RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 100) != Globals_boolean_type ){
/*833*/ 		Scanner_Error(m2runtime_concat_STRING(0, Operators_where, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)": found a value of type ", Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_r, 8, Operators_0err_entry_get, 101)), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)" - expected a boolean value", 1));
/*837*/ 	}
/*839*/ }


/*841*/ RECORD *
/*841*/ Operators_EvalAnd(STRING *Operators_n, RECORD *Operators_a, RECORD *Operators_b)
/*841*/ {
/*843*/ 	RECORD * Operators_r = NULL;
/*843*/ 	Operators_r = (
/*843*/ 		push((char*) alloc_RECORD(16, 2)),
/*843*/ 		push((char*) Globals_boolean_type),
/*843*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*843*/ 		push((char*) NULL),
/*844*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*844*/ 		(RECORD*) pop()
/*844*/ 	);
/*844*/ 	if( ((Operators_a == NULL) || (Operators_b == NULL)) ){
/*845*/ 		return Operators_r;
/*847*/ 	}
/*847*/ 	Operators_RequireBoolean(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"`EXPR ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" ...'", 1), Operators_a);
/*848*/ 	Operators_RequireBoolean(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"`... ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)" EXPR'", 1), Operators_b);
/*849*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 102) != Globals_boolean_type) || ((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 103) != Globals_boolean_type)) ){
/*850*/ 		return Operators_r;
/*852*/ 	}
/*852*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 104) == NULL) || ((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 105) == NULL)) ){
/*853*/ 		return Operators_r;
/*855*/ 	}
/*855*/ 	if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 106), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 107), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0)) ){
/*856*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 108) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*858*/ 	} else {
/*858*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 109) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*860*/ 	}
/*860*/ 	return Operators_r;
/*864*/ }


/*866*/ RECORD *
/*866*/ Operators_EvalOr(STRING *Operators_n, RECORD *Operators_a, RECORD *Operators_b)
/*866*/ {
/*868*/ 	RECORD * Operators_r = NULL;
/*868*/ 	Operators_r = (
/*868*/ 		push((char*) alloc_RECORD(16, 2)),
/*868*/ 		push((char*) Globals_boolean_type),
/*868*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*868*/ 		push((char*) NULL),
/*869*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*869*/ 		(RECORD*) pop()
/*869*/ 	);
/*869*/ 	if( ((Operators_a == NULL) || (Operators_b == NULL)) ){
/*870*/ 		return Operators_r;
/*872*/ 	}
/*872*/ 	Operators_RequireBoolean(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"`EXPR ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)" ...'", 1), Operators_a);
/*873*/ 	Operators_RequireBoolean(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"`... ", Operators_n, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\17,\0,\0,\0)" EXPR' operator", 1), Operators_b);
/*874*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 110) != Globals_boolean_type) || ((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 111) != Globals_boolean_type)) ){
/*875*/ 		return Operators_r;
/*877*/ 	}
/*877*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 112) == NULL) || ((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 113) == NULL)) ){
/*878*/ 		return Operators_r;
/*880*/ 	}
/*880*/ 	if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 114), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0) || (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 115), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0)) ){
/*881*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 116) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*883*/ 	} else {
/*883*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 117) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*885*/ 	}
/*885*/ 	return Operators_r;
/*889*/ }


/*890*/ RECORD *
/*890*/ Operators_EvalXor(RECORD *Operators_a, RECORD *Operators_b)
/*890*/ {
/*892*/ 	RECORD * Operators_r = NULL;
/*892*/ 	Operators_r = (
/*892*/ 		push((char*) alloc_RECORD(16, 2)),
/*892*/ 		push((char*) Globals_boolean_type),
/*892*/ 		*(RECORD**) (tosn(1)+8) = (RECORD*) tos(), pop(),
/*892*/ 		push((char*) NULL),
/*893*/ 		*(STRING**) (tosn(1)+12) = (STRING*) tos(), pop(),
/*893*/ 		(RECORD*) pop()
/*893*/ 	);
/*893*/ 	if( ((Operators_a == NULL) || (Operators_b == NULL)) ){
/*894*/ 		return Operators_r;
/*896*/ 	}
/*896*/ 	Operators_RequireBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"`EXPR xor ...'", Operators_a);
/*897*/ 	Operators_RequireBoolean((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"`... xor EXPR'", Operators_b);
/*898*/ 	if( (((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_a, 8, Operators_0err_entry_get, 118) != Globals_boolean_type) || ((RECORD *)m2runtime_dereference_rhs_RECORD(Operators_b, 8, Operators_0err_entry_get, 119) != Globals_boolean_type)) ){
/*899*/ 		return Operators_r;
/*901*/ 	}
/*901*/ 	if( (((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 120) == NULL) || ((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 121) == NULL)) ){
/*902*/ 		return Operators_r;
/*904*/ 	}
/*904*/ 	if( ((m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_a, 12, Operators_0err_entry_get, 122), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE") == 0) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Operators_b, 12, Operators_0err_entry_get, 123), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE") == 0)) ){
/*905*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 124) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"TRUE";
/*907*/ 	} else {
/*907*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Operators_r, 16, 2, 12, Operators_0err_entry_get, 125) = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"FALSE";
/*909*/ 	}
/*909*/ 	return Operators_r;
/*913*/ }


char * Operators_0func[] = {
    "invalid",
    "EvalValueConversion",
    "invalid",
    "EvalFormalTypecastArray",
    "EvalTypeConversion",
    "eval_res_type",
    "EvalPeriod",
    "EvalNot",
    "EvalUnaryPlusMinus",
    "check_args_bit_binary_op",
    "EvalLShift",
    "EvalRShift",
    "EvalBitNot",
    "EvalBitAnd",
    "EvalBitXor",
    "EvalBitOr",
    "EvalCmp",
    "RequireBoolean",
    "EvalAnd",
    "EvalOr",
    "EvalXor"
};

int Operators_0err_entry[] = {
    0 /* invalid */, 36,
    1 /* EvalValueConversion */, 51,
    1 /* EvalValueConversion */, 56,
    1 /* EvalValueConversion */, 59,
    1 /* EvalValueConversion */, 60,
    1 /* EvalValueConversion */, 62,
    1 /* EvalValueConversion */, 72,
    1 /* EvalValueConversion */, 79,
    1 /* EvalValueConversion */, 85,
    1 /* EvalValueConversion */, 91,
    1 /* EvalValueConversion */, 97,
    1 /* EvalValueConversion */, 98,
    1 /* EvalValueConversion */, 99,
    1 /* EvalValueConversion */, 111,
    1 /* EvalValueConversion */, 123,
    1 /* EvalValueConversion */, 124,
    1 /* EvalValueConversion */, 128,
    2 /* invalid */, 135,
    3 /* EvalFormalTypecastArray */, 154,
    4 /* EvalTypeConversion */, 166,
    4 /* EvalTypeConversion */, 171,
    4 /* EvalTypeConversion */, 174,
    4 /* EvalTypeConversion */, 181,
    4 /* EvalTypeConversion */, 187,
    4 /* EvalTypeConversion */, 190,
    4 /* EvalTypeConversion */, 190,
    4 /* EvalTypeConversion */, 191,
    4 /* EvalTypeConversion */, 191,
    4 /* EvalTypeConversion */, 195,
    4 /* EvalTypeConversion */, 204,
    4 /* EvalTypeConversion */, 214,
    4 /* EvalTypeConversion */, 217,
    4 /* EvalTypeConversion */, 219,
    5 /* eval_res_type */, 233,
    5 /* eval_res_type */, 235,
    5 /* eval_res_type */, 237,
    5 /* eval_res_type */, 240,
    5 /* eval_res_type */, 247,
    5 /* eval_res_type */, 249,
    5 /* eval_res_type */, 251,
    5 /* eval_res_type */, 253,
    6 /* EvalPeriod */, 391,
    6 /* EvalPeriod */, 398,
    6 /* EvalPeriod */, 400,
    6 /* EvalPeriod */, 402,
    6 /* EvalPeriod */, 409,
    6 /* EvalPeriod */, 416,
    6 /* EvalPeriod */, 418,
    6 /* EvalPeriod */, 420,
    6 /* EvalPeriod */, 431,
    7 /* EvalNot */, 440,
    7 /* EvalNot */, 441,
    7 /* EvalNot */, 444,
    7 /* EvalNot */, 447,
    7 /* EvalNot */, 448,
    7 /* EvalNot */, 450,
    8 /* EvalUnaryPlusMinus */, 461,
    8 /* EvalUnaryPlusMinus */, 463,
    8 /* EvalUnaryPlusMinus */, 465,
    8 /* EvalUnaryPlusMinus */, 467,
    8 /* EvalUnaryPlusMinus */, 469,
    8 /* EvalUnaryPlusMinus */, 471,
    8 /* EvalUnaryPlusMinus */, 474,
    9 /* check_args_bit_binary_op */, 495,
    9 /* check_args_bit_binary_op */, 496,
    9 /* check_args_bit_binary_op */, 500,
    9 /* check_args_bit_binary_op */, 501,
    9 /* check_args_bit_binary_op */, 510,
    9 /* check_args_bit_binary_op */, 510,
    10 /* EvalLShift */, 523,
    10 /* EvalLShift */, 523,
    10 /* EvalLShift */, 523,
    11 /* EvalRShift */, 534,
    11 /* EvalRShift */, 534,
    11 /* EvalRShift */, 534,
    12 /* EvalBitNot */, 545,
    12 /* EvalBitNot */, 545,
    12 /* EvalBitNot */, 546,
    12 /* EvalBitNot */, 547,
    12 /* EvalBitNot */, 550,
    13 /* EvalBitAnd */, 562,
    13 /* EvalBitAnd */, 562,
    13 /* EvalBitAnd */, 562,
    14 /* EvalBitXor */, 573,
    14 /* EvalBitXor */, 573,
    14 /* EvalBitXor */, 573,
    15 /* EvalBitOr */, 584,
    15 /* EvalBitOr */, 584,
    15 /* EvalBitOr */, 584,
    16 /* EvalCmp */, 613,
    16 /* EvalCmp */, 613,
    16 /* EvalCmp */, 616,
    16 /* EvalCmp */, 616,
    16 /* EvalCmp */, 686,
    16 /* EvalCmp */, 712,
    16 /* EvalCmp */, 717,
    16 /* EvalCmp */, 730,
    16 /* EvalCmp */, 813,
    17 /* RequireBoolean */, 829,
    17 /* RequireBoolean */, 830,
    17 /* RequireBoolean */, 832,
    17 /* RequireBoolean */, 833,
    18 /* EvalAnd */, 849,
    18 /* EvalAnd */, 849,
    18 /* EvalAnd */, 852,
    18 /* EvalAnd */, 852,
    18 /* EvalAnd */, 855,
    18 /* EvalAnd */, 855,
    18 /* EvalAnd */, 856,
    18 /* EvalAnd */, 858,
    19 /* EvalOr */, 874,
    19 /* EvalOr */, 874,
    19 /* EvalOr */, 877,
    19 /* EvalOr */, 877,
    19 /* EvalOr */, 880,
    19 /* EvalOr */, 880,
    19 /* EvalOr */, 881,
    19 /* EvalOr */, 883,
    20 /* EvalXor */, 898,
    20 /* EvalXor */, 898,
    20 /* EvalXor */, 901,
    20 /* EvalXor */, 901,
    20 /* EvalXor */, 904,
    20 /* EvalXor */, 904,
    20 /* EvalXor */, 905,
    20 /* EvalXor */, 907
};

void Operators_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Operators";
    *f = Operators_0func[ Operators_0err_entry[2*i] ];
    *l = Operators_0err_entry[2*i + 1];
}
