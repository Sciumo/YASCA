/* IMPLEMENTATION MODULE Types */
#define M2_IMPORT_Types

void Types_0err_entry_get(int i, char **m, char **f, int *l);

/*  6*/ STRING *
/*  6*/ Types_TypeToString(RECORD *Types_t)
/*  6*/ {

/*  7*/ 	STRING *
/*  7*/ 	Types_ArrayToString(RECORD *Types_t)
/*  7*/ 	{
/*  9*/ 		STRING * Types_x = NULL;
/*  9*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Types_t, 20, Types_0err_entry_get, 0)){

/* 10*/ 		case 1:
/* 10*/ 		Types_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"[]";
/* 11*/ 		break;

/* 11*/ 		case 3:
/* 11*/ 		Types_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"[int]";
/* 12*/ 		break;

/* 12*/ 		case 5:
/* 12*/ 		Types_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"[string]";
/* 13*/ 		break;

/* 13*/ 		case 7:
/* 13*/ 		Types_x = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"[mixed]";
/* 15*/ 		break;

/* 15*/ 		default: m2runtime_missing_case_in_switch(Types_0err_entry_get, 1);
/* 15*/ 		}
/* 15*/ 		Types_t = (RECORD *)m2runtime_dereference_rhs_RECORD(Types_t, 8, Types_0err_entry_get, 2);
/* 16*/ 		if( Types_t == NULL ){
/* 17*/ 			return Types_x;
/* 18*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Types_t, 16, Types_0err_entry_get, 3) == 6) ){
/* 19*/ 			return m2runtime_concat_STRING(0, Types_x, Types_ArrayToString(Types_t), 1);
/* 21*/ 		} else {
/* 21*/ 			return m2runtime_concat_STRING(0, Types_x, Types_TypeToString(Types_t), 1);
/* 24*/ 		}
/* 24*/ 		m2runtime_missing_return(Types_0err_entry_get, 4);
/* 24*/ 		return NULL;
/* 26*/ 	}

/* 26*/ 	if( Types_t == NULL ){
/* 27*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"unknown";
/* 29*/ 	} else {
/* 29*/ 		switch( *(int *)m2runtime_dereference_rhs_RECORD(Types_t, 16, Types_0err_entry_get, 5)){

/* 30*/ 		case 0:
/* 30*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"null";
/* 31*/ 		break;

/* 31*/ 		case 1:
/* 31*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"void";
/* 32*/ 		break;

/* 32*/ 		case 2:
/* 32*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"boolean";
/* 33*/ 		break;

/* 33*/ 		case 3:
/* 33*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"int";
/* 34*/ 		break;

/* 34*/ 		case 4:
/* 34*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"float";
/* 35*/ 		break;

/* 35*/ 		case 5:
/* 35*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"string";
/* 36*/ 		break;

/* 36*/ 		case 6:
/* 37*/ 		if( ((( *(int *)m2runtime_dereference_rhs_RECORD(Types_t, 20, Types_0err_entry_get, 6) == 1)) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Types_t, 8, Types_0err_entry_get, 7) == NULL)) ){
/* 38*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array";
/* 40*/ 		} else {
/* 40*/ 			return m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"array", Types_ArrayToString(Types_t), 1);
/* 42*/ 		}
/* 42*/ 		break;

/* 42*/ 		case 7:
/* 42*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\5,\0,\0,\0)"mixed";
/* 43*/ 		break;

/* 43*/ 		case 8:
/* 43*/ 		return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"resource";
/* 44*/ 		break;

/* 44*/ 		case 9:
/* 45*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Types_t, 12, Types_0err_entry_get, 8) == NULL ){
/* 46*/ 			return (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"object";
/* 48*/ 		} else {
/* 48*/ 			return (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Types_t, 12, Types_0err_entry_get, 9), 8, Types_0err_entry_get, 10);
/* 51*/ 		}
/* 51*/ 		break;

/* 51*/ 		default: m2runtime_missing_case_in_switch(Types_0err_entry_get, 11);
/* 52*/ 		}
/* 53*/ 	}
/* 53*/ 	m2runtime_missing_return(Types_0err_entry_get, 12);
/* 53*/ 	return NULL;
/* 55*/ }


/* 57*/ int
/* 57*/ Types_SameType(RECORD *Types_a, RECORD *Types_b)
/* 57*/ {
/* 57*/ 	if( ((Types_a == NULL) || (Types_b == NULL) || (( *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 16, Types_0err_entry_get, 13) !=  *(int *)m2runtime_dereference_rhs_RECORD(Types_b, 16, Types_0err_entry_get, 14)))) ){
/* 58*/ 		return FALSE;
/* 60*/ 	}
/* 60*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 16, Types_0err_entry_get, 15) == 6) ){
/* 61*/ 		return ((( *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 20, Types_0err_entry_get, 16) ==  *(int *)m2runtime_dereference_rhs_RECORD(Types_b, 20, Types_0err_entry_get, 17))) && Types_SameType((RECORD *)m2runtime_dereference_rhs_RECORD(Types_a, 8, Types_0err_entry_get, 18), (RECORD *)m2runtime_dereference_rhs_RECORD(Types_b, 8, Types_0err_entry_get, 19)));
/* 63*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 16, Types_0err_entry_get, 20) == 9) ){
/* 64*/ 		return (RECORD *)m2runtime_dereference_rhs_RECORD(Types_a, 12, Types_0err_entry_get, 21) == (RECORD *)m2runtime_dereference_rhs_RECORD(Types_b, 12, Types_0err_entry_get, 22);
/* 66*/ 	} else {
/* 66*/ 		return TRUE;
/* 69*/ 	}
/* 69*/ 	m2runtime_missing_return(Types_0err_entry_get, 23);
/* 69*/ 	return 0;
/* 71*/ }


/* 73*/ STRING *
/* 73*/ Types_FunctionSignatureToString(RECORD *Types_s)
/* 73*/ {
/* 74*/ 	STRING * Types_t = NULL;
/* 75*/ 	int Types_i = 0;
/* 77*/ 	RECORD * Types_a = NULL;
/* 77*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 16, Types_0err_entry_get, 24) ){
/* 78*/ 		Types_t = m2runtime_CHR(38);
/* 80*/ 	}
/* 80*/ 	Types_t = m2runtime_concat_STRING(0, Types_t, Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Types_s, 8, Types_0err_entry_get, 25)), m2runtime_CHR(40), 1);
/* 83*/ 	{
/* 83*/ 		int m2runtime_for_limit_1;
/* 83*/ 		Types_i = 0;
/* 83*/ 		m2runtime_for_limit_1 = ( *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 20, Types_0err_entry_get, 26) - 1);
/* 84*/ 		for( ; Types_i <= m2runtime_for_limit_1; Types_i += 1 ){
/* 84*/ 			Types_a = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Types_s, 12, Types_0err_entry_get, 27), Types_i, Types_0err_entry_get, 28);
/* 85*/ 			if( (Types_i > 0) ){
/* 86*/ 				Types_t = m2runtime_concat_STRING(0, Types_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", 1);
/* 88*/ 			}
/* 88*/ 			if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 20, Types_0err_entry_get, 29) ){
/* 89*/ 				Types_t = m2runtime_concat_STRING(0, Types_t, m2runtime_CHR(38), 1);
/* 91*/ 			}
/* 91*/ 			Types_t = m2runtime_concat_STRING(0, Types_t, Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Types_a, 12, Types_0err_entry_get, 30)), 1);
/* 95*/ 		}
/* 95*/ 	}
/* 95*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 20, Types_0err_entry_get, 31) < m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Types_s, 12, Types_0err_entry_get, 32))) ){
/* 96*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 20, Types_0err_entry_get, 33) > 0) ){
/* 97*/ 			Types_t = m2runtime_concat_STRING(0, Types_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)" [", 1);
/* 99*/ 		} else {
/* 99*/ 			Types_t = m2runtime_concat_STRING(0, Types_t, m2runtime_CHR(91), 1);
/*101*/ 		}
/*101*/ 		{
/*101*/ 			int m2runtime_for_limit_1;
/*101*/ 			Types_i =  *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 20, Types_0err_entry_get, 34);
/*101*/ 			m2runtime_for_limit_1 = (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Types_s, 12, Types_0err_entry_get, 35)) - 1);
/*102*/ 			for( ; Types_i <= m2runtime_for_limit_1; Types_i += 1 ){
/*102*/ 				Types_a = (RECORD *)m2runtime_dereference_rhs_ARRAY((ARRAY *)m2runtime_dereference_rhs_RECORD(Types_s, 12, Types_0err_entry_get, 36), Types_i, Types_0err_entry_get, 37);
/*103*/ 				if( (Types_i > 0) ){
/*104*/ 					Types_t = m2runtime_concat_STRING(0, Types_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", 1);
/*106*/ 				}
/*106*/ 				if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_a, 20, Types_0err_entry_get, 38) ){
/*107*/ 					Types_t = m2runtime_concat_STRING(0, Types_t, m2runtime_CHR(38), 1);
/*109*/ 				}
/*109*/ 				Types_t = m2runtime_concat_STRING(0, Types_t, Types_TypeToString((RECORD *)m2runtime_dereference_rhs_RECORD(Types_a, 12, Types_0err_entry_get, 39)), 1);
/*111*/ 			}
/*111*/ 		}
/*111*/ 		Types_t = m2runtime_concat_STRING(0, Types_t, m2runtime_CHR(93), 1);
/*114*/ 	}
/*114*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_s, 24, Types_0err_entry_get, 40) ){
/*115*/ 		if( (m2runtime_count((ARRAY *)m2runtime_dereference_rhs_RECORD(Types_s, 12, Types_0err_entry_get, 41)) > 0) ){
/*116*/ 			Types_t = m2runtime_concat_STRING(0, Types_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)", ", 1);
/*118*/ 		}
/*118*/ 		Types_t = m2runtime_concat_STRING(0, Types_t, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"...", 1);
/*120*/ 	}
/*120*/ 	Types_t = m2runtime_concat_STRING(0, Types_t, m2runtime_CHR(41), 1);
/*121*/ 	return Types_t;
/*125*/ }


/*126*/ STRING *
/*126*/ Types_MethodSignatureToString(RECORD *Types_m)
/*126*/ {
/*128*/ 	STRING * Types_s = NULL;
/*128*/ 	switch( *(int *)m2runtime_dereference_rhs_RECORD(Types_m, 52, Types_0err_entry_get, 42)){

/*129*/ 	case 2:
/*129*/ 	Types_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)"public";
/*130*/ 	break;

/*130*/ 	case 1:
/*130*/ 	Types_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"protected";
/*131*/ 	break;

/*131*/ 	case 0:
/*131*/ 	Types_s = (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)"private";
/*133*/ 	break;

/*133*/ 	default: m2runtime_missing_case_in_switch(Types_0err_entry_get, 43);
/*134*/ 	}
/*134*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_m, 60, Types_0err_entry_get, 44) ){
/*134*/ 		Types_s = m2runtime_concat_STRING(0, Types_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\6,\0,\0,\0)" final", 1);
/*135*/ 	}
/*135*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Types_m, 56, Types_0err_entry_get, 45) ){
/*135*/ 		Types_s = m2runtime_concat_STRING(0, Types_s, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\7,\0,\0,\0)" static", 1);
/*136*/ 	}
/*136*/ 	Types_s = m2runtime_concat_STRING(0, Types_s, m2runtime_CHR(32), Types_FunctionSignatureToString((RECORD *)m2runtime_dereference_rhs_RECORD(Types_m, 16, Types_0err_entry_get, 46)), 1);
/*137*/ 	return Types_s;
/*142*/ }


char * Types_0func[] = {
    "ArrayToString",
    "TypeToString",
    "SameType",
    "FunctionSignatureToString",
    "MethodSignatureToString"
};

int Types_0err_entry[] = {
    0 /* ArrayToString */, 9,
    0 /* ArrayToString */, 14,
    0 /* ArrayToString */, 15,
    0 /* ArrayToString */, 18,
    0 /* ArrayToString */, 23,
    1 /* TypeToString */, 29,
    1 /* TypeToString */, 37,
    1 /* TypeToString */, 37,
    1 /* TypeToString */, 45,
    1 /* TypeToString */, 48,
    1 /* TypeToString */, 48,
    1 /* TypeToString */, 50,
    1 /* TypeToString */, 52,
    2 /* SameType */, 57,
    2 /* SameType */, 57,
    2 /* SameType */, 60,
    2 /* SameType */, 61,
    2 /* SameType */, 61,
    2 /* SameType */, 62,
    2 /* SameType */, 62,
    2 /* SameType */, 63,
    2 /* SameType */, 64,
    2 /* SameType */, 64,
    2 /* SameType */, 68,
    3 /* FunctionSignatureToString */, 77,
    3 /* FunctionSignatureToString */, 80,
    3 /* FunctionSignatureToString */, 83,
    3 /* FunctionSignatureToString */, 84,
    3 /* FunctionSignatureToString */, 85,
    3 /* FunctionSignatureToString */, 88,
    3 /* FunctionSignatureToString */, 91,
    3 /* FunctionSignatureToString */, 95,
    3 /* FunctionSignatureToString */, 95,
    3 /* FunctionSignatureToString */, 96,
    3 /* FunctionSignatureToString */, 101,
    3 /* FunctionSignatureToString */, 101,
    3 /* FunctionSignatureToString */, 102,
    3 /* FunctionSignatureToString */, 103,
    3 /* FunctionSignatureToString */, 106,
    3 /* FunctionSignatureToString */, 109,
    3 /* FunctionSignatureToString */, 114,
    3 /* FunctionSignatureToString */, 115,
    4 /* MethodSignatureToString */, 128,
    4 /* MethodSignatureToString */, 132,
    4 /* MethodSignatureToString */, 134,
    4 /* MethodSignatureToString */, 135,
    4 /* MethodSignatureToString */, 136
};

void Types_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Types";
    *f = Types_0func[ Types_0err_entry[2*i] ];
    *l = Types_0err_entry[2*i + 1];
}
