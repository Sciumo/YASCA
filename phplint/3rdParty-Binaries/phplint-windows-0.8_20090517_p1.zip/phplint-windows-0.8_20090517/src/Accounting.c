/* IMPLEMENTATION MODULE Accounting */
#define M2_IMPORT_Accounting

#ifndef M2_IMPORT_Types
#    include "Types.c"
#endif
/*  8*/ int Accounting_report_unused = 0;

#ifndef M2_IMPORT_m2
#    include "m2.c"
#endif

#ifndef M2_IMPORT_str
#    include "str.c"
#endif

#ifndef M2_IMPORT_Globals
#    include "Globals.c"
#endif

#ifndef M2_IMPORT_Scanner
#    include "Scanner.c"
#endif

#ifndef M2_IMPORT_Search
#    include "Search.c"
#endif

void Accounting_0err_entry_get(int i, char **m, char **f, int *l);

/* 11*/ void
/* 11*/ Accounting_AccountModule(RECORD *Accounting_decl_in)
/* 11*/ {
/* 12*/ 	STRING * Accounting_m = NULL;
/* 13*/ 	int Accounting_i = 0;
/* 15*/ 	RECORD * Accounting_pkg = NULL;
/* 15*/ 	if( Accounting_decl_in == NULL ){
/* 18*/ 		return ;
/* 19*/ 	}
/* 19*/ 	Accounting_m = (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_decl_in, 8, Accounting_0err_entry_get, 0);
/* 20*/ 	if( m2runtime_strcmp(Accounting_m, Scanner_fn) == 0 ){
/* 22*/ 		return ;
/* 23*/ 	}
/* 23*/ 	{
/* 23*/ 		int m2runtime_for_limit_1;
/* 23*/ 		Accounting_i = 0;
/* 23*/ 		m2runtime_for_limit_1 = (m2runtime_count(Globals_required_packages) - 1);
/* 24*/ 		for( ; Accounting_i <= m2runtime_for_limit_1; Accounting_i += 1 ){
/* 24*/ 			Accounting_pkg = (RECORD *)m2runtime_dereference_rhs_ARRAY(Globals_required_packages, Accounting_i, Accounting_0err_entry_get, 1);
/* 25*/ 			if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_pkg, 8, Accounting_0err_entry_get, 2), Accounting_m) == 0 ){
/* 26*/ 				m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_pkg, 28, 3, 24, Accounting_0err_entry_get, 3), 1);
/* 28*/ 				return ;
/* 30*/ 			}
/* 31*/ 		}
/* 31*/ 	}
/* 33*/ }


/* 34*/ RECORD *
/* 34*/ Accounting_AccountConstLHS(STRING *Accounting_name, int Accounting_private, RECORD *Accounting_value)
/* 34*/ {
/* 36*/ 	RECORD * Accounting_c = NULL;
/* 36*/ 	Accounting_c = Search_SearchConst(Accounting_name);
/* 37*/ 	if( Accounting_c == NULL ){
/* 38*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 8, Accounting_0err_entry_get, 4) = Accounting_name;
/* 39*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 32, Accounting_0err_entry_get, 5) = Accounting_private;
/* 40*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 12, Accounting_0err_entry_get, 6) = Scanner_here();
/* 41*/ 		if( Accounting_report_unused ){
/* 42*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 36, Accounting_0err_entry_get, 7) = 0;
/* 44*/ 		} else {
/* 44*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 36, Accounting_0err_entry_get, 8) = 100;
/* 46*/ 		}
/* 46*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 16, Accounting_0err_entry_get, 9) = Scanner_here();
/* 47*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 20, Accounting_0err_entry_get, 10) = Accounting_value;
/* 48*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_consts, 4, 1, Accounting_0err_entry_get, 11) = Accounting_c;
/* 49*/ 		if( (Globals_scope > 0) ){
/* 50*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"define() inside a function:", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)" still constants have global scope;", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\74,\0,\0,\0)" this constant will exists only if the function is executed;", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\64,\0,\0,\0)" if the function is called once more, PHP will raise", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\61,\0,\0,\0)" a notice and the define() itself will be ignored", 1));
/* 57*/ 		}
/* 57*/ 	} else {
/* 57*/ 		if( (RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 12) != NULL ){
/* 58*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"constant `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"' already declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 13)), 1));
/* 61*/ 		} else {
/* 61*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\12,\0,\0,\0)"constant `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"' declared after use in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 16, Accounting_0err_entry_get, 14)), 1));
/* 65*/ 		}
/* 65*/ 	}
/* 65*/ 	return Accounting_c;
/* 69*/ }


/* 70*/ RECORD *
/* 70*/ Accounting_AccountConstRHS(STRING *Accounting_name)
/* 70*/ {
/* 72*/ 	RECORD * Accounting_c = NULL;
/* 72*/ 	Accounting_c = Search_SearchConst(Accounting_name);
/* 73*/ 	if( Accounting_c == NULL ){
/* 74*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\25,\0,\0,\0)"undeclared constant `", Accounting_name, m2runtime_CHR(39), 1));
/* 75*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 8, Accounting_0err_entry_get, 15) = Accounting_name;
/* 76*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 12, Accounting_0err_entry_get, 16) = NULL;
/* 77*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 36, Accounting_0err_entry_get, 17) = 1;
/* 78*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 16, Accounting_0err_entry_get, 18) = Scanner_here();
/* 79*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 20, Accounting_0err_entry_get, 19) = NULL;
/* 80*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_consts, 4, 1, Accounting_0err_entry_get, 20) = Accounting_c;
/* 82*/ 	} else {
/* 82*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_c, 32, Accounting_0err_entry_get, 21) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 22) != NULL) && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 23), 8, Accounting_0err_entry_get, 24)) != 0)) ){
/* 83*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"access forbidden to private constant `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 25)), 1));
/* 86*/ 		}
/* 86*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 28, Accounting_0err_entry_get, 26), EMPTY_STRING) > 0 ){
/* 87*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"using deprecated constant `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 28, Accounting_0err_entry_get, 27), 1));
/* 90*/ 		}
/* 90*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 36, Accounting_0err_entry_get, 28), 1);
/* 91*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_c, 40, 6, 16, Accounting_0err_entry_get, 29) = Scanner_here();
/* 92*/ 		Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_c, 12, Accounting_0err_entry_get, 30));
/* 94*/ 	}
/* 94*/ 	return Accounting_c;
/* 98*/ }


/*103*/ void
/*103*/ Accounting_AccountGlobalVar(STRING *Accounting_name)
/*103*/ {
/*105*/ 	RECORD * Accounting_g = NULL;
/*105*/ 	RECORD * Accounting_v = NULL;
/*105*/ 	Accounting_v = Search_SearchVar(Accounting_name, Globals_scope);
/*106*/ 	if( Accounting_v == NULL ){
/*108*/ 		Accounting_g = Search_SearchVar(Accounting_name, 0);
/*109*/ 		if( Accounting_g == NULL ){
/*110*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)"global `$", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\54,\0,\0,\0)"': variable still not found in global scope.", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\71,\0,\0,\0)" Hint: declare this variable in global scope assigning it", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\11,\0,\0,\0)" a value.", 1));
/*114*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 20, Accounting_0err_entry_get, 31) = NULL;
/*115*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 36, Accounting_0err_entry_get, 32) = FALSE;
/*117*/ 		} else {
/*117*/ 			if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_g, 36, Accounting_0err_entry_get, 33) && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_g, 12, Accounting_0err_entry_get, 34), 8, Accounting_0err_entry_get, 35)) != 0)) ){
/*118*/ 				Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"access forbidden to private variable `$", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_g, 12, Accounting_0err_entry_get, 36)), 1));
/*121*/ 			}
/*121*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 20, Accounting_0err_entry_get, 37) = (RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_g, 20, Accounting_0err_entry_get, 38);
/*122*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 36, Accounting_0err_entry_get, 39) =  *(int *)m2runtime_dereference_rhs_RECORD(Accounting_g, 36, Accounting_0err_entry_get, 40);
/*124*/ 		}
/*124*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 8, Accounting_0err_entry_get, 41) = Accounting_name;
/*125*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 12, Accounting_0err_entry_get, 42) = Scanner_here();
/*126*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 40, Accounting_0err_entry_get, 43) = Globals_scope;
/*127*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 44, Accounting_0err_entry_get, 44) = TRUE;
/*128*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 16, Accounting_0err_entry_get, 45) = NULL;
/*129*/ 		if( Accounting_report_unused ){
/*130*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 46) = 0;
/*132*/ 		} else {
/*132*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 47) = 100;
/*134*/ 		}
/*134*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Globals_vars_n, Accounting_0err_entry_get, 48) = Accounting_v;
/*135*/ 		m2_inc(&Globals_vars_n, 1);
/*136*/ 	} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_v, 40, Accounting_0err_entry_get, 49) == -1) ){
/*137*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"global $", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\40,\0,\0,\0)": this variable is a superglobal", 1));
/*139*/ 	} else {
/*139*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\10,\0,\0,\0)"global $", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)": declaration shadows local variable ", (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\45,\0,\0,\0)"or formal argument with the same name", 1));
/*143*/ 	}
/*145*/ }


/*146*/ void
/*146*/ Accounting_AccountVarLHS2(RECORD *Accounting_v)
/*146*/ {
/*148*/ 	RECORD * Accounting_g = NULL;
/*148*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_v, 36, Accounting_0err_entry_get, 50) && ((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 51) != NULL) && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 52), 8, Accounting_0err_entry_get, 53)) != 0)) ){
/*149*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"access forbidden to private variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 54), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 55)), 1));
/*153*/ 	}
/*153*/ 	*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 16, Accounting_0err_entry_get, 56) = Scanner_here();
/*155*/ 	Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 57));
/*157*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Accounting_v, 44, Accounting_0err_entry_get, 58) ){
/*158*/ 		Accounting_g = Search_SearchVar((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 59), 0);
/*159*/ 		if( Accounting_g != NULL ){
/*160*/ 			*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_g, 52, 7, 16, Accounting_0err_entry_get, 60) = Scanner_here();
/*161*/ 			Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_g, 12, Accounting_0err_entry_get, 61));
/*164*/ 		}
/*165*/ 	}
/*165*/ 	if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 32, Accounting_0err_entry_get, 62), EMPTY_STRING) > 0 ){
/*166*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using deprecated variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 63), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 32, Accounting_0err_entry_get, 64), 1));
/*173*/ 	}
/*173*/ 	if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 65), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this") != 0 ){
/*175*/ 		return ;
/*176*/ 	}
/*176*/ 	if( Globals_curr_method == NULL ){
/*177*/ 		Scanner_Warning((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\76,\0,\0,\0)"using of the variable name `$this' outside of any class method");
/*178*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 56, Accounting_0err_entry_get, 66) ){
/*179*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"using variable `$this' inside static method `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 8, Accounting_0err_entry_get, 67), m2runtime_CHR(39), 1));
/*182*/ 	} else {
/*182*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\37,\0,\0,\0)"assignment forbidden to `$this'");
/*186*/ 	}
/*188*/ }


/*192*/ void
/*192*/ Accounting_AccountVarRHS2(RECORD *Accounting_v)
/*192*/ {
/*194*/ 	RECORD * Accounting_g = NULL;
/*194*/ 	m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 68), 1);
/*195*/ 	Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 69));
/*196*/ 	if(  *(int *)m2runtime_dereference_rhs_RECORD(Accounting_v, 44, Accounting_0err_entry_get, 70) ){
/*197*/ 		Accounting_g = Search_SearchVar((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 71), 0);
/*198*/ 		if( Accounting_g != NULL ){
/*199*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_g, 52, 7, 48, Accounting_0err_entry_get, 72), 1);
/*200*/ 			Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_g, 12, Accounting_0err_entry_get, 73));
/*203*/ 		}
/*204*/ 	}
/*204*/ 	if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_v, 36, Accounting_0err_entry_get, 74) && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 75), 8, Accounting_0err_entry_get, 76)) != 0)) ){
/*205*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\47,\0,\0,\0)"access forbidden to private variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 77), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 78)), 1));
/*209*/ 	}
/*209*/ 	if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 32, Accounting_0err_entry_get, 79), EMPTY_STRING) > 0 ){
/*210*/ 		Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\34,\0,\0,\0)"using deprecated variable `$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 80), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 32, Accounting_0err_entry_get, 81), 1));
/*217*/ 	}
/*217*/ 	if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_v, 8, Accounting_0err_entry_get, 82), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\4,\0,\0,\0)"this") != 0 ){
/*219*/ 		return ;
/*220*/ 	}
/*220*/ 	if( Globals_curr_method == NULL ){
/*221*/ 		Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\62,\0,\0,\0)"using variable `$this' outside of any class method");
/*222*/ 	} else if(  *(int *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 56, Accounting_0err_entry_get, 83) ){
/*223*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\55,\0,\0,\0)"using variable `$this' inside static method `", (STRING *)m2runtime_dereference_rhs_RECORD(Globals_curr_method, 8, Accounting_0err_entry_get, 84), m2runtime_CHR(39), 1));
/*227*/ 	}
/*229*/ }


/*234*/ void
/*234*/ Accounting_AccountVarRHS(STRING *Accounting_name)
/*234*/ {
/*236*/ 	RECORD * Accounting_v = NULL;
/*236*/ 	Accounting_v = Search_SearchVar(Accounting_name, Globals_scope);
/*237*/ 	if( Accounting_v == NULL ){
/*238*/ 		Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\13,\0,\0,\0)"variable `$", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"' has not been assigned", 1));
/*239*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 8, Accounting_0err_entry_get, 85) = Accounting_name;
/*240*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 36, Accounting_0err_entry_get, 86) = FALSE;
/*241*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 12, Accounting_0err_entry_get, 87) = Scanner_here();
/*242*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 40, Accounting_0err_entry_get, 88) = Globals_scope;
/*243*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 44, Accounting_0err_entry_get, 89) = FALSE;
/*244*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 16, Accounting_0err_entry_get, 90) = NULL;
/*245*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 91) = 0;
/*246*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Globals_vars_n, Accounting_0err_entry_get, 92) = Accounting_v;
/*247*/ 		m2_inc(&Globals_vars_n, 1);
/*249*/ 	}
/*249*/ 	Accounting_AccountVarRHS2(Accounting_v);
/*253*/ }


/*258*/ void
/*258*/ Accounting_AccountVarLHS(STRING *Accounting_name, int Accounting_private)
/*258*/ {
/*260*/ 	RECORD * Accounting_v = NULL;
/*260*/ 	Accounting_v = Search_SearchVar(Accounting_name, Globals_scope);
/*261*/ 	if( Accounting_v == NULL ){
/*262*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 8, Accounting_0err_entry_get, 93) = Accounting_name;
/*263*/ 		if( (Accounting_private && ((Globals_scope > 0))) ){
/*264*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"unuseful `private' qualifier for local variable");
/*265*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 36, Accounting_0err_entry_get, 94) = FALSE;
/*267*/ 		} else {
/*267*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 36, Accounting_0err_entry_get, 95) = Accounting_private;
/*269*/ 		}
/*269*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 12, Accounting_0err_entry_get, 96) = Scanner_here();
/*270*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 40, Accounting_0err_entry_get, 97) = Globals_scope;
/*271*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 44, Accounting_0err_entry_get, 98) = FALSE;
/*272*/ 		if( Accounting_report_unused ){
/*273*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 99) = 0;
/*275*/ 		} else {
/*275*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_v, 52, 7, 48, Accounting_0err_entry_get, 100) = 100;
/*277*/ 		}
/*277*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY(&Globals_vars, 4, 1, Globals_vars_n, Accounting_0err_entry_get, 101) = Accounting_v;
/*278*/ 		m2_inc(&Globals_vars_n, 1);
/*279*/ 	} else if( Accounting_private ){
/*280*/ 		if( (Globals_scope == 0) ){
/*281*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\77,\0,\0,\0)"invalid `private' qualifier: variable already set as public in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_v, 12, Accounting_0err_entry_get, 102)), 1));
/*283*/ 		} else {
/*283*/ 			Scanner_Error((STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\57,\0,\0,\0)"unuseful `private' qualifier for local variable");
/*286*/ 		}
/*286*/ 	}
/*286*/ 	Accounting_AccountVarLHS2(Accounting_v);
/*290*/ }


/*291*/ RECORD *
/*291*/ Accounting_AccountFuncCall(STRING *Accounting_name)
/*291*/ {
/*293*/ 	RECORD * Accounting_f = NULL;
/*293*/ 	Accounting_f = Search_SearchFunc(Accounting_name, TRUE);
/*294*/ 	if( Accounting_f == NULL ){
/*295*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 8, Accounting_0err_entry_get, 103) = Accounting_name;
/*296*/ 		*(STRING **)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 12, Accounting_0err_entry_get, 104) = str_toupper(Accounting_name);
/*297*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 16, Accounting_0err_entry_get, 105) = NULL;
/*298*/ 		*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 56, Accounting_0err_entry_get, 106) = 1;
/*299*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 24, Accounting_0err_entry_get, 107) = Scanner_here();
/*300*/ 		*(RECORD **)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 28, Accounting_0err_entry_get, 108) = NULL;
/*301*/ 		*(RECORD **)m2runtime_dereference_lhs_ARRAY_next(&Globals_funcs, 4, 1, Accounting_0err_entry_get, 109) = Accounting_f;
/*303*/ 	} else {
/*303*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_f, 52, Accounting_0err_entry_get, 110) && (m2runtime_strcmp(Scanner_fn, (STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_f, 16, Accounting_0err_entry_get, 111), 8, Accounting_0err_entry_get, 112)) != 0)) ){
/*304*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\46,\0,\0,\0)"access forbidden to private function `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_f, 16, Accounting_0err_entry_get, 113)), 1));
/*307*/ 		}
/*307*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_f, 44, Accounting_0err_entry_get, 114), EMPTY_STRING) > 0 ){
/*308*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"using deprecated function `", Accounting_name, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_f, 44, Accounting_0err_entry_get, 115), 1));
/*311*/ 		}
/*311*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_f, 64, 10, 56, Accounting_0err_entry_get, 116), 1);
/*312*/ 		Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_f, 16, Accounting_0err_entry_get, 117));
/*314*/ 	}
/*314*/ 	return Accounting_f;
/*318*/ }


/*320*/ void
/*320*/ Accounting_AccountClass(RECORD *Accounting_class)
/*320*/ {
/*320*/ 	if( Accounting_class != Globals_curr_class ){
/*321*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_class, 64, Accounting_0err_entry_get, 118) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_class, 48, Accounting_0err_entry_get, 119), 8, Accounting_0err_entry_get, 120), Scanner_fn) != 0)) ){
/*322*/ 			Scanner_Error(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\43,\0,\0,\0)"access forbidden to private class `", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 8, Accounting_0err_entry_get, 121), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\16,\0,\0,\0)"' declared in ", Scanner_reference((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_class, 48, Accounting_0err_entry_get, 122)), 1));
/*325*/ 		}
/*325*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_class, 92, 13, 88, Accounting_0err_entry_get, 123), 1);
/*326*/ 		Accounting_AccountModule((RECORD *)m2runtime_dereference_rhs_RECORD(Accounting_class, 48, Accounting_0err_entry_get, 124));
/*329*/ 	}
/*331*/ }


/*333*/ void
/*333*/ Accounting_AccountClassConst(RECORD *Accounting_class, RECORD *Accounting_c)
/*333*/ {
/*333*/ 	if( Globals_curr_class == Accounting_class ){
/*334*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_c, 28, Accounting_0err_entry_get, 125) == 0) ){
/*335*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 44, 5, 32, Accounting_0err_entry_get, 126), 1);
/*337*/ 		} else {
/*337*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 44, 5, 36, Accounting_0err_entry_get, 127) = TRUE;
/*340*/ 		}
/*340*/ 	} else {
/*340*/ 		Accounting_AccountClass(Accounting_class);
/*341*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_c, 44, 5, 32, Accounting_0err_entry_get, 128), 1);
/*342*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 24, Accounting_0err_entry_get, 129), EMPTY_STRING) > 0 ){
/*343*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\41,\0,\0,\0)"using deprecated class constant `", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 8, Accounting_0err_entry_get, 130), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 8, Accounting_0err_entry_get, 131), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 24, Accounting_0err_entry_get, 132), 1));
/*345*/ 		} else if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 133), EMPTY_STRING) > 0 ){
/*346*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\26,\0,\0,\0)"using class constant `", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 8, Accounting_0err_entry_get, 134), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)"::", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_c, 8, Accounting_0err_entry_get, 135), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"' from deprecated class: ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 136), 1));
/*350*/ 		}
/*351*/ 	}
/*353*/ }


/*355*/ void
/*355*/ Accounting_AccountClassProperty(RECORD *Accounting_class, RECORD *Accounting_p)
/*355*/ {
/*355*/ 	if( Globals_curr_class == Accounting_class ){
/*356*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_p, 32, Accounting_0err_entry_get, 137) == 0) ){
/*357*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_p, 48, 6, 40, Accounting_0err_entry_get, 138), 1);
/*359*/ 		} else {
/*359*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_p, 48, 6, 44, Accounting_0err_entry_get, 139) = TRUE;
/*362*/ 		}
/*362*/ 	} else {
/*362*/ 		Accounting_AccountClass(Accounting_class);
/*363*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_p, 48, 6, 40, Accounting_0err_entry_get, 140), 1);
/*364*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_p, 28, Accounting_0err_entry_get, 141), EMPTY_STRING) > 0 ){
/*365*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\33,\0,\0,\0)"using deprecated property `", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 8, Accounting_0err_entry_get, 142), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_p, 8, Accounting_0err_entry_get, 143), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"': ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_p, 28, Accounting_0err_entry_get, 144), 1));
/*367*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_p, 36, Accounting_0err_entry_get, 145) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 146), EMPTY_STRING) > 0)) ){
/*368*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\27,\0,\0,\0)"using static property `", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 8, Accounting_0err_entry_get, 147), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\3,\0,\0,\0)"::$", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_p, 8, Accounting_0err_entry_get, 148), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\31,\0,\0,\0)"' from deprecated class: ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 149), 1));
/*372*/ 		}
/*373*/ 	}
/*375*/ }


/*377*/ void
/*377*/ Accounting_AccountClassMethod(RECORD *Accounting_class, RECORD *Accounting_m)
/*377*/ {
/*377*/ 	if( Globals_curr_class == Accounting_class ){
/*378*/ 		if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_m, 52, Accounting_0err_entry_get, 150) == 0) ){
/*379*/ 			m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_m, 76, 9, 64, Accounting_0err_entry_get, 151), 1);
/*381*/ 		} else {
/*381*/ 			*(int *)m2runtime_dereference_lhs_RECORD(&Accounting_m, 76, 9, 68, Accounting_0err_entry_get, 152) = TRUE;
/*384*/ 		}
/*384*/ 	} else {
/*384*/ 		Accounting_AccountClass(Accounting_class);
/*385*/ 		m2_inc((int *)m2runtime_dereference_lhs_RECORD(&Accounting_m, 76, 9, 64, Accounting_0err_entry_get, 153), 1);
/*386*/ 		if( m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_m, 40, Accounting_0err_entry_get, 154), EMPTY_STRING) > 0 ){
/*387*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)"using deprecated method ", Scanner_mn(Accounting_class, Accounting_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\2,\0,\0,\0)": ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_m, 40, Accounting_0err_entry_get, 155), 1));
/*389*/ 		} else if( ( *(int *)m2runtime_dereference_rhs_RECORD(Accounting_m, 56, Accounting_0err_entry_get, 156) && (m2runtime_strcmp((STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 157), EMPTY_STRING) > 0)) ){
/*390*/ 			Scanner_Warning(m2runtime_concat_STRING(0, (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\24,\0,\0,\0)"using static method ", Scanner_mn(Accounting_class, Accounting_m), (STRING *) INTSTR(\0,\0,\0,\0)INTSTR(\30,\0,\0,\0)" from deprecated class: ", (STRING *)m2runtime_dereference_rhs_RECORD(Accounting_class, 56, Accounting_0err_entry_get, 158), 1));
/*394*/ 		}
/*395*/ 	}
/*398*/ }


char * Accounting_0func[] = {
    "AccountModule",
    "AccountConstLHS",
    "AccountConstRHS",
    "AccountGlobalVar",
    "AccountVarLHS2",
    "AccountVarRHS2",
    "AccountVarRHS",
    "AccountVarLHS",
    "AccountFuncCall",
    "AccountClass",
    "AccountClassConst",
    "AccountClassProperty",
    "AccountClassMethod"
};

int Accounting_0err_entry[] = {
    0 /* AccountModule */, 19,
    0 /* AccountModule */, 25,
    0 /* AccountModule */, 25,
    0 /* AccountModule */, 26,
    1 /* AccountConstLHS */, 38,
    1 /* AccountConstLHS */, 39,
    1 /* AccountConstLHS */, 40,
    1 /* AccountConstLHS */, 42,
    1 /* AccountConstLHS */, 44,
    1 /* AccountConstLHS */, 46,
    1 /* AccountConstLHS */, 47,
    1 /* AccountConstLHS */, 48,
    1 /* AccountConstLHS */, 57,
    1 /* AccountConstLHS */, 59,
    1 /* AccountConstLHS */, 62,
    2 /* AccountConstRHS */, 75,
    2 /* AccountConstRHS */, 76,
    2 /* AccountConstRHS */, 77,
    2 /* AccountConstRHS */, 78,
    2 /* AccountConstRHS */, 79,
    2 /* AccountConstRHS */, 80,
    2 /* AccountConstRHS */, 82,
    2 /* AccountConstRHS */, 82,
    2 /* AccountConstRHS */, 82,
    2 /* AccountConstRHS */, 82,
    2 /* AccountConstRHS */, 84,
    2 /* AccountConstRHS */, 86,
    2 /* AccountConstRHS */, 88,
    2 /* AccountConstRHS */, 90,
    2 /* AccountConstRHS */, 91,
    2 /* AccountConstRHS */, 92,
    3 /* AccountGlobalVar */, 114,
    3 /* AccountGlobalVar */, 115,
    3 /* AccountGlobalVar */, 117,
    3 /* AccountGlobalVar */, 117,
    3 /* AccountGlobalVar */, 117,
    3 /* AccountGlobalVar */, 119,
    3 /* AccountGlobalVar */, 121,
    3 /* AccountGlobalVar */, 121,
    3 /* AccountGlobalVar */, 122,
    3 /* AccountGlobalVar */, 122,
    3 /* AccountGlobalVar */, 124,
    3 /* AccountGlobalVar */, 125,
    3 /* AccountGlobalVar */, 126,
    3 /* AccountGlobalVar */, 127,
    3 /* AccountGlobalVar */, 128,
    3 /* AccountGlobalVar */, 130,
    3 /* AccountGlobalVar */, 132,
    3 /* AccountGlobalVar */, 134,
    3 /* AccountGlobalVar */, 136,
    4 /* AccountVarLHS2 */, 148,
    4 /* AccountVarLHS2 */, 148,
    4 /* AccountVarLHS2 */, 148,
    4 /* AccountVarLHS2 */, 148,
    4 /* AccountVarLHS2 */, 149,
    4 /* AccountVarLHS2 */, 150,
    4 /* AccountVarLHS2 */, 153,
    4 /* AccountVarLHS2 */, 155,
    4 /* AccountVarLHS2 */, 157,
    4 /* AccountVarLHS2 */, 158,
    4 /* AccountVarLHS2 */, 160,
    4 /* AccountVarLHS2 */, 161,
    4 /* AccountVarLHS2 */, 165,
    4 /* AccountVarLHS2 */, 166,
    4 /* AccountVarLHS2 */, 167,
    4 /* AccountVarLHS2 */, 173,
    4 /* AccountVarLHS2 */, 178,
    4 /* AccountVarLHS2 */, 180,
    5 /* AccountVarRHS2 */, 194,
    5 /* AccountVarRHS2 */, 195,
    5 /* AccountVarRHS2 */, 196,
    5 /* AccountVarRHS2 */, 197,
    5 /* AccountVarRHS2 */, 199,
    5 /* AccountVarRHS2 */, 200,
    5 /* AccountVarRHS2 */, 204,
    5 /* AccountVarRHS2 */, 204,
    5 /* AccountVarRHS2 */, 204,
    5 /* AccountVarRHS2 */, 205,
    5 /* AccountVarRHS2 */, 206,
    5 /* AccountVarRHS2 */, 209,
    5 /* AccountVarRHS2 */, 210,
    5 /* AccountVarRHS2 */, 211,
    5 /* AccountVarRHS2 */, 217,
    5 /* AccountVarRHS2 */, 222,
    5 /* AccountVarRHS2 */, 224,
    6 /* AccountVarRHS */, 239,
    6 /* AccountVarRHS */, 240,
    6 /* AccountVarRHS */, 241,
    6 /* AccountVarRHS */, 242,
    6 /* AccountVarRHS */, 243,
    6 /* AccountVarRHS */, 244,
    6 /* AccountVarRHS */, 245,
    6 /* AccountVarRHS */, 246,
    7 /* AccountVarLHS */, 262,
    7 /* AccountVarLHS */, 265,
    7 /* AccountVarLHS */, 267,
    7 /* AccountVarLHS */, 269,
    7 /* AccountVarLHS */, 270,
    7 /* AccountVarLHS */, 271,
    7 /* AccountVarLHS */, 273,
    7 /* AccountVarLHS */, 275,
    7 /* AccountVarLHS */, 277,
    7 /* AccountVarLHS */, 281,
    8 /* AccountFuncCall */, 295,
    8 /* AccountFuncCall */, 296,
    8 /* AccountFuncCall */, 297,
    8 /* AccountFuncCall */, 298,
    8 /* AccountFuncCall */, 299,
    8 /* AccountFuncCall */, 300,
    8 /* AccountFuncCall */, 301,
    8 /* AccountFuncCall */, 303,
    8 /* AccountFuncCall */, 303,
    8 /* AccountFuncCall */, 303,
    8 /* AccountFuncCall */, 305,
    8 /* AccountFuncCall */, 307,
    8 /* AccountFuncCall */, 309,
    8 /* AccountFuncCall */, 311,
    8 /* AccountFuncCall */, 312,
    9 /* AccountClass */, 321,
    9 /* AccountClass */, 321,
    9 /* AccountClass */, 321,
    9 /* AccountClass */, 322,
    9 /* AccountClass */, 323,
    9 /* AccountClass */, 325,
    9 /* AccountClass */, 326,
    10 /* AccountClassConst */, 334,
    10 /* AccountClassConst */, 335,
    10 /* AccountClassConst */, 337,
    10 /* AccountClassConst */, 341,
    10 /* AccountClassConst */, 342,
    10 /* AccountClassConst */, 343,
    10 /* AccountClassConst */, 344,
    10 /* AccountClassConst */, 344,
    10 /* AccountClassConst */, 345,
    10 /* AccountClassConst */, 346,
    10 /* AccountClassConst */, 347,
    10 /* AccountClassConst */, 347,
    11 /* AccountClassProperty */, 356,
    11 /* AccountClassProperty */, 357,
    11 /* AccountClassProperty */, 359,
    11 /* AccountClassProperty */, 363,
    11 /* AccountClassProperty */, 364,
    11 /* AccountClassProperty */, 365,
    11 /* AccountClassProperty */, 366,
    11 /* AccountClassProperty */, 366,
    11 /* AccountClassProperty */, 367,
    11 /* AccountClassProperty */, 367,
    11 /* AccountClassProperty */, 368,
    11 /* AccountClassProperty */, 369,
    11 /* AccountClassProperty */, 369,
    12 /* AccountClassMethod */, 378,
    12 /* AccountClassMethod */, 379,
    12 /* AccountClassMethod */, 381,
    12 /* AccountClassMethod */, 385,
    12 /* AccountClassMethod */, 386,
    12 /* AccountClassMethod */, 388,
    12 /* AccountClassMethod */, 389,
    12 /* AccountClassMethod */, 389,
    12 /* AccountClassMethod */, 391
};

void Accounting_0err_entry_get(int i, char **m, char **f, int *l)
{
    *m = "Accounting";
    *f = Accounting_0func[ Accounting_0err_entry[2*i] ];
    *l = Accounting_0err_entry[2*i + 1];
}
