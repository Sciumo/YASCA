PHPLint pure-C version intallation
==================================

This package contains the PHPLint executable program tested on
Microsoft Windows Vista.

The original M2 source of PHPLint was translated to C code
using the M2 cross-compiler and  then compiled in binary executable
code using MinGW (www.mingw.org).

The resulting executable program is src\phplint.exe.

You may use that program directly, but two other useful utility
are also provided:

phpl.bat is a simple batch file that set some common options and
then displays the PHPLint result in a window of Notepad:

C:\> phpl myprogram.php

You may also generate the HTML document about the source adding the
--doc option:


C:\> phpl --doc myprogram.php

that will generate the file myprogram.html.

The second utility is phplint.tcl. To launch this program you will
need to install first the Tcl/Tk interpreter (www.tcl.tk). This
latter program offers a simple but powerful graphical user interface.

For more info, all the available documentation is under doc/.
Beginners of PHPLint should start reading the tutorial first,
then the reference manual for more details.
Please visit http://www.icosaedro.it/phplint/ to check for updates.

- Umberto Salsi <phplint@icosaedro.it>
