cppcheck-htmlreport

This is a little utility to generate a html report of a xml file produced by
cppcheck.

The utility is implemented in python and require the pygments module to be
able to generate syntax highlighted source code.
